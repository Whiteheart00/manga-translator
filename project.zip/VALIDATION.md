# Marked-name-only option validation

- `gradle --offline testDebugUnitTest assembleDebug --no-daemon`: **BUILD SUCCESSFUL**.
- Full suite: **192 tests, 0 failures, 0 errors, 0 skipped**, across 28 suites.
- All 27 previous name-filter tests pass. Twelve new tests cover the exact marker
  set, mandatory suffix, all positions, non-qualifying punctuation, whitespace,
  unlisted names, word/possessive boundaries, case/Unicode/multiword names,
  strict-mode independence, flag precedence, matcher cache scope changes, marked
  name-list entries, repeated labels and literal regex characters.
- Debug APK signature verified using Android apksigner (v2).
- Only four production Kotlin files changed: NameFilter, TranslatorSettings,
  MainActivity and the LiveSubtitle filter call. No provider, capture, voice or
  replay-engine changes; no new dependencies or permissions.
- Existing scope preferences remain the defaults on update. The third scope is
  opt-in. Physical UI persistence/playback has not been tested in this workspace.

Examples and phone acceptance checks: NAME_MARKED_ONLY.md.
validation/android-build.log is the current build log. Prior voice-model metrics
are inherited verification, not a new test of this name-filter option.
Build tools: Gradle 8.9, Android SDK/build-tools 34, Kotlin plugin 1.9.24, JDK 21
with Java/Kotlin target 17.
