# Current live-subtitle verification

- Android build: `gradle --offline testDebugUnitTest assembleDebug --no-daemon`
  **BUILD SUCCESSFUL**.
- Full JVM suite: **144 tests, 0 failures, 0 errors, 0 skipped** in
  23 suites. This includes the existing short-speech tests and 19 new
  live-speech/typewriter/early-part/prefetch tests.
- Debug APK signature verified using Android apksigner (v2 signature).
- ADB currently reports no attached device or emulator. Playback in an actual game
  and end-to-end latency are **not verified**; no timing improvement is claimed as
  a measured phone result. Phone checks: LIVE_SUBTITLE_FIX.md.
- `validation/android-build.log` is the latest full build log. JDK 21 targets
  Java/Kotlin bytecode 17; Android API 34, Gradle 8.9, Kotlin plugin 1.9.24.

The files in validation/voice-model-results.json and the tools/verify_short_speech.py
check are inherited from the previous short-speech fix. The model/encoder/synthesis
code is byte-for-byte unchanged in this update. Earlier model signal checks are
not new live-game tests.

Google, OCR, capture cadence, selected speech speed, and model weights are unchanged.
The queue retains real pending lines. Successful callbacks and watchdog recovery
no longer automatically replay completed/possibly completed speech. Explicit
errors may retry once while a source subtitle remains visible.
