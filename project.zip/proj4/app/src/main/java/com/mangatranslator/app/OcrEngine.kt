package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/** یەک ناوچەی دەق (بابلی قسە) لەسەر وێنەی گیراو. rect بە پیکسێلی وێنەکەیە. */
data class TextBox(
    val rect: Rect,
    val text: String,
    /** true = `text` پێشتر سۆرانییە (Gemini خوێندییەوە و وەریگێڕا)، پێویست بە وەرگێڕانی دووبارە نییە */
    val translated: Boolean = false,
    /** ڕەنگی باگراوندی ڕەسەنی بابلەکە (ARGB)؛ 0 = نەزانراو. بۆ نووسینی وەرگێڕان بەهەمان ڕەنگ وەک Google */
    val bg: Int = 0,
    /** true = دەقەکە خۆی کوردییە: لەسەر شاشە ناکێشرێتەوە (وەک خۆی دەمێنێتەوە)، تەنها دەخوێنرێتەوە */
    val native: Boolean = false
)

/**
 * OCR ئۆفلاین: ئینگلیزی/لاتین، چینی، جاپانی، کۆری بە Google ML Kit، و عەرەبی (و جاپانیی ستوونی وەک یەدەگ) بە Tesseract.
 * `lang()` یەکێکە لە SourceLangs.codes. لە دۆخی "auto" هەموو ML Kit ـەکان تاقی دەکرێنەوە و زمانی
 * دۆزراوە بۆ پەڕەکانی دواتر دەهێڵرێتەوە (تا پەڕەیەک بێ دەق بێت).
 * دەرەنجامەکان لەسەر main thread دەگەڕێنەوە.
 */
class OcrEngine(
    private val ctx: Context,
    private val lang: () -> String = { "auto" },
    private val onNotice: (String) -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()

    /** کلیلی Gemini و دۆخی خێرا؛ ئەگەر کلیل هەبێت عەرەبی بە Gemini دەخوێنرێتەوە (Tesseract زۆر خراپە بۆ مانگای عەرەبی) */
    var geminiKey: () -> String = { "" }
    var geminiFast: () -> Boolean = { true }
    /** true = Tesseract بپەڕێنە و Gemini بەکاربهێنە (مۆبایلی ئاست نزم + کلیلی Gemini، لە ڕێکخستنەکان دەگۆڕدرێت) */
    var skipLocalOcr: () -> Boolean = { false }

    // ناسێنەرەکان تەنها کاتێک دروست دەبن کە پێویست بن، و لە ڕامی کەمدا دەتوانرێن ئازاد بکرێن (trimModels)
    private val recLock = Any()
    /** ژمارەی داواکارییە کارکردووەکانی ML Kit؛ تا سفر نەبێت ناسێنەرەکان داناخرێن */
    private val inFlight = java.util.concurrent.atomic.AtomicInteger(0)
    private val recs = HashMap<String, TextRecognizer>()

    private fun recognizerFor(code: String): TextRecognizer = synchronized(recLock) {
        val key = when (code) { "ja", "ko", "zh", "hi" -> code; else -> "en" }
        recs.getOrPut(key) {
            when (key) {
                "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
                "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                "hi" -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            }
        }
    }

    /** هەموو ناسێنەرەکانی ML Kit دادەخات و ڕامەکەیان ئازاد دەکات؛ دواتر خۆکارانە دووبارە دروست دەبنەوە */
    fun trimModels(keep: String? = null) {
        if (inFlight.get() > 0) return
        val drop = synchronized(recLock) {
            val gone = recs.filterKeys { it != keep }
            gone.keys.forEach { recs.remove(it) }
            gone.values.toList()
        }
        for (r in drop) try { r.close() } catch (_: Throwable) {}
    }

    /** زمانی دۆزراوە لە دۆخی auto (بۆ خێرایی پەڕەکانی دواتر) */
    @Volatile private var detected: String? = null

    fun recognize(bitmap: Bitmap, onPartial: ((List<TextBox>) -> Unit)? = null, allowAccessibility: Boolean = true, done: (List<TextBox>) -> Unit) {
        // ڕەنگی باگراوند پێش ئەوەی بانگکەر bitmap ـەکە recycle بکات هەڵدەگیرێت
        val onDone: (List<TextBox>) -> Unit = { boxes -> done(boxes.map { b -> if (b.bg != 0) b else b.copy(bg = BgSampler.sample(bitmap, b.rect)) }) }
        val chosen = lang()
        when (chosen) {
            "ar" -> {
                val key = geminiKey()
                if (key.isBlank()) recognizeTess(bitmap, TessOcr.ARA, onDone)
                else if (onPartial != null) recognizeGeminiStream(bitmap, key, onPartial) { boxes ->
                    if (boxes != null) onDone(boxes) else recognizeTess(bitmap, TessOcr.ARA, onDone)
                }
                else recognizeGemini(bitmap, key) { boxes ->
                    // Gemini شکستی هێنا (ئینتەرنێت، quota…) ← Tesseract وەک یەدەگ
                    if (boxes != null) onDone(boxes) else recognizeTess(bitmap, TessOcr.ARA, onDone)
                }
            }
            // جاپانی: ML Kit یەکەم؛ ئەگەر هیچی نەدۆزییەوە و فایلی jpn_vert دابەزیبوو، Tesseract بۆ نووسینی ستوونی
            "ja" -> runOne("ja", bitmap) { boxes ->
                if (boxes.isNotEmpty() || !JPN_VERT_FALLBACK || !TessOcr.isInstalled(ctx, TessOcr.JPN_VERT)) onDone(boxes)
                else recognizeTess(bitmap, TessOcr.JPN_VERT, onDone)
            }
            "auto" -> {
                // ڕێگای خێرا: دەقی ڕاستەقینەی شاشە لە Accessibility (ئەپ/وێب، هەموو زمانێک، بێ OCR)
                // بۆ مانگا (وێنە) Accessibility زۆرجار تەنها دوگمە/ناونیشانی UI دەدۆزێتەوە و OCR لێدەبڕێت —
                // بۆیە تەنها کاتێک بەکاری دەهێنین کە دەقی بەڕاستی زۆر و درێژ هەبێت.
                val direct = try { if (allowAccessibility) ScreenText.collect(ctx, bitmap.width, bitmap.height) else emptyList() } catch (_: Throwable) { emptyList() }
                Perf.mark("ocr[auto] accessibility: ${direct.size} دەق")
                // دەقی کوردیش «دەقی شیاوە» — پێشتر فڕێدەدرا و OCR ی هێواش (٦-٧ چرکە) دەکەوتە کار
                val goodDirect = direct.filter { TextFilter.worthTranslating(it.text) || TextFilter.isLikelySorani(it.text) }
                val directChars = goodDirect.sumOf { it.text.length }
                val soraniChars = goodDirect.filter { TextFilter.isLikelySorani(it.text) }.sumOf { it.text.length }
                if ((goodDirect.size >= DIRECT_MIN_BOXES && directChars >= DIRECT_MIN_CHARS) ||
                    soraniChars >= DIRECT_MIN_KURDISH_CHARS) {
                    Perf.mark("ocr[auto] ← ڕێگای خێرا بەکارهات (کوردی=$soraniChars پیت، کۆ=$directChars) بێ OCR")
                    onDone(direct)
                    return
                }
                Perf.mark("ocr[auto] ← ڕێگای خێرا نەبوو (شیاو=${goodDirect.size}، پیت=$directChars) ← ML Kit/Tesseract")
                // لاتینی ئەگەر عەرەبی بخوێنێتەوە پیتی شێواو دەدات؛ لێرە بە خۆکار ڕاستی دەکەینەوە
                // هەموو ناسێنەرەکان بە پارالێل؛ هەر بۆکسێک بەپێی پیتەکانی زمانەکەی خۆی
                detect(bitmap) { b ->
                    Perf.mark("ocr[auto] ML Kit detect تەواو: ${b.size} بۆکس")
                    fixMisreadArabic(bitmap, b) { fixed ->
                        Perf.mark("ocr[auto] fixMisreadArabic (Tesseract عەرەبی) تەواو")
                        onDone(fixed)
                    }
                }
            }
            else -> runOne(chosen, bitmap, onDone)
        }
    }

    /**
     * ئەگەر هیچ بۆکسێکی لاتینی وەک "عەرەبیی بە هەڵە خوێندراوە" دەرکەوت، تەواوی شاشە بە Tesseract ی عەرەبی دەخوێنرێتەوە:
     * بۆکسە شێواوەکان دەگۆڕدرێن بە دەقی عەرەبیی ڕاست، و دێڕە عەرەبییەکانی ML Kit نەیدۆزییەوە زیاد دەکرێن.
     */
    private fun fixMisreadArabic(bitmap: Bitmap, boxes: List<TextBox>, onDone: (List<TextBox>) -> Unit) {
        val bad = boxes.filter { TextFilter.looksLikeMisreadScript(it.text) }
        if (bad.isEmpty()) { onDone(boxes); return }
        val key = geminiKey()
        fun viaTesseract() {
            bg.execute {
                val merged: List<TextBox> = try {
                    val ar = TessOcr.recognize(ctx, bitmap, TessOcr.ARA) { msg -> onNotice(msg) }
                        .filter { TextFilter.arabicLetters(it.text) >= 2 }
                    if (ar.isEmpty()) boxes
                    else {
                        // ML Kit ی لاتینی لەسەر دەقی عەرەبی/کوردی پیتی شێواو دەدات (yojyaJ CO2 soi) و هەمیشە "شێواو"ی
                        // دیار نییە؛ ئەگەر Tesseract دەقێکی کوردیی بەهێزی لەو شوێنەدا خوێندەوە، ئەوە دەگرێتەوە جێی.
                        val strong = ar.filter { TextFilter.isLikelySorani(it.text) }
                        val good = boxes.filter { b ->
                            b !in bad && !(TextFilter.arabicLetters(b.text) == 0 &&
                                strong.any { a -> TextFilter.overlapsMostly(a.rect, b.rect) })
                        }
                        val keepAr = ar.filter { a -> good.none { g -> TextFilter.overlapsMostly(a.rect, g.rect) } }
                        val keepBad = bad.filter { b -> ar.none { a -> TextFilter.overlapsMostly(a.rect, b.rect) } }
                        good + keepBad + keepAr
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "Arabic refine failed", t)
                    boxes
                }
                main.post { onDone(merged) }
            }
        }
        // کلیلی Gemini هەبێت: یەکسەر Gemini (خێراتر و دروستتر لە Tesseract ی تەواوی شاشە) — کوردی وەک خۆی دەمێنێتەوە
        if (key.isNotBlank()) {
            Perf.mark("ocr[auto] ${bad.size} بۆکسی شێواو ← Gemini")
            recognizeGemini(bitmap, key) { g ->
                if (g != null && g.isNotEmpty()) onDone(g)
                else if (skipLocalOcr()) onDone(boxes.filter { it !in bad })
                else viaTesseract()
            }
            return
        }
        viaTesseract()
    }

    /**
     * خوێندنەوە + وەرگێڕان بە یەک داواکاری Gemini (بینین): بۆکس و دەقی سۆرانی پێکەوە دەگەڕێنەوە.
     * null = شکستی هێنا. لەسەر main thread دەگەڕێتەوە.
     */
    private fun recognizeGemini(bitmap: Bitmap, key: String, onDone: (List<TextBox>?) -> Unit) {
        bg.execute {
            val boxes: List<TextBox>? = try {
                RegionTranslator.run(bitmap, key, geminiFast())
                    .mapNotNull { it -> it.rect?.let { r -> TextBox(r, it.kurdish, translated = true, native = it.alreadyKurdish) } }
            } catch (t: Throwable) {
                Log.e(TAG, "Gemini vision OCR failed", t)
                null
            }
            main.post { onDone(boxes) }
        }
    }

    /**
     * وەرگێڕانی خۆکار (عەرەبی): هەر بلۆکێک هەر کە Gemini تەواوی کرد، دەستبەجێ دەگەڕێتەوە (onPartial) و لەسەر شاشە دەردەکەوێت،
     * بێ چاوەڕێی وەڵامی تەواو. هیچ ئەنیمەیشنێکی Gemini ی تێدا نییە، تەنها هەمان ئۆڤەرلەی ئاسایی.
     */
    private fun recognizeGeminiStream(
        bitmap: Bitmap, key: String,
        onPartial: (List<TextBox>) -> Unit,
        onDone: (List<TextBox>?) -> Unit
    ) {
        bg.execute {
            val acc = ArrayList<TextBox>()
            val t0 = android.os.SystemClock.elapsedRealtime()
            val ok = try {
                // شاشەکە بە پارچە دابەش دەکرێت و بە پارالێل دەنێردرێت (٣ هێندە خێراتر)
                RegionTranslator.runStripsStream(bitmap, key, geminiFast()) { item ->
                    val r = item.rect
                    if (r != null) {
                        val box = TextBox(r, item.kurdish, translated = true, bg = BgSampler.sample(bitmap, r), native = item.alreadyKurdish)
                        val snap = synchronized(acc) { acc.add(box); ArrayList(acc) }
                        main.post { onPartial(snap) }
                    }
                }
                Log.d(TAG, "Gemini Arabic vision took ${android.os.SystemClock.elapsedRealtime() - t0} ms, ${acc.size} blocks")
                true
            } catch (t: Throwable) {
                Log.e(TAG, "Gemini stream OCR failed", t)
                false
            }
            val result = synchronized(acc) { ArrayList(acc) }
            main.post { onDone(if (ok || result.isNotEmpty()) result else null) }
        }
    }

    private fun recognizeTess(bitmap: Bitmap, tessLang: String, onDone: (List<TextBox>) -> Unit) {
        // Tesseract لە thread ی پاشبنەما؛ bitmap ـەکە تا کۆتایی ئەم کارە ناسڕدرێتەوە چونکە بانگکەر دوای onDone recycle دەکات
        bg.execute {
            val boxes = try {
                TessOcr.recognize(ctx, bitmap, tessLang) { msg -> onNotice(msg) }
            } catch (t: Throwable) {
                Log.e(TAG, "Tesseract failed", t)
                emptyList()
            }
            main.post { onDone(boxes) }
        }
    }

    /**
     * بۆ ڕووبەری زیندوو (ژێرنووسی ڤیدیۆ/یاری): تەنها ML Kit (ئۆفلاین و خێرا) — بێ Accessibility و بێ Gemini.
     * عەرەبی: Tesseract. "auto": زمانی دۆزراوە لەبیر دەکرێت و جاری دواتر یەکەم تاقی دەکرێتەوە.
     * دەقەکان بە ڕیزبەندی (سەرەوە ← خوارەوە، چەپ ← ڕاست) دەبەسترێنەوە. `done` لەسەر main thread بانگ دەکرێت.
     */
    fun recognizeLive(bitmap: Bitmap, done: (String) -> Unit) =
        recognizeLiveBoxes(bitmap) { done(joinBoxes(it)) }

    private fun joinBoxes(b: List<TextBox>) =
        b.sortedWith(compareBy({ it.rect.top }, { it.rect.left })).joinToString(" ") { it.text }.trim()

    /** وەک [recognizeLive] بەڵام بلۆکەکان بە شوێنەوە دەگەڕێنێتەوە (بۆ لادانی واتەرمارک/نووسینی جێگیر). */
    fun recognizeLiveBoxes(bitmap: Bitmap, done: (List<TextBox>) -> Unit) {
        val chosen = lang()
        if (chosen == "ckb" && TranslatorSettings(ctx).localKurdish) {
            // Sorani has its own bundled Tesseract model; keep this path fully offline.
            bg.execute {
                val read = try { LocalKurdishOcr.detectNative(ctx, bitmap, allowMixedSorani = true) } catch (_: Throwable) { null }
                val boxes = read?.words?.map { w ->
                    TextBox(Rect(w.left, w.top, w.right, w.bottom), w.text.trim(), translated = true, native = true)
                }?.filter { it.text.isNotBlank() }.orEmpty().ifEmpty {
                    val text = read?.text.orEmpty().trim()
                    if (text.isBlank()) emptyList() else listOf(TextBox(Rect(0, 0, bitmap.width, bitmap.height), text, translated = true, native = true))
                }
                main.post { done(boxes) }
            }
            return
        }
        if (chosen == "ckb") {
            // Local Kurdish OCR is disabled. LiveSubtitle tries Gemini first when
            // a key is available; without Gemini, do not silently use any OCR.
            main.post { done(emptyList()) }
            return
        }
        if (chosen == "ar") {
            recognizeTess(bitmap, TessOcr.ARA) { done(it) }
            return
        }
        val order = ArrayList<String>()
        if (chosen == "auto") {
            detected?.let { order.add(it) }
            for (c in listOf("en", "ja", "ko", "zh", "hi")) if (c != detected) order.add(c)
        } else {
            order.add(chosen)
        }
        fun step(i: Int) {
            if (i >= order.size) { done(emptyList()); return }
            val c = order[i]
            runOne(c, bitmap) { boxes ->
                val ok = boxes.filter { accepts(c, scriptOf(it.text)) }
                if (ok.isNotEmpty()) {
                    if (chosen == "auto") detected = c
                    done(ok)
                } else step(i + 1)
            }
        }
        step(0)
    }

    /** ڕووبەر: تەنها ML Kit ی ئینگلیزی/لاتینی (کوردی بە LocalKurdishOcr ـی جیا). زمانەکانی تر بە Gemini. */
    fun recognizeEnglishOnly(bitmap: Bitmap, done: (List<TextBox>) -> Unit) {
        runOne("en", bitmap) { boxes -> done(boxes.map { b -> if (b.bg != 0) b else b.copy(bg = BgSampler.sample(bitmap, b.rect)) }) }
    }

    /** Bundled Latin ML Kit only: no Gemini, translation or garbage-script fallback. */
    internal fun recognizeLatinWords(bitmap: Bitmap, done: (List<MixedOcrFilter.Word>) -> Unit) {
        inFlight.incrementAndGet()
        recognizerFor("en").process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                inFlight.decrementAndGet()
                val words = result.textBlocks.flatMap { it.lines }.flatMap { it.elements }.mapNotNull { element ->
                    val rect = element.boundingBox ?: return@mapNotNull null
                    MixedOcrFilter.Word(element.text, rect.left, rect.top, rect.right, rect.bottom,
                        element.confidence.let { if (it.isFinite() && it > 0f) it * 100f else -1f }, latin = true)
                }
                done(words)
            }
            .addOnFailureListener { inFlight.decrementAndGet(); done(emptyList()) }
    }

    /** Tesseract ی عەرەبی/کوردی بۆ ڕووبەر (بێ Gemini). بۆکسەکان وەک کوردیی خۆی دادەنرێن. */
    fun recognizeArabicOnly(bitmap: Bitmap, done: (List<TextBox>) -> Unit) =
        recognizeTess(bitmap, TessOcr.ARA) { boxes ->
            done(boxes.filter { TextFilter.arabicLetters(it.text) >= 2 }
                .map { b -> b.copy(translated = true, native = true, bg = if (b.bg != 0) b.bg else BgSampler.sample(bitmap, b.rect)) })
        }

    private fun runOne(code: String, bitmap: Bitmap, onDone: (List<TextBox>) -> Unit) {
        inFlight.incrementAndGet()
        recognizerFor(code).process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { inFlight.decrementAndGet(); onDone(toBoxes(it, code)) }
            .addOnFailureListener { e -> inFlight.decrementAndGet(); Log.e(TAG, "OCR failed ($code)", e); onDone(emptyList()) }
    }

    private enum class Script { LATIN, KANA, HANGUL, HAN, DEVA, OTHER }

    private fun scriptOf(t: String): Script {
        var la = 0; var ka = 0; var hg = 0; var han = 0; var dv = 0
        for (ch in t) {
            if (!ch.isLetter()) continue
            val c = ch.code
            when {
                c in 0x3040..0x30FF -> ka++
                c in 0xAC00..0xD7AF || c in 0x1100..0x11FF -> hg++
                c in 0x4E00..0x9FFF -> han++
                c in 0x0900..0x097F -> dv++
                c < 0x250 -> la++
            }
        }
        val m = maxOf(la, ka, hg, han, dv)
        if (m == 0) return Script.OTHER
        return when {
            ka == m || (ka > 0 && han > 0 && ka * 4 >= han) -> Script.KANA
            hg == m -> Script.HANGUL
            han == m -> Script.HAN
            dv == m -> Script.DEVA
            else -> Script.LATIN
        }
    }

    /** هەر ناسێنەرێک تەنها ئەو بۆکسانە دەدات کە پیتەکانیان بۆ زمانەکەی خۆیەتی؛ پاشان بێ دووبارەبوونەوە تێکەڵ دەکرێن */
    private fun accepts(code: String, s: Script) = when (code) {
        "en" -> s == Script.LATIN
        // مانگا زۆرجار تەنها کانجی (بێ هیراگانا)ی تێدایە — پێشتر فڕێدەدرا
        "ja" -> s == Script.KANA || s == Script.HAN
        "ko" -> s == Script.HANGUL
        "zh" -> s == Script.HAN
        "hi" -> s == Script.DEVA
        else -> false
    }

    private fun detect(bitmap: Bitmap, onDone: (List<TextBox>) -> Unit) {
        if (DeviceProfile.low) { detectLow(bitmap, onDone); return }
        val codes = listOf("ja", "ko", "zh", "hi", "en")   // لاتینی کۆتایی: ئەگەر لەسەر پیتی تر بێت پیتی شێواو دەدات
        val results = HashMap<String, List<TextBox>>()
        // AtomicInteger: پێشتر var left + --left raceی هەبوو و هەندێک جار onDone هەرگیز بانگ نەدەکرا
        val left = java.util.concurrent.atomic.AtomicInteger(codes.size)
        for (c in codes) {
            runOne(c, bitmap) { boxes ->
                synchronized(results) { results[c] = boxes.filter { accepts(c, scriptOf(it.text)) } }
                if (left.decrementAndGet() == 0) {
                    val merged = ArrayList<TextBox>()
                    for (code in codes) for (b in results[code].orEmpty()) {
                        if (merged.none { TextFilter.overlapsMostly(it.rect, b.rect) }) merged.add(b)
                    }
                    // هیچ پیتێکی لاتینی/CJK/هیندی نەدۆزرایەوە ← لەوانەیە عەرەبی بێت
                    if (merged.isEmpty()) {
                        recognizeTess(bitmap, TessOcr.ARA) { ar -> onDone(ar) }
                    } else onDone(merged)
                }
            }
        }
    }

    /**
     * ڕامی کەم: ناسێنەرەکان یەک لەدوای یەک (نەک ٥ پێکەوە)، و زمانی دۆزراوە بۆ پەڕەکانی دواتر دەهێڵرێتەوە.
     * هەر پەڕەیەک تەنها ١ ناسێنەر بەکاردێنێت؛ ئەگەر هیچی نەدۆزییەوە، ئەوانی تریش تاقی دەکرێنەوە.
     * ناسێنەرە بەکارنەهاتووەکان دادەخرێن تا ڕامەکەیان ئازاد بێت.
     */
    private fun detectLow(bitmap: Bitmap, onDone: (List<TextBox>) -> Unit) {
        val first = detected
        val order = ArrayList<String>()
        if (first != null) order.add(first)
        for (c in listOf("en", "ja", "ko", "zh", "hi")) if (c != first) order.add(c)

        fun step(i: Int) {
            if (i >= order.size) {
                // هیچ پیتێکی لاتینی/CJK/هیندی نەدۆزرایەوە ← لەوانەیە عەرەبی بێت
                detected = null
                recognizeTess(bitmap, TessOcr.ARA) { ar -> onDone(ar) }
                return
            }
            val c = order[i]
            runOne(c, bitmap) { boxes ->
                val ok = boxes.filter { accepts(c, scriptOf(it.text)) }
                if (ok.isNotEmpty()) {
                    if (detected != c) { detected = c; bg.execute { trimModels(keep = c) } }
                    onDone(ok)
                } else step(i + 1)
            }
        }
        step(0)
    }

    private fun toBoxes(result: Text, code: String): List<TextBox> {
        val cjk = code == "ja" || code == "ko" || code == "zh"
        return result.textBlocks.mapNotNull { block ->
            val rect = block.boundingBox ?: return@mapNotNull null
            // لە CJK دا بۆشایی لە نێوان هێڵەکان نییە؛ لە لاتین بۆشایی دەخرێتە نێوان
            val text = if (cjk) block.lines.joinToString("") { it.text }.trim()
            else block.text.replace(HYPHEN_BREAK, "").replace('\n', ' ').trim()
            val ok = if (cjk) text.any { it.isLetterOrDigit() } else text.length >= 2
            if (ok) TextBox(rect, text) else null
        }.also { Log.d(TAG, "OCR($code) found ${it.size} blocks") }
    }

    fun close() {
        trimModels()
        bg.shutdown()
        TessOcr.release()
    }

    companion object {
        private const val TAG = "OcrEngine"
        /** «EXAM-\nPLE» ← «EXAMPLE»: وشەی بە هێڵ بڕاو لەسەر دوو دێڕ (زۆر لە مانگا) پێکەوە دەلکێنرێت، نەک دوو وشەی شێواو */
        private val HYPHEN_BREAK = Regex("(?<=\\p{L})-\\s*\\n\\s*(?=\\p{Ll})")
        /** ئەگەر Accessibility لانیکەم ئەم ژمارە دەقەی دۆزییەوە، OCR نەکرێت (خێراتر) */
        private const val DIRECT_MIN_BOXES = 3
        /** کۆی درێژایی دەق: بۆ مانگا UIی کورت (دوگمە/ناونیشان) OCR لێنەبڕێت */
        private const val DIRECT_MIN_CHARS = 40
        /** ئەگەر Accessibility ئەم ڕێژە پیتە کوردییەی دۆزییەوە، یەکسەر بەکاری دێنین (بێ OCR) */
        private const val DIRECT_MIN_KURDISH_CHARS = 25
        /** ئەگەر false بێت، Tesseract ی jpn_vert هەرگیز بەکارنایەت (ML Kit بەتەنها) */
        private const val JPN_VERT_FALLBACK = true
    }
}
