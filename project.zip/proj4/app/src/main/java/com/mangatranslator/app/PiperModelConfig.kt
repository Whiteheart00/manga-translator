package com.mangatranslator.app

import org.json.JSONObject

/** Keep legacy model tuning while honoring the reference voice's exported contract. */
internal object PiperModelConfig {
    const val REFERENCE_FORMAT = "sorani-reference-vits-v1"

    data class Inference(
        val referenceVoice: Boolean,
        val blankInterleaved: Boolean,
        val useModelTiming: Boolean,
        val noise: Float,
        val length: Float,
        val durationNoise: Float
    )

    fun inference(config: JSONObject): Inference {
        val reference = config.optString("format") == REFERENCE_FORMAT
        val timing = reference || config.optBoolean("use_model_timing", false)
        val inference = config.optJSONObject("inference")
        fun value(name: String, fallback: Float, min: Float, max: Float): Float {
            val raw = inference?.optDouble(name, fallback.toDouble())?.toFloat() ?: fallback
            return if (raw.isFinite() && raw in min..max) raw else fallback
        }
        return Inference(
            referenceVoice = reference,
            blankInterleaved = reference || config.optString("sequence_style", "piper") == "blank_interleaved",
            useModelTiming = timing,
            noise = if (reference) value("noise_scale", 0.3f, 0f, 1f) else 0.4f,
            length = value("length_scale", 1f, 0.5f, 2f) * if (timing) 1f else 1.08f,
            durationNoise = if (reference) value("noise_w", 0.3f, 0f, 1f) else 0.55f
        )
    }
}
