package com.mangatranslator.app

import java.text.Normalizer

/** Normalize OCR typography without guessing words, numbers, units or Kurdish letters. */
internal object KurdishOcrText {
    private val controls = Regex("[\\u061C\\u200C-\\u200F\\u202A-\\u202E\\u2060\\u2066-\\u2069\\uFEFF\\u00AD]")
    private val horizontal = Regex("[\\p{Zs}\\t\\u000B\\f]+")
    private val noiseBars = Regex("[|¦]+")
    private val beforePunctuation = Regex(" +([،؛؟!.,:٫٪%])")
    private val token = Regex("\\S+")

    fun clean(input: String): String {
        val forms = buildString(input.length) {
            for (ch in input) {
                // Restrict compatibility normalization to Arabic presentation forms.
                // Global NFKC would change scientific notation such as Ca²⁺ or x².
                if (ch.code in 0xFB50..0xFDFF || ch.code in 0xFE70..0xFEFE)
                    append(Normalizer.normalize(ch.toString(), Normalizer.Form.NFKC))
                else append(ch)
            }
        }
        val normalized = Normalizer.normalize(forms, Normalizer.Form.NFC)
            .replace('ي', 'ی').replace('ى', 'ی').replace('ك', 'ک')
            .replace("\r\n", "\n").replace('\r', '\n')
            .replace('\u2028', '\n').replace('\u2029', '\n')
            .replace('\u200B', ' ')
            .replace(controls, "")
            .replace("ـ", "") // elongation belongs inside a word; it is not a word boundary
            .replace(noiseBars, " ")
        return normalized.split('\n').joinToString("\n") { line ->
            line.replace(horizontal, " ").replace(beforePunctuation, "$1").trim()
        }.trim()
    }

    /** Apply dictionary correction per token while retaining line breaks and spacing. */
    fun mapWords(text: String, transform: (String) -> String): String =
        token.replace(text) { transform(it.value) }
}
