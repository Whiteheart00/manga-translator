package com.mangatranslator.app

internal object PiperModelChoice {
    val labels = listOf("دەنگی ڕەسەن (خێراتر)", "دەنگی فێرکراوی تۆ (تاقیکاری)")
    fun directory(id: Int) = if (id == 1) "piper_kurdish_trained" else "piper_kurdish"
}
