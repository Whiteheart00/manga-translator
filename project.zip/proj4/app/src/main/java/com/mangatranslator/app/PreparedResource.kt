package com.mangatranslator.app

/** One unclaimed resource, with explicit ownership transfer. Heavy warmup is scheduled,
 * never awaited by take(). The resource must support disposal racing with warmup;
 * PiperTts already serializes native work/close through its synthesis gate.
 */
internal class PreparedResource<T : Any>(private val dispose: (T) -> Unit) {
    private class Entry<T>(val key: String, val value: T) {
        @Volatile var cancelled = false
        var claimed = false // guarded by lock
    }
    private val lock = Any()
    private var entry: Entry<T>? = null

    fun preload(key: String, create: () -> T, warm: (T) -> Unit,
                execute: (() -> Unit) -> Unit): T {
        var stale: Entry<T>? = null
        val next = synchronized(lock) {
            entry?.takeIf { it.key == key }?.let { return it.value }
            stale = entry
            stale?.cancelled = true
            Entry(key, create()).also { entry = it }
        }
        stale?.let { dispose(it.value) }
        try {
            execute {
                val shouldWarm = synchronized(lock) { !next.cancelled && !next.claimed }
                if (shouldWarm) warm(next.value)
            }
        } catch (error: Throwable) {
            expire(next.value)
            throw error
        }
        return next.value
    }

    fun take(key: String, create: () -> T): T {
        val stale = synchronized(lock) {
            entry?.takeIf { it.key == key }?.let {
                it.claimed = true
                entry = null // warmup may still finish; only the consumer now owns this resource
                return it.value
            }
            entry.also { entry = null; it?.cancelled = true }
        }
        stale?.let { dispose(it.value) }
        return create()
    }

    fun expire(value: T) {
        val stale = synchronized(lock) {
            if (entry?.value !== value) return
            entry.also { entry = null; it?.cancelled = true }
        }
        stale?.let { dispose(it.value) }
    }

    fun clear() {
        val stale = synchronized(lock) { entry.also { entry = null; it?.cancelled = true } }
        stale?.let { dispose(it.value) }
    }
}
