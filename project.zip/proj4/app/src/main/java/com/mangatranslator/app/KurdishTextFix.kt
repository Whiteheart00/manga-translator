package com.mangatranslator.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * چاکردنی هەڵە بچووکەکانی دەقی نووسراو (دوای مۆدێلی ئۆفلاینی Vekol) بە Gemini.
 *
 * بۆ ئەوەی خاو نەکاتەوە:
 *  - تەنها دەق دەنێرێت (نە دەنگ) و مۆدێلی خێرا (fast) + بیرکردنەوەی کەمترین ئاست بەکاردێنێت
 *  - کاتی چاوەڕێکردن کورتە (٤ چرکە پەیوەندی، ٧ چرکە وەڵام)
 *  - ئەگەر هەر شتێک هەڵە بوو یان وەڵامەکە گومانلێکراو بوو، null دەگەڕێتەوە و دەقە ئۆفلاینەکە وەک خۆی دەمێنێتەوە
 * لە thread ی پاشبنەما بانگ بکرێت.
 */
object KurdishTextFix {

    private const val PROMPT =
        "You are a proofreader for Central Kurdish (Sorani) text that was produced by a speech-to-text model. " +
            "Fix ONLY small mistakes: wrong or confused letters (ی not ي, ک not ك, ە, ێ, ۆ, ڵ, ڕ, وو), wrongly split or joined words, " +
            "obvious misheard words that are clearly wrong from context, and punctuation (، . ؟). " +
            "Do NOT rephrase, translate, summarize, shorten, extend or explain. Keep the meaning and the word order. " +
            "Keep English words in Latin letters and numbers as digits. " +
            "Personal names (people, places, brands) are NOT mistakes: never replace, translate or correct a name into a common word; keep every name exactly as spelled, in Kurdish script. If the text is already correct, return it unchanged. Return ONLY the corrected text on a single line.\n\nText:\n"

    private const val PROMPT_MANUAL =
        "You are an editor of Central Kurdish (Sorani). The text below was produced by a speech-to-text model and the speaker says it contains mistakes. " +
            "The speaker may be poorly educated and speak colloquially or in a local dialect (Hawleri, Slemani, Garmiyan, Kirkuki...), so non-standard grammar and colloquial or dialect words are NOT mistakes: keep them. " +
            "Fix ONLY: wrong or confused letters (ی not ي, ک not ك, ە, ێ, ۆ, ڵ, ڕ, وو), wrongly split or joined words, words that are clearly misheard or nonsense from context " +
            "(replace them with the word the speaker most likely said, in the speaker's own style), and punctuation (، . ؟). " +
            "Do NOT make the text more formal or literary, do NOT correct the grammar, do NOT translate, summarize, explain or add ideas. Keep English words in Latin letters and numbers as digits. " +
            "Personal names (people, places, brands) are NOT mistakes: never replace, translate or correct a name into a common word; keep every name exactly as spelled, in Kurdish script. Return ONLY the corrected text.\n\nText:\n"

    private const val AR = "Common Arabic/Islamic phrases used in Kurdish speech must be written in their standard spelling, e.g. السلام علیکم، وعلیکم السلام، ئینشائەڵڵا، ماشائەڵڵا، سوپاس، الحمدلله، بسم الله، نەخێر؛ never turn them into unrelated Kurdish words. "

    private const val PROMPT_AUDIO =
        "You are an expert Central Kurdish (Sorani) transcriber. You get (1) the original AUDIO of a person speaking and " +
            "(2) a draft transcript written by a speech-to-text model that may contain mistakes. LISTEN to the audio and use the draft as a hint: " +
            "write what was actually said, word for word, in Arabic script with the correct Sorani letters (ی not ي, ک not ك, ە, ێ, ۆ, ڵ, ڕ, وو) and natural punctuation (، . ؟). " +
            "The speaker may be poorly educated and speak colloquially or in a local dialect, so keep the speaker's own words, dialect and non-standard grammar; never replace them with formal standard words. " +
            "Keep the draft's wording wherever it matches the audio; change only what the audio shows is wrong. " +
            "Personal names, places and brands are NOT mistakes: write them phonetically as heard in Kurdish script, never replace them with common words. " +
            "$AR" +
            "Keep English words in Latin letters and numbers as digits. Do NOT translate, summarize, explain or add anything. " +
            "Return ONLY the final transcript on one line, no comments.\n\nText:\n"

    /**
     * ناوە نزیکەکانی فەرهەنگی ناو (KurdishEntities) وەک ئاماژە دەخاتە ناو ڕێنماییەکەوە.
     * Gemini تەنها کاتێک ناوەکە بەکاردەهێنێت کە وشەکە بە ڕوونی هەڵەنووسینی ئەو ناوە بێت.
     */
    private fun withHints(prompt: String, hints: List<String>): String {
        if (hints.isEmpty()) return prompt
        val head = prompt.substringBefore("\n\nText:\n")
        return head + " Possible proper names from a Kurdish names dictionary (its spellings may be informal): " +
            hints.joinToString("، ") + ". Use one ONLY if a word in the text is clearly a misspelling or mishearing of it, and then write it in correct standard Sorani spelling; " +
            "otherwise ignore this list. Never add a name that is not already in the text.\n\nText:\n"
    }

    /** ناوەکانی بەکارهێنەر: ئەگەر وشەیەک بە دەنگ لەو ناوانە بچێت، بە هەمان نووسین بنووسرێت. */
    private fun withNames(prompt: String, names: List<String>): String {
        if (names.isEmpty()) return prompt
        val head = prompt.substringBefore("\n\nText:\n")
        return head + " The speaker often says these names. Whenever a word in the text sounds like one of them (even if it also resembles a common word), write it with EXACTLY this spelling: " +
            names.joinToString("، ") + ".\n\nText:\n"
    }

    /**
     * چاککردنی دەستی (کاتێک بەکارهێنەر دووگمەی «چاک بکە» دادەگرێت): ئازادترە لە fix() و مۆدێلی بەهێزتر بەکاردێنێت.
     * دەقی چاککراو دەگەڕێنێتەوە (ڕەنگە هەمان دەق بێت)، یان null ئەگەر نەکرا. لە thread ی پاشبنەما بانگ بکرێت.
     */
    fun fixManual(text: String, keysRaw: String, pcm: ByteArray? = null, hints: List<String> = emptyList(), names: List<String> = emptyList()): String? {
        val src = text.trim()
        if (src.isEmpty() || keysRaw.isBlank()) return null
        return try {
            val out = GeminiKeys.withKeys(keysRaw) { key ->
                GeminiModels.call(false) { m, think ->
                    post(
                        body(src, m, false, withNames(withHints(if (pcm != null && pcm.size >= 16000 * 2) PROMPT_AUDIO else PROMPT_MANUAL, hints), names), 1024, pcm),
                        key, m, 10_000, 45_000
                    )
                }
            }.trim().trim('"', '`').trim()
            if (out.isEmpty()) return null
            val ratio = out.length.toFloat() / src.length
            val heard = pcm != null && pcm.size >= 16000 * 2   // بە دەنگەوە دەقە خراپەکە زۆر دەگۆڕێت، بۆیە سنوور فراوانترە
            if (ratio < (if (heard) 0.3f else 0.5f) || ratio > (if (heard) 2.5f else 1.8f)) return null
            // مۆدێل ڕێنمایی خۆی یان لێدوانی ئینگلیزی دەنووسێت (وەک "Keep the original...")؟ ڕەتی بکەرەوە.
            val srcLatin = src.count { it in 'a'..'z' || it in 'A'..'Z' }
            val outLatin = out.count { it in 'a'..'z' || it in 'A'..'Z' }
            if (outLatin - srcLatin > 6) return null
            val a = src.split(Regex("\\s+")).size
            val b = out.split(Regex("\\s+")).size
            if (!heard && b > a * 2 + 3) return null
            out
        } catch (_: Throwable) {
            null
        }
    }

    /** دەقی چاککراو، یان null ئەگەر نەکرا / متمانەی پێ ناکرێت. */
    fun fix(text: String, keysRaw: String, hints: List<String> = emptyList()): String? {
        val src = text.trim()
        if (src.length < 3 || keysRaw.isBlank()) return null
        return try {
            val out = GeminiKeys.withKeys(keysRaw) { key ->
                GeminiModels.call(true) { m, think -> post(body(src, m, think, withHints(PROMPT, hints)), key, m) }
            }
            accept(src, out)
        } catch (_: Throwable) {
            null
        }
    }

    internal fun body(src: String, model: String, think: Boolean, prompt: String = PROMPT, maxTokens: Int = 512, pcm: ByteArray? = null): String {
        val gen = JSONObject().put("temperature", 0).put("maxOutputTokens", maxTokens)
        if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
        return JSONObject()
            // ڕێنمایی لە system_instruction جیا دەکرێتەوە تا مۆدێل تێکەڵی دەقەکە نەکات و نەیگەڕێنێتەوە
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt.substringBefore("\n\nText:\n"))))
            )
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user").put(
                        "parts",
                        JSONArray().apply {
                            if (pcm != null && pcm.size >= 16000 * 2) {
                                put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", Dictation.wavBase64(pcm))))
                            }
                            put(JSONObject().put("text", "Text:\n" + src))
                        }
                    )
                )
            )
            .put("generationConfig", gen)
            .toString()
    }

    /** پاراستن: دەبێت هێشتا هەمان دەق بێت (درێژی و ژمارەی وشە نزیک بێت)، نەک شرۆڤە یان وەرگێڕان. */
    private fun accept(src: String, raw: String): String? {
        val out = raw.trim().trim('"', '`').replace(Regex("\\s+"), " ")
        if (out.isEmpty()) return null
        val ratio = out.length.toFloat() / src.length
        if (ratio < 0.7f || ratio > 1.4f) return null
        val a = src.split(' ').size
        val b = out.split(' ').size
        if (kotlin.math.abs(a - b) > maxOf(2, a * 3 / 10)) return null
        return out
    }

    internal fun post(body: String, key: String, model: String, connectMs: Int = 4_000, readMs: Int = 7_000): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = connectMs
            c.readTimeout = readMs
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try {
                    JSONObject(resp).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    resp
                }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            return try {
                val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").optJSONArray("parts")
                if (parts == null || parts.length() == 0) "" else parts.getJSONObject(0).optString("text", "")
            } catch (_: Exception) {
                throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
            }
        } finally {
            c.disconnect()
        }
    }
}
