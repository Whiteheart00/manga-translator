package com.mangatranslator.app

/** Preserve existing tones; the reference recipe is applied in PCM, not again at playback. */
internal object PiperVoiceProfile {
    data class Preset(val id: Int, val label: String, val pitch: Float,
                      val cutoffHz: Float, val targetRms: Float)
    data class Tuning(val profileId: Int, val pitch: Float, val cutoffHz: Int,
                      val targetRmsPercent: Int, val noisePercent: Int,
                      val lengthPercent: Int, val durationNoisePercent: Int, val endPauseMs: Int)
    private val presets = listOf(
        Preset(0, "دەنگی ڕەسەن", 1f, 7000f, 0.1f),
        Preset(1, "پیاوانەی نەرم", 1f, 5600f, 0.095f),
        Preset(2, "تۆنی ژنانەی نەرم (گۆڕینی دەنگ)", 1.22f, 6000f, 0.095f),
        Preset(3, "نموونەی ئافرەت — ٢١٥ Hz", 1f, 7000f, 0.1f)
    )
    val labels: List<String> = presets.map { it.label }
    fun get(id: Int): Preset = presets.getOrElse(id) { presets[0] }
    fun customized(tuning: Tuning): Preset {
        val base = get(tuning.profileId)
        return base.copy(
            pitch = tuning.pitch,
            cutoffHz = tuning.cutoffHz.toFloat(),
            targetRms = 0.1f * tuning.targetRmsPercent / 100f
        )
    }
    fun cacheKey(speed: Float, lowLatency: Boolean, preset: Preset, text: String, tuning: Tuning? = null) =
        "voice-pcm-v5|${(speed * 100).toInt()}|${if (lowLatency) 1 else 0}|tone=${preset.id}|p=${preset.pitch}|c=${preset.cutoffHz}|r=${preset.targetRms}|tuning=$tuning|$text"
}
