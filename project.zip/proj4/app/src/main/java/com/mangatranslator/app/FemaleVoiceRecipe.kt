package com.mangatranslator.app

import kotlin.math.*

/** Mobile approximation of the 215-Hz audition, not Praat PSOLA or a new speaker.
 * Resampling raises pitch AND formants 4%; WSOLA restores the original duration.
 * Unlike the desktop audition, pitch is not independently reset to 215 Hz per sentence.
 * All processing is per utterance, off the playback thread, without Android dependencies.
 */
internal object FemaleVoiceRecipe {
    const val PROFILE_ID = 3
    const val MODEL_SHA256 = "b4485e8bb28e6b483007c9e64251dee24d09fbfd76a8417fb66ec247b445ea1d"
    const val PITCH_FORMANT_RATIO = 1.04

    fun process(input: FloatArray, rate: Int): FloatArray {
        require(rate >= 8000)
        if (input.isEmpty()) return input.copyOf()
        require(input.all { it.isFinite() })
        if (input.all { abs(it) < 1e-8f }) return input.copyOf()
        val shifted = FloatArray(max(1, (input.size / PITCH_FORMANT_RATIO).roundToInt())) { i ->
            val p = i * PITCH_FORMANT_RATIO
            val a = floor(p).toInt().coerceAtMost(input.lastIndex)
            val b = min(a + 1, input.lastIndex)
            (input[a] + (input[b] - input[a]) * (p - a)).toFloat()
        }
        val y = stretch(shifted, input.size, rate)
        highPass(90.0, 0.70710678, rate).apply(y)
        peakEq(min(4000.0, rate * .4), 1.0, 3.0, rate).apply(y)
        compress(y, rate)
        normalize(y, rate)
        // Avoid clicks at utterance boundaries without touching the natural phrase timing.
        val fade = min(rate / 200, y.size / 2)
        for (i in 0 until fade) {
            val gain = i.toFloat() / fade
            y[i] *= gain
            y[y.lastIndex - i] *= gain
        }
        return y
    }

    /** 40-ms Hann grains, 20-ms hops, normalized overlap-add with ±5-ms correlation search. */
    private fun stretch(x: FloatArray, size: Int, rate: Int): FloatArray {
        val window = max(32, rate * 40 / 1000)
        val hop = window / 2
        val overlap = window - hop
        val search = max(4, rate * 5 / 1000)
        val output = DoubleArray(size + window)
        val weights = DoubleArray(size + window)
        val hann = DoubleArray(window) { i -> .5 - .5 * cos(2 * PI * (i + .5) / window) }
        val stretch = size.toDouble() / x.size
        var out = -hop // pre-roll gives the beginning a fully supported window
        while (out < size) {
            val nominal = (out / stretch).roundToInt()
            var best = nominal
            if (out >= hop && nominal + window < x.size) {
                var bestScore = -Double.MAX_VALUE
                val reference = DoubleArray(overlap) { j ->
                    if (weights[out + j] > 1e-9) output[out + j] / weights[out + j] else 0.0
                }
                val referenceEnergy = reference.sumOf { it * it }
                if (referenceEnergy > 1e-10) {
                    for (candidate in max(0, nominal - search)..min(x.size - window, nominal + search) step 2) {
                        var dot = 0.0; var energy = 0.0
                        for (j in 0 until overlap step 4) {
                            val sample = x[candidate + j].toDouble()
                            dot += reference[j] * sample
                            energy += sample * sample
                        }
                        // Match the already-rendered overlap; favour the nominal position on ties.
                        val score = dot / sqrt(max(1e-20, energy * referenceEnergy / 4)) -
                            .002 * abs(candidate - nominal) / search
                        if (score > bestScore) { bestScore = score; best = candidate }
                    }
                }
            }
            for (j in 0 until window) {
                val dst = out + j; val src = best + j
                if (dst !in 0 until size || src !in x.indices) continue
                output[dst] += x[src] * hann[j]
                weights[dst] += hann[j]
            }
            out += hop
        }
        return FloatArray(size) { i -> if (weights[i] > 1e-9) (output[i] / weights[i]).toFloat() else 0f }
    }

    private class Biquad(val b0: Double, val b1: Double, val b2: Double,
                         val a1: Double, val a2: Double) {
        fun apply(y: FloatArray) {
            var z1 = 0.0; var z2 = 0.0
            for (i in y.indices) {
                val v = y[i].toDouble(); val out = b0 * v + z1
                z1 = b1 * v - a1 * out + z2
                z2 = b2 * v - a2 * out
                y[i] = out.toFloat()
            }
        }
    }

    private fun highPass(hz: Double, q: Double, rate: Int): Biquad {
        val w = 2 * PI * hz / rate; val c = cos(w); val alpha = sin(w) / (2 * q)
        val a0 = 1 + alpha
        return Biquad((1+c)/2/a0, -(1+c)/a0, (1+c)/2/a0, -2*c/a0, (1-alpha)/a0)
    }

    private fun peakEq(hz: Double, q: Double, gainDb: Double, rate: Int): Biquad {
        val a = 10.0.pow(gainDb / 40); val w = 2 * PI * hz / rate
        val alpha = sin(w) / (2*q); val c = cos(w); val a0 = 1 + alpha/a
        return Biquad((1+alpha*a)/a0, -2*c/a0, (1-alpha*a)/a0, -2*c/a0, (1-alpha/a)/a0)
    }

    private fun compress(y: FloatArray, rate: Int) {
        val attack = exp(-1.0 / (.015 * rate)); val release = exp(-1.0 / (.100 * rate))
        var envelope = 0.0
        for (i in y.indices) {
            val level = abs(y[i].toDouble()); val alpha = if (level > envelope) attack else release
            envelope = alpha * envelope + (1-alpha) * level
            // Peak detector, threshold 0.125, ratio 2:1. Not the desktop filter's exact knee.
            val gain = if (envelope > .125) sqrt(.125 / envelope) else 1.0
            y[i] = (y[i] * gain).toFloat()
        }
    }

    /** BS.1770-style K weighting and absolute/relative gates, mono; sample peak limited.
     * Not a certified true-peak limiter. The final exported fixture is checked with FFmpeg.
     */
    internal fun integratedLufs(input: FloatArray, rate: Int): Double {
        if (input.isEmpty()) return Double.NEGATIVE_INFINITY
        val weighted = input.copyOf()
        val k = tan(PI * 1681.974450955533 / rate)
        val vh = 10.0.pow(3.999843853973347 / 20); val vb = vh.pow(.4996667741545416)
        val q = .7071752369554196; val a0 = 1+k/q+k*k
        Biquad((vh+vb*k/q+k*k)/a0, 2*(k*k-vh)/a0, (vh-vb*k/q+k*k)/a0,
            2*(k*k-1)/a0, (1-k/q+k*k)/a0).apply(weighted)
        highPass(38.13547087602444, .5003270373238773, rate).apply(weighted)
        val block = max(1, rate * 4 / 10); val step = max(1, rate / 10)
        val energies = ArrayList<Double>()
        if (weighted.size < block) energies.add(weighted.sumOf { it.toDouble()*it } / weighted.size)
        else for (start in 0..weighted.size-block step step) {
            var sum = 0.0
            for (j in start until start+block) sum += weighted[j].toDouble()*weighted[j]
            energies.add(sum/block)
        }
        val absolute = energies.filter { it > 10.0.pow((-70+.691)/10) }
        if (absolute.isEmpty()) return Double.NEGATIVE_INFINITY
        val relative = absolute.average() * .1
        return -.691 + 10 * log10(absolute.filter { it >= relative }.average())
    }

    private fun normalize(y: FloatArray, rate: Int) {
        val lufs = integratedLufs(y, rate)
        if (!lufs.isFinite()) return
        val peak = y.maxOf { abs(it.toDouble()) }
        val gain = minOf(10.0.pow((-18-lufs)/20), .84/max(peak, 1e-12), 4.0)
        for (i in y.indices) y[i] = (y[i]*gain).toFloat()
    }
}
