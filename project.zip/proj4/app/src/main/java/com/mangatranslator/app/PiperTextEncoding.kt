package com.mangatranslator.app

import java.text.Normalizer

/** Preserve legacy Piper phonemes; exported MMS/VITS models use NFC characters and blanks. */
internal object PiperTextEncoding {
    fun encode(text: String, idMap: Map<String, Long>, blankInterleaved: Boolean,
               referenceVoice: Boolean = false): LongArray? {
        if (referenceVoice) return encodeReference(text, idMap)
        val cleaned = text.replace('ك', 'ک').replace('ي', 'ی').replace('ى', 'ی').replace('ة', 'ە')
            .replace("\u200c", "").replace("\u200d", "").replace("ـ", "")
        val t = Normalizer.normalize(cleaned, if (blankInterleaved) Normalizer.Form.NFC else Normalizer.Form.NFD)
        val pad = idMap["_"] ?: 0L
        val ids = ArrayList<Long>(t.length * 2 + 2)
        ids.add(if (blankInterleaved) pad else idMap["^"] ?: 1L)
        var any = false
        for (ch in t) {
            val id = idMap[ch.toString()] ?: continue
            if (ch == '^' || ch == '$' || ch == '_') continue
            ids.add(id); ids.add(pad)
            if (ch != ' ' && ch != '.' && ch != '!' && ch != '-' && ch != ':') any = true
        }
        if (!blankInterleaved) ids.add(idMap["$"] ?: 2L)
        return if (any) ids.toLongArray() else null
    }

    private fun encodeReference(text: String, idMap: Map<String, Long>): LongArray? {
        val normalized = Normalizer.normalize(text, Normalizer.Form.NFC)
            .replace('ک', 'ك').replace('ي', 'ی').replace('ھ', 'ه')
            .replace('أ', 'ئ').replace('إ', 'ئ')
        val special = setOf('^', '$', '_', '|')
        val cleaned = normalized.map { ch ->
            if (ch !in special && idMap.containsKey(ch.toString())) ch else ' '
        }.joinToString("").replace(Regex("\\s+"), " ").trim()
        if (cleaned.isEmpty()) return null
        val blank = idMap["_"] ?: 0L
        val ids = LongArray(cleaned.length * 2 + 1) { blank }
        cleaned.forEachIndexed { index, ch -> ids[index * 2 + 1] = idMap.getValue(ch.toString()) }
        return ids
    }
}
