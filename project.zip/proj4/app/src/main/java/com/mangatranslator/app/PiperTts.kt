package com.mangatranslator.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.util.concurrent.BlockingQueue
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.ZipInputStream

/** پەیامێک بۆ ڕیزی خوێندنەوە: text == null واتە کۆتایی. */
class SpeechMsg(val text: String?)

/**
 * دەنگی کوردیی نیورالی ئۆفلاین (Piper / VITS بە ONNX، ڕاستەوخۆ بە onnxruntime).
 * مۆدێلەکە (model.onnx + model.onnx.json) پیتی کوردیی سۆرانی ڕاستەوخۆ دەخوێنێتەوە، بێ espeak.
 * مۆدێلەکە لە ڕێکخستنی دەنگ ← «هێنانی مۆدێل» دەهێنرێت و دەکرێتە filesDir/piper_kurdish/.
 */
class PiperTts(private val ctx: Context) {

    @Volatile private var env: OrtEnvironment? = null
    @Volatile private var session: OrtSession? = null
    private var loadedModelIdentity: String? = null
    @Volatile private var idMap: Map<String, Long> = emptyMap()
    @Volatile private var sampleRate = 22050
    // ڕێکخستنی ڕوونی دەنگ (بێ گۆڕینی مۆدێلەکە): noise کەمتر = دەنگی جێگیرتر، length زیاتر = کەمێک هێواشتر.
    // ئەگەر دەنگەکە زۆر «ڕۆبۆت» بوو TUNE_NOISE بەرەو 0.667 بەرز بکەرەوە.
    private val TUNE_NOISE = 0.4f
    private val TUNE_NOISE_W = 0.55f
    private val TUNE_LENGTH = 1.08f
    @Volatile private var noiseScale = TUNE_NOISE
    @Volatile private var lengthScale = 1.0f * TUNE_LENGTH
    @Volatile private var noiseW = TUNE_NOISE_W
    @Volatile private var hasSid = false
    @Volatile private var blankInterleaved = false
    @Volatile private var referenceVoice = false
    @Volatile private var femaleRecipeModel = false
    @Volatile private var useModelTiming = false
    @Volatile private var track: AudioTrack? = null
    @Volatile private var cancelled = false
    @Volatile private var closed = false
    @Volatile private var nativeWarmed = false
    private val synthesisGate = java.util.concurrent.locks.ReentrantLock()
    private val playbackLock = Any()
    private val workGeneration = java.util.concurrent.atomic.AtomicInteger()
    @Volatile var playbackMayHaveStarted = false
        private set

    @Volatile var speaking = false
        private set

    /**
     * دۆخی دواکەوتنی کەم (ژێرنووسی زیندوو): دێڕی کورت هێندە هێواش ناکرێت و وچانی کۆتایی کورتترە،
     * بۆ ئەوەی دەنگەکە لە ئاخێوەری ڕەسەن دوا نەکەوێت.
     */
    @Volatile var lowLatency = false

    // cache ی دەنگی دروستکراو: هەمان ڕستە (دێڕی دووبارەی ژێرنووس، پەیامە جێگیرەکان) دووبارە دروست ناکرێتەوە.
    private val pcmCache = LinkedHashMap<String, FloatArray>(32, 0.75f, true)
    private var cacheFloats = 0

    private fun cacheGet(k: String): FloatArray? = synchronized(pcmCache) { pcmCache[k] }

    private fun cachePut(k: String, v: FloatArray) {
        synchronized(pcmCache) {
            if (v.size > CACHE_MAX_FLOATS / 4) return
            pcmCache.put(k, v)?.let { cacheFloats -= it.size }
            cacheFloats += v.size
            val it = pcmCache.entries.iterator()
            while (cacheFloats > CACHE_MAX_FLOATS && it.hasNext()) {
                val e = it.next()
                cacheFloats -= e.value.size
                it.remove()
            }
        }
    }

    /** پەیام دەگەڕێنێتەوە ئەگەر مۆدێل نەدۆزرایەوە یان بار نەبوو. */
    private fun ensureLoaded(): String? {
        synthesisGate.lockInterruptibly()
        try { return loadLocked() } finally { synthesisGate.unlock() }
    }

    private fun loadLocked(): String? {
        if (closed) return "Piper: engine closed"
        val dir = selectedModelDir(ctx)
        val identity = dir.absolutePath + "#" + modelEpoch.get()
        if (session != null && loadedModelIdentity == identity) return null
        if (session != null) {
            session?.close(); session = null
            nativeWarmed = false
            workGeneration.incrementAndGet()
            synchronized(pcmCache) { pcmCache.clear(); cacheFloats = 0 }
        }
        val onnx = File(dir, MODEL)
        val cfg = File(dir, CONFIG)
        if (!onnx.exists() || !cfg.exists()) {
            return "مۆدێلی کوردیی نیورالی نەهێنراوە. لە ڕێکخستنی دەنگ دوگمەی «هێنانی مۆدێل» دابگرە و فایلی zip ی مۆدێلەکە هەڵبژێرە"
        }
        return try {
            val j = JSONObject(cfg.readText())
            val m = j.getJSONObject("phoneme_id_map")
            val map = HashMap<String, Long>()
            for (k in m.keys()) map[k] = m.getJSONArray(k).getLong(0)
            idMap = map
            val inference = PiperModelConfig.inference(j)
            referenceVoice = inference.referenceVoice
            femaleRecipeModel = referenceVoice && matchesFemaleRecipeModel(onnx)
            blankInterleaved = inference.blankInterleaved
            useModelTiming = inference.useModelTiming
            sampleRate = j.optJSONObject("audio")?.optInt("sample_rate", 22050) ?: 22050
            noiseScale = inference.noise
            lengthScale = inference.length
            noiseW = inference.durationNoise
            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                val threads = if (referenceVoice) {
                    minOf(if (DeviceProfile.low) 2 else 4,
                        Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
                } else if (DeviceProfile.low) 2 else 4
                setIntraOpNumThreads(threads)
                setInterOpNumThreads(1)
                if (DeviceProfile.low) {
                    try { setCPUArenaAllocator(false) } catch (_: Throwable) {}
                    try { setMemoryPatternOptimization(false) } catch (_: Throwable) {}
                }
            }
            val s = try { e.createSession(onnx.absolutePath, opts) } finally { opts.close() }
            hasSid = s.inputNames.contains("sid")
            env = e
            session = s
            loadedModelIdentity = identity
            null
        } catch (e: Throwable) {
            Log.e(TAG, "load failed", e)
            "بارکردنی مۆدێلی کوردی سەرنەکەوت: ${e.message}"
        }
    }

    /** دەقی سۆرانی ← ID ـی پیتەکان (وەک Piper: ^ پیت _ پیت _ ... $). */
    private fun toIds(text: String): LongArray? =
        PiperTextEncoding.encode(text, idMap, blankInterleaved, referenceVoice)

    private fun voiceTuning(settings: TranslatorSettings) = PiperVoiceProfile.Tuning(
        settings.piperVoiceProfile, settings.piperPitch, settings.piperCutoffHz,
        settings.piperTargetRms, settings.piperNoiseScale, settings.piperLengthScale,
        settings.piperNoiseW, settings.piperEndPauseMs
    )

    /** بێدەنگیی سەر و کۆتا دەبڕێت، fade ی کورت دەدات و ئاستی دەنگ یەکسان دەکات؛ endPauseMs = وەستانی دوای ڕستە. */
    private fun polish(x: FloatArray, rate: Int, endPauseMs: Int, profile: PiperVoiceProfile.Preset): FloatArray {
        if (profile.id == FemaleVoiceRecipe.PROFILE_ID) {
            val processed = FemaleVoiceRecipe.process(PiperSpeechTiming.trimEdges(x, rate), rate)
            return processed.copyOf(processed.size + rate * endPauseMs / 1000)
        }
        var peak = 0f
        for (v in x) { val a = Math.abs(v); if (a > peak) peak = a }
        if (peak < 1e-4f) return x
        val th = peak * 0.01f
        var st = 0
        while (st < x.size - 1 && Math.abs(x[st]) < th) st++
        var en = x.size - 1
        while (en > st && Math.abs(x[en]) < th) en--
        val a = maxOf(0, st - (rate * 0.04).toInt())
        val b = minOf(x.size, en + (rate * 0.06).toInt())
        if (b <= a) return x
        val pad = rate * endPauseMs / 1000
        val y = FloatArray(b - a + pad)
        System.arraycopy(x, a, y, 0, b - a)
        val len = b - a
        denoise(y, len, rate, profile.cutoffHz)   // DC و خشەی زیر (hiss) کەم دەکاتەوە
        val fade = minOf((rate * 0.015).toInt(), len / 2)
        for (i in 0 until fade) {
            val g = i / fade.toFloat()
            y[i] *= g
            y[len - 1 - i] *= g
        }
        var sum = 0.0
        var pk = 0f
        for (i in 0 until len) { val v = y[i]; sum += v.toDouble() * v; val q = Math.abs(v); if (q > pk) pk = q }
        val rms = Math.sqrt(sum / len).toFloat()
        if (rms < 1e-5f || pk < 1e-5f) return y
        val g = minOf(profile.targetRms / rms, 0.9f / pk, 2.5f)   // 4x خشەی بێدەنگی بەرز دەکردەوە
        for (i in 0 until len) y[i] *= g
        return y
    }

    /**
     * DC-blocker + دوو فلتەری نەرمی low-pass (~٧kHz): خشە و گزگزەی زیری VITS کەم دەکاتەوە بێ ئەوەی دەنگەکە کپ بکات.
     * تەنها بەشی [0, len) دەگۆڕێت (وەستانی کۆتایی دەست لێنادرێت).
     */
    private fun denoise(y: FloatArray, len: Int, rate: Int, cutoffHz: Float) {
        val r = 0.995f
        var px = 0f
        var py = 0f
        for (i in 0 until len) {
            val x = y[i]
            val o = x - px + r * py
            px = x
            py = o
            y[i] = o
        }
        val fc = minOf(cutoffHz, rate * 0.45f)
        val a = (1.0 - Math.exp(-2.0 * Math.PI * fc / rate)).toFloat()
        var s1 = 0f
        var s2 = 0f
        for (i in 0 until len) {
            s1 += a * (y[i] - s1)
            s2 += a * (s1 - s2)
            y[i] = s2
        }
    }

    private fun synth(ids: LongArray, speed: Float): FloatArray {
        val e = env ?: throw IllegalStateException("env")
        val s = session ?: throw IllegalStateException("session")
        val n = ids.size.toLong()
        val inputs = HashMap<String, OnnxTensor>()
        try {
            inputs["input"] = OnnxTensor.createTensor(e, LongBuffer.wrap(ids), longArrayOf(1, n))
            inputs["input_lengths"] = OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(n)), longArrayOf(1))
            val st = TranslatorSettings(ctx)
            val userNoise = st.piperNoiseScale / 100f
            val userLength = st.piperLengthScale / 100f
            val userNoiseW = st.piperNoiseW / 100f
            inputs["scales"] = OnnxTensor.createTensor(
                e, FloatBuffer.wrap(floatArrayOf(userNoise, userLength / speed.coerceIn(0.5f, 2f), userNoiseW)), longArrayOf(3)
            )
            if (hasSid) inputs["sid"] = OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(0)), longArrayOf(1))
            s.run(inputs).use { res ->
                val fb = (res[0] as OnnxTensor).floatBuffer
                val out = FloatArray(fb.remaining())
                fb.get(out)
                nativeWarmed = true
                return out
            }
        } finally {
            inputs.values.forEach { try { it.close() } catch (_: Exception) {} }
        }
    }

    /** مۆدێلەکە بار دەکات و یەک ڕستەی کورت دروست دەکات، تا یەکەم خوێندنەوە چاوەڕێی بارکردن نەکات. */
    fun warmUp() {
        if (closed || !synthesisGate.tryLock()) return
        try {
            if (!closed && ensureLoaded() == null && !nativeWarmed) {
                toIds("سڵاو.")?.let { synth(it, 1f) }
            }
        } catch (_: Throwable) {
        } finally { synthesisGate.unlock() }
    }

    /**
     * دەقی کورت بۆ Piper/Berfin: مۆدێلەکە ڕستەی زۆر کورت زۆرجار بێدەنگ یان نابیستراو دەردەچێت.
     * تەنها خاڵ زیاد دەکرێت؛ وشە زیاد یان دووبارە ناکرێتەوە.
     */
    private fun padShortKu(s: String): String {
        var t = s.trim()
        if (t.isEmpty()) return t
        val last = t.lastOrNull()
        val hasEnd = last == '.' || last == '!' || last == '؟' || last == '،'
        // هەموو ڕستەی کورت/مامناوەند خاڵ وەرگرن تا مۆدێل دەنگ دروست بکات
        if (t.length < 36 && !hasEnd) t = "$t."
        return t
    }

    /**
     * دەقی کورت: VITS ڕستەی زۆر کورت زۆرجار بێدەنگ یان زۆر کورت دەردەکات. چەند شێوەی جیاواز دەکرێت
     * (خاڵ، بۆشایی بۆ دەوروبەر، فاریزە) و یەکەمیان کە دەنگی بەس بوو هەڵدەبژێردرێت؛ دەنگەکە دووبارە ناکرێتەوە.
     */
    private fun synthShort(sentence: String, bare: String, spd: Float, pause: Int, profile: PiperVoiceProfile.Preset): FloatArray {
        return PiperShortSpeech.render(
            sentence, bare, sampleRate,
            synthesize = { variant -> toIds(variant)?.let { synth(it, spd) } },
            polish = { raw -> polish(raw, sampleRate, pause, profile) }
        )
    }

    /**
     * یەک ڕستە دەکات بە PCM (لە cache ەوە ئەگەر پێشتر دروست کرابوو). هەم speakStream و هەم prefetch بەکاریدەهێنن،
     * بۆیە ئەنجامی prefetch دەستبەجێ لە cache دا دەبێت کاتێک خوێندنەوەکە دەگاتە ئەو ڕستەیە.
     */
    private fun render(sentence: String, speed: Float, profile: PiperVoiceProfile.Preset, wanted: () -> Boolean = { true }): FloatArray? {
        synthesisGate.lockInterruptibly()
        try {
            if (closed || !wanted()) return null
            return renderLocked(sentence, speed, profile)
        } finally { synthesisGate.unlock() }
    }

    /** Cache check and inference share a gate, coalescing foreground/prefetch misses. */
    private fun renderLocked(sentence: String, speed: Float, profile: PiperVoiceProfile.Preset): FloatArray? {
        check(profile.id != FemaleVoiceRecipe.PROFILE_ID || femaleRecipeModel) {
            "ڕێکخستنی نموونەی ئافرەت تەنها بۆ مۆدێلی sorani-ckb-female-voice-onnx ـە؛ مۆدێلەکە هەڵبژێرە یان تۆنێکی تر بەکار بهێنە."
        }
        val ids = toIds(sentence) ?: return null
        val bare = sentence.replace(".", "").replace("؟", "").replace("!", "").replace("،", "").trim()
        // تا ~٤٠ پیت: ڕستەی کورت/مامناوەند (وەک «سڵاو ئەمڕۆ ویستم»)
        val short = bare.length < 40
        val low = lowLatency
        val spd = if (short && !useModelTiming) (speed * (if (low) 0.9f else 0.72f)).coerceAtLeast(0.55f) else speed
        // ژێرنووسی زیندوو: وچانی نێوان ڕستەکان کورت (پێشتر ١٤٠/١٠٠ms + بێدەنگی سەر و کۆتا = وەستانێکی بیستراو)
        val st = TranslatorSettings(ctx)
        val pause = if (referenceVoice) PiperSpeechTiming.pauseMs(sentence, low, st.piperEndPauseMs)
            else if (low) minOf(st.piperEndPauseMs, 60) else st.piperEndPauseMs
        val ck = PiperVoiceProfile.cacheKey(speed, low, profile, sentence, voiceTuning(st))
        cacheGet(ck)?.let { return it }
        val out = if (short) synthShort(sentence, bare, spd, pause, profile) else {
            val raw = synth(ids, spd)
            if (!PcmSignal.hasSignal(raw, sampleRate)) return null
            polish(raw, sampleRate, pause, profile)
        }
        // Silence is not successful synthesis and must not enter the cache.
        if (!PcmSignal.hasSignal(out, sampleRate)) return null
        if (out.isNotEmpty()) cachePut(ck, out)
        return out
    }

    // One running and one latest queued prefetch; outdated OCR cannot build
    // an unbounded background synthesis queue or compete with current speech.
    private val prefetchPool = java.util.concurrent.ThreadPoolExecutor(
        1, 1, 0L, TimeUnit.MILLISECONDS, LinkedBlockingQueue<Runnable>(1),
        java.util.concurrent.ThreadFactory { r -> Thread({
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Throwable) {}
            r.run()
        }, "piper-prefetch").apply { isDaemon = true } },
        java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy()
    )

    /**
     * دەنگی ڕستەیەک پێشوەختە دروست دەکات (لە پاشبنەما) و دەیخاتە cache، لەکاتێکدا ڕستەی ئێستا دەپەخشرێت؛
     * بەم شێوەیە کاتێک خوێندنەوەی ڕستەی پێشوو تەواو بوو، ڕستەی دواتر بێ چاوەڕێی دروستکردن دەست پێدەکات.
     * `speed` دەبێت هەمان خێرایی بێت کە دواتر بۆ خوێندنەوە بەکاردێت (cache بە خێرایی کلیل دەکرێت).
     */
    fun prefetch(text: String, speed: Float) {
        val profile = PiperVoiceProfile.customized(voiceTuning(TranslatorSettings(ctx)))
        val generation = workGeneration.get()
        if (closed) return
        try {
            prefetchPool.execute {
                try {
                    if (closed || generation != workGeneration.get() || session == null) return@execute
                    for (sentence in chunks(padShortKu(KurdishSpeechPrep.prepare(text)))) {
                        if (closed || generation != workGeneration.get()) break
                        render(sentence, speed, profile) { generation == workGeneration.get() }
                    }
                } catch (_: Throwable) {
                }
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
        }
    }

    /** بە ڕیز دەخوێنێتەوە؛ لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو. */
    fun speakBlocking(texts: List<String>, speed: Float, isCurrent: () -> Boolean): String? {
        val q = LinkedBlockingQueue<SpeechMsg>()
        for (t in texts) q.add(SpeechMsg(t))
        q.add(SpeechMsg(null))
        return speakStream(q, speed, isCurrent)
    }

    /**
     * دەقەکان لە `source` وەردەگرێت تا کۆتایی (SpeechMsg(null)). دروستکردنی دەنگ (thread ی خۆی) و پەخشکردن
     * پێکەوە کار دەکەن: لە کاتی خوێندنەوەی ڕستەیەک، ڕستەی دواتر دروست دەکرێت، و بە یەک AudioTrack دەپەخشرێت بێ وچان.
     * لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو.
     */
    fun speakStream(source: BlockingQueue<SpeechMsg>, speed: Float, isCurrent: () -> Boolean): String? {
        if (!isCurrent() || closed) return null
        playbackMayHaveStarted = false
        ensureLoaded()?.let { return it }
        val profile = PiperVoiceProfile.customized(voiceTuning(TranslatorSettings(ctx)))
        synchronized(playbackLock) {
            if (!isCurrent() || closed) return null
            cancelled = false
            speaking = true
        }
        val pcmQ = PiperPcmQueue()
        val consumerDone = java.util.concurrent.atomic.AtomicBoolean(false)
        fun active() = !cancelled && isCurrent() && !consumerDone.get()
        val err = AtomicReference<String?>(null)
        val producer = Thread({
            try {
                // CPU inference must not run at the mixer's urgent-audio priority.
                try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DEFAULT) } catch (_: Throwable) {}
                loop@ while (active()) {
                    val m = source.poll(150, TimeUnit.MILLISECONDS) ?: continue
                    val t = m.text ?: break
                    var produced = 0
                    for (sentence in chunks(padShortKu(KurdishSpeechPrep.prepare(t)))) {
                        if (!active()) break@loop
                        val samples = render(sentence, speed, profile) { active() } ?: continue
                        if (!active()) break@loop
                        if (samples.isEmpty()) continue
                        produced++
                        while (!pcmQ.offer(samples, 200)) {
                            if (!active()) break@loop
                        }
                    }
                    // ئەگەر هیچ دەنگێک دروست نەبوو، هەڵە بگەڕێنەوە بۆ fallback
                    if (produced == 0 && t.trim().isNotEmpty()) {
                        err.set("Piper: دەنگی ئەم دەقە دروست نەبوو")
                    }
                }
            } catch (e: Throwable) {
                if (active()) {
                    Log.e(TAG, "synth failed", e)
                    err.compareAndSet(null, "Piper: ${e.message}")
                }
            } finally {
                // A full queue must not lose its only end-of-stream signal.
                pcmQ.finish()
            }
        }, "piper-synth")
        producer.start()

        var at: AudioTrack? = null
        var toneApplied = false
        var written = 0L
        val progress = PiperPlaybackProgress()
        val oldPriority = try { android.os.Process.getThreadPriority(android.os.Process.myTid()) } catch (_: Throwable) { 0 }
        fun startPlayback(t: AudioTrack) = synchronized(playbackLock) {
            if (!cancelled && isCurrent() && t.playState != AudioTrack.PLAYSTATE_PLAYING) {
                // Apply only once, after PCM has been queued: setting playback
                // parameters may start a paused track on some Android versions.
                if (!toneApplied) {
                    if (profile.pitch != 1f) {
                        t.playbackParams = PlaybackParams().allowDefaults()
                            .setSpeed(1f).setPitch(profile.pitch)
                            .setAudioFallbackMode(PlaybackParams.AUDIO_FALLBACK_MODE_FAIL)
                    }
                    toneApplied = true
                }
                t.play()
                playbackMayHaveStarted = true
            }
        }
        fun checkProgress(t: AudioTrack) {
            if (!progress.update(t.playbackHeadPosition, written,
                    t.playState == AudioTrack.PLAYSTATE_PLAYING, android.os.SystemClock.elapsedRealtime())) {
                throw IllegalStateException("Piper: پەخشکردنی دەنگ ڕاگیرا؛ بەفەر پێش ناکەوێت")
            }
        }
        try {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO) } catch (_: Throwable) {}
            while (!cancelled && isCurrent()) {
                val samples = pcmQ.poll(100)
                if (samples == null) {
                    if (pcmQ.isDrained) break
                    // دروستکردنی ڕستەی دواتر درێژەی کێشا: ئەوەی هەیە بیپەخشێنە
                    at?.let { if (written > 0) { startPlayback(it); checkProgress(it) } }
                    continue
                }
                var pcm = ShortArray(samples.size) { i -> (samples[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
                var t = at
                if (t == null) {
                    t = newTrack(sampleRate, pcm.size)
                    // Some AudioTrack implementations wait for a full initial
                    // buffer even after play(). Pad PCM only, never the text.
                    pcm = PiperPlayback.fillFirstBuffer(pcm, t.bufferSizeInFrames)
                    at = t
                    synchronized(playbackLock) { if (!cancelled && isCurrent()) track = t }
                }
                var off = 0
                while (off < pcm.size && !cancelled && isCurrent()) {
                    val n = t.write(pcm, off, minOf(pcm.size - off, 2048), AudioTrack.WRITE_NON_BLOCKING)
                    if (n < 0) throw IllegalStateException("Piper: AudioTrack write failed ($n)")
                    if (n == 0) {
                        startPlayback(t)
                        checkProgress(t)
                        Thread.sleep(8)
                    } else {
                        off += n
                        written += n
                        checkProgress(t)
                    }
                }
                // دەست بە پەخش دەکات دوای ٠٫٣ چرکە دەنگ لە بەفەر (underrun = گزگزە)
                if (written >= minOf(sampleRate * 3L / 10, pcm.size.toLong())) startPlayback(t)
            }
            // ڕستەی کۆتایی هەتا کۆتایی دەپەخشرێت
            val t = at
            if (t != null && !cancelled && isCurrent()) {
                startPlayback(t)
                val deadline = android.os.SystemClock.elapsedRealtime() + written * 1000L / sampleRate + 1500
                while (!cancelled && isCurrent()) {
                    checkProgress(t)
                    if (progress.playedFrames >= written) break
                    if (android.os.SystemClock.elapsedRealtime() >= deadline) {
                        throw IllegalStateException("Piper: پەخشکردنی دەنگ تەواو نەبوو")
                    }
                    Thread.sleep(20)
                }
            }
        } catch (e: Exception) {
            if (!cancelled && isCurrent()) err.set("Piper: ${e.message}")
        } finally {
            consumerDone.set(true)
            producer.interrupt()
            at?.let {
                // وەستاندن: دەنگی ماوە لە بەفەر فڕێ دەدرێت، نەک هەتا کۆتایی بپەخشرێت
                if (cancelled || !isCurrent() || err.get() != null) {
                    try { it.pause(); it.flush() } catch (_: Exception) {}
                }
                try { it.stop() } catch (_: Exception) {}
                try { it.release() } catch (_: Exception) {}
            }
            synchronized(playbackLock) { if (track === at) track = null }
            speaking = false
            try { android.os.Process.setThreadPriority(oldPriority) } catch (_: Throwable) {}
        }
        return err.get()
    }

    private fun newTrack(rate: Int, firstSamples: Int): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(
                VoiceOutput.attributes(TranslatorSettings(ctx).voiceOutput)
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(PiperPlayback.bufferBytes(minBuf, rate, firstSamples))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    private fun splitSentences(s: String): List<String> =
        s.split(Regex("(?<=[.!?؟\\n])\\s*")).map { it.trim() }.filter { it.isNotEmpty() }

    /** ڕستەی درێژ دەکرێتە پارچەی کورت (لە فاریزە/بۆشایی)، بۆ ئەوەی دەنگی یەکەم پارچە زوو ئامادە بێت. */
    private fun chunks(s: String): List<String> {
        if (referenceVoice) return PiperSpeechTiming.chunks(s)
        val out = ArrayList<String>()
        for (sent in splitSentences(s)) {
            if (sent.length <= MAX_CHUNK) {
                out.add(sent)
                continue
            }
            val cur = StringBuilder()
            for (w in sent.split(' ')) {
                if (w.isEmpty()) continue
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(w)
                val endsComma = w.endsWith("،") || w.endsWith(",") || w.endsWith("؛")
                if (cur.length >= MAX_CHUNK || (endsComma && cur.length >= (if (out.isEmpty()) 18 else 35))) {
                    out.add(cur.toString())
                    cur.setLength(0)
                }
            }
            if (cur.isNotEmpty()) {
                if (cur.length < 8 && out.isNotEmpty()) out[out.size - 1] = out.last() + " " + cur else out.add(cur.toString())
            }
        }
        return out.filter { it.isNotEmpty() }
    }

    fun stop() {
        workGeneration.incrementAndGet()
        prefetchPool.queue.clear()
        synchronized(playbackLock) {
            cancelled = true
            speaking = false
            track?.let { try { it.pause(); it.flush() } catch (_: Exception) {} }
        }
    }

    fun shutdown() {
        closed = true
        stop()
        prefetchPool.shutdownNow()
        // Native inference cannot be closed underneath a producer. Closing on
        // a daemon avoids making the UI wait for an in-flight ONNX call.
        Thread({
            synthesisGate.lock()
            try {
                synchronized(pcmCache) { pcmCache.clear(); cacheFloats = 0 }
                try { session?.close() } catch (_: Throwable) {}
                session = null
            } finally { synthesisGate.unlock() }
        }, "piper-close").apply { isDaemon = true }.start()
    }

    companion object {
        private const val TAG = "PiperTts"
        private const val MODEL = "model.onnx"
        private const val CONFIG = "model.onnx.json"
        private const val MAX_CHUNK = 80
        /** سنووری cache: ≈١.٥ ملیۆن نموونە ≈ ٦MB ≈ ١.١ خولەک دەنگ */
        private const val CACHE_MAX_FLOATS = 1_500_000

        private val modelEpoch = java.util.concurrent.atomic.AtomicInteger()
        private val preparedFirstUse = PreparedResource<PiperTts> { it.shutdown() }
        private val firstUseExecutor = java.util.concurrent.Executors.newSingleThreadScheduledExecutor { task ->
            Thread(task, "piper-first-use").apply { isDaemon = true }
        }

        private fun firstUseIdentity(ctx: Context) = selectedModelDir(ctx).absolutePath + "#" + modelEpoch.get()

        /** Called while the user is still in setup/main UI. No native work on the UI thread. */
        fun prepareFirstUse(ctx: Context) {
            val app = ctx.applicationContext
            val settings = TranslatorSettings(app)
            if (DeviceProfile.low || !settings.offlineTts || settings.pawanTts ||
                settings.offlineVoice != KurdishVoiceText.PIPER || !isInstalled(app)) return
            try {
                val engine = preparedFirstUse.preload(firstUseIdentity(app), { PiperTts(app) },
                    { it.warmUp() }, { task -> firstUseExecutor.execute { task() } })
                // Only an unclaimed engine may expire. A live reader owns its own lifecycle.
                firstUseExecutor.schedule({ preparedFirstUse.expire(engine) }, 5, TimeUnit.MINUTES)
            } catch (error: Exception) {
                Log.w(TAG, "background preparation failed", error)
            }
        }

        fun takePrepared(ctx: Context): PiperTts {
            val app = ctx.applicationContext
            return preparedFirstUse.take(firstUseIdentity(app)) { PiperTts(app) }
        }

        fun clearPrepared() = preparedFirstUse.clear()

        private fun matchesFemaleRecipeModel(file: File): Boolean {
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            file.inputStream().buffered().use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    digest.update(buffer, 0, n)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it.toInt() and 255) } ==
                FemaleVoiceRecipe.MODEL_SHA256
        }
        fun modelDir(ctx: Context) = File(ctx.filesDir, PiperModelChoice.directory(0))
        private fun selectedModelDir(ctx: Context) =
            File(ctx.filesDir, PiperModelChoice.directory(TranslatorSettings(ctx).piperModelVariant))
        private fun installedAt(dir: File) = File(dir, MODEL).exists() && File(dir, CONFIG).exists()
        fun isOriginalInstalled(ctx: Context) = installedAt(modelDir(ctx))
        fun isInstalled(ctx: Context) = installedAt(selectedModelDir(ctx))

        const val VOICE_URL = "https://github.com/Whiteheart00/manga-translator/releases/download/v1.0.1/kurdish_onnx_model.zip"

        /** دەنگی کوردی دادەبەزێنێت و دەیکاتەوە. null = باشە. لەسەر thread ی کار بانگ بکرێت. */
        fun download(ctx: Context, url: String = VOICE_URL, progress: (Int) -> Unit): String? {
            val dir = modelDir(ctx)
            dir.mkdirs()
            val z = File(ctx.cacheDir, "ku_voice.zip")
            return try {
                var u = url
                var c: java.net.HttpURLConnection
                var hops = 0
                while (true) {
                    c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 15_000
                    c.readTimeout = 60_000
                    c.instanceFollowRedirects = false
                    val code = c.responseCode
                    if (code in 300..399 && hops++ < 6) {
                        u = java.net.URL(java.net.URL(u), c.getHeaderField("Location") ?: return "داگرتن سەرنەکەوت: redirect").toString()
                        c.disconnect()
                        continue
                    }
                    if (code !in 200..299) { c.disconnect(); return "داگرتن سەرنەکەوت: HTTP $code" }
                    break
                }
                val total = c.contentLengthLong
                var got = 0L
                var last = -1
                c.inputStream.use { ins ->
                    z.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            got += n
                            if (total > 0) {
                                val p = (got * 100 / total).toInt()
                                if (p != last) { last = p; progress(p) }
                            }
                        }
                    }
                }
                c.disconnect()
                ZipInputStream(z.inputStream().buffered()).use { zin ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        if (e.isDirectory) continue
                        val base = e.name.substringAfterLast('/').lowercase()
                        val target = when {
                            base.endsWith(".onnx.json") -> CONFIG
                            base.endsWith(".onnx") -> MODEL
                            else -> null
                        } ?: continue
                        val tmp = File(dir, "$target.tmp")
                        tmp.outputStream().use { zin.copyTo(it) }
                        File(dir, target).delete()
                        tmp.renameTo(File(dir, target))
                    }
                }
                if (installedAt(dir)) { modelEpoch.incrementAndGet(); null } else "model.onnx یان model.onnx.json لە zip دا نەبوو"
            } catch (e: Throwable) {
                Log.e(TAG, "download failed", e)
                "داگرتن سەرنەکەوت: ${e.message}"
            } finally {
                z.delete()
            }
        }

        private fun displayName(ctx: Context, uri: Uri): String =
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0) else null
                }
            } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()

        /**
         * فایلە هەڵبژێردراوەکان دەهێنێت: zip (کە model.onnx و model.onnx.json ی تێدایە) یان .onnx / .json.
         * لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو، ئەگینا پەیامی هەڵە.
         */
        fun importModel(ctx: Context, uris: List<Uri>): String? {
            val dir = selectedModelDir(ctx)
            dir.mkdirs()
            try {
                for (uri in uris) {
                    val name = displayName(ctx, uri).lowercase()
                    val input = ctx.contentResolver.openInputStream(uri) ?: return "فایلەکە نەکرایەوە"
                    input.use { ins ->
                        when {
                            name.endsWith(".zip") -> {
                                ZipInputStream(ins.buffered()).use { zin ->
                                    while (true) {
                                        val e = zin.nextEntry ?: break
                                        if (e.isDirectory) continue
                                        val base = e.name.substringAfterLast('/').lowercase()
                                        val target = when {
                                            base.endsWith(".onnx.json") -> CONFIG
                                            base.endsWith(".onnx") -> MODEL
                                            else -> null
                                        } ?: continue
                                        File(dir, target + ".tmp").outputStream().use { zin.copyTo(it) }
                                        File(dir, target).delete()
                                        File(dir, target + ".tmp").renameTo(File(dir, target))
                                    }
                                }
                            }
                            name.endsWith(".onnx.json") || name.endsWith(".json") ->
                                File(dir, CONFIG).outputStream().use { ins.copyTo(it) }
                            name.endsWith(".onnx") ->
                                File(dir, MODEL).outputStream().use { ins.copyTo(it) }
                            else -> return "جۆری فایل نەناسراوە ($name). zip یان .onnx یان .json هەڵبژێرە"
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "import failed", e)
                return "هێنان سەرنەکەوت: ${e.message}"
            }
            return if (installedAt(dir)) { modelEpoch.incrementAndGet(); null }
            else "model.onnx یان model.onnx.json لە فایلەکاندا نەبوو"
        }
    }
}
