package com.mangatranslator.app

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * شاشەی یەکەم کردنەوە: هەموو پێویستییەکان (OCR ی کوردی، دەنگی کوردی، مۆدێلی نووسینی ئۆفلاین)
 * خۆکارانە دادەبەزێنێت و لۆدینگێکی جوان نیشان دەدات. کاتێک تەواو بوو، دەچێتە شاشەی سەرەکی.
 * ئەگەر پچڕا، دووبارە هەوڵدان لەو شوێنەوە بەردەوام دەبێت (VekolStt resume دەکات).
 */
class SetupActivity : Activity() {

    private class Step(
        val title: String,
        val weightMb: Float,
        val isDone: () -> Boolean,
        val run: (progress: (Float) -> Unit) -> String?
    )

    private class Row(val icon: TextView, val label: TextView, val state: TextView)

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var pal: Palette
    private lateinit var bar: FancyBar
    private lateinit var pctText: TextView
    private lateinit var headline: TextView
    private lateinit var subText: TextView
    private lateinit var infoText: TextView
    private lateinit var retryBtn: Button
    private lateinit var skipBtn: TextView
    private lateinit var logo: ImageView
    private val rows = ArrayList<Row>()
    private lateinit var steps: List<Step>
    private var pulse: ValueAnimator? = null
    private lateinit var frame: FrameLayout
    private lateinit var fab: SpeakFab
    private var picker: LiteracyPicker.Handle? = null
    private var failedMsg = false

    @Volatile private var working = false
    @Volatile private var alive = true

    private val textMain get() = if (pal.light) Color.parseColor("#0F172A") else Color.parseColor("#EAF2FF")
    private val textDim get() = if (pal.light) Color.parseColor("#475569") else Color.parseColor("#B4C4E4")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val appCtx = applicationContext
        DeviceProfile.init(appCtx)
        if (OverlayService.instance == null) PiperTts.prepareFirstUse(appCtx)

        steps = listOf(
            Step("ناسینەوەی دەقی کوردی (OCR)", 4f, { LocalKurdishOcr.isInstalled(appCtx) || prefs().getBoolean("ocr_skipped", false) }) { prog ->
                prog(0.05f)
                val err = LocalKurdishOcr.download(appCtx)
                if (err == null) prog(1f)
                // OCR ی ناوخۆیی دڵخوازە (ئەگەر نەبوو، ئەپەکە Gemini بەکاردەهێنێت)؛ نابێتە بەربەست بۆ دوو هەنگاوەکەی تر
                else prefs().edit().putBoolean("ocr_skipped", true).apply()
                null
            },
            Step("OCR ی عەرەبی و جاپانیی ستوونی", 4f, { TessOcr.allInstalled(appCtx) || prefs().getBoolean("tess_skipped", false) }) { prog ->
                var failedLang = false
                TessOcr.FIRST_RUN.forEachIndexed { i, l ->
                    prog(i / TessOcr.FIRST_RUN.size.toFloat())
                    if (!TessOcr.isInstalled(appCtx, l) && TessOcr.download(appCtx, l) != null) failedLang = true
                }
                // دڵخوازە: ئەگەر نەبوو ئەپەکە دواتر لە پاشبنەما دووبارە هەوڵ دەدات و نابێتە بەربەست
                if (failedLang) prefs().edit().putBoolean("tess_skipped", true).apply() else prog(1f)
                null
            },
            Step("دەنگی کوردیی نیورالی", 60f, { PiperTts.isInstalled(appCtx) }) { prog ->
                PiperTts.download(appCtx) { p -> prog(p / 100f) }
            },
            Step("نووسینی ئۆفلاینی کوردی", 291f, { VekolStt.isReady(appCtx) }) { prog ->
                try {
                    VekolStt.download(appCtx) { done, total, _ ->
                        prog(if (total > 0) done.toFloat() / total else 0f)
                    }
                    null
                } catch (t: Throwable) {
                    "دابەزاندن پچڕا: " + (t.message ?: t.javaClass.simpleName).take(100)
                }
            }
        )

        // ئەگەر هەموو شتێک ئامادەیە، یەکسەر بڕۆ شاشەی سەرەکی
        if (steps.all { it.isDone() } || prefs().getBoolean("skipped", false)) {
            openMain(false)
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pal = Palettes.get(TranslatorSettings(this).theme)
        buildUi()
        startWork()
    }

    private fun prefs() = getSharedPreferences("setup", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        frame = FrameLayout(this)
        frame.addView(GlassBackground(this, pal), FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(26), dp(56), dp(26), dp(28))
        }

        logo = ImageView(this).apply {
            setImageResource(R.drawable.app_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        col.addView(logo, LinearLayout.LayoutParams(dp(112), dp(112)).apply { bottomMargin = dp(16) })

        col.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textMain)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })

        headline = TextView(this).apply {
            text = "ئامادەکردنی ئەپەکە بۆ یەکەم جار"
            textSize = 14f
            setTextColor(textDim)
            gravity = Gravity.CENTER
        }
        col.addView(headline, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(30) })

        pctText = TextView(this).apply {
            text = "0%"
            textSize = 46f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(textMain)
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        col.addView(pctText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val track = if (pal.light) 0x22000000 else 0x30FFFFFF
        bar = FancyBar(this, pal.a1, pal.a2, track)
        col.addView(bar, LinearLayout.LayoutParams(-1, dp(12)).apply { bottomMargin = dp(12) })

        infoText = TextView(this).apply {
            textSize = 12.5f
            setTextColor(textDim)
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        col.addView(infoText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(26) })

        // کارتی هەنگاوەکان
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(if (pal.light) 0x14000000 else 0x24FFFFFF)
                setStroke(dp(1), if (pal.light) 0x22000000 else 0x30FFFFFF)
            }
        }
        for (s in steps) {
            val ic = TextView(this).apply {
                text = "○"; textSize = 18f; gravity = Gravity.CENTER
                setTextColor(textDim)
            }
            val lb = TextView(this).apply {
                text = s.title; textSize = 15f; setTextColor(textMain)
            }
            val st = TextView(this).apply {
                textSize = 12f; setTextColor(textDim)
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(9), 0, dp(9))
            }
            r.addView(ic, LinearLayout.LayoutParams(dp(30), -2))
            r.addView(lb, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
            r.addView(st, LinearLayout.LayoutParams(-2, -2))
            card.addView(r, LinearLayout.LayoutParams(-1, -2))
            rows.add(Row(ic, lb, st))
        }
        col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        subText = TextView(this).apply {
            textSize = 12.5f
            setTextColor(textDim)
            gravity = Gravity.CENTER
            text = if (isMetered()) "نزیکەی ٣٥٠ مێگابایت دادەبەزێت، بۆیە WiFi باشترە" else
                "تەنها یەکجار دادەبەزێت؛ دوای ئەوە ئەپەکە خێرا دەکرێتەوە"
        }
        col.addView(subText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        retryBtn = Button(this).apply {
            text = "↻  دووبارە هەوڵبدەرەوە"
            textSize = 15f
            setTextColor(Color.WHITE)
            setAllCaps(false)
            background = GradientDrawable(
                GradientDrawable.Orientation.RIGHT_LEFT, intArrayOf(pal.a1, pal.a2)
            ).apply { cornerRadius = dp(16).toFloat() }
            visibility = View.GONE
            setOnClickListener { startWork() }
        }
        col.addView(retryBtn, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(8) })

        skipBtn = TextView(this).apply {
            text = "تێپەڕاندن (دواتر لە ڕێکخستنەکان دایبەزێنە)"
            textSize = 13f
            setTextColor(textDim)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            visibility = View.GONE
            setOnClickListener {
                prefs().edit().putBoolean("skipped", true).apply()
                openMain(true)
            }
        }
        col.addView(skipBtn, LinearLayout.LayoutParams(-1, -2))

        frame.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        fab = SpeakFab(this, pal.a1, pal.a2).apply { setOnClickListener { onFab() } }
        frame.addView(fab, FrameLayout.LayoutParams(dp(104), dp(68), Gravity.BOTTOM or Gravity.LEFT).apply {
            leftMargin = dp(10); bottomMargin = dp(14)
        })
        if (TranslatorSettings(this).literacy != 1) Narrator.warmUp(this)

        pulse = ValueAnimator.ofFloat(1f, 1.07f).apply {
            duration = 1100
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                val v = it.animatedValue as Float
                logo.scaleX = v; logo.scaleY = v
            }
            start()
        }
    }

    /** هەر کاتێک دەنگی کوردی ئامادە بوو، پرسیاری خوێندەواری نیشان دەدرێت. */
    private fun maybeAskLiteracy() {
        if (picker != null || !alive) return
        if (TranslatorSettings(this).literacy != 0 || !PiperTts.isInstalled(applicationContext)) return
        picker = LiteracyPicker.show(this, frame, pal) { n ->
            picker = null
            if (n == 2) Narrator.speak(this, "باشە. ئەپەکە ئێستا شتە پێویستەکان دادەبەزێنێت. تکایە چاوەڕێ بکە.")
        }
        fab.bringToFront()
    }

    private fun onFab() {
        val p = picker
        if (p != null) { p.speakNow(); return }
        Narrator.speak(this, if (failedMsg)
            "دابەزاندن وەستا. ئینتەرنێتەکەت بپشکنە، پاشان دوگمەی دووبارە هەوڵدانەوە دابگرە."
        else
            "ئەپەکە خەریکە شتە پێویستەکان دادەبەزێنێت. تکایە چاوەڕێ بکە. ئەمە تەنها یەکجار دەکرێت.")
    }

    private fun isMetered(): Boolean = try {
        (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
    } catch (_: Throwable) { false }

    // ---------------------------------------------------------------- دابەزاندن

    private fun startWork() {
        if (working) return
        working = true
        failedMsg = false
        retryBtn.visibility = View.GONE
        skipBtn.visibility = View.VISIBLE
        headline.text = "ئامادەکردنی ئەپەکە بۆ یەکەم جار"

        val total = steps.sumOf { it.weightMb.toDouble() }.toFloat()
        Thread {
            var lastMb = 0f
            var lastT = System.currentTimeMillis()
            var speed = 0f
            var failed: String? = null

            fun overall(cur: Int, frac: Float): Float {
                var d = 0f
                for (i in steps.indices) {
                    d += when {
                        i < cur -> steps[i].weightMb
                        i == cur -> steps[i].weightMb * frac
                        else -> if (steps[i].isDone()) steps[i].weightMb else 0f
                    }
                }
                return d
            }

            for (i in steps.indices) {
                val s = steps[i]
                if (s.isDone()) { post { markRow(i, "✓", "ئامادەیە", true); maybeAskLiteracy() }; continue }
                post { markRow(i, "●", "0%", false) }

                val err = s.run { frac ->
                    val f = frac.coerceIn(0f, 1f)
                    val doneMb = overall(i, f)
                    val now = System.currentTimeMillis()
                    if (now - lastT >= 500) {
                        val inst = (doneMb - lastMb) / ((now - lastT) / 1000f)
                        speed = if (speed == 0f) inst else speed * 0.7f + inst * 0.3f
                        lastMb = doneMb; lastT = now
                    }
                    post {
                        setProgress(doneMb / total, doneMb, total, speed)
                        rows[i].state.text = "${(f * 100).toInt()}%"
                    }
                }
                if (err != null) { failed = err; post { markRow(i, "!", "هەڵە", false) }; break }
                post { markRow(i, "✓", "ئامادەیە", true); maybeAskLiteracy() }
            }

            working = false
            post {
                if (failed != null) onFailed(failed) else onSuccess()
            }
        }.start()
    }

    private fun post(r: () -> Unit) { ui.post { if (alive) r() } }

    private fun markRow(i: Int, icon: String, state: String, done: Boolean) {
        val r = rows[i]
        r.icon.text = icon
        r.icon.setTextColor(
            when {
                done -> Color.parseColor("#2EE57A")
                icon == "!" -> Color.parseColor("#FF5C6C")
                else -> pal.a2
            }
        )
        r.state.text = state
    }

    private fun setProgress(frac: Float, doneMb: Float, totalMb: Float, speed: Float) {
        bar.target = frac
        pctText.text = "${(frac * 100).toInt()}%"
        val sp = if (speed > 0.01f) "   ·   " + String.format("%.1f", speed) + " MB/s" else ""
        infoText.text = String.format("%.0f / %.0f MB", doneMb, totalMb) + sp
    }

    private fun onFailed(msg: String) {
        headline.text = "دابەزاندن وەستا"
        subText.text = msg + "\nئینتەرنێتەکەت بپشکنە و دووبارە هەوڵبدەرەوە؛ لەو شوێنەوە بەردەوام دەبێت"
        retryBtn.visibility = View.VISIBLE
        skipBtn.visibility = View.VISIBLE
        failedMsg = true
        if (picker == null) Narrator.autoSpeak(this,
            "دابەزاندن وەستا. ئینتەرنێتەکەت بپشکنە، پاشان دوگمەی دووبارە هەوڵدانەوە دابگرە.")
    }

    private fun onSuccess() {
        bar.target = 1f
        pctText.text = "100%"
        headline.text = "ئامادەیە ✓"
        subText.text = "هەموو شتێک دابەزێندرا"
        skipBtn.visibility = View.GONE
        if (picker == null && Narrator.needsVoice(this) && Narrator.isReady(this)) {
            Narrator.speak(this, "هەموو شتێک ئامادەیە. ئێستا دەچینە ناو ئەپەکە.") { if (alive) openMain(true) }
        } else {
            ui.postDelayed({ if (alive) openMain(true) }, 900)
        }
    }

    private fun openMain(animate: Boolean) {
        if (OverlayService.instance == null) PiperTts.prepareFirstUse(applicationContext)
        startActivity(Intent(this, MainActivity::class.java))
        if (animate) overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // لە کاتی دابەزاندن دا ئەپەکە دادەخرێتە پاشبنەما (دابەزاندنەکە ناوەستێت)
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        alive = false
        pulse?.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- ستوونی پێشکەوتن

    private class FancyBar(ctx: Context, private val c1: Int, private val c2: Int, private val track: Int) : View(ctx) {
        var target = 0f
            set(v) { field = v.coerceIn(0f, 1f) }
        private var shown = 0f
        private var phase = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val clip = Path()
        private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
        }

        override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
        override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

        override fun onDraw(cv: Canvas) {
            shown += (target - shown) * 0.12f
            if (Math.abs(target - shown) < 0.0005f) shown = target

            val w = width.toFloat()
            val h = height.toFloat()
            val r = h / 2f

            p.shader = null
            p.color = track
            rect.set(0f, 0f, w, h)
            cv.drawRoundRect(rect, r, r, p)

            val fw = if (shown <= 0f) 0f else (w * shown).coerceAtLeast(h)
            if (fw <= 0f) return
            val left = w - fw   // لە ڕاستەوە بۆ چەپ (RTL)
            rect.set(left, 0f, w, h)
            p.shader = LinearGradient(w, 0f, left, 0f, c1, c2, Shader.TileMode.CLAMP)
            cv.drawRoundRect(rect, r, r, p)

            // درەوشانەوە
            cv.save()
            clip.reset()
            clip.addRoundRect(rect, r, r, Path.Direction.CW)
            cv.clipPath(clip)
            val band = h * 5f
            val bx = w - phase * (fw + band)
            p.shader = LinearGradient(
                bx - band, 0f, bx, 0f,
                intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            cv.drawRect(bx - band, 0f, bx, h, p)
            cv.restore()
        }
    }
}
