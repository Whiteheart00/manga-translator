package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.*

class FemaleVoiceRecipeTest {
    @Test fun shiftsPitchWithoutChangingUtteranceDurationOrClipping() {
        val rate = 16000
        val x = FloatArray(rate*3) { (.15*sin(2*PI*205*it/rate)).toFloat() }
        val y = FemaleVoiceRecipe.process(x, rate)
        assertEquals(x.size, y.size)
        assertTrue(y.all { it.isFinite() && abs(it) <= .841f })
        val start = rate/2; val end = rate*5/2
        val crossings = (start+1 until end).count { y[it-1] <= 0 && y[it] > 0 }
        val measured = crossings.toDouble()*rate/(end-start)
        assertEquals(205*1.04, measured, 2.0)
        assertEquals(-18.0, FemaleVoiceRecipe.integratedLufs(y, rate), .6)
    }
    @Test fun preservesSilenceAndDoesNotAddFakeBreathNoise() {
        assertArrayEquals(FloatArray(8000), FemaleVoiceRecipe.process(FloatArray(8000),16000),0f)
        assertEquals(0,FemaleVoiceRecipe.process(floatArrayOf(),16000).size)
    }
    @Test fun rejectsNonFinitePcm() {
        assertThrows(IllegalArgumentException::class.java) {
            FemaleVoiceRecipe.process(floatArrayOf(Float.NaN),16000)
        }
    }
    @Test fun keepsBriefSpeechFiniteAndRetainsSignalAtTheEnd() {
        for (length in listOf(1,64,800,16000)) {
            val x=FloatArray(length) { (.1*sin(2*PI*220*it/16000)).toFloat() }
            val y=FemaleVoiceRecipe.process(x,16000)
            assertEquals(length,y.size)
            assertTrue(y.all { it.isFinite() })
            if(length>=800) assertTrue(y.takeLast(length/4).any { abs(it)>.001f })
        }
    }
}
