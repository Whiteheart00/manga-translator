package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class PiperModelChoiceTest {
    @Test fun importingTrainedVoiceCannotTargetOriginalVoiceDirectory() {
        assertNotEquals(PiperModelChoice.directory(0), PiperModelChoice.directory(1))
    }
    @Test fun invalidModelSelectionResolvesToOriginalSlot() {
        assertEquals(PiperModelChoice.directory(0), PiperModelChoice.directory(-1))
        assertEquals(PiperModelChoice.directory(0), PiperModelChoice.directory(10))
    }
}
