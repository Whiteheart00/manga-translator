package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class KurdishOcrTextTest {
    @Test fun elongationNeverSplitsAKurdishWord() {
        assertEquals("کوردی سڵاو", KurdishOcrText.clean("کـوردی سـڵاو"))
    }
    @Test fun paragraphsAndLinesSurviveCleanup() {
        assertEquals("سڵاو هاوڕێ\n\nدەقی کوردی", KurdishOcrText.clean("  سڵاو\tهاوڕێ\r\n\r\n  دەقی   کوردی  "))
        assertEquals("سڵاو\nهاوڕێ", KurdishOcrText.clean("سڵاو\u2028هاوڕێ"))
    }
    @Test fun zeroWidthWordSpaceDoesNotJoinSeparateWords() {
        assertEquals("دەقی کوردی", KurdishOcrText.clean("دەقی\u200Bکوردی"))
        assertEquals("دەچم", KurdishOcrText.clean("دە\u200Cچم"))
    }
    @Test fun directionControlsAndBomDoNotRemainInRecognizedWords() {
        assertEquals("سڵاو هاوڕێ", KurdishOcrText.clean("\uFEFF\u2067سڵاو\u2069 \u200Fهاوڕێ\u061C"))
    }
    @Test fun hamzaIsComposedBeforeArabicYehIsNormalized() {
        assertEquals("ئێمە کوردی", KurdishOcrText.clean("ي\u0654ێمە كوردي"))
    }
    @Test fun arabicPresentationFormsBecomeReadableLetters() {
        assertEquals("کوردی", KurdishOcrText.clean("\uFEDB\uFEEE\uFEAD\uFEA9\uFEF1"))
    }
    @Test fun rAndHeavyRAndLAndHeavyLAreNotConflated() {
        val text="ر ڕ ل ڵ تەر تەڕ دڵ"
        assertEquals(text, KurdishOcrText.clean(text))
    }
    @Test fun numbersDosesPercentagesAndScientificUnitsKeepTheirMeaning() {
        val text="٥٫٢ mg/dL، ١٠٠٪، Ca²⁺ و x²"
        assertEquals(text, KurdishOcrText.clean(text))
        assertEquals("٥٪", KurdishOcrText.clean("٥ ٪"))
    }
    @Test fun borrowedNamesAndTechnicalTermsAreNotDictionaryGuesses() {
        assertEquals("کوردی ERPNext و GPT-4", KurdishOcrText.clean("کوردی ERPNext و GPT-4"))
    }
    @Test fun cleanupIsIdempotent() {
        val once=KurdishOcrText.clean("\u200Fکـوردی\n  سڵاو  ، ERPNext")
        assertEquals(once,KurdishOcrText.clean(once))
    }
    @Test fun dictionaryMappingPreservesWhitespaceAndPunctuation() {
        val input="کوردى\n\n  سڵاو، هاوڕێ"
        assertEquals("کوردی\n\n  سڵاو، هاوڕێ", KurdishOcrText.mapWords(input) { if(it=="کوردى") "کوردی" else it })
    }
    @Test fun correctedWordBoxesKeepTheirGeometryAndReadingOrder() {
        val words=listOf(
            MixedOcrFilter.Word("کـوردی",100,0,150,20,90f),
            MixedOcrFilter.Word("دەق",0,0,50,20,90f),
            MixedOcrFilter.Word("سڵاو",100,40,150,60,90f)
        )
        val cleaned=words.map {it.copy(text=KurdishOcrText.clean(it.text))}
        assertEquals("کوردی دەق\nسڵاو", MixedOcrFilter.text(cleaned))
        assertEquals(words.map {it.left to it.top},cleaned.map {it.left to it.top})
        assertEquals(words.map {it.right to it.bottom},cleaned.map {it.right to it.bottom})
    }
}
