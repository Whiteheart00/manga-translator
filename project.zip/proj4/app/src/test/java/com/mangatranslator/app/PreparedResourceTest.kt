package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger

class PreparedResourceTest {
    private class Resource { var warm=0; var disposed=0 }

    @Test fun repeatedPreparationSchedulesOneResourceAndDoesNoWarmupOnCaller() {
        val tasks=ArrayList<()->Unit>();var created=0
        val pool=PreparedResource<Resource> { it.disposed++ }
        fun prepare()=pool.preload("female#1",{created++;Resource()},{it.warm++},{tasks.add(it)})
        val a=prepare();val b=prepare()
        assertSame(a,b);assertEquals(1,created);assertEquals(1,tasks.size);assertEquals(0,a.warm)
        tasks.single().invoke();assertEquals(1,a.warm)
    }
    @Test fun transferOfWarmEngineDoesNotLoadAgainOrCloseTheReadersResource() {
        val tasks=ArrayList<()->Unit>();val pool=PreparedResource<Resource> {it.disposed++}
        val original=pool.preload("female#1",{Resource()},{it.warm++},{tasks.add(it)})
        tasks.single().invoke()
        val reader=pool.take("female#1") {fail("Duplicate model load");Resource()}
        assertSame(original,reader)
        pool.clear();pool.expire(original)
        assertEquals(1,reader.warm);assertEquals(0,reader.disposed)
    }
    @Test fun immediateActivationSkipsAQueuedDummyWarmup() {
        val tasks=ArrayList<()->Unit>();val pool=PreparedResource<Resource> {it.disposed++}
        val original=pool.preload("female#1",{Resource()},{it.warm++},{tasks.add(it)})
        assertSame(original,pool.take("female#1") {Resource()})
        tasks.single().invoke()
        assertEquals(0,original.warm);assertEquals(0,original.disposed)
    }
    @Test fun changingModelRejectsTheOtherModelsPreparedEngine() {
        val tasks=ArrayList<()->Unit>();val pool=PreparedResource<Resource> {it.disposed++}
        val old=pool.preload("original#1",{Resource()},{it.warm++},{tasks.add(it)})
        val selected=pool.take("female#1") {Resource()}
        assertNotSame(old,selected);assertEquals(1,old.disposed)
        tasks.single().invoke();assertEquals(0,old.warm)
    }
    @Test fun aNewImportEpochInvalidatesThePreparedModel() {
        val tasks=ArrayList<()->Unit>();val pool=PreparedResource<Resource> {it.disposed++}
        val old=pool.preload("female#1",{Resource()},{it.warm++},{tasks.add(it)})
        val fresh=pool.preload("female#2",{Resource()},{it.warm++},{tasks.add(it)})
        tasks.forEach {it()}
        assertEquals(1,old.disposed);assertEquals(0,old.warm);assertEquals(1,fresh.warm)
    }
    @Test fun memoryPressureCancelsUnusedPreparationExactlyOnce() {
        val tasks=ArrayList<()->Unit>();val pool=PreparedResource<Resource> {it.disposed++}
        val unused=pool.preload("female#1",{Resource()},{it.warm++},{tasks.add(it)})
        pool.clear();pool.clear();tasks.single().invoke()
        assertEquals(1,unused.disposed);assertEquals(0,unused.warm)
    }
    @Test fun aStaleExpiryCannotCloseTheNewModel() {
        val pool=PreparedResource<Resource> {it.disposed++}
        val old=pool.preload("original#1",{Resource()},{},{it()})
        val fresh=pool.preload("female#1",{Resource()},{},{it()})
        pool.expire(old)
        assertSame(fresh,pool.take("female#1") {Resource()})
        assertEquals(0,fresh.disposed)
    }
    @Test fun schedulingFailureDisposesTheUnclaimedResource() {
        val pool=PreparedResource<Resource> {it.disposed++};val value=Resource()
        assertThrows(RejectedExecutionException::class.java) {
            pool.preload("female#1",{value},{},{throw RejectedExecutionException()})
        }
        assertEquals(1,value.disposed)
        assertNotSame(value,pool.take("female#1") {Resource()})
    }
    @Test fun simultaneousUiCallbacksDoNotCreateDuplicateWarmups() {
        val created=AtomicInteger();val scheduled=AtomicInteger()
        val pool=PreparedResource<Resource> {it.disposed++}
        val start=CountDownLatch(1);val workers=Executors.newFixedThreadPool(8)
        try {
            val results=(1..8).map {workers.submit<Resource> {
                start.await()
                pool.preload("female#1",{created.incrementAndGet();Resource()},{},{scheduled.incrementAndGet()})
            }}
            start.countDown();val values=results.map {it.get(5,TimeUnit.SECONDS)}
            assertEquals(1,created.get());assertEquals(1,scheduled.get())
            assertTrue(values.all {it===values.first()})
        } finally {workers.shutdownNow()}
    }
}
