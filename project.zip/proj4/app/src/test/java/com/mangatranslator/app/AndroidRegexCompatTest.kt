package com.mangatranslator.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * JVM regex accepts `\p{IsLatin}`, but Android's ICU engine rejects it (PatternSyntaxException in a static
 * initializer → the first use crashes and every later use is NoClassDefFoundError). Use `\p{script=Latin}`, valid on both.
 */
class AndroidRegexCompatTest {
    @Test fun noJvmOnlyUnicodeScriptSyntaxInSources() {
        val root = listOf(File("src/main/java"), File("app/src/main/java")).first { it.exists() }
        val bad = root.walkTopDown().filter { it.extension == "kt" }
            .filter { f -> f.readText().contains(Regex("""\\\\p\{(Is|In)[A-Z]""")) }
            .map { it.name }.toList()
        assertTrue("JVM-only \\p{IsXxx} regex in: $bad", bad.isEmpty())
    }

    @Test fun latinScriptSyntaxCompiles() {
        Regex("[\\p{script=Latin}0-9]+").matches("abc123")
    }
}
