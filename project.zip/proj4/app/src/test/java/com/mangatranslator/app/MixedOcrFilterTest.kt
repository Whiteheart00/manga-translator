package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class MixedOcrFilterTest {
    private fun word(text: String, left: Int, confidence: Float = 90f, latin: Boolean = false, top: Int = 0) =
        MixedOcrFilter.Word(text, left, top, left + 40, top + 20, confidence, latin)

    @Test fun noiseTokenDoesNotEraseTheWholeGoodLine() {
        val text = MixedOcrFilter.text(MixedOcrFilter.nativeWords(listOf(word("سڵاو", 120), word("ئئئئ", 60), word("هاوڕێ", 0))))
        assertEquals("سڵاو هاوڕێ", text)
    }
    @Test fun shortKurdishWordsSurviveWithoutAThreeLetterAnchor() {
        assertEquals("نا", MixedOcrFilter.text(MixedOcrFilter.nativeWords(listOf(word("نا", 0)))))
        assertEquals("لە تۆ", MixedOcrFilter.text(MixedOcrFilter.nativeWords(listOf(word("لە", 80), word("تۆ", 0)))))
    }
    @Test fun weakRealWordBetweenClearWordsIsRetained() {
        val result = MixedOcrFilter.nativeWords(listOf(word("سڵاو", 120), word("لە", 60, 35f), word("تۆ", 0)))
        assertEquals(3, result.size)
    }
    @Test fun isolatedLowConfidenceNumbersAndPunctuationAreRejected() {
        assertTrue(MixedOcrFilter.nativeWords(listOf(word("٩٦", 60, 40f), word("٥٥", 0, 40f))).isEmpty())
        assertTrue(MixedOcrFilter.nativeWords(listOf(word("...", 0))).isEmpty())
    }
    @Test fun numbersInARealSentenceKeepTheirMeaning() {
        assertEquals("ژمارە 2026", MixedOcrFilter.text(MixedOcrFilter.nativeWords(listOf(word("ژمارە", 80), word("2026", 0, 60f)))))
    }
    @Test fun englishProductNameFillsTheMissingSlot() {
        val mixed = MixedOcrFilter.merge(listOf(word("ئێمە", 160), word("بەکاردەهێنین", 0)),
            listOf(word("ERPNext", 80, 96f, true)))
        assertEquals("ئێمە ERPNext بەکاردەهێنین", MixedOcrFilter.text(mixed))
    }
    @Test fun englishRunStaysLeftToRightInsideTheKurdishLine() {
        val mixed = MixedOcrFilter.merge(listOf(word("ئێمە", 240), word("هەیە", 0)),
            listOf(word("Nwebeen", 80, 98f, true), word("ERPNext", 140, 98f, true)))
        assertEquals("ئێمە Nwebeen ERPNext هەیە", MixedOcrFilter.text(mixed))
    }
    @Test fun acronymsDigitsAndCamelCaseAreNotRejectedAsGibberish() {
        for (name in listOf("ERP", "ERPNext", "GPT4", "Nwebeen", "readX", "CO2")) {
            assertTrue(MixedOcrFilter.merge(emptyList(), listOf(word(name, 0, 96f, true))).any { it.text == name })
        }
    }
    @Test fun confidentKurdishDoesNotBecomeALatinHallucination() {
        val merged = MixedOcrFilter.merge(listOf(word("پڕۆگرامەر", 0, 95f)), listOf(word("yojyaJ", 0, 80f, true)))
        assertEquals("پڕۆگرامەر", MixedOcrFilter.text(merged))
    }
    @Test fun strongerEnglishCanReplaceAnUncertainCkbOnlyGuess() {
        val merged = MixedOcrFilter.merge(listOf(word("شەرم", 0, 60f)), listOf(word("ERPNext", 0, 98f, true)))
        assertEquals("ERPNext", MixedOcrFilter.text(merged))
    }
    @Test fun duplicateLatinDetectorBoxesAreNotSpokenTwice() {
        val latin = word("ERPNext", 0, 98f, true)
        assertEquals(1, MixedOcrFilter.merge(emptyList(), listOf(latin, latin)).size)
    }
    @Test fun separateLinesRetainTheirOrder() {
        val words = listOf(word("سڵاو", 0, top = 40), word("ئێمە", 80, top = 0))
        assertEquals("ئێمە\nسڵاو", MixedOcrFilter.text(words))
    }
    @Test fun invalidConfidenceOrGeometryCannotPolluteOutput() {
        assertTrue(MixedOcrFilter.nativeWords(listOf(word("سڵاو", 0, Float.NaN))).isEmpty())
        assertTrue(MixedOcrFilter.merge(emptyList(), listOf(word("ERPNext", 0, Float.NaN, true))).isEmpty())
    }
    @Test fun legitimateRepeatedVowelInsideAWordDoesNotEraseIt() {
        assertEquals("زۆۆۆۆر", MixedOcrFilter.text(MixedOcrFilter.nativeWords(listOf(word("زۆۆۆۆر", 0)))))
    }
    @Test fun leadingDigitNamesKeepTheirLatinSuffix() {
        for (name in listOf("4K", "3D", "5G")) {
            assertEquals(name, MixedOcrFilter.text(MixedOcrFilter.merge(emptyList(), listOf(word(name, 0, 98f, true)))))
        }
    }
    @Test fun ckbNumericPrefixDoesNotEraseTheLetterOf4K() {
        val words = MixedOcrFilter.merge(listOf(word("ژمارە", 80), word("٤", 0, 96f)), listOf(word("4K", 0, 98f, true)))
        assertEquals("ژمارە 4K", MixedOcrFilter.text(words))
    }
    @Test fun latinWordsWithUnavailableConfidenceFillGapsWithoutInventingAScore() {
        val mixed = MixedOcrFilter.merge(listOf(word("ئێمە", 160), word("هەیە", 0)), listOf(word("ERPNext", 80, -1f, true)))
        assertEquals("ئێمە ERPNext هەیە", MixedOcrFilter.text(mixed))
    }
    @Test fun unknownLatinConfidenceCannotOverwriteARealKurdishWord() {
        val mixed = MixedOcrFilter.merge(listOf(word("پڕۆگرامەر", 0, 90f)), listOf(word("yojyaJ", 0, -1f, true)))
        assertEquals("پڕۆگرامەر", MixedOcrFilter.text(mixed))
    }

    @Test fun screenshotSplitDigitsAreConfirmedAsOneLeftToRightNumber() {
        val native = listOf(word("بۆ", 220), word("ماوەی", 160),
            word("8", 100, 55f), word("1", 50, 91f), word("مانگ", 0, 66f))
        val eighteen = MixedOcrFilter.Word("18", 50, 0, 140, 20, 97f, true)
        assertEquals("بۆ ماوەی 18 مانگ", MixedOcrFilter.text(MixedOcrFilter.merge(native, listOf(eighteen))))
    }
    @Test fun screenshotMangaWordCannotBecomeModeratelyConfidentSilo() {
        assertEquals("مانگ", MixedOcrFilter.text(MixedOcrFilter.merge(
            listOf(word("مانگ", 0, 66f)), listOf(word("Silo", 0, 82f, true)))))
    }
    @Test fun screenshotTelephoneSurvivesWithoutKurdishLineAnchor() {
        val phone = word("07765952001", 0, 93f, true)
        assertEquals(phone.text, MixedOcrFilter.text(MixedOcrFilter.merge(emptyList(), listOf(phone))))
    }
    @Test fun latinNumbersNeverReplaceKurdishWaw() {
        assertEquals("و", MixedOcrFilter.text(MixedOcrFilter.merge(
            listOf(word("و", 0, 90f), word("تۆ", 80)), listOf(word("9", 0, 99f, true)))).substringAfter("تۆ "))
    }
    @Test fun priceAndUnknownConfidencePhoneAreKept() {
        for (number in listOf("5,000", "07765952001")) {
            assertEquals(number, MixedOcrFilter.text(MixedOcrFilter.merge(emptyList(), listOf(word(number, 0, -1f, true)))))
        }
        assertTrue(MixedOcrFilter.merge(emptyList(), listOf(word("92", 0, 70f, true))).isEmpty())
    }
    @Test fun screenshotLatinNameAndProductDoNotNeedKurdishAnchors() {
        val english = listOf(word("Darya", 0, 93f, true), word("Muhamad", 90, 92f, true),
            word("Gimeni", 0, 92f, true, 40), word("Pro", 90, 97f, true, 40))
        assertEquals("Darya Muhamad\nGimeni Pro", MixedOcrFilter.text(MixedOcrFilter.merge(emptyList(), english)))
    }
    @Test fun whollyLatinLogoRowReadsLeftToRightAcrossWideGaps() {
        assertEquals("QiCard FIB FastPay", MixedOcrFilter.text(listOf(word("FastPay", 400, latin = true),
            word("QiCard", 0, latin = true), word("FIB", 220, latin = true))))
    }
    @Test fun unpairedStandaloneBracketFromCheckIconIsDropped() {
        assertEquals("سڵاو", MixedOcrFilter.text(MixedOcrFilter.nativeWords(listOf(word(")", 80), word("سڵاو", 0)))))
        assertEquals("( سڵاو )", MixedOcrFilter.text(MixedOcrFilter.nativeWords(
            listOf(word("(", 160), word("سڵاو", 80), word(")", 0)))))
    }
    @Test fun numberHeavyArtworkNeedsMoreThanWeakTwoLetterGuesses() {
        assertTrue(MixedOcrFilter.nativeWords(listOf(word("ێی", 0, 54f), word("متا", 240, 0f), word("٥٥", 80, 92f), word("٥", 160, 78f))).isEmpty())
        assertFalse(MixedOcrFilter.nativeWords(listOf(word("دینار", 0, 60f), word("5,000", 80, 92f), word("98", 160, 78f))).isEmpty())
    }
}
