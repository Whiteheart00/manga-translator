package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject

class PiperTextEncodingTest {
    private val letters = mapOf("س" to 3L, "ڵ" to 4L, "ا" to 5L, "و" to 6L, "ئ" to 16L, "ە" to 1L, "ک" to 10L)
    @Test fun originalPiperIdsRemainUnchanged() {
        val m = letters + mapOf("^" to 1L, "$" to 2L, "_" to 0L)
        assertArrayEquals(longArrayOf(1,3,0,4,0,5,0,6,0,2), PiperTextEncoding.encode("سڵاو", m, false))
    }
    @Test fun mmsMatchesBlankInterleavingWithoutAnExtraEos() {
        val m = letters + mapOf("_" to 0L)
        assertArrayEquals(longArrayOf(0,3,0,4,0,5,0,6,0), PiperTextEncoding.encode("سڵاو", m, true))
    }
    @Test fun nfcKeepsKurdishHamzaCharacterForNewModel() {
        assertArrayEquals(longArrayOf(0,16,0,1,0), PiperTextEncoding.encode("ئە", letters, true))
    }
    @Test fun legacyStillSupportsDecomposedPhonemeIds() {
        val m = mapOf("^" to 1L, "$" to 2L, "_" to 0L, "ي" to 7L, "ٔ" to 8L, "ە" to 9L)
        assertArrayEquals(longArrayOf(1,7,0,8,0,9,0,2), PiperTextEncoding.encode("ئە", m, false))
    }
    @Test fun scriptNormalizationAndNoSpeechInputsRemainSafe() {
        assertArrayEquals(longArrayOf(0,10,0), PiperTextEncoding.encode("ك", letters, true))
        assertNull(PiperTextEncoding.encode("xyz", letters, true))
    }

    private fun referenceMap(): Map<String, Long> {
        val text = checkNotNull(javaClass.getResourceAsStream("/reference-voice-config.json"))
            .bufferedReader().use { it.readText() }
        val map = JSONObject(text).getJSONObject("phoneme_id_map")
        return map.keys().asSequence().associateWith { map.getJSONArray(it).getLong(0) }
    }
    @Test fun referenceVoiceMatchesExportedIdsIncludingHamzaAndKaf() {
        assertArrayEquals(longArrayOf(0,16,0,1,0,10,0),
            PiperTextEncoding.encode("ئەک", referenceMap(), true, true))
    }
    @Test fun referencePunctuationSeparatesWordsInsteadOfJoiningThem() {
        assertArrayEquals(longArrayOf(0,15,0,32,0,2,0,5,0,37,0,16,0,1,0),
            PiperTextEncoding.encode("  سڵاو،\n\tئە  ", referenceMap(), true, true))
    }
    @Test fun referenceCombiningHamzaAndArabicScriptVariantsAreHandled() {
        assertArrayEquals(PiperTextEncoding.encode("ئەک", referenceMap(), true, true),
            PiperTextEncoding.encode("ي\u0654ەك", referenceMap(), true, true))
    }
    @Test fun referenceSpecialTokensAndUnsupportedTextAreNotSpeech() {
        assertNull(PiperTextEncoding.encode("^\$_| 123 😀", referenceMap(), true, true))
    }
}
