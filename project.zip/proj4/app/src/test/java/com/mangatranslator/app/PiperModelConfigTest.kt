package com.mangatranslator.app

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PiperModelConfigTest {
    @Test fun exportedReferenceConfigSelectsItsEncoderAndExactScales() {
        val text = checkNotNull(javaClass.getResourceAsStream("/reference-voice-config.json"))
            .bufferedReader().use { it.readText() }
        val config = PiperModelConfig.inference(JSONObject(text))
        assertTrue(config.referenceVoice)
        assertTrue(config.blankInterleaved)
        assertTrue(config.useModelTiming)
        assertEquals(0.3f, config.noise, 0f)
        assertEquals(0.3f, config.durationNoise, 0f)
        assertEquals(1f, config.length, 0f)
    }
    @Test fun originalPiperRetainsItsTuning() {
        val config = PiperModelConfig.inference(JSONObject("""{"inference":{"noise_scale":0.8,"noise_w":0.9,"length_scale":1.2}}"""))
        assertFalse(config.referenceVoice)
        assertFalse(config.blankInterleaved)
        assertEquals(0.4f, config.noise, 0f)
        assertEquals(0.55f, config.durationNoise, 0f)
        assertEquals(1.2f * 1.08f, config.length, 0f)
    }
    @Test fun previousTrainedModelsKeepTheirEncodingAndTiming() {
        val config = PiperModelConfig.inference(JSONObject("""{"sequence_style":"blank_interleaved","use_model_timing":true}"""))
        assertTrue(config.blankInterleaved)
        assertTrue(config.useModelTiming)
        assertFalse(config.referenceVoice)
        assertEquals(1f, config.length, 0f)
    }
    @Test fun missingConfigDoesNotRetainThePreviousModelsScales() {
        val config = PiperModelConfig.inference(JSONObject())
        assertEquals(0.4f, config.noise, 0f)
        assertEquals(0.55f, config.durationNoise, 0f)
        assertEquals(1.08f, config.length, 0f)
    }
    @Test fun malformedReferenceScalesFallBackToSafeDefaults() {
        val j = JSONObject().put("format", PiperModelConfig.REFERENCE_FORMAT)
            .put("inference", JSONObject().put("noise_scale", "NaN")
                .put("noise_w", -1).put("length_scale", 100))
        val config = PiperModelConfig.inference(j)
        assertEquals(0.3f, config.noise, 0f)
        assertEquals(0.3f, config.durationNoise, 0f)
        assertEquals(1f, config.length, 0f)
    }
}
