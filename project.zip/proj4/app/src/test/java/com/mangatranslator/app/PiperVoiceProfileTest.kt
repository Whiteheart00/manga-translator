package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class PiperVoiceProfileTest {
    @Test fun differentTonesCannotReuseOneAnothersProcessedAudio() {
        val keys = (0..3).map {
            PiperVoiceProfile.cacheKey(1f, true, PiperVoiceProfile.get(it), "سڵاو")
        }
        assertEquals(4, keys.toSet().size)
        assertEquals(keys[2], PiperVoiceProfile.cacheKey(1f, true, PiperVoiceProfile.get(2), "سڵاو"))
        assertNotEquals(keys[2], PiperVoiceProfile.cacheKey(1f, false, PiperVoiceProfile.get(2), "سڵاو"))
    }
    @Test fun unknownPersistedToneKeepsTheOriginalVoice() {
        for (invalid in listOf(-1, 4, Int.MAX_VALUE)) {
            assertEquals(PiperVoiceProfile.get(0), PiperVoiceProfile.get(invalid))
        }
    }
    @Test fun recipeCannotReceiveTheLegacyFemalePitchAgain() {
        assertEquals(1.22f, PiperVoiceProfile.get(2).pitch, 0f)
        assertEquals(1f, PiperVoiceProfile.get(FemaleVoiceRecipe.PROFILE_ID).pitch, 0f)
    }
    @Test fun sliderValuesAreRetainedInTheSelectedProfile() {
        val tuning = PiperVoiceProfile.Tuning(3, 1.05f, 6200, 90, 30, 100, 30, 20)
        val profile = PiperVoiceProfile.customized(tuning)
        assertEquals(3, profile.id)
        assertEquals(1.05f, profile.pitch, 0f)
        assertEquals(6200f, profile.cutoffHz, 0f)
        assertEquals(.09f, profile.targetRms, .00001f)
    }
    @Test fun inferenceSliderChangesCannotReuseStalePcm() {
        val a = PiperVoiceProfile.Tuning(3, 1f, 7000, 100, 30, 100, 30, 20)
        val profile = PiperVoiceProfile.customized(a)
        val original = PiperVoiceProfile.cacheKey(1f, false, profile, "سڵاو", a)
        for (changed in listOf(a.copy(noisePercent=20), a.copy(lengthPercent=110),
            a.copy(durationNoisePercent=20), a.copy(endPauseMs=0))) {
            assertNotEquals(original, PiperVoiceProfile.cacheKey(1f, false, profile, "سڵاو", changed))
        }
    }
}
