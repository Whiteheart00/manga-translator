package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class PiperVoiceProfileTest {
    @Test fun differentTonesCannotReuseOneAnothersProcessedAudio() {
        val keys = (0..3).map {
            PiperVoiceProfile.cacheKey(1f, true, PiperVoiceProfile.get(it), "سڵاو")
        }
        assertEquals(4, keys.toSet().size)
        assertEquals(keys[2], PiperVoiceProfile.cacheKey(1f, true, PiperVoiceProfile.get(2), "سڵاو"))
        assertNotEquals(keys[2], PiperVoiceProfile.cacheKey(1f, false, PiperVoiceProfile.get(2), "سڵاو"))
    }
    @Test fun unknownPersistedToneKeepsTheOriginalVoice() {
        for (invalid in listOf(-1, 4, Int.MAX_VALUE)) {
            assertEquals(PiperVoiceProfile.get(0), PiperVoiceProfile.get(invalid))
        }
    }
    @Test fun recipeCannotReceiveTheLegacyFemalePitchAgain() {
        assertEquals(1.22f, PiperVoiceProfile.get(2).pitch, 0f)
        assertEquals(1f, PiperVoiceProfile.get(FemaleVoiceRecipe.PROFILE_ID).pitch, 0f)
    }
}
