# Local Kurdish / English OCR and conservative word filtering

The uploaded ckb.traineddata model has 92 LSTM unicharset entries and no individual ASCII letters A–Z/a–z. Filtering its Kurdish output cannot recover English letters it cannot recognize. The bundled model and the user's dictionaries remain unchanged; inventory/hash evidence is in verification/ocr-model-inventory.json.

For a selected region with local Kurdish OCR enabled, the app now runs the ckb reader and the existing bundled Latin ML Kit reader locally against the same crop. It waits for both callbacks, merges their word boxes, and reads recognized Sorani directly. There is no Gemini request, translation, timeout race or cloud preconnection on this successful native path. The ordinary foreign-language fallback starts only after the local stage has finished without a readable Sorani result. The selected speech engine still applies: choosing an online TTS service can require network for speech itself.

## Filter behavior

- A repeated-character garbage token does not delete its entire good line.
- Short real words such as نا / لە / تۆ survive; a three-letter word is no longer mandatory.
- Weak words can be kept in a line anchored by clear text. Isolated numeric/punctuation noise is removed; numbers in meaningful sentences remain.
- Latin names, acronyms and identifiers such as ERPNext, Nwebeen, GPT4, CO2, 4K and 5G are preserved. Case and spelling are not translated or dictionary-corrected.
- Overlapping detector outputs do not speak twice. A Latin candidate replaces an overlapping Kurdish candidate only when its reported confidence is clearly stronger; trusted Kurdish readings are protected from Latin-shaped gibberish. A matching numeric prefix alone cannot erase the letters in 4K.
- Missing Latin confidence is represented as unknown. Such words can fill gaps, but cannot overwrite trusted Kurdish words using an invented confidence value.
- Lines are ordered top-to-bottom, with Kurdish right-to-left and adjacent Latin runs left-to-right. Coordinates account for ckb preprocessing scale and padding.

The accessibility route remains first and avoids both OCR engines for readable screen text. Region collection prunes unrelated valid-bounds branches, and can accept a large native content description when nearly fully selected. A short selected word can read directly. Explicit native reading is not rejected just because it matches previous overlay output.

Local recognition is warmed while selecting a region. The low-RAM cloud shortcut does not bypass the local native stage. Canceling the selection invalidates late results; the shared crop is kept until both local readers have finished. Existing image-language fallbacks and the live-subtitle filter retain their separate roles.

## Supplied screenshot validation

The Facebook screenshot has now been checked with the bundled ckb model on desktop.
The existing Kotlin filter was run against captured word boxes before and after the
fix. Desktop English Tesseract is a diagnostic surrogate for Latin word boxes;
Android ML Kit was not run. See verification/photo-ocr/README.md for reproducible
fixtures, improvements and remaining recognition errors.

Numeric Latin detections are retained at high reported confidence (or explicit
unknown confidence), without replacing Kurdish letter boxes. Split native digits
can confirm a complete Latin number. Moderate Latin confidence cannot replace a
multi-letter Kurdish word; known scores must reach 90 in addition to the existing
confidence margin. A fully Latin row reads left-to-right across wide gaps. Numeric
artwork needs a genuine word anchor; unmatched standalone brackets are discarded.

All changes reuse existing detections. No extra recognition pass, cloud request,
model or artificial wait was added. The model and dictionaries remain unchanged.
Physical-device integration and latency are still unmeasured.

This delivery contains source only, with no APK.
