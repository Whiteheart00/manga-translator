from pathlib import Path
import numpy as np,math,wave,subprocess,json
r=Path(__file__).parent;rate=22050;raw=np.load(r/'preview-source.npy')
def process(raw,fc,target):
 peak=float(np.max(np.abs(raw)));active=np.flatnonzero(np.abs(raw)>=peak*.01);a=max(0,int(active[0])-int(rate*.04));b=min(len(raw),int(active[-1])+int(rate*.06));y=np.copy(raw[a:b]);n=len(y)
 alpha=1-math.exp(-2*math.pi*fc/rate);px=py=s1=s2=0.
 for i,x in enumerate(y):
  o=float(x)-px+.995*py;px=float(x);py=o;s1+=alpha*(o-s1);s2+=alpha*(s1-s2);y[i]=s2
 fade=min(int(rate*.015),n//2)
 for i in range(fade):y[i]*=i/fade;y[n-1-i]*=i/fade
 rms=float(np.sqrt(np.mean(y.astype(np.float64)**2)));gain=min(target/max(rms,1e-9),.9/float(np.max(np.abs(y))),2.5);y*=gain
 return np.concatenate([y,np.zeros(rate*280//1000,np.float32)])
def save(path,y):
 with wave.open(str(path),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate);f.writeframes((np.clip(y,-1,1)*32767).astype('<i2').tobytes())
save(r/'male-soft.wav',process(raw,5600,.095));save(r/'feminine-source.wav',process(raw,6000,.095))
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(r/'feminine-source.wav'),'-af','rubberband=pitch=1.22:tempo=1:transients=smooth:detector=soft:phase=laminar:formant=shifted:pitchq=quality','-ar','22050','-ac','1','-c:a','pcm_s16le',str(r/'feminine-soft.wav')],check=True)
summary={}
for name in ['male-soft.wav','feminine-soft.wav']:
 with wave.open(str(r/name)) as f:
  y=np.frombuffer(f.readframes(f.getnframes()),'<i2').astype(float)/32767
  summary[name]={'sample_rate':f.getframerate(),'seconds':len(y)/f.getframerate(),'peak':float(np.max(np.abs(y))),'clipped_samples':int(np.sum(np.abs(y)>=1))}
assert abs(summary['male-soft.wav']['seconds']-summary['feminine-soft.wav']['seconds'])<.03
assert all(v['clipped_samples']==0 for v in summary.values())
(r/'preview-validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
