from PIL import Image, ImageOps
from pathlib import Path
import subprocess, csv, json
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('screenshot', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('--tessdata', type=Path, required=True, help='Directory containing ckb.traineddata and eng.traineddata')
args=parser.parse_args()
root=args.output
root.mkdir(parents=True, exist_ok=True)
original=Image.open(args.screenshot).convert('RGB')
for name,im in [('advert',original.crop((100,770,1000,1830))),('full',original)]:
 m=max(im.size); k=min(2,900/m) if m<700 else 960/m if m>960 else 1
 sz=tuple(max(1,int(v*k)) for v in im.size)
 scaled=im.resize(sz,Image.Resampling.BILINEAR)
 vals=[(r*299+g*587+b*114)//1000 for r,g,b in scaled.getdata()]
 if sum(vals)//len(vals)<110: vals=[255-v for v in vals]
 hist=[0]*256
 for v in vals:hist[v]+=1
 lo=0;acc=0
 while lo<255 and acc+hist[lo]<len(vals)//100:acc+=hist[lo];lo+=1
 hi=255;acc=0
 while hi>0 and acc+hist[hi]<len(vals)//100:acc+=hist[hi];hi-=1
 if hi-lo<30:lo,hi=0,255
 gray=Image.new('L',sz);gray.putdata([max(0,min(255,(v-lo)*255//max(1,hi-lo))) for v in vals])
 prepared=ImageOps.expand(gray,border=12,fill=255); prepared.save(root/(name+'-prepared.png'))
 for lang,source,psm in [('ckb',root/(name+'-prepared.png'),'6'),('eng',root/(name+'.png'),'11')]:
  if lang=='eng': im.save(source)
  out=root/(name+'-'+lang)
  subprocess.run(['tesseract',str(source),str(out),'--tessdata-dir',str(args.tessdata),'-l',lang,'--psm',psm,'-c','tessedit_create_tsv=1','-c','tessedit_create_txt=1'],check=True)
  words=[]
  for w in csv.DictReader(open(str(out)+'.tsv'),delimiter='\t'):
   if not w['text'].strip():continue
   l,t,width,height=[int(w[x]) for x in ['left','top','width','height']]
   if lang=='ckb': l,t,r,b=[int((v-12)/k) for v in [l,t,l+width,t+height]]
   else:r,b=l+width,t+height
   words.append([w['text'],max(0,l),max(0,t),min(im.width,r),min(im.height,b),float(w['conf']),lang=='eng'])
  json.dump(words,open(str(out)+'.json','w'),ensure_ascii=False,indent=2)
  print(name,lang,Path(str(out)+'.txt').read_text())
