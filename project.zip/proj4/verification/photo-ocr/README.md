# Supplied Facebook screenshot — desktop diagnostic

Input dimensions: 1080 × 2400. Selected advert: (100, 770)–(1000, 1830).
The screenshot hash, model hash and exact engine limitations are in manifest.json.

The ckb pass uses the uploaded model with Android-equivalent first-pass grayscale,
contrast, resize and padding (Pillow bilinear, not Android Bitmap scaling).
The Latin pass uses desktop Tesseract eng as a diagnostic surrogate. It does NOT
exercise Android ML Kit. No emulator/device or audio test was performed.

Captured bounding boxes feed the actual Kotlin MixedOcrFilter. before.txt uses the
previous filter; after.txt uses this revision. These are diagnostic outputs, NOT
hand-corrected transcriptions or a promise of identical device output.

Verified changes on the selected advert:
- Preserve Darya Muhamad and Gimeni Pro as recognized Latin names.
- Preserve 18 and the telephone 07765952001.
- Prevent an 82-confidence Latin Silo guess replacing 66-confidence Kurdish مانگ.
- Remove number-heavy rows anchored only by weak two-letter Kurdish guesses.
- Remove isolated unmatched bracket tokens generated from check icons.
- Read a wholly Latin logo row from left to right.

Known remaining recognition errors:
- The large Kurdish headline is not recovered accurately by the provided model.
- A check icon is still recognized as 0 in one row.
- Some Kurdish spelling remains wrong (e.g. تاببەتمندییەکان, دبنار).
- White-on-blue price appears as 5/000 and the IQD logo as 98 in native OCR;
  the desktop Latin pass misses that panel. No arbitrary price rewriting is applied.
- Stylized Zain logo is not reliably recognized; other logo fragments remain.
- Full-screen downscaling loses more detail than selecting just the advert.

No additional OCR passes, AI calls, delays or network requests were introduced by
these filter changes. Device latency has not been measured.

Reproduce diagnostic OCR (Tesseract 5, Python Pillow):
    python run_photo.py /path/to/1000018527.png /tmp/photo-output --tessdata /path/to/tessdata
The tessdata directory must contain the app's ckb.traineddata and an eng.traineddata.

Reproduce recorded-box filtering from project root (Kotlin compiler on PATH):
    kotlinc app/src/main/java/com/mangatranslator/app/MixedOcrFilter.kt verification/photo-ocr/PhotoRunner.kt -include-runtime -d /tmp/photo-filter.jar
    java -jar /tmp/photo-filter.jar
