package com.mangatranslator.app
fun main() {
val map=mapOf(" " to 37L,"ئ" to 16L,"ا" to 2L,"ب" to 9L,"ت" to 11L,"ج" to 26L,"ح" to 29L,"خ" to 19L,"د" to 8L,"ر" to 7L,"ز" to 22L,"س" to 15L,"ش" to 23L,"ع" to 31L,"غ" to 33L,"ف" to 28L,"ق" to 30L,"ک" to 10L,"ل" to 14L,"م" to 12L,"ن" to 4L,"ه" to 13L,"و" to 5L,"پ" to 24L,"چ" to 25L,"ڕ" to 27L,"ژ" to 21L,"ڤ" to 18L,"گ" to 20L,"ڵ" to 32L,"ۆ" to 17L,"ی" to 3L,"ێ" to 6L,"ە" to 1L,"_" to 0L,"^" to 0L,"\$" to 0L)
check(PiperTextEncoding.encode("سڵاو.",map,true)!!.contentEquals(longArrayOf(0L,15L,0L,32L,0L,2L,0L,5L,0L)))
check(PiperTextEncoding.encode("ئەمە دەنگی كوردییە.",map,true)!!.contentEquals(longArrayOf(0L,16L,0L,1L,0L,12L,0L,1L,0L,37L,0L,8L,0L,1L,0L,4L,0L,20L,0L,3L,0L,37L,0L,10L,0L,5L,0L,7L,0L,8L,0L,3L,0L,3L,0L,1L,0L)))
check(PiperTextEncoding.encode("سڵاو هاوڕێ، ئەمە یەکەم نموونەی دەنگی نوێیە.",map,true)!!.contentEquals(longArrayOf(0L,15L,0L,32L,0L,2L,0L,5L,0L,37L,0L,13L,0L,2L,0L,5L,0L,27L,0L,6L,0L,37L,0L,16L,0L,1L,0L,12L,0L,1L,0L,37L,0L,3L,0L,1L,0L,10L,0L,1L,0L,12L,0L,37L,0L,4L,0L,12L,0L,5L,0L,5L,0L,4L,0L,1L,0L,3L,0L,37L,0L,8L,0L,1L,0L,4L,0L,20L,0L,3L,0L,37L,0L,4L,0L,5L,0L,6L,0L,3L,0L,1L,0L)))
check(PiperTextEncoding.encode("ئەمڕۆ هەوا خۆشە و دەچین بۆ باخچە.",map,true)!!.contentEquals(longArrayOf(0L,16L,0L,1L,0L,12L,0L,27L,0L,17L,0L,37L,0L,13L,0L,1L,0L,5L,0L,2L,0L,37L,0L,19L,0L,17L,0L,23L,0L,1L,0L,37L,0L,5L,0L,37L,0L,8L,0L,1L,0L,25L,0L,3L,0L,4L,0L,37L,0L,9L,0L,17L,0L,37L,0L,9L,0L,2L,0L,19L,0L,25L,0L,1L,0L)))
println("PASS: Android text encoding matches exported HF tokenizer for all four reference checks")
}
