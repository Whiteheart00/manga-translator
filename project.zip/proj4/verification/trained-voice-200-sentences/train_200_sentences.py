from pathlib import Path
import os,sys,json,wave,random,re,time,hashlib,argparse
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('HF_HOME',str(ROOT/'hf-cache'));os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'mpl-cache'));os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
sys.path.insert(0,str(ROOT/'training'))
import numpy as np
import torch
import torch.nn.functional as F
from scipy.signal import resample_poly
from safetensors.torch import load_file,save_file
from transformers import AutoTokenizer
from utils import VitsConfig,VitsModelForPreTraining,VitsFeatureExtractor,slice_segments
from monotonic_align import maximum_path
P=argparse.ArgumentParser();P.add_argument('--steps',type=int,default=600);P.add_argument('--out',type=Path,default=ROOT/'run');P.add_argument('--eval-every',type=int,default=25);args=P.parse_args();args.out.mkdir(parents=True,exist_ok=True)
torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.manual_seed(2026);np.random.seed(2026);random.seed(2026)
config=VitsConfig.from_pretrained(ROOT/'base',local_files_only=True);model=VitsModelForPreTraining(config)
state=load_file(ROOT/'base/model.safetensors');state={k.replace('._orig_mod.','.'):v for k,v in state.items()};info=model.load_state_dict(state,strict=True);del state
print('Exact pretrained generator/discriminator load:',info,flush=True)
warm=load_file(ROOT/'run/generator.safetensors');current=model.state_dict();current.update(warm);model.load_state_dict(current,strict=True);del warm,current
print('Warm start: previous 200-step generator, original pretrained discriminator; optimizer starts fresh.',flush=True)
tok=AutoTokenizer.from_pretrained(ROOT/'base',local_files_only=True);fe=VitsFeatureExtractor.from_pretrained(ROOT/'base',local_files_only=True)
# Preserve the confirmed text separately; normalize only equivalent script codepoints for this tokenizer.
def normalize(text):
 text=text.replace('ک','ك').replace('ي','ی').replace('ى','ی').replace('ھ','ه').replace('ة','ە').replace('ـ','')
 return re.sub(r'\s+',' ',text).strip()
def make_item(path,text,key,split):
 with wave.open(str(path)) as w:
  sr=w.getframerate();x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 g=np.gcd(sr,16000);x=resample_poly(x,16000//g,sr//g).astype(np.float32)
 if len(x)<16000 or len(x)>16000*12:return None
 ntext=normalize(text);ids=tok(ntext,return_tensors='pt');assert int(ids.input_ids.max())<config.vocab_size
 with torch.no_grad():spec,mel=fe._torch_extract_fbank_features(torch.from_numpy(x)[None])
 assert spec.shape[-1]>=ids.input_ids.shape[-1],(key,'not enough frames for monotonic alignment')
 return {'key':key,'path':str(path),'text':text,'normalized_text':ntext,'split':split,'wave':torch.from_numpy(x)[None,None], 'spec':spec,'mel':mel,'ids':ids.input_ids,'mask':ids.attention_mask}
items=[]
manifest=json.load(open(ROOT/'numbered-corpus/candidate-manifest.json'))
assert len(manifest['sentences'])==200
for row in manifest['sentences']:
 n=row['sentence_number']
 if n==124:assert row['year_confirmed_by_user']==2026
 if n==191:assert row['text'].startswith('بەرەبەیان')
 item=make_item(Path(row['file']),row['text'],f'numbered_{n:03}','validation' if n%10==5 else 'train')
 assert item is not None,(n,'unexpected duration')
 items.append(item)
train=[x for x in items if x['split']=='train'];val=[x for x in items if x['split']=='validation'];assert len(train)==180 and len(val)==20
# Balanced shuffled epochs: all180 training clips receive gradient updates in each epoch.
schedule=[]
while len(schedule)<args.steps:
 epoch=train.copy();random.shuffle(epoch);schedule.extend(epoch)
json.dump([{k:v for k,v in x.items() if k not in ['wave','spec','mel','ids','mask']} for x in items],open(args.out/'data-split.json','w'),ensure_ascii=False,indent=2)
print('Data:',len(train),'train,',len(val),'validation; sample rate',config.sampling_rate,flush=True)
# Keep text pronunciation and duration prior fixed during this small adaptation.
for name,p in model.named_parameters():p.requires_grad_(not name.startswith(('text_encoder.','duration_predictor.')))
disc=model.discriminator;gp=[p for n,p in model.named_parameters() if not n.startswith('discriminator.') and p.requires_grad]
opt_g=torch.optim.AdamW(gp,lr=1e-5,betas=(.8,.99),weight_decay=.01);opt_d=torch.optim.AdamW(disc.parameters(),lr=1e-5,betas=(.8,.99),weight_decay=.01)
probe_name='decoder.conv_pre.weight';before=model.state_dict()[probe_name].detach().clone();initial_hash=hashlib.sha256(before.numpy().tobytes()).hexdigest()
def forward(item):return model(input_ids=item['ids'],attention_mask=item['mask'],labels=item['spec'],monotonic_alignment_function=maximum_path,return_dict=True)
def mel_loss(out,item):
 target=slice_segments(item['mel'],out.ids_slice,model.segment_size);generated=fe._torch_extract_fbank_features(out.waveform.squeeze(1))[1]
 return F.l1_loss(target,generated)
def kl_loss(out):
 kl=out.prior_log_variances-out.posterior_log_variances-.5+.5*((out.prior_latents-out.prior_means)**2)*torch.exp(-2*out.prior_log_variances)
 return torch.sum(kl*out.labels_padding_mask)/torch.sum(out.labels_padding_mask)
def validate():
 rng=torch.random.get_rng_state();model.eval();values=[]
 with torch.no_grad():
  for i,x in enumerate(val):torch.manual_seed(5000+i);values.append(float(mel_loss(forward(x),x)))
 torch.random.set_rng_state(rng);model.train();model.text_encoder.eval();model.duration_predictor.eval()
 return float(np.mean(values))
texts=['سڵاو هاوڕێ، ئەمە دەنگێکە کە بە تۆمارە نوێیەکان ڕاهێنراوە.','لە ئێوارەیەکی ئارامدا، من و هاوڕێکەم لە باخچەکە پیاسەمان کرد.']
def preview(prefix):
 rng=torch.random.get_rng_state();model.eval()
 with torch.no_grad():
  for i,text in enumerate(texts,1):
   torch.manual_seed(660+i);ids=tok(normalize(text),return_tensors='pt');y=model(**ids).waveform[0].cpu().numpy();peak=float(np.max(np.abs(y)));gain=min(1.,.95/max(peak,1e-12));pcm=(np.clip(y*gain,-1,1)*32767).astype('<i2')
   with wave.open(str(args.out/f'{prefix}-{i}.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(config.sampling_rate);w.writeframes(pcm.tobytes())
 torch.random.set_rng_state(rng);model.train();model.text_encoder.eval();model.duration_predictor.eval()
def save_checkpoint(step,score):
 sd={n:p.detach().cpu().contiguous() for n,p in model.state_dict().items() if not n.startswith('discriminator.')};save_file(sd,str(args.out/'generator.safetensors'))
 config.save_pretrained(args.out);tok.save_pretrained(args.out);fe.save_pretrained(args.out)
 json.dump({'step':step,'validation_mel_l1':score,'initial_probe_hash':initial_hash,'current_probe_hash':hashlib.sha256(model.state_dict()[probe_name].detach().numpy().tobytes()).hexdigest(),'probe_weight_l2_change':float(torch.linalg.vector_norm(model.state_dict()[probe_name].detach()-before))},open(args.out/'checkpoint-info.json','w'),indent=2)
baseline=validate();print('Baseline held-out mel L1:',baseline,flush=True);preview('before');best=baseline;records=[];start=time.monotonic()
for step in range(1,args.steps+1):
 t=time.monotonic();item=schedule[step-1];model.train();model.text_encoder.eval();model.duration_predictor.eval();out=forward(item)
 target=slice_segments(item['wave'],out.ids_slice*fe.hop_length,config.segment_size)
 for p in disc.parameters():p.requires_grad_(True)
 opt_d.zero_grad(set_to_none=True);real,_=disc(target);fake,_=disc(out.waveform.detach());loss_d=sum(((1-r)**2).mean()+(f*f).mean() for r,f in zip(real,fake));(loss_d*3).backward();torch.nn.utils.clip_grad_norm_(disc.parameters(),1.);opt_d.step();opt_d.zero_grad(set_to_none=True)
 for p in disc.parameters():p.requires_grad_(False)
 opt_g.zero_grad(set_to_none=True)
 with torch.no_grad():_,maps_real=disc(target)
 fake,maps_fake=disc(out.waveform);fm=sum((r.detach()-f).abs().mean() for mr,mf in zip(maps_real,maps_fake) for r,f in zip(mr,mf))*2;adv=sum(((1-f)**2).mean() for f in fake);ml=mel_loss(out,item);kl=kl_loss(out);loss=35*ml+1.5*kl+fm+adv
 assert torch.isfinite(loss) and torch.isfinite(loss_d),(step,'nonfinite loss');loss.backward();grad=torch.nn.utils.clip_grad_norm_(gp,1.);assert torch.isfinite(grad);opt_g.step()
 row={'step':step,'key':item['key'],'mel_l1':float(ml.detach()),'kl':float(kl.detach()),'generator_loss':float(loss.detach()),'discriminator_loss':float(loss_d.detach()),'gradient_norm':float(grad),'seconds':round(time.monotonic()-t,3)};records.append(row)
 if step==1 or step%5==0:print(json.dumps(row),flush=True)
 if step==1 or step%args.eval_every==0 or step==args.steps:
  score=validate();row['validation_mel_l1']=score;print('HELDOUT',step,score,'elapsed',round(time.monotonic()-start,1),flush=True)
  if score<best or step==1:best=min(best,score);save_checkpoint(step,score);preview('adapted')
 (args.out/'training-log.json').write_text(json.dumps(records,indent=2)+'\n')
# Preserve final as well, even if it is not best; no claims of perceived voice match.
change=float(torch.linalg.vector_norm(model.state_dict()[probe_name].detach()-before));assert change>0
json.dump({'steps_completed':args.steps,'baseline_validation_mel_l1':baseline,'best_validation_mel_l1':best,'probe_weight_l2_change':change,'elapsed_seconds':time.monotonic()-start,'train_clips':len(train),'validation_clips':len(val),'warm_start':'previous200-step generator; original discriminator; fresh optimizers','data_note':'200 ASR-crosschecked candidates; no manual boundary listening;180train20heldout;no pitch effects','quality_note':'Mel reconstruction is not voice identity, intelligibility or mobile validation.'},open(args.out/'result.json','w'),indent=2)
print('TRAINING_COMPLETE',args.steps,'weight_change',change,flush=True)
