from pathlib import Path
import os,sys,argparse,json,hashlib,wave,time
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('HF_HOME',str(ROOT/'hf-cache'));os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'mpl-cache'))
sys.path.insert(0,str(ROOT/'training'))
import torch,numpy as np
from safetensors.torch import load_file
from transformers import AutoTokenizer
from utils.modeling_vits_training import VitsModel
from utils import VitsConfig
P=argparse.ArgumentParser();P.add_argument('--checkpoint',type=Path,required=True);P.add_argument('--out',type=Path,required=True);args=P.parse_args();args.out.mkdir(parents=True,exist_ok=True)
torch.set_num_threads(1);torch.set_num_interop_threads(1)
config=VitsConfig.from_pretrained(args.checkpoint,local_files_only=True)
model=VitsModel(config)
file=args.checkpoint/'generator.safetensors'
if not file.exists():file=args.checkpoint/'model.safetensors'
sd=load_file(file);sd={k.replace('._orig_mod.','.'):v for k,v in sd.items() if not k.startswith('discriminator.')};model.load_state_dict(sd,strict=True);del sd;model.eval()
tok=AutoTokenizer.from_pretrained(args.checkpoint,local_files_only=True)
class Wrapper(torch.nn.Module):
 def __init__(self,m):super().__init__();self.model=m
 def forward(self,input,input_lengths,scales):
  mask=(torch.arange(input.shape[1],device=input.device)[None,:]<input_lengths[:,None]).long()
  self.model.noise_scale=scales[0];self.model.speaking_rate=1./scales[1];self.model.noise_scale_duration=scales[2]
  return self.model(input_ids=input,attention_mask=mask,return_dict=True).waveform.unsqueeze(1)
w=Wrapper(model).eval();text='سڵاو هاوڕێ.';ids=tok(text.replace('ک','ك'),return_tensors='pt').input_ids;lengths=torch.tensor([ids.shape[1]],dtype=torch.long);scales=torch.tensor([0.,1.,0.],dtype=torch.float32)
with torch.no_grad():
 torch.onnx.export(w,(ids,lengths,scales),str(args.out/'model.onnx'),input_names=['input','input_lengths','scales'],output_names=['output'],dynamic_axes={'input':{0:'batch',1:'phones'},'input_lengths':{0:'batch'},'output':{0:'batch',2:'samples'}},opset_version=17,do_constant_folding=True)
import onnx,onnxruntime as ort
onnx.checker.check_model(str(args.out/'model.onnx'))
opt=ort.SessionOptions();opt.intra_op_num_threads=1;session=ort.InferenceSession(str(args.out/'model.onnx'),sess_options=opt,providers=['CPUExecutionProvider'])
report={'inputs':{x.name:[x.shape,x.type] for x in session.get_inputs()},'checks':[]}
texts=['سڵاو.','باشی هاوڕێ؟','من لێرەم.','ئەمڕۆ هەوا خۆشە و دەچین بۆ باخچە.','سڵاو هاوڕێ، ئەمە دەنگێکە کە بە تۆمارە نوێیەکان ڕاهێنراوە.','لە ئێوارەیەکی ئارامدا، من و هاوڕێکەم لە باخچەکە پیاسەمان کرد.']
for i,text in enumerate(texts,1):
 ids=tok(text.replace('ک','ك'),return_tensors='pt').input_ids;lens=torch.tensor([ids.shape[1]])
 with torch.no_grad():expected=w(ids,lens,scales).numpy()
 start=time.monotonic();actual=session.run(None,{'input':ids.numpy(),'input_lengths':lens.numpy(),'scales':scales.numpy()})[0];elapsed=time.monotonic()-start
 assert actual.shape==expected.shape,(actual.shape,expected.shape)
 error=float(np.max(np.abs(actual-expected)));assert error<.005,(text,error)
 noisy=session.run(None,{'input':ids.numpy(),'input_lengths':lens.numpy(),'scales':np.array([.4,1.,.55],np.float32)})[0].flatten()
 assert np.isfinite(noisy).all() and len(noisy)>1600
 gain=min(1.,.95/max(float(np.max(np.abs(noisy))),1e-12))
 with wave.open(str(args.out/f'onnx-sample-{i}.wav'),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(config.sampling_rate);f.writeframes((np.clip(noisy*gain,-1,1)*32767).astype('<i2').tobytes())
 report['checks'].append({'text':text,'ids':ids.numpy().tolist()[0],'samples':actual.shape[-1],'max_abs_error_pytorch_vs_ort':error,'cpu_seconds':elapsed});print(report['checks'][-1],flush=True)
vocab=json.load(open(args.checkpoint/'vocab.json'));mapping={}
for ch,i in vocab.items():
 if len(ch)==1 and (ch==' ' or '\u0620'<=ch<='\u06ff'):mapping['ک' if ch=='ك' else ch]=[i]
mapping.update({'_':[0],'^':[0],'$':[0]})
cfg={'audio':{'sample_rate':config.sampling_rate},'phoneme_type':'text','sequence_style':'blank_interleaved','use_model_timing':True,'phoneme_id_map':mapping,'num_speakers':1,'inference':{'noise_scale':.4,'length_scale':1.,'noise_w':.55},'voice_name':'Female reference — 200-sentence adaptation (experimental)','source_repository':'akam-ot/ckb-tts'}
(args.out/'model.onnx.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n');report['model_bytes']=(args.out/'model.onnx').stat().st_size;report['sha256']=hashlib.sha256((args.out/'model.onnx').read_bytes()).hexdigest();(args.out/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('EXPORT_VALIDATED',report['model_bytes'],flush=True)
