from pathlib import Path
import json,numpy as np,onnxruntime as ort,unicodedata,time,gc,statistics
r=Path(__file__).resolve().parent;text='ئەمڕۆ هەوا خۆشە و دەچین بۆ باخچە.';rows=[]
for label,path in [('original_fast',Path('/workspace/voice-investigation')),('previous_adaptation',r/'trained-onnx'),('adapted_200_sentences',r/'trained-200sentences-onnx')]:
 cfg=json.load(open(path/'model.onnx.json'));m=cfg['phoneme_id_map'];isnew=cfg.get('sequence_style')=='blank_interleaved';t=unicodedata.normalize('NFC' if isnew else 'NFD',text.replace('ك','ک').replace('ي','ی').replace('ى','ی').replace('ة','ە'))
 ids=[m['_'][0] if isnew else m['^'][0]]
 for c in t:
  if c in m and c not in '^$_':ids.extend([m[c][0],m['_'][0]])
 if not isnew:ids+=m['$']
 op=ort.SessionOptions();op.intra_op_num_threads=2;op.inter_op_num_threads=1;s=ort.InferenceSession(str(path/'model.onnx'),sess_options=op,providers=['CPUExecutionProvider']);feed={'input':np.array([ids],np.int64),'input_lengths':np.array([len(ids)],np.int64),'scales':np.array([.4,1.,.55],np.float32)}
 if 'sid' in {x.name for x in s.get_inputs()}:feed['sid']=np.array([0],np.int64)
 s.run(None,feed);timings=[];ratios=[];dur=[]
 for i in range(5):
  start=time.monotonic();y=s.run(None,feed)[0].flatten();elapsed=time.monotonic()-start;assert np.isfinite(y).all();length=len(y)/cfg['audio']['sample_rate'];timings.append(elapsed);ratios.append(elapsed/length);dur.append(length)
 row={'model':label,'threads':2,'median_compute_seconds':statistics.median(timings),'median_audio_seconds':statistics.median(dur),'median_real_time_factor':statistics.median(ratios),'repeat_seconds':timings};rows.append(row);print(row,flush=True);del s;gc.collect()
(r/'run-200sentences/runtime-benchmark.json').write_text(json.dumps({'scope':'idle desktop CPU; not Android/phone/battery/thermal validation','sentence':text,'models':rows},indent=2)+'\n')
