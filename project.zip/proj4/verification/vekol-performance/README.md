# Vekol Edge comparison and runtime tuning — 1.3.25

The public Vekol model was pinned to revision 64037ebd9dedeacb7b946752d474a3a265b3f853 and its download SHA-256 checked. It has about 19.03 million initializer elements, versus 28.27 million in the female graph. Its waveform decoder starts with 256 channels and 3 transposed-convolution upsampling stages; the female decoder starts with 512 channels and 4 stages. Vekol also has fewer convolution/nonlinearity operations. File size alone is misleading: the female download stores many weights in float16 but still computes in float32.

Both graphs were benchmarked on the same server with 2 intra-op / 1 inter-op threads and their own correct encoders/default noise settings. Three texts were repeated three times. Median real-time factors were approximately 0.080 for Vekol and 0.247 for the female model, about a 3.08-fold ratio on this server. Output durations and learned voices differ. The Python benchmark runtime is recorded in benchmark.json; it is not a phone measurement or the Android runtime version.

A mathematically equivalent Conv1D-to-Conv2D rewrite retained waveform SNR above 82 dB in deterministic comparisons, but one case got slower and timing variation was substantial. The candidate is not distributed or enabled.

The app previously forced reference/female models to 2 CPU threads while the legacy Piper path used 4 on capable phones. The reference path now uses up to 4 threads on capable devices, up to 2 in low-RAM mode, capped by available processors. Inter-op threads are explicitly 1. The actual SessionOptions code was extracted, compiled and run against ONNX Runtime 1.19.2. All 58 existing unit tests passed. This policy has not been benchmarked on the user's phone; a higher thread count is not guaranteed faster on every CPU.

There are no changes to the learned female weights, tokenization, voice profiles, first-use handoff or punctuation-only 20-ms padding. No Vekol weights are bundled. Vekol's own NOTICE identifies a non-commercial license; inspecting its architecture does not convert the female model into Vekol or transfer its voice. Achieving its smaller decoder cost with the female voice requires a separately trained/distilled smaller model, not a thread-setting change.

A complete Android build and physical-device performance test were not performed in this environment. Keep using the original-key GitHub Secret when building an update.
