package com.mangatranslator.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import kotlin.math.sqrt

/** JVM integration probe using the actual app encoder and its ONNX Runtime version. */
fun main(args: Array<String>) {
    require(args.size in 3..4) { "model.onnx model.onnx.json report.json [female-recipe]" }
    val femaleRecipe = args.getOrNull(3) == "female-recipe"
    val config = JSONObject(File(args[1]).readText())
    val inference = PiperModelConfig.inference(config)
    check(inference.referenceVoice)
    check(config.getJSONObject("audio").getInt("sample_rate") == 16000)
    val jsonMap = config.getJSONObject("phoneme_id_map")
    val map = jsonMap.keys().asSequence().associateWith { jsonMap.getJSONArray(it).getLong(0) }
    val report = JSONArray()
    val environment = OrtEnvironment.getEnvironment()
    OrtSession.SessionOptions().use { options ->
        options.setIntraOpNumThreads(2)
        options.setInterOpNumThreads(1)
        environment.createSession(args[0], options).use { session ->
            for (text in listOf("نا", "سڵاو", "ئەک", "سوپاس بۆ هاوکاریت.",
                "ئەمڕۆ هەوا خۆشە و دەچین بۆ باخچە.", "سڵاو،\n  هاوڕێ")) {
                val ids = checkNotNull(PiperTextEncoding.encode(text, map, inference.blankInterleaved, true))
                val scales = floatArrayOf(inference.noise, inference.length, inference.durationNoise)
                OnnxTensor.createTensor(environment, LongBuffer.wrap(ids), longArrayOf(1, ids.size.toLong())).use { input ->
                    OnnxTensor.createTensor(environment, LongBuffer.wrap(longArrayOf(ids.size.toLong())), longArrayOf(1)).use { lengths ->
                        OnnxTensor.createTensor(environment, FloatBuffer.wrap(scales), longArrayOf(3)).use { settings ->
                            session.run(mapOf("input" to input, "input_lengths" to lengths, "scales" to settings)).use { output ->
                                val buffer = (output[0] as OnnxTensor).floatBuffer
                                val raw = FloatArray(buffer.remaining()); buffer.get(raw)
                                val samples = if (femaleRecipe) FemaleVoiceRecipe.process(raw, 16000) else raw
                                check(samples.size == raw.size)
                                check(samples.isNotEmpty() && samples.size <= 16000 * 30)
                                check(samples.all { it.isFinite() })
                                val rms = sqrt(samples.sumOf { it.toDouble() * it } / samples.size)
                                check(rms > 1e-5)
                                report.put(JSONObject().put("text", text).put("ids", JSONArray(ids.toList()))
                                    .put("scales", JSONArray(scales.toList())).put("samples", samples.size).put("rms", rms)
                                    .put("female_recipe", femaleRecipe))
                            }
                        }
                    }
                }
            }
        }
    }
    File(args[2]).writeText(report.toString(2))
    println("App encoder + ONNX Runtime 1.19.2: ${report.length()} successful finite, non-silent checks")
}
