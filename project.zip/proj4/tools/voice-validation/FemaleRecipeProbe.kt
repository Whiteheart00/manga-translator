package com.mangatranslator.app

import java.io.File
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.AudioInputStream
import javax.sound.sampled.AudioFileFormat
import java.io.ByteArrayInputStream
import kotlin.math.*

/** Run the actual Android-independent DSP against an existing mono PCM16 fixture. */
fun main(args: Array<String>) {
    val stream=AudioSystem.getAudioInputStream(File(args[0]))
    val format=stream.format
    require(format.channels==1 && format.sampleSizeInBits==16 && !format.isBigEndian)
    val bytes=stream.use { it.readBytes() }
    val input=FloatArray(bytes.size/2) { i ->
        (((bytes[2*i].toInt() and 255) or (bytes[2*i+1].toInt() shl 8)).toShort().toInt()/32768f)
    }
    val started=System.nanoTime()
    val output=FemaleVoiceRecipe.process(input,format.sampleRate.toInt())
    val elapsed=(System.nanoTime()-started)/1e9
    require(output.size==input.size && output.all { it.isFinite() && abs(it)<1 })
    val pcm=ByteArray(output.size*2)
    output.forEachIndexed { i,v ->
        val n=(v*32767).roundToInt().coerceIn(-32768,32767)
        pcm[2*i]=n.toByte();pcm[2*i+1]=(n shr 8).toByte()
    }
    val audio=AudioInputStream(ByteArrayInputStream(pcm),AudioFormat(format.sampleRate,16,1,true,false),output.size.toLong())
    AudioSystem.write(audio,AudioFileFormat.Type.WAVE,File(args[1]))
    println("{\"samples\":${output.size},\"sample_rate\":${format.sampleRate},\"processing_seconds\":$elapsed,\"estimated_lufs\":${FemaleVoiceRecipe.integratedLufs(output,format.sampleRate.toInt())}}")
}
