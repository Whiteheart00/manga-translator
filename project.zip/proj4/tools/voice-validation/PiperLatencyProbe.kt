package com.mangatranslator.app

import ai.onnxruntime.*
import org.json.*
import java.io.File
import java.nio.*

/** Local server measurements, not an Android timing claim. */
private fun oldChunks(s:String):List<String> {
    val out=ArrayList<String>()
    for(sent in s.split(Regex("(?<=[.!?؟\\n])\\s*")).map { it.trim() }.filter { it.isNotEmpty() }) {
        if(sent.length<=80) {out.add(sent);continue}
        val cur=StringBuilder()
        for(w in sent.split(' ')) {
            if(w.isEmpty())continue
            if(cur.isNotEmpty())cur.append(' ')
            cur.append(w)
            val comma=w.endsWith("،")||w.endsWith(",")||w.endsWith("؛")
            if(cur.length>=80 || (comma && cur.length >= if(out.isEmpty())18 else 35)) {
                out.add(cur.toString());cur.setLength(0)
            }
        }
        if(cur.isNotEmpty()) {
            if(cur.length<8 && out.isNotEmpty())out[out.lastIndex]=out.last()+" "+cur else out.add(cur.toString())
        }
    }
    return out
}
fun main(args:Array<String>) {
    val text=File(args[2]).readText()
    val cfg=JSONObject(File(args[1]).readText());val inf=PiperModelConfig.inference(cfg)
    val jm=cfg.getJSONObject("phoneme_id_map")
    val map=jm.keys().asSequence().associateWith {jm.getJSONArray(it).getLong(0)}
    val env=OrtEnvironment.getEnvironment();val start=System.nanoTime()
    OrtSession.SessionOptions().use { options ->
        options.setIntraOpNumThreads(2);options.setInterOpNumThreads(1)
        env.createSession(args[0],options).use {session ->
            val load=(System.nanoTime()-start)/1e9
            fun synth(text:String):FloatArray {
                val ids=checkNotNull(PiperTextEncoding.encode(text,map,true,true))
                OnnxTensor.createTensor(env,LongBuffer.wrap(ids),longArrayOf(1,ids.size.toLong())).use {input ->
                    OnnxTensor.createTensor(env,LongBuffer.wrap(longArrayOf(ids.size.toLong())),longArrayOf(1)).use {lengths ->
                        OnnxTensor.createTensor(env,FloatBuffer.wrap(floatArrayOf(inf.noise,inf.length,inf.durationNoise)),longArrayOf(3)).use {scales ->
                            session.run(mapOf("input" to input,"input_lengths" to lengths,"scales" to scales)).use {out ->
                                val b=(out[0] as OnnxTensor).floatBuffer;val y=FloatArray(b.remaining());b.get(y);check(y.all {it.isFinite()});return y
                            }
                        }
                    }
                }
            }
            val warmStart=System.nanoTime();synth("سڵاو.");val warm=(System.nanoTime()-warmStart)/1e9
            val report=JSONObject().put("server_session_load_seconds",load).put("server_warmup_seconds",warm)
                .put("limits","Local JVM/ONNX server timings only. No Android benchmark or listening assessment. Model weights unchanged.")
            for((name,parts) in listOf("previous" to oldChunks(text),"new" to PiperSpeechTiming.chunks(text))) {
                val rows=JSONArray();var inference=0.0;var process=0.0;var addedPause=0;var edgeRemoved=0.0
                for(part in parts) {
                    val t=System.nanoTime();val raw=synth(part);val dt=(System.nanoTime()-t)/1e9
                    val t2=System.nanoTime();val trimmed=if(name=="new")PiperSpeechTiming.trimEdges(raw,16000) else raw
                    val processed=FemaleVoiceRecipe.process(trimmed,16000);val dp=(System.nanoTime()-t2)/1e9
                    val pause=if(name=="new")PiperSpeechTiming.pauseMs(part,false) else if(part.replace(Regex("[.؟!،]"),"").trim().length<40)280 else 100
                    inference+=dt;process+=dp;addedPause+=pause;edgeRemoved+=(raw.size-trimmed.size)/16000.0
                    rows.put(JSONObject().put("text",part).put("characters",part.length).put("inference_seconds",dt)
                        .put("processing_seconds",dp).put("raw_audio_seconds",raw.size/16000.0)
                        .put("processed_audio_seconds",processed.size/16000.0).put("added_pause_ms",pause))
                }
                report.put(name,JSONObject().put("chunks",rows).put("chunk_count",parts.size)
                    .put("inference_seconds",inference).put("processing_seconds",process)
                    .put("added_pause_ms",addedPause).put("boundary_silence_removed_seconds",edgeRemoved))
            }
            File(args[3]).writeText(report.toString(2));println(report.toString(2))
        }
    }
}
