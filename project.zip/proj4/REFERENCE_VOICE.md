# Reference voice integration — 1.3.20

This update connects the provided app to the newly exported `sorani-reference-vits-v1` model. The model ZIP stays separate from the source and APK.

## بەکارهێنان

١. لە ڕێکخستنی دەنگ، «دەنگی فێرکراوی تۆ (تاقیکاری)» هەڵبژێرە.
٢. ZIPی `sorani-female-voice-onnx.zip` لە بەشی هێنانی مۆدێل بهێنە ناو ئەپ.
٣. بۆ بیستنی دەنگی مۆدێل بەبێ زیادکردنی pitch، تۆنی «دەنگی ڕەسەن» هەڵبژێرە.

مۆدێل و نموونەی دەنگ: https://gofile.io/d/h1xZxfOL

## Changes

- Recognize the new format independently of the older `sequence_style` flag.
- Use the same Kurdish character normalization, punctuation spacing and blank interleaving as the exported model. Preserve hamza and map Kurdish kaf to the actual vocabulary.
- Honor the reference model's noise settings (0.3 / 0.3) and its length scale without the legacy 1.08 timing multiplier.
- Reset inference settings on every model load, so switching model slots does not retain another model's scales.
- Use two CPU inference threads for this reference model.
- Keep the existing original Piper model and earlier blank-interleaved models supported.

## Validation

- Kotlin 1.9.24 compilation and 18 relevant JUnit tests passed, including the original encoding/model-choice/profile checks and nine new regression tests.
- The actual app encoder and configuration parser were exercised with the actual compact ONNX model in ONNX Runtime **1.19.2**, matching the Android dependency: six short/novel/Unicode cases produced finite, non-silent 16 kHz output.
- Reports are under `tools/voice-validation/`.
- Full Android Gradle compilation, APK generation, physical-phone import and AudioTrack playback were not performed. This environment has no Android SDK or installed Gradle. Existing Android CI remains the build check.
- The supplied source archive does not contain `app/debug.keystore`. Keep the original project's signing key when building updates; this change does not create or replace it.

The voice model remains experimental. Speaker similarity and pronunciation vary by sentence; matching the app's encoder does not guarantee perfect speech or phone latency.
