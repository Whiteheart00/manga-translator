# Local Piper voice tones

Voice settings now include Original, Soft male and Soft feminine tone. They apply
only to the local Piper engine and retain the selected voice-output route. Existing
installations default to Original (no new pitch or smoothing settings applied).

Soft feminine is an effect on the current speaker, not a newly trained female
voice/model. The upstream config declares two speakers but documents only Berfin=0;
no unknown speaker embedding is promoted or relabeled. Model weights and speaker ID
remain unchanged.

- Original: pitch 1.00, existing two-stage low-pass 7000 Hz, target RMS 0.100.
- Soft male: pitch 1.00, low-pass 5600 Hz, target RMS 0.095.
- Soft feminine: pitch 1.22 (about +3.44 semitones), low-pass 6000 Hz, RMS 0.095.

The existing DC blocker, trim, fades, peak limit, signal rejection and queue remain.
There is no extra ONNX inference, model download, cloud call or processing loop.
Softening reuses the existing low-pass and gain passes. Native Android pitch shifting
adds platform-dependent CPU work/latency; this was not measured on a device.

The tone is captured once per speaking session and passed through render/prefetch
explicitly. Processed audio cache keys include tone ID so switching tones cannot
play another tone's cached audio. The low-latency flag, synthesis speed and chunking
retain their existing behavior.

Feminine pitch uses AudioTrack PlaybackParams pitch=1.22 and speed=1.00; it does not
use sample-rate retagging to speed up speech. Parameters are applied once after PCM
is queued, immediately before play, to avoid accidental early playback on Android
versions where setPlaybackParams can resume a track. An unsupported platform effect
reports through the existing playback-error path instead of silently changing tempo.

## Preview and validation limits

The preview WAVs derive from the exact same generated PCM as the previous clean
sample. Python mirrors the softening; FFmpeg Rubber Band shifts feminine pitch
with tempo=1 and shifted formants. The two previews have equal duration (3.78458s),
22050 Hz mono PCM16 and no full-scale/clipped samples.

Android's native pitch algorithm differs from Rubber Band: previews demonstrate
the intended tone and are NOT recordings of app playback. Naturalness/softness are
subjective and were not validated by a listening panel. No new female voice was
trained. No phone/AudioTrack effect, mobile latency, audio route or heat/battery test
was performed. App unit/source checks are documented in VALIDATION.md.

Use Voice settings -> local Kurdish neural voice -> voice tone; Save or Test.
The profile does not affect Pawan, Gemini or Android system TTS.

Source-only delivery. No APK assembled or supplied.
