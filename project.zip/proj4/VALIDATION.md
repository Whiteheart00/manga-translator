# 200-sentence voice validation

Kotlin integration is unchanged from the previously compiled Android source with
311 passing unit tests across42 suites. This update changes model weights and
documentation only. No APK built. New model passed ONNX checks and CPU/PyTorch
parity, short/novel synthesis and actual Kotlin token-ID checks. Desktop runtime
and novel ASR reports included; ASR is not listening/identity validation.
No physical Android import/playback/latency/thermal/battery test performed.
See TRAINED_VOICE.md and verification/trained-voice-200-sentences for exact results.
