# Actual adaptation using the user's 200 sentences

Completed600 additional real GAN gradient steps;180 training/20 held-out clips.
Warm start from the earlier200-step generator; original pinned pretrained
discriminator and fresh AdamW optimizers. This is not full optimizer resume.
Base akam-ot/ckb-tts revision5099a6f2bc776ffbca3445a348ba32ffca664491;
training ylacombe/finetune-hf-vits commit6f3f51f4d667f5c3eef89484d151ffd39d2c2b89.
Text/duration modules frozen; decoder/posterior/flow/discriminator updated.
All180 training clips seen in each shuffled epoch; held-out IDs end in5.
No exact normalized text matches between these held-outs and warm-start training.
Source cuts automated and locally ASR-crosschecked, not manually listened to.
Year124=2026 user-confirmed;191–200 alternate transcript supplied by user;
198 uses the correct تا پێکەوە کار بکەین, never the incorrect ASR draft.
No user audio uploaded to any remote service.

Held-out mel L1 before=0.6087969;
best=0.5593525; selected checkpoint step=600.
These are reconstruction metrics, not speaker identity/naturalness/gender scores.
Changed generator probe hashes/finite gradients and data hashes are recorded.
Generator checkpoint only; trained discriminator/optimizer resume state not saved.
No pitch shift in supplied trained previews. Rough pitch is only a diagnostic.
ASR on new text is imperfect and not a listening assessment. Some short phrases
were recognized accurately, while a longer introduction had substantial errors.
Those may be unclear synthesis or ASR failure; flawless pronunciation is not
established. User listening is
needed to judge voice similarity, softness and suitability as a woman's voice.

ONNX float generator:16kHz mono;114306764 bytes.
NFC text + blank interleaving; app-compatible input,input_lengths,scales; no sid.
CPU checker/parity/finite-output checks include short utterances and novel text.
Original/trained model slots remain separate; original fast voice stays default.
The Kotlin integration code is unchanged from the version with311 passing tests;
new export token IDs are checked independently with the actual Kotlin encoder.
General English pronunciation is not established by this Kurdish training.
No physical Android import/AudioTrack, sustained heat/battery or phone benchmark.
Larger adapted model remains slower than original on desktop. Do not claim equal
live-subtitle latency; measurements are included. No APK generated/delivered.

Preserve upstream model/MMS license terms and MIT code attribution. Do not publish
the user's voice data/model without authorization. This text does not relicense it.
