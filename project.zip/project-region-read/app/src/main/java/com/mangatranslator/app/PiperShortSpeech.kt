package com.mangatranslator.app

/** Punctuation-only retries; never add words or slow down the requested rate. */
internal object PiperShortSpeech {
    fun render(
        sentence: String,
        bare: String,
        sampleRate: Int,
        synthesize: (String) -> FloatArray?,
        polish: (FloatArray) -> FloatArray
    ): FloatArray {
        for (variant in listOf(sentence, " $bare .", "$bare، .", " $bare ، .").distinct()) {
            val raw = synthesize(variant) ?: continue
            if (!PcmSignal.hasSignal(raw, sampleRate)) continue
            val result = polish(raw)
            if (PcmSignal.hasSignal(result, sampleRate)) return result
        }
        return FloatArray(0)
    }
}

internal object PiperPlayback {
    /** Keep the original two-second buffer for long audio; fit short audio. */
    fun bufferBytes(minBytes: Int, sampleRate: Int, firstSamples: Int): Int =
        maxOf(minBytes, minOf(sampleRate * 4, firstSamples * 2))

    /** Fill the actual native buffer with trailing silence if the first clip is tiny. */
    fun fillFirstBuffer(pcm: ShortArray, bufferFrames: Int): ShortArray =
        if (pcm.size < bufferFrames) pcm.copyOf(bufferFrames) else pcm
}
