package com.mangatranslator.app

import kotlin.math.abs

/** یەک بلۆکی دەق لەناو وێنەی ڕووبەر (پیکسێلی crop). */
data class Blk(val text: String, val l: Int, val t: Int, val r: Int, val b: Int)

/**
 * واتەرمارک و نووسینی جێگیری یاری/ڤیدیۆ (ناوی کەناڵ «MKIceAndFire»، «X=SELECT»...) لە ژێرنووسی زیندوو لادەبات.
 *  ١) یەکسەر: ناوی تاکی وشەیی بە پیتی تێکەڵ (camelCase) یان @user / #tag ← واتەرمارکە.
 *  ٢) فێربوون: بلۆکێک کە لە هەمان شوێن و بە دەقێکی هاوشێوە زیاتر لە [staticMs] (٦ چرکە) بەردەوام بێت ← جێگیرە (ژێرنووس نییە)،
 *     و تا [keepMs] دوای ون بوونیشی هەر لادەبرێت. جیاوازیی OCR (MKIceAndFire / MKceAndFire / Mklceand) هەر وەک هەمان بلۆک دەژمێردرێت.
 * لە یەک thread ی تەنها بەکاربهێنرێت.
 */
class WatermarkFilter(
    private val staticMs: Long = 6_000L,
    private val gapMs: Long = 4_000L,
    private val keepMs: Long = 60_000L
) {
    private class Track(var b: Blk, var first: Long, var last: Long) {
        var isStatic = false
    }

    private val tracks = ArrayList<Track>()

    fun reset() = tracks.clear()

    fun filter(blocks: List<Blk>, now: Long, cw: Int, ch: Int): List<Blk> {
        tracks.removeAll { now - it.last > (if (it.isStatic) keepMs else gapMs) }
        val out = ArrayList<Blk>(blocks.size)
        val used = HashSet<Track>()
        for (b in blocks) {
            if (looksLikeHandle(b.text)) continue
            val tr = tracks.firstOrNull { it !in used && near(it.b, b, cw, ch) && similar(it.b.text, b.text) }
            if (tr == null) {
                val t = Track(b, now, now)
                tracks.add(t); used.add(t)
                out.add(b)
                continue
            }
            used.add(tr)
            // بەردەوامی: ئەگەر بلۆکەکە ماوەیەک نەبینرا (ژێرنووسێکی دووبارەبووەوە)، ژمێرەکە لە سەرەتاوە دەست پێدەکات
            if (!tr.isStatic && now - tr.last > CONT_MS) tr.first = now
            tr.b = b
            tr.last = now
            if (!tr.isStatic && now - tr.first >= staticMs) tr.isStatic = true
            if (!tr.isStatic) out.add(b)
        }
        return out
    }

    companion object {
        private const val CONT_MS = 1_500L
        private val HANDLE = Regex("^[@#][\\w.]{3,}$|^[A-Za-z0-9_.-]*[a-z][A-Z][A-Za-z0-9_.-]*$")

        /** ناوی کەناڵ/بەکارهێنەر: یەک وشە، بێ بۆشایی، پیتی بچووک و گەورە تێکەڵ */
        fun looksLikeHandle(raw: String): Boolean {
            val s = raw.trim()
            return s.length >= 6 && !s.contains(' ') && HANDLE.matches(s)
        }

        private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

        fun similar(a: String, b: String): Boolean {
            val x = norm(a); val y = norm(b)
            if (x.isEmpty() || y.isEmpty()) return false
            if (x == y || x.contains(y) || y.contains(x)) return true
            val m = maxOf(x.length, y.length)
            if (abs(x.length - y.length) > m / 2) return false
            return lev(x, y) <= (m * 0.45f).toInt()
        }

        private fun lev(a: String, b: String): Int {
            var prev = IntArray(b.length + 1) { it }
            var cur = IntArray(b.length + 1)
            for (i in 1..a.length) {
                cur[0] = i
                for (j in 1..b.length) {
                    val c = if (a[i - 1] == b[j - 1]) 0 else 1
                    cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
                }
                val t = prev; prev = cur; cur = t
            }
            return prev[b.length]
        }

        fun near(a: Blk, b: Blk, cw: Int, ch: Int): Boolean {
            val dx = abs((a.l + a.r) / 2 - (b.l + b.r) / 2)
            val dy = abs((a.t + a.b) / 2 - (b.t + b.b) / 2)
            return dx <= maxOf(cw / 10, 24) && dy <= maxOf(ch / 5, 14)
        }
    }
}
