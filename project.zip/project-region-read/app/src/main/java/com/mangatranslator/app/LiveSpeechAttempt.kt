package com.mangatranslator.app

/** Main-thread speech lifecycle. Successful/uncertain finishes never replay audio. */
internal class LiveSpeechAttempt {
    var token = 0
        private set
    private var active = false
    private var text = ""
    private val retried = LinkedHashSet<String>()
    data class Failure(val retryText: String?)

    fun begin(value: String): Int {
        token++
        active = true
        text = value
        return token
    }
    fun isCurrent(value: Int): Boolean = active && value == token
    fun complete(value: Int): Boolean {
        if (!isCurrent(value)) return false
        active = false
        text = ""
        return true
    }
    fun fail(value: Int, sourceVisible: Boolean, retryAllowed: Boolean = true): Failure? {
        if (!isCurrent(value)) return null
        val failed = text
        complete(value)
        if (!retryAllowed || !sourceVisible || failed.isBlank() || !retried.add(failed)) return Failure(null)
        if (retried.size > 200) retried.remove(retried.first())
        return Failure(failed)
    }
    fun cancel() { active = false; text = ""; token++ }
}
