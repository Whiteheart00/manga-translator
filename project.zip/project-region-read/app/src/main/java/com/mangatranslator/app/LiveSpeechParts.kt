package com.mangatranslator.app

/** Early speech at sentence/clause boundaries; never cut an arbitrary word group. */
internal object LiveSpeechParts {
    private val sentences = Regex("(?<=[.!?؟…。！？])\\s+")
    private val clauses = Regex("(?<=[,،;؛:])\\s+")
    private val abbreviation = Regex("(?i)(?:.*\\s)?(?:mr|mrs|ms|dr|prof|sr|jr|st|[a-z]|(?:[a-z]\\.)+[a-z])\\.")
    fun split(text: String): List<String> {
        val whole = text.trim()
        val parts = ArrayList<String>()
        var previous = ""
        for (piece in whole.split(sentences).map { it.trim() }.filter { it.isNotEmpty() }) {
            previous = if (previous.isEmpty()) piece else "$previous $piece"
            if (abbreviation.matches(previous)) continue
            if (previous.length >= 100) {
                var chunk = ""
                for (clause in previous.split(clauses)) {
                    chunk = if (chunk.isEmpty()) clause else "$chunk $clause"
                    if (chunk.length >= 40) { parts.add(chunk); chunk = "" }
                }
                if (chunk.isNotEmpty()) {
                    if (parts.isNotEmpty() && chunk.length < 20) parts[parts.lastIndex] += " $chunk"
                    else parts.add(chunk)
                }
            } else parts.add(previous)
            previous = ""
        }
        if (previous.isNotEmpty()) parts.add(previous)
        while (parts.size > 4) {
            val last = parts.removeAt(parts.lastIndex)
            parts[parts.lastIndex] += " $last"
        }
        return if (parts.size >= 2) parts else emptyList()
    }
}
