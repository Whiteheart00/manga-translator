package com.mangatranslator.app

import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** هەڵەی API ی Gemini لەگەڵ کۆدی HTTP، بۆ ئەوەی بزانین کلیلێک پشوو بدرێت یان نا. */
class ApiException(val code: Int, msg: String) : IOException(msg)

/**
 * چەند کلیلی Gemini (هەر یەکێک لە دێڕێک): بە نۆرە بەکاردێن و ئەگەر یەکێک تەواو بوو (429) یان هەڵە بوو،
 * کلیلی دواتر بەکاردێت.
 */
object GeminiKeys {
    private val sep = Regex("[\\s,;]+")
    private val cool = ConcurrentHashMap<String, Long>()
    private var rr = 0

    fun parse(raw: String): List<String> = raw.split(sep).filter { it.length > 10 }.distinct()

    fun next(raw: String): String = next(parse(raw))

    @Synchronized
    private fun next(ks: List<String>): String {
        if (ks.isEmpty()) return ""
        val now = System.currentTimeMillis()
        for (i in ks.indices) {
            val k = ks[(rr + i) % ks.size]
            if ((cool[k] ?: 0L) <= now) {
                rr = (rr + i + 1) % ks.size
                return k
            }
        }
        val k = ks.minByOrNull { cool[it] ?: 0L }!!
        rr = (ks.indexOf(k) + 1) % ks.size
        return k
    }

    fun rest(key: String, code: Int) {
        val ms = when {
            code == 429 -> 30_000L
            code == 400 -> 2 * 60_000L
            code == 401 || code == 403 -> 10 * 60_000L
            code >= 500 -> 5_000L
            else -> return
        }
        cool[key] = System.currentTimeMillis() + ms
    }

    /** `block` بە هەر کلیلێک تاقی دەکاتەوە تا یەکێکیان سەرکەوت. */
    fun <T> withKeys(raw: String, block: (String) -> T): T {
        // Keep a request-local list: concurrent calls and cooldowns can otherwise
        // cause next(raw) to select a key that this request has already tried.
        val remaining = parse(raw).toMutableList()
        if (remaining.isEmpty()) throw IOException("no key")
        var last: ApiException? = null
        while (remaining.isNotEmpty()) {
            val k = next(remaining)
            remaining.remove(k)
            try {
                return block(k)
            } catch (e: ApiException) {
                rest(k, e.code)
                last = e
            }
        }
        throw last ?: IOException("no key")
    }
}
