package com.mangatranslator.app

import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

/** End-of-stream survives a full queue; finish never blocks the synth thread. */
internal class PiperPcmQueue(capacity: Int = 3) {
    private val queue = ArrayBlockingQueue<FloatArray>(capacity)
    private val end = FloatArray(0)
    @Volatile private var finished = false
    val isDrained: Boolean get() = finished && queue.isEmpty()
    fun offer(samples: FloatArray, timeoutMs: Long): Boolean =
        queue.offer(samples, timeoutMs, TimeUnit.MILLISECONDS)
    fun finish() {
        finished = true
        queue.offer(end) // Wake an idle consumer; a full queue relies on finished.
    }
    fun poll(timeoutMs: Long): FloatArray? {
        val value = if (finished) queue.poll() else queue.poll(timeoutMs, TimeUnit.MILLISECONDS)
        return if (value === end) null else value
    }
}
