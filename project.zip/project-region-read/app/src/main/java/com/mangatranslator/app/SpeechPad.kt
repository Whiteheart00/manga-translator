package com.mangatranslator.app

/**
 * فایلی دەنگی کوردی (Piper) ڕستەی زۆر کورت ناخوێنێتەوە. ئەگەر ڕستەیەک لە [minChars] پیت کەمتر بوو، وشەیەکی پڕکەرەوە
 * ([word]، نموونە «هەرکردم») لە کۆتاییدا دەخرێتە سەر تا درێژییەکەی ≥ [minChars] بێت. خاڵبەندیی کۆتایی دەمێنێتەوە لە کۆتایی.
 * فەنکشنی پاک، بێ Android، تاقیکراو. تەنها بۆ دەنگە، نووسینی سەر شاشە ناگۆڕێت.
 */
object SpeechPad {
    const val DEFAULT_WORD = "هەرکردم"
    const val DEFAULT_MIN_CHARS = 20
    /** وشەی پڕکەرەوە نابێت لەم ژمارەی پیتە کەمتر بێت */
    const val MIN_WORD_LETTERS = 7
    private val TAIL = Regex("[.!?؟،,…:;]+$")

    /** ژمارەی پیتەکانی وشەکە (بۆشایی و خاڵبەندی ناژمێردرێن) */
    fun letterCount(word: String): Int = word.count { it.isLetter() }

    /** ئایا وشەکە دروستە: لانیکەم [MIN_WORD_LETTERS] پیت */
    fun isValidWord(word: String?): Boolean = word != null && letterCount(word.trim()) >= MIN_WORD_LETTERS

    /** وشەی دروست دەگەڕێنێتەوە، یان [DEFAULT_WORD] ئەگەر کورتتر بوو یان بەتاڵ بوو */
    fun sanitizeWord(word: String?): String = if (isValidWord(word)) word!!.trim() else DEFAULT_WORD

    /**
     * @param word وشەی پڕکەرەوە. بەتاڵ = هیچ پڕنەکرێتەوە. ئەگەر کورتتر بوو لە [MIN_WORD_LETTERS] پیت، [DEFAULT_WORD] بەکاردێت.
     */
    fun pad(text: String, word: String = DEFAULT_WORD, minChars: Int = DEFAULT_MIN_CHARS): String {
        val t = text.trim()
        if (t.isEmpty() || word.isBlank() || minChars <= 0 || t.length >= minChars) return t
        val w = sanitizeWord(word)
        val m = TAIL.find(t)
        val tail = m?.value ?: ""
        var out = if (m != null) t.substring(0, m.range.first).trimEnd() else t
        if (out.isEmpty()) return t                       // تەنها خاڵبەندی: هیچ نابێت
        var guard = 0
        while (out.length + tail.length < minChars && guard++ < 12) out = "$out $w"
        return out + tail
    }
}
