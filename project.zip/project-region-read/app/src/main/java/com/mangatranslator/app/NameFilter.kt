package com.mangatranslator.app

/**
 * خشتەی ناوە نەخوێندراوەکان لە وەرگێڕانی زیندوو: ناوێک (بە ئینگلیزی یان هەر زمانێک) کە لە سەرەتای ڕستەدایە لە دەقی سەرچاوە
 * لادەبرێت، بۆیە نە وەردەگێڕدرێت و نە دەنووسرێت و نە دەخوێنرێتەوە. ئەگەر ناوەکە لەناو ڕستەکەدا بێت (نەک سەرەتا) دەمێنێتەوە.
 * فەنکشنی پاک، بێ Android، تاقیکراو.
 *
 * @param strict ئەگەر true بێت، تەنها ئەو کاتە لادەبرێت کە دوای ناوەکە جیاکەرەوەیەک ( : - , | ) بێت یان ناوەکە تەنها بێت.
 *               false (بنەڕەت) = هەرکاتێک لە سەرەتای ڕستەدا بوو.
 * @param everywhere Whole names are omitted anywhere; strict applies only to the start-only mode.
 * @param followedByMarker Third scope: omit only listed names followed by colon, comma or Arabic semicolon.
 */
object NameFilter {
    private val SENTENCES = Regex("(?<=[.!?؟…])\\s+|\\n+")
    private val SEP = Regex("^\\s*([:,;\\-–—|»>]+)?\\s*")

    /** هەر دێڕێک ناوێک؛ «John:» دەنووسرێت «John». دووبارە و بەتاڵ لادەبرێن، درێژترەکان یەکەم. */
    fun parse(raw: String): List<String> =
        raw.lines()
            .map { it.trim().trimEnd(':', ',', '-', '–', '—').trim() }
            .filter { it.isNotEmpty() }
            .distinctBy { it.lowercase() }
            .sortedByDescending { it.length }

    fun strip(text: String, names: List<String>, strict: Boolean = false, everywhere: Boolean = false,
              followedByMarker: Boolean = false): String {
        if (names.isEmpty() || text.isBlank()) return text
        if (followedByMarker) return stripEverywhere(text, names, markedOnly = true)
        if (everywhere) return stripEverywhere(text, names)
        val out = ArrayList<String>()
        for (seg in text.trim().split(SENTENCES)) {
            var s = seg.trim()
            var changed = true
            var guard = 0
            while (changed && guard++ < 3) {                  // «John Mary: hi»
                val r = stripLeading(s, names, strict) ?: break
                changed = r.text != s
                s = r.text
                // After an explicit speaker separator, the remaining words are
                // the sentence body, even if its first word is another name.
                if (r.hadSeparator) break
            }
            if (s.any { it.isLetterOrDigit() }) out.add(s)
        }
        return out.joinToString(" ")
    }

    private data class AnywhereRule(val names: List<String>, val markedOnly: Boolean, val regex: Regex?)
    @Volatile private var anywhereRule: AnywhereRule? = null
    private val WS = Regex("\\s+")
    private val BEFORE_PUNCT = Regex("\\s+([,،;؛:.!?؟…])")
    private val DANGLING_LABEL = Regex("^[\\s,:;،؛：\\-–—|»>]+")
    private val COMMA_BEFORE_END = Regex("[,،;؛:]+\\s*([.!?؟…])")
    private val EMPTY_PAIRS = Regex("\\(\\s*\\)|\\[\\s*\\]|\\{\\s*\\}|\"\\s*\"|'\\s*'|«\\s*»|“\\s*”")

    /** Compile once per edited name list, not on every live OCR result. */
    private fun anywhereRegex(names: List<String>, markedOnly: Boolean): Regex? {
        anywhereRule?.takeIf { it.names == names && it.markedOnly == markedOnly }?.let { return it.regex }
        val alternatives = names.map { if (markedOnly) it.trim().trimEnd(':', ',', '؛').trim() else it }
            .filter { it.isNotBlank() }.distinct()
            .sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        val word = "[\\p{L}\\p{M}\\p{N}_\\u200C\\u200D]"
        val suffix = if (markedOnly) "[\\t\\p{Zs}]*[:,؛]+" else ""
        val regex = if (alternatives.isEmpty()) null else Regex(
            "(?<!$word)(?<!$word['’])(?:$alternatives)(?!$word|['’]$word)$suffix",
            RegexOption.IGNORE_CASE
        )
        anywhereRule = AnywhereRule(names.toList(), markedOnly, regex)
        return regex
    }

    private fun stripEverywhere(text: String, names: List<String>, markedOnly: Boolean = false): String {
        val regex = anywhereRegex(names, markedOnly) ?: return text
        // Match before sentence splitting so names such as Dr. Smith stay intact.
        val removed = text.replace(regex, "")
        if (removed.length == text.length) return text
        return removed.split(SENTENCES).mapNotNull { segment ->
            val cleaned = segment.replace(EMPTY_PAIRS, " ")
                .replace(DANGLING_LABEL, "")
                .replace(WS, " ")
                .replace(BEFORE_PUNCT, "$1")
                .replace(COMMA_BEFORE_END, "$1")
                .trim().trimEnd(',', '،', ';', '؛', ':', '：', '-', '–', '—').trimEnd()
            cleaned.takeIf { value -> value.any { it.isLetterOrDigit() } }
        }.joinToString(" ")
    }

    private data class LeadingResult(val text: String, val hadSeparator: Boolean)

    private fun stripLeading(seg: String, names: List<String>, strict: Boolean): LeadingResult? {
        for (n in names) {
            if (seg.length < n.length || !seg.regionMatches(0, n, 0, n.length, ignoreCase = true)) continue
            val rest = seg.substring(n.length)
            // «Johnson» و «John's» ناوی «John» نین
            if (rest.isNotEmpty() && (rest[0].isLetterOrDigit() || rest[0] == '\'' || rest[0] == '’')) continue
            val m = SEP.find(rest)!!
            val hasSep = m.groups[1] != null
            if (strict && rest.isNotBlank() && !hasSep) continue
            return LeadingResult(rest.substring(m.value.length), hasSep)
        }
        return null
    }
}
