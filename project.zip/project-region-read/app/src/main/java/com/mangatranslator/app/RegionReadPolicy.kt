package com.mangatranslator.app

/** Region reading: borrowed Latin words do not change a Sorani paragraph's language. */
internal object RegionReadPolicy {
    private const val soraniLetters = "ەۆێڕڵڤ"
    private val tokens = Regex("\\s+")
    private val latinTerm = Regex("[A-Za-z0-9]+(?:[.+#_/-][A-Za-z0-9]+)*")
    private val camel = Regex("[a-z][A-Z]")

    fun isSorani(text: String): Boolean {
        var letters = 0
        var arabic = 0
        var special = 0
        for (c in text) {
            if (!c.isLetter()) continue
            letters++
            if (c.code in 0x0600..0x06ff || c.code in 0x0750..0x077f || c.code in 0xfb50..0xfeff) arabic++
            if (c in soraniLetters) special++
        }
        return arabic >= 2 && special >= 1 &&
            (arabic * 100 >= letters * 55 || special >= 2 && arabic * 100 >= letters * 35)
    }

    /** OCR/accessibility can place a product name in its own small text box. */
    fun nativeIndices(texts: List<String>): Set<Int> {
        val native = texts.indices.filterTo(LinkedHashSet()) { isSorani(texts[it]) }
        if (native.isEmpty() || !isSorani(texts.joinToString(" "))) return native
        for (i in texts.indices) {
            if (i in native) continue
            val text = texts[i].trim().trim('(', ')', '[', ']', ',', '،', '.', ':', '؛')
            val words = text.split(tokens).filter { it.isNotEmpty() }
            val term = words.isNotEmpty() && words.size <= 4 && words.all { latinTerm.matches(it) } &&
                (words.size == 1 || words.all { w -> w.all { !it.isLetter() || it.isUpperCase() } || camel.containsMatchIn(w) })
            val shortArabicFragment = text.length <= 32 && text.any { it.isLetter() } &&
                text.all { !it.isLetter() || it.code in 0x0600..0x06ff }
            if (term || shortArabicFragment) native.add(i)
        }
        return native
    }

    /** An OCR source is stronger evidence than a model's rewritten translation. */
    fun visionText(original: String, translated: String): String =
        if (isSorani(original)) original else translated
}
