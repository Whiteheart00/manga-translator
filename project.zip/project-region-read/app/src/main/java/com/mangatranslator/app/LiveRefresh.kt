package com.mangatranslator.app

/** Faster live sampling without overlapping OCR or exceeding Accessibility limits. */
internal object LiveRefresh {
    fun captureMs(low: Boolean) = if (low) 140L else 90L
    fun accessibilityMs(low: Boolean) = if (low) 450L else 350L
    fun ocrGapMs(kurdish: Boolean) = if (kurdish) 100L else 120L
    fun forceMs(kurdish: Boolean) = if (kurdish) 180L else 250L
}
