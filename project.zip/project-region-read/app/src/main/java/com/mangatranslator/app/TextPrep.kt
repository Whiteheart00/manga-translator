package com.mangatranslator.app

/**
 * ئامادەکردنی دەقی OCR پێش وەرگێڕان، و چاکسازی دەقی سۆرانی دوای وەرگێڕان.
 */
object TextPrep {
    private val whitespace = Regex("\\s+")
    private val standaloneI = Regex("\\bi\\b")

    /**
     * مانگا زۆربەی کات بە پیتی گەورەیە ("WHAT ARE YOU DOING?!") و مۆدێلی وەرگێڕان بەو شێوەیە خراپ دەبێت،
     * بۆیە ئەگەر دەقەکە زۆربەی گەورەیە، دەیکەین بە شێوەی ئاسایی (پیتی یەکەمی هەر ڕستەیەک گەورە).
     */
    fun prepare(raw: String): String {
        val t = raw.replace('\n', ' ').replace(whitespace, " ").trim()
        val letters = t.count { it.isLetter() }
        if (letters < 3) return t
        val upper = t.count { it.isUpperCase() }
        return if (upper.toFloat() / letters >= 0.7f) sentenceCase(t) else t
    }

    /** ئایا دەقەکە پیتی چینی/جاپانی/کۆری تێدایە */
    fun hasCjk(s: String): Boolean = s.any {
        it.code in 0x4E00..0x9FFF || it.code in 0x3040..0x30FF || it.code in 0xAC00..0xD7AF || it.code in 0x1100..0x11FF
    }

    private fun sentenceCase(s: String): String {
        val lower = s.lowercase()
        val sb = StringBuilder(lower.length)
        var capNext = true
        for (ch in lower) {
            if (capNext && ch.isLetter()) {
                sb.append(ch.uppercaseChar())
                capNext = false
            } else {
                sb.append(ch)
                if (ch == '.' || ch == '!' || ch == '?' || ch == '…') {
                    capNext = true
                } else if (ch.isLetterOrDigit()) {
                    capNext = false
                }
            }
        }
        return sb.toString().replace(standaloneI, "I")
    }

    private val junkMarks = Regex("[\\u200B\\u200E\\u200F\\u202A-\\u202E\\u2066-\\u2069\\uFEFF]")
    private val mdMarks = Regex("[*`#]+")

    /**
     * دەقی وەرگێڕدراو بۆ پیشاندان و خوێندنەوە ئامادە دەکات: جیاکەرەوەی باتش (¤)، نیشانەی نەبینراوی ئاراستە
     * و markdown لادەبات و بۆشاییەکان یەک دەکات. ZWNJ (U+200C) دەمێنێتەوە.
     */
    fun finish(s: String): String =
        fixSorani(s)
            .replace("¤", " ")
            .replace(junkMarks, "")
            .replace(mdMarks, "")
            .replace('\n', ' ')
            .replace(whitespace, " ")
            .trim()

    /** یەکخستنی پیتە عەرەبییەکان بۆ شێوەی کوردی: ي/ى → ی ، ك → ک */
    fun fixSorani(s: String): String =
        s.replace('ي', 'ی')
            .replace('ى', 'ی')
            .replace('ك', 'ک')
            .trim()
}
