package com.mangatranslator.app

/**
 * پاسەوانی دژی «نووسینی لەحۆوە» (hallucination) بۆ ژێرنووسی زیندوو. هەموو فەنکشنەکان پاکن (بێ Android) و تاقیکراون.
 *
 * ٣ چین: ١) ڕووبەرەکە دەبێت لێواری وەک-نووسینی تێدا بێت؛ ٢) دەقی OCR دەبێت وەک دەقی ڕاستەقینە بێت (نەک خشت و هێما)؛
 * ٣) وەرگێڕانەکە دەبێت بەپێی سەرچاوەکەی ئەگەر بێت (درێژیی نەگونجاو، «no text»، <NONE> ڕەتدەکرێنەوە).
 */
object SubtitleGuard {
    const val NONE = "<NONE>"

    /** کەمترین ڕێژەی پیکسێلی لێوارداری بەهێز بۆ ئەوەی ڕووبەرەکە «نووسینی تێدا بێت» */
    const val EDGE_MIN_FRACTION = 0.004f
    const val EDGE_THRESHOLD = 48

    private val REFUSAL = Regex(
        "(?i)\\b(no (readable )?text|no subtitles?|cannot (translate|read)|can't (translate|read)|unable to|" +
            "i'm sorry|i am sorry|there is no|not enough context|as an ai|noise)\\b"
    )
    private const val VOWELS = "aeiouyàáâäãåèéêëìíîïòóôöõùúûü"

    /** ڕێژەی پیکسێلی لێوارداری بەهێز (جیاوازی ≥ [threshold] لەگەڵ دراوسێی ڕاست یان خوارەوە) لە وێنەی خۆڵەمێشیدا */
    fun edgeFraction(gray: IntArray, w: Int, h: Int, threshold: Int = EDGE_THRESHOLD): Float {
        if (w < 2 || h < 2 || gray.size < w * h) return 0f
        var edges = 0
        for (y in 0 until h - 1) {
            val row = y * w
            for (x in 0 until w - 1) {
                val g = gray[row + x]
                if (Math.abs(g - gray[row + x + 1]) >= threshold || Math.abs(g - gray[row + w + x]) >= threshold) edges++
            }
        }
        return edges.toFloat() / ((w - 1) * (h - 1))
    }

    fun hasTextLikeEdges(gray: IntArray, w: Int, h: Int): Boolean = edgeFraction(gray, w, h) >= EDGE_MIN_FRACTION

    /** ئایا دەقی OCR دەقی ڕاستەقینەیە، نەک خشت، هێما، یان پیتی دووبارە (ڕێگری لە وەرگێڕانی دەنگەدەنگ) */
    fun looksLikeRealText(raw: String): Boolean {
        val s = raw.trim()
        val compact = s.filterNot { it.isWhitespace() }
        if (compact.isEmpty()) return false
        val letterChars = compact.filter { it.isLetter() }
        val letters = letterChars.length
        if (letters < 2) return false
        if (letters.toFloat() / compact.length < 0.55f) return false              // زۆربەی هێمایە
        if (letterChars.lowercase().toSet().size < 2) return false                // "llll" / "ااااا"
        val latinOnly = letterChars.all { it.code < 0x250 }
        if (latinOnly) {
            val tokens = s.split(Regex("\\s+")).filter { t -> t.any { it.isLetter() } }
            val single = tokens.count { t -> t.count { it.isLetter() } == 1 }
            if (tokens.size >= 3 && single.toFloat() / tokens.size > 0.5f) return false   // "l I i |"
            if (letters >= 4 && letterChars.count { it.lowercaseChar() in VOWELS } == 0) return false  // "ptkrs"
        }
        return true
    }

    /** ئایا وەرگێڕانەکە لەگەڵ سەرچاوەکەی دەگونجێت، نەک نووسینی داهێنراو یان وەڵامی مۆدێل */
    fun plausibleTranslation(src: String, out: String): Boolean {
        val o = out.trim()
        if (o.isEmpty() || o.contains(NONE, ignoreCase = true)) return false
        if (REFUSAL.containsMatchIn(o)) return false
        val srcLen = src.count { !it.isWhitespace() }.coerceAtLeast(1)
        val outLen = o.count { !it.isWhitespace() }
        val cjk = src.any { it.code >= 0x2E80 }
        val factor = if (cjk) 10 else 4
        return outLen <= maxOf(40, srcLen * factor)
    }
}
