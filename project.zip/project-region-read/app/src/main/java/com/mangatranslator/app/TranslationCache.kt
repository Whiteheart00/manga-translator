package com.mangatranslator.app

/**
 * کاشی وەرگێڕان (LRU، لە ڕامدا): دەقێک پێشتر وەرگێڕدرابێت، دووبارە داواکاری ناردرێت.
 * زۆر یارمەتیدەرە لە سکرۆڵکردن و گەڕانەوە (هەمان UI، هەمان پۆست، هەمان بابڵ).
 * کلیل = زمانی سەرچاوە + دەقی ئاسایکراو. تەنها وەرگێڕانی سەرکەوتوو دەخرێتە ناو کاش.
 */
object TranslationCache {
    private const val MAX_ENTRIES = 600
    private const val MAX_TEXT_LEN = 800

    private val map = object : LinkedHashMap<String, String>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > MAX_ENTRIES
    }

    private val ws = Regex("\\s+")
    private fun key(lang: String, text: String) = lang + "\u0001" + text.trim().replace(ws, " ")

    fun get(lang: String, text: String): String? {
        if (text.isBlank() || text.length > MAX_TEXT_LEN) return null
        val k = key(lang, text)
        return synchronized(map) { map[k] }
    }

    fun put(lang: String, text: String, translated: String) {
        val t = translated.trim()
        if (t.isEmpty() || t == "؟" || t == "…" || text.isBlank() || text.length > MAX_TEXT_LEN) return
        val k = key(lang, text)
        synchronized(map) { map[k] = t }
    }

    fun clear() = synchronized(map) { map.clear() }

    fun size() = synchronized(map) { map.size }
}
