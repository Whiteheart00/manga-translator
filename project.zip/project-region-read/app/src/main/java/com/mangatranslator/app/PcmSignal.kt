package com.mangatranslator.app

/** Rejects silent/invalid synthesis without assuming a minimum word count. */
internal object PcmSignal {
    fun hasSignal(samples: FloatArray, sampleRate: Int): Boolean {
        if (sampleRate <= 0 || samples.isEmpty()) return false
        var energy = 0.0
        var sum = 0.0
        var peak = 0f
        var active = 0
        for (sample in samples) {
            if (!sample.isFinite()) return false
            val magnitude = kotlin.math.abs(sample)
            if (magnitude > peak) peak = magnitude
            if (magnitude >= 0.0001f) active++
            energy += sample.toDouble() * sample
            sum += sample
        }
        val mean = sum / samples.size
        val acEnergy = energy / samples.size - mean * mean
        return acEnergy >= 1e-10 && peak >= 0.0001f && energy / samples.size >= 1e-10 &&
            active >= (sampleRate / 50).coerceAtLeast(1)
    }
}
