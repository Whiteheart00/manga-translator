package com.mangatranslator.app

/** Service-owned lifecycle; a generation rejects callbacks from closed live runs. */
internal class LivePlaybackControl<T> {
    enum class Phase { STOPPED, RUNNING, PAUSED }
    @Volatile var phase = Phase.STOPPED
        private set
    @Volatile var generation = 0
        private set
    private var selection: T? = null

    @Synchronized fun start(value: T): Int {
        generation++
        selection = value
        phase = Phase.RUNNING
        return generation
    }
    @Synchronized fun pause(value: T): Boolean {
        if (phase != Phase.RUNNING) return false
        phase = Phase.PAUSED
        generation++
        selection = value
        return true
    }
    @Synchronized fun resume(): T? {
        if (phase != Phase.PAUSED) return null
        val value = selection ?: return null
        generation++
        phase = Phase.RUNNING
        return value
    }
    @Synchronized fun accepts(token: Int): Boolean = phase == Phase.RUNNING && generation == token
    @Synchronized fun withCurrent(token: Int, action: () -> Unit) {
        if (accepts(token)) action()
    }
    @Synchronized fun stop() {
        phase = Phase.STOPPED
        generation++
        selection = null
    }
}

/** The live control sits beside the existing stop button and stays on screen. */
internal object LiveControlLayout {
    data class Point(val x: Int, val y: Int)
    fun position(screenW: Int, screenH: Int, stopX: Int, stopY: Int, stopSize: Int, size: Int, gap: Int): Point {
        val right = stopX + stopSize + gap
        val x = if (right + size <= screenW) right else stopX - size - gap
        return Point(x.coerceIn(0, (screenW - size).coerceAtLeast(0)),
            stopY.coerceIn(0, (screenH - size).coerceAtLeast(0)))
    }
}
