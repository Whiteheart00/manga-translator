package com.mangatranslator.app

import android.media.AudioAttributes

/**
 * دەنگی خوێندنەوە لە کام «بەش»ی دەنگی مۆبایلەوە دەربچێت؛ بەکارهێنەر هەڵیدەبژێرێت (ڕێکخستنی دەنگ).
 * هەر بەشێک ڤۆلیومی خۆی هەیە لە پانێلی ڤۆلیومی مۆبایل، بۆیە دەتوانیت دەنگی کوردی لە دەنگی ڤیدیۆ/یاری جیا بکەیتەوە.
 *   0 = میدیا (ئاسایی)   1 = Accessibility   2 = ئەلارم   3 = ئاگادارکردنەوە / زەنگ
 */
object VoiceOutput {
    val labels = listOf("میدیا (ئاسایی)", "Accessibility", "ئەلارم", "ئاگادارکردنەوە / زەنگ")

    fun usage(pref: Int): Int = when (pref) {
        1 -> AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY
        2 -> AudioAttributes.USAGE_ALARM
        3 -> AudioAttributes.USAGE_NOTIFICATION
        else -> AudioAttributes.USAGE_MEDIA
    }

    fun attributes(pref: Int): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(usage(pref))
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
}
