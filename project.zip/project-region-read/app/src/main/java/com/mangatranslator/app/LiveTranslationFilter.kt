package com.mangatranslator.app

/** Live output only: never alter the source used for translation / matching. */
internal object LiveTranslationFilter {
    // Include contractions, hyphenated words, mixed Latin/number identifiers,
    // numeric separators and units, without consuming adjacent Kurdish text.
    private const val LATIN_DIGIT = "[\\p{IsLatin}0-9]"
    private const val LATIN_MARK_DIGIT = "[\\p{IsLatin}\\p{M}0-9]"
    private val latinOrNumber = Regex("[+\\-]?" + LATIN_DIGIT + LATIN_MARK_DIGIT + "*(?:[.'’:/,_%+\\-]" + LATIN_DIGIT + LATIN_MARK_DIGIT + "*)*[+%]*")
    private val emptyPairs = Regex("\\(\\s*\\)|\\[\\s*]|\\{\\s*}|[\"“«]\\s*[\"”»]")
    private val repeatedSeparators = Regex("([،,؛;:])(?:\\s*[،,؛;:])+")
    private val spaces = Regex("\\s+")
    private val beforePunctuation = Regex("\\s+([،؛:,.!?؟])")
    private val edgeJunk = Regex("^[\\s,،؛:;./\\-–—]+|[\\s,،؛:;/\\-–—]+$")
    private data class Cached(val raw: String, val clean: String)
    @Volatile private var cached: Cached? = null

    fun clean(raw: String): String {
        cached?.let { if (it.raw == raw) return it.clean }
        val clean = if (alreadyClean(raw)) raw else cleanMixed(raw)
        cached = Cached(raw, clean)
        return clean
    }

    /** Common Sorani results need no replacements, regexes or text copies. */
    private fun alreadyClean(text: String): Boolean {
        if (text.isEmpty()) return true
        var content = false
        for (i in text.indices) {
            val c = text[i]
            when {
                c == 'ي' || c == 'ى' || c == 'ك' -> return false
                c in '\u0600'..'\u06ff' -> {
                    if (c.isLetterOrDigit()) content = true
                    else if (c == '،' || c == '؛' || c == '؟') {
                        if ((c == '،' || c == '؛') && (i == 0 || i == text.lastIndex ||
                            text[i - 1] in ",،؛;:")) return false
                    }
                }
                c == ' ' -> {
                    if (i == 0 || i == text.lastIndex || text[i - 1] == ' ' || text[i + 1] in "،؛:,.!?؟") return false
                }
                c in ".!?،؛:,…" -> {
                    if ((i == 0 && c in ",،؛:.") || (i == text.lastIndex && c in ",،؛:")) return false
                    if (c in ",،؛:" && i > 0 && text[i - 1] in ",،؛;:") return false
                }
                c == '\u200c' -> {}
                else -> return false
            }
        }
        return content
    }

    private fun finishIfNeeded(raw: String): String {
        if (raw.isNotEmpty() && (raw.first().isWhitespace() || raw.last().isWhitespace())) return TextPrep.finish(raw)
        for (i in raw.indices) {
            val c = raw[i]
            if (c == 'ي' || c == 'ى' || c == 'ك' || c == '¤' || c == '*' || c == '`' || c == '#' ||
                c in '\u200b'..'\u200f' && c != '\u200c' && c != '\u200d' ||
                c in '\u202a'..'\u202e' || c in '\u2066'..'\u2069' || c == '\ufeff' ||
                c <= ' ' && c != ' ' || c == ' ' && i > 0 && raw[i - 1] == ' ') return TextPrep.finish(raw)
        }
        return raw
    }

    private fun cleanMixed(raw: String): String {
        var text = finishIfNeeded(raw).replace(latinOrNumber, " ")
        if (text.any { it in "([{\"“«" }) text = text.replace(emptyPairs, " ")
        text = text.replace(spaces, " ")
            .replace(beforePunctuation, "$1").replace(repeatedSeparators, "$1")
            .replace(edgeJunk, "").trim()
        return text.takeIf { it.any(Char::isLetterOrDigit) }.orEmpty()
    }
}
