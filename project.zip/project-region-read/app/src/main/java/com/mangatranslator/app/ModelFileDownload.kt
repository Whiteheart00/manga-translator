package com.mangatranslator.app

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** Resumes a model download and publishes it only after its size is verified. */
internal object ModelFileDownload {
    fun fetch(url: String, dst: File, expectedSize: Long, onBytes: (Long) -> Unit) {
        require(expectedSize > 0)
        val part = File(dst.parentFile, dst.name + ".part")
        var have = part.length()
        if (have > expectedSize) {
            Files.delete(part.toPath())
            have = 0L
        }
        // A previous attempt may have finished writing before it was interrupted.
        if (have != expectedSize) {
            val connection = URL(url).openConnection() as HttpURLConnection
            try {
                connection.connectTimeout = 20_000
                connection.readTimeout = 60_000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "MangaTranslator/1.0")
                connection.setRequestProperty("Accept-Encoding", "identity")
                if (have > 0) connection.setRequestProperty("Range", "bytes=$have-")
                val code = connection.responseCode
                if (code != 200 && code != 206) throw IOException("HTTP $code")
                if (code == 206) {
                    // Never append bytes from the wrong offset or a different size.
                    val range = Regex("bytes (\\d+)-(\\d+)/(\\d+)")
                        .matchEntire(connection.getHeaderField("Content-Range").orEmpty())
                    val start = range?.groupValues?.get(1)?.toLongOrNull()
                    val end = range?.groupValues?.get(2)?.toLongOrNull()
                    val total = range?.groupValues?.get(3)?.toLongOrNull()
                    if (start != have || total != expectedSize || end == null || end < have || end >= expectedSize) {
                        throw IOException("Invalid Content-Range")
                    }
                } else {
                    // Some servers ignore Range and return the entire file.
                    have = 0L
                }
                onBytes(have)
                connection.inputStream.use { input ->
                    FileOutputStream(part, code == 206 && have > 0).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var total = have
                        var reported = have
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            if (count.toLong() > expectedSize - total) throw IOException("Model exceeds expected size")
                            output.write(buffer, 0, count)
                            total += count
                            if (total - reported >= 256 * 1024) {
                                onBytes(total)
                                reported = total
                            }
                        }
                        onBytes(total)
                    }
                }
            } finally {
                connection.disconnect()
            }
        }
        if (part.length() != expectedSize) throw IOException("${dst.name}: incorrect size (${part.length()} / $expectedSize)")
        Files.move(part.toPath(), dst.toPath(), StandardCopyOption.REPLACE_EXISTING)
        onBytes(expectedSize)
    }
}
