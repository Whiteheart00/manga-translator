package com.mangatranslator.app

import android.content.Context

/** Shared non-Arabic translation policy for screen, auto and region translation. */
internal object TextTranslationService {
    fun translate(
        ctx: Context, texts: List<String>, lang: String, keys: String,
        provider: TranslationProvider, fast: Boolean, onItem: (Int, String) -> Unit
    ): List<String?> = TranslationRouter.shared.batch(provider, keys, texts,
        gemini = { emit -> ContextTranslator.translate(ctx, texts, lang, keys, fast, strict = true, onItem = emit) },
        google = { missing -> GoogleTranslator.translateBubbles(missing, lang) },
        onItem = onItem)
}
