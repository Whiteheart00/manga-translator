package com.mangatranslator.app

/** A typewriter subtitle must not delay an unrelated, fully displayed next line. */
internal class LiveTypingWindow(private val memoryMs: Long = 6000L) {
    private var previous = ""
    private var until = 0L
    data class Decision(val growing: Boolean, val wait: Boolean)
    fun observe(norm: String, now: Long, sameLine: (String, String) -> Boolean): Decision {
        val growing = isGrowth(previous, norm)
        if (growing) until = now + memoryMs
        else if (previous.isEmpty() || !sameLine(previous, norm)) until = 0L
        previous = norm
        return Decision(growing, now < until)
    }
    fun reset() { previous = ""; until = 0L }
    private fun isGrowth(old: String, current: String): Boolean {
        if (old.isEmpty() || current.length <= old.length) return false
        var common = 0
        while (common < old.length && common < current.length && old[common] == current[common]) common++
        return common >= (old.length * .8f).toInt().coerceAtLeast(1)
    }
}
