package com.mangatranslator.app

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * خوێندنەوەی کوردی بێ ئینتەرنێت: دەقی سۆرانی دەگۆڕدرێت (KurdishVoiceText) و بە دەنگی ئۆفلاینی
 * ناو مۆبایلەکە (Android TextToSpeech) دەخوێندرێتەوە. دەنگەکە ئینگلیزییە.
 * پێویستی: دەنگەکە لەسەر مۆبایلەکە دابەزێنرابێت (Settings ← Text-to-speech ← Google ← Install voice data).
 */
class OfflineKurdishTts(private val ctx: Context) {

    private var engine: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var failMsg: String? = null
    private val initLatch = CountDownLatch(1)
    @Volatile private var done: CountDownLatch? = null

    @Volatile var speaking = false
        private set

    init {
        engine = TextToSpeech(ctx.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                failMsg = "ئامێری TextToSpeech ی مۆبایلەکە کارا نەبوو"
            } else {
                ready = true
            }
            initLatch.countDown()
        }
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { done?.countDown() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { done?.countDown() }
        })
    }

    /** ژێرنووسی زیندوو: خێراتر (٠.٨٥ ی کۆن زۆر خاو بوو) و وچانی کەمتر */
    @Volatile var lowLatency = false

    @Volatile private var voiceMode = -1

    /** باشترین دەنگی ئینگلیزیی ئۆفلاین هەڵدەبژێرێت (en-US، پاشان en-GB)؛ ئەگەر نەبوو، پەیامی هەڵە دەگەڕێنێتەوە. */
    private fun pickOfflineVoice(): String? {
        val tts = engine ?: return "TTS نییە"
        val voices = try { tts.voices.orEmpty() } catch (_: Exception) { emptySet() }
        val best = voices
            .filter {
                it.locale.language == "en" && !it.isNetworkConnectionRequired &&
                    !it.features.contains("notInstalled")
            }
            .sortedWith(
                compareByDescending<android.speech.tts.Voice> {
                    when (it.locale.country) { "US" -> 2; "GB" -> 1; else -> 0 }
                }.thenByDescending { it.quality }
            )
            .firstOrNull()
        if (best != null) {
            tts.voice = best
            return null
        }
        val r = tts.setLanguage(Locale.US)
        return if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            "دەنگی ئینگلیزیی ئۆفلاین نییە. لە Settings ← Text-to-speech ← Google ← Install voice data دایبەزێنە"
        } else null
    }

    /**
     * دەقی کورت (١-١٢ پیت): Android TTS زۆرجار بێدەنگ تێدەپەڕێت.
     * خاڵ/بۆشایی زیاد دەکرێت تا دەنگ دەستی پێبکات.
     */
    private fun padShort(s: String): String {
        var t = s.trim()
        if (t.isEmpty()) return t
        if (t.length < 12) {
            val last = t.lastOrNull()
            if (last != '.' && last != '!' && last != '?' && last != '؟' && last != '。') {
                t = "$t."
            }
            // بۆشایی کۆتایی: هەندێک موتور دەقی زۆر کورت فڕێدەدات
            t = "$t "
        }
        return t
    }

    /** بە ڕیز دەخوێنێتەوە؛ لەسەر thread ی کار (نەک main) بانگ بکرێت. null = سەرکەوتوو. */
    fun speakBlocking(texts: List<String>, mode: Int, rate: Float = 1f, isCurrent: () -> Boolean): String? {
        if (!initLatch.await(8, TimeUnit.SECONDS)) return "TTS ی ئۆفلاین ئامادە نەبوو"
        failMsg?.let { return it }
        val tts = engine ?: return "TTS نییە"
        if (voiceMode != KurdishVoiceText.EN) {
            pickOfflineVoice()?.let { return it }
            voiceMode = KurdishVoiceText.EN
        }
        speaking = true
        try {
            // کەمێک هێواشتر بۆ دەقی کورت — باشتر دەبیسترێت
            tts.setSpeechRate((if (lowLatency) 1.1f else 0.85f) * rate)
            try { tts.setAudioAttributes(VoiceOutput.attributes(TranslatorSettings(ctx).voiceOutput)) } catch (_: Throwable) {}
            var any = false
            for ((i, raw) in texts.withIndex()) {
                if (!isCurrent()) break
                val src = raw.trim()
                if (src.isEmpty()) continue
                var latin = KurdishVoiceText.convert(src, mode).trim()
                if (latin.isBlank()) latin = src  // ئەگەر convert بەتاڵ بوو، ڕەسەن بخوێنە
                latin = padShort(latin)
                Log.d(TAG, "latin(${src.length}): $latin")
                val latch = CountDownLatch(1)
                done = latch
                val params = Bundle()
                // یەکەم: FLUSH؛ دواتر ADD بۆ ئەوەی کورتەکان نەپچڕێن
                val modeQ = if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val r = tts.speak(latin, modeQ, params, "ku$i")
                if (r != TextToSpeech.SUCCESS) {
                    // هەوڵی دووەم بێ pad
                    val r2 = tts.speak("$src.", TextToSpeech.QUEUE_FLUSH, params, "ku${i}b")
                    if (r2 != TextToSpeech.SUCCESS) return "TTS سەرنەکەوت"
                }
                any = true
                // لانیکەم ~٤٠٠ms چاوەڕێ بۆ دەقی کورت (onDone زوو دێت بێ دەنگ)
                val minWait = if (src.length < 12) (if (lowLatency) 250L else 450L) else 0L
                val t0 = System.currentTimeMillis()
                while (isCurrent() && !latch.await(80, TimeUnit.MILLISECONDS)) {
                    if (minWait > 0 && System.currentTimeMillis() - t0 > 8000) break
                }
                while (isCurrent() && System.currentTimeMillis() - t0 < minWait) {
                    Thread.sleep(40)
                }
            }
            if (!any) return "دەق بۆ خوێندنەوە نەما"
        } finally {
            speaking = false
        }
        return null
    }

    fun stop() {
        speaking = false
        done?.countDown()
        try { engine?.stop() } catch (_: Exception) {}
    }

    fun shutdown() {
        stop()
        try { engine?.shutdown() } catch (_: Exception) {}
        engine = null
    }

    companion object { private const val TAG = "OfflineKurdishTts" }
}
