package com.mangatranslator.app

import android.graphics.Bitmap

/** سەرچاوەی فرەیمی شاشە: MediaProjection (ScreenCapturer) یان Accessibility (AccessibilityCapturer). */
interface FrameSource {
    /** لە thread ی گرتنەوە بانگ دەکرێت؛ وەرگر دەبێت bitmap recycle بکات. */
    var frameListener: ((Bitmap) -> Unit)?
    fun start()
    /** دوای `delayMs` فرەیمێک دەدات بە `cb` (لە thread ی گرتنەوە؛ cb دەبێت recycle ی بکات). null = نەگیرا. */
    fun requestFrame(delayMs: Long, cb: (Bitmap?) -> Unit)
    fun release()
    /** Faster sampling only for an explicitly enabled live, non-Arabic session. */
    fun setLiveRefresh(enabled: Boolean) {}
    /** Refresh after Play, rather than replaying a bitmap retained before Pause. */
    fun setCapturePaused(paused: Boolean) {}
    fun requestFreshFrame(onReady: () -> Unit) { kick(); onReady() }
    /** داوای فرەیمی دووبارە بکە (بۆ forceRescan کاتێک شاشە نەگۆڕاوە)؛ بنەڕەت: هیچ */
    fun kick() {}
}
