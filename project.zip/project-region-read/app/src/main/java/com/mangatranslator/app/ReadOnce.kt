package com.mangatranslator.app

/**
 * «هیچ کات دووجار هەمان شت نەخوێندرێتەوە». فەنکشنی پاک، بێ Android، تاقیکراو.
 *
 * کاتێک ڕستەی A وەرگێڕدرا و خوێندرایەوە، پاشان شاشە «A B» نیشان دەدات (ڕستەی نوێ لەگەڵ ئەوی پێشوو لەسەر هەمان
 * شاشە، یان دەقەکە بە وشە بە وشە گەشە دەکات)، OCR ی «A B» وەک دەقی نوێ دەهات و A دووبارە وەردەگێڕدرا و دەخوێندرایەوە.
 * ئێستا: ئەو بەشەی لە سەرەتای دەقی نوێدا پێشتر وەرگێڕدراوە و خوێندراوەتەوە لادەبرێت و تەنها بەشی نوێ ([Result.text]) دەمێنێتەوە.
 *
 * ئاگاداری: تەنها لە سەرەتای دەقدا لادەبرێت (نەک ناوەڕاست)، و دەقی پێشووی زۆر کورت (<[MIN_NORM] پیت: «Yes»، «No») لادەنابرێت،
 * بۆ ئەوەی وشەیەکی ئاسایی لە ناو ڕستەیەکی نوێدا ون نەبێت.
 */
object ReadOnce {
    const val MIN_NORM = 5

    class Result(val text: String, val stripped: Boolean, val matched: List<String>)

    /**
     * @param handled دەقە سەرچاوە ئەم دواییە وەرگێڕدراو/خوێندراوەکان
     * @param norm ئاسایی کردنی دەق (بێ هێما، پیتی بچووک)
     * @param similar ئایا دوو دەقی ئاسایی کراو هەمان دێڕن (OCR ی کەمێک جیاواز)
     */
    fun strip(
        text: String,
        handled: List<String>,
        norm: (String) -> String,
        similar: (String, String) -> Boolean
    ): Result {
        var tokens = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.size < 2 || handled.isEmpty()) return Result(text, false, emptyList())

        // درێژترینەکان پێشتر: «A B» لە پێش «A»
        val cands = handled
            .map { it to norm(it) }
            .filter { it.second.length >= MIN_NORM }
            .sortedByDescending { it.second.length }
        if (cands.isEmpty()) return Result(text, false, emptyList())

        val matched = ArrayList<String>()
        var progress = true
        while (progress && tokens.size >= 1) {
            progress = false
            for ((raw, n) in cands) {
                val pc = raw.trim().split(Regex("\\s+")).count { it.isNotEmpty() }.coerceAtLeast(1)
                for (k in intArrayOf(pc, pc - 1, pc + 1)) {
                    if (k < 1 || k > tokens.size) continue
                    val head = tokens.subList(0, k).joinToString(" ")
                    val hn = norm(head)
                    if (hn.length >= MIN_NORM && (hn == n || similar(hn, n))) {
                        matched.add(raw)
                        tokens = tokens.subList(k, tokens.size)
                        progress = true
                        break
                    }
                }
                if (progress) break
            }
        }
        if (matched.isEmpty()) return Result(text, false, emptyList())
        return Result(tokens.joinToString(" "), true, matched)
    }
}
