package com.mangatranslator.app

import java.io.IOException

/**
 * مۆدێلی Gemini ی بینین/دەنگ/دەق. ئەگەر مۆدێلێک نەمابوو (404)، خۆکارانە مۆدێلی دواتر تاقی دەکرێتەوە،
 * و مۆدێلی کارا بیر دەکرێتەوە. ئەگەر پارامەتری بیرکردنەوە (thinking) قبوڵ نەکرا (400)، بێ ئەو تاقی دەکرێتەوە.
 */
object GeminiModels {
    private val QUALITY = listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash")
    private val FAST = listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-3.6-flash", "gemini-2.5-flash-lite", "gemini-2.5-flash")

    @Volatile
    private var okQuality: String? = null
    @Volatile
    private var okFast: String? = null

    private const val PREFS = "gemini_models"
    @Volatile
    private var prefs: android.content.SharedPreferences? = null

    /**
     * مۆدێلە سەرکەوتووەکان لە SharedPreferences دەپارێزێت، بۆ ئەوەی دوای داخستنی ئەپ یەکەمجار
     * مۆدێلە هەڵەکان (404/429) دووبارە تاقی نەکرێنەوە. دەتوانرێت چەند جارێک بانگ بکرێت.
     */
    @Synchronized
    fun init(ctx: android.content.Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        prefs = p
        // تەنها ئەگەر هێشتا لە لیستەکەدا بێت (مۆدێلێکی لابراو بەکارنایەت)
        if (okQuality == null) okQuality = p.getString("ok_quality", null)?.takeIf { it in QUALITY }
        if (okFast == null) okFast = p.getString("ok_fast", null)?.takeIf { it in FAST }
    }

    private fun remember(fast: Boolean, model: String) {
        val old = if (fast) okFast else okQuality
        if (fast) okFast = model else okQuality = model
        // تەنها کاتێک دەنووسرێت کە مۆدێلەکە گۆڕابێت، نەک لە هەر داواکارییەک
        if (old != model) prefs?.edit()?.putString(if (fast) "ok_fast" else "ok_quality", model)?.apply()
    }

    /** بۆ خێرایی: بیرکردنەوە بە کەمترین ئاستی ببە. */
    fun thinking(model: String): org.json.JSONObject =
        if (model.startsWith("gemini-2.5")) org.json.JSONObject().put("thinkingBudget", 0)
        else org.json.JSONObject().put("thinkingLevel", "minimal")

    fun <T> call(fast: Boolean = false, quotaSensitive: Boolean = false, post: (model: String, think: Boolean) -> T): T {
        val order = (listOfNotNull(if (fast) okFast else okQuality) + (if (fast) FAST else QUALITY)).distinct()
        var last: ApiException? = null
        for (m in order) {
            for (think in listOf(true, false)) {
                try {
                    val r = post(m, think)
                    remember(fast, m)
                    return r
                } catch (e: ApiException) {
                    last = e
                    // Opt-in for the new provider policy. Preserve 429 rather
                    // than masking it with a later missing-model response.
                    if (quotaSensitive && e.code == 429) throw e
                    if (e.code == 404) break               // مۆدێلەکە نییە ← مۆدێلی دواتر
                    if (e.code == 400 && think) continue   // لەوانەیە thinking قبوڵ نەکرابێت
                    // quota (429) یان قەرەباڵغی/هەڵەی سێرڤەر: مۆدێلی دواتر quota ی جیاوازی هەیە
                    if (e.code == 429 || e.code == 500 || e.code == 503 || e.code == 504) break
                    throw e
                }
            }
        }
        throw last ?: IOException("هیچ مۆدێلێکی Gemini کار ناکات")
    }
}
