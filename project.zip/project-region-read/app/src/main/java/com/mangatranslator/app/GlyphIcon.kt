package com.mangatranslator.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * ئایکۆنی ڤێکتەر (خەتی سپی) بۆ پانێلی شەمەندەفەر؛ هیچ وێنەیەک پێویست نییە.
 * پاشبنەمای بازنەکە لەلایەن بەکارهێنەرەوە (background) دادەنرێت و بۆ نیشاندانی دۆخ دەگۆڕدرێت.
 */
class GlyphIcon(ctx: Context, kind: Int) : View(ctx) {

    var kind: Int = kind
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val path = Path()
    private val box = RectF()

    // سێبەری نەرم: ئایکۆنی سپی لەسەر شووشەی ڕوون و هەر پاشبنەمایەک دیار بێت
    private val shadowStroke = Paint(stroke).apply { color = 0x73000000 }
    private val shadowFill = Paint(fill).apply { color = 0x73000000 }

    private val settings = TranslatorSettings(ctx)

    /** ڕەنگی هەڵبژێردراوی بەکارهێنەر، یان ڕەنگی بنەڕەت */
    private fun colorFor(k: Int): Int {
        val chosen = settings.iconColor(k)
        return if (chosen != 0) chosen else defaultColor(k)
    }

    private val wash = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val col = colorFor(kind)
        stroke.color = col
        fill.color = col
        // خودی شووشەکەش بە ڕەنگی هەمان ئایکۆن ڕەنگ دەکرێت (ئەگەر شووشەی ڕەنگاوڕەنگ چالاک بێت)
        if (GlassStyle.colored && width > 0 && height > 0) {
            val cx = width / 2f
            val cy = height / 2f
            val r = minOf(width, height) / 2f * 0.86f
            val rgb = col and 0x00FFFFFF
            wash.shader = RadialGradient(cx - r * .12f, cy - r * .15f, r,
                intArrayOf(rgb or (0x38 shl 24), rgb or (0x66 shl 24), rgb or (0xAA shl 24)),
                floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, wash)
        }
        c.save()
        c.translate(0f, 1.1f * d)
        glyph(c, shadowStroke, shadowFill, 1.4f * d)
        c.restore()
        glyph(c, stroke, fill, 0f)
    }

    private fun glyph(c: Canvas, stroke: Paint, fill: Paint, extra: Float) {
        val cx = width / 2f
        val cy = height / 2f
        val s = width / 46f
        stroke.strokeWidth = 2.2f * s + extra
        when (kind) {
            MIC -> {
                box.set(cx - 4.5f * s, cy - 11f * s, cx + 4.5f * s, cy + 2f * s)
                c.drawRoundRect(box, 4.5f * s, 4.5f * s, fill)
                box.set(cx - 8f * s, cy - 6f * s, cx + 8f * s, cy + 8f * s)
                c.drawArc(box, 0f, 180f, false, stroke)
                c.drawLine(cx, cy + 8f * s, cx, cy + 12f * s, stroke)
                c.drawLine(cx - 4f * s, cy + 12f * s, cx + 4f * s, cy + 12f * s, stroke)
            }
            STOP -> {
                box.set(cx - 7f * s, cy - 7f * s, cx + 7f * s, cy + 7f * s)
                c.drawRoundRect(box, 2.5f * s, 2.5f * s, fill)
            }
            PLAY -> {
                path.reset()
                path.moveTo(cx - 5f * s, cy - 9f * s)
                path.lineTo(cx + 9f * s, cy)
                path.lineTo(cx - 5f * s, cy + 9f * s)
                path.close()
                c.drawPath(path, fill)
            }
            PAUSE -> {
                c.drawRoundRect(cx - 7f * s, cy - 9f * s, cx - 2f * s, cy + 9f * s, s, s, fill)
                c.drawRoundRect(cx + 2f * s, cy - 9f * s, cx + 7f * s, cy + 9f * s, s, s, fill)
            }
            SPEAK -> {
                val gx = cx - 2f * s
                path.reset()
                box.set(gx - 8f * s, cy - 3.2f * s, gx - 4.6f * s, cy + 3.2f * s)
                path.addRoundRect(box, 0.8f * s, 0.8f * s, Path.Direction.CW)
                path.moveTo(gx - 4.6f * s, cy - 3.2f * s)
                path.lineTo(gx - 0.2f * s, cy - 7.5f * s)
                path.lineTo(gx - 0.2f * s, cy + 7.5f * s)
                path.lineTo(gx - 4.6f * s, cy + 3.2f * s)
                path.close()
                c.drawPath(path, fill)
                for (i in 0..1) {
                    val r = (4.8f + i * 3.8f) * s
                    box.set(gx + 1f * s - r, cy - r, gx + 1f * s + r, cy + r)
                    c.drawArc(box, -46f, 92f, false, stroke)
                }
            }
            TRANSLATE -> {   // گڵۆب
                val r = 10f * s
                c.drawCircle(cx, cy, r, stroke)
                c.drawLine(cx - r, cy, cx + r, cy, stroke)
                box.set(cx - 4.6f * s, cy - r, cx + 4.6f * s, cy + r)
                c.drawOval(box, stroke)
            }
            AUTO -> {        // تیری خولاوە (refresh)
                val r = 8.5f * s
                box.set(cx - r, cy - r, cx + r, cy + r)
                c.drawArc(box, -50f, 280f, false, stroke)
                val a = Math.toRadians(230.0)
                val px = cx + r * cos(a).toFloat()
                val py = cy + r * sin(a).toFloat()
                val t = Math.toRadians(320.0)
                val tx = cos(t).toFloat(); val ty = sin(t).toFloat()
                val nx = cos(a).toFloat(); val ny = sin(a).toFloat()
                path.reset()
                path.moveTo(px + tx * 5f * s, py + ty * 5f * s)
                path.lineTo(px + nx * 4.2f * s - tx * 1.5f * s, py + ny * 4.2f * s - ty * 1.5f * s)
                path.lineTo(px - nx * 4.2f * s - tx * 1.5f * s, py - ny * 4.2f * s - ty * 1.5f * s)
                path.close()
                c.drawPath(path, fill)
            }
            REGION -> {      // چوار گۆشەی دیاریکردن
                val h = 9f * s
                val a = 5f * s
                path.reset()
                path.moveTo(cx - h, cy - h + a); path.lineTo(cx - h, cy - h); path.lineTo(cx - h + a, cy - h)
                path.moveTo(cx + h - a, cy - h); path.lineTo(cx + h, cy - h); path.lineTo(cx + h, cy - h + a)
                path.moveTo(cx + h, cy + h - a); path.lineTo(cx + h, cy + h); path.lineTo(cx + h - a, cy + h)
                path.moveTo(cx - h + a, cy + h); path.lineTo(cx - h, cy + h); path.lineTo(cx - h, cy + h - a)
                c.drawPath(path, stroke)
                c.drawCircle(cx, cy, 1.8f * s, fill)
            }
            CLOSE -> {       // ✕
                val h = 6.5f * s
                c.drawLine(cx - h, cy - h, cx + h, cy + h, stroke)
                c.drawLine(cx + h, cy - h, cx - h, cy + h, stroke)
            }
            CHEVRON -> {
                path.reset()
                path.moveTo(cx - 7f * s, cy + 3f * s)
                path.lineTo(cx, cy - 4f * s)
                path.lineTo(cx + 7f * s, cy + 3f * s)
                c.drawPath(path, stroke)
            }
        }
    }

    companion object {
        /** ڕەنگی بنەڕەتیی هەر هێمایەک (ڕوون و زیندوو، تا لەسەر شووشەی ڕوون دیار بێت) */
        fun defaultColor(k: Int): Int = when (k) {
            MIC -> 0xFFFF4D9A.toInt()        // پەمەیی
            STOP -> 0xFFFF4D5E.toInt()       // سوور
            PLAY -> 0xFF35E08A.toInt()
            PAUSE -> 0xFFFFB340.toInt()
            SPEAK -> 0xFFA58BFF.toInt()      // مۆر
            TRANSLATE -> 0xFF4DB2FF.toInt()  // شین
            AUTO -> 0xFF35E08A.toInt()       // سەوز
            REGION -> 0xFF2EE6D6.toInt()     // تورکوازی
            CLOSE -> 0xFFFF5A5F.toInt()      // سوور
            CHEVRON -> 0xFFB4C2FF.toInt()    // شینی کاڵ
            else -> 0xFFFFFFFF.toInt()
        }

        const val MIC = 0
        const val STOP = 1
        const val SPEAK = 2
        const val TRANSLATE = 3
        const val AUTO = 4
        const val REGION = 5
        const val CHEVRON = 6
        const val CLOSE = 7
        const val PLAY = 8
        const val PAUSE = 9
    }
}
