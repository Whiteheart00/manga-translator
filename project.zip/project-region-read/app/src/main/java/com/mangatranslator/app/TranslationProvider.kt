package com.mangatranslator.app

import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

enum class TranslationProvider(val id: String, val label: String) {
    GOOGLE("google", "تەنها Google"),
    GEMINI("gemini", "تەنها Gemini"),
    GEMINI_QUOTA_GOOGLE("gemini_quota_google", "Gemini؛ Google تەنها لە تەواوبوونی quota");
    /** Arabic keeps legacy warmup; hybrid must not send even a warmup translation before quota. */
    fun warmGoogle(sourceLang: String): Boolean = sourceLang == "ar" || this == GOOGLE
    companion object {
        fun fromId(id: String?): TranslationProvider = values().firstOrNull { it.id == id } ?: GOOGLE
    }
}

/** No racing: only a confirmed HTTP 429 can switch the hybrid mode to Google. */
internal class TranslationRouter(
    private val now: () -> Long = { System.nanoTime() / 1_000_000 },
    private val cooldownMs: Long = 30_000L
) {
    private val quotaUntil = ConcurrentHashMap<String, Long>()

    fun <T> run(provider: TranslationProvider, keysRaw: String, gemini: () -> T, google: () -> T): T {
        if (provider == TranslationProvider.GOOGLE) return google()
        val keys = GeminiKeys.parse(keysRaw).sorted().joinToString("\n")
        if (keys.isEmpty()) throw IOException("کلیلی Gemini لە ڕێکخستنەکان دابنێ")
        if (provider == TranslationProvider.GEMINI) return gemini()
        val until = quotaUntil[keys]
        if (until != null && until > now()) return google()
        return try {
            gemini().also { quotaUntil.remove(keys) }
        } catch (error: ApiException) {
            if (error.code != 429) throw error
            quotaUntil[keys] = now() + cooldownMs
            google()
        }
    }

    fun batch(
        provider: TranslationProvider, keys: String, texts: List<String>,
        gemini: ((Int, String) -> Unit) -> List<String?>,
        google: (List<String>) -> List<String?>,
        onItem: (Int, String) -> Unit
    ): List<String?> {
        val result = arrayOfNulls<String>(texts.size)
        return run(provider, keys,
            gemini = { gemini { i, value -> result[i] = value; onItem(i, value) } },
            google = {
                val missing = texts.indices.filter { result[it] == null }
                val values = google(missing.map { texts[it] })
                for ((position, i) in missing.withIndex()) {
                    result[i] = values.getOrNull(position)
                    result[i]?.let { onItem(i, it) }
                }
                result.toList()
            })
    }

    companion object { val shared = TranslationRouter() }
}
