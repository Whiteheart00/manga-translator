package com.mangatranslator.app

/** Monotonic progress: a full buffer must never trap the writer forever. */
internal class PiperPlaybackProgress(private val stallMs: Long = 2000L) {
    var playedFrames = 0L
        private set
    private var lastUnsigned = 0L
    private var wraps = 0L
    private var pendingSince = -1L

    fun update(rawHead: Int, written: Long, playing: Boolean, now: Long): Boolean {
        val unsigned = rawHead.toLong() and 0xffffffffL
        if (unsigned < lastUnsigned && lastUnsigned - unsigned > 0x80000000L) wraps += 1L shl 32
        lastUnsigned = unsigned
        val head = wraps + unsigned
        if (head > playedFrames) {
            playedFrames = head
            pendingSince = if (playing && written > head) now else -1L
        }
        if (!playing || written <= playedFrames) { pendingSince = -1L; return true }
        val since = pendingSince
        if (since < 0L) { pendingSince = now; return true }
        return now - since < stallMs
    }
}
