package com.mangatranslator.app

/**
 * ڕووبەری ژێرنووس کاتێک شاشە دەسوڕێتەوە (یوتوب فوڵسکرین = لاندسکەیپ). فەنکشنی پاک، بێ Android، تاقیکراو.
 *
 * ڕووبەرەکە بە پیکسێلی شاشەی ئەو ئاراستەیە دیاری کراوە؛ لە ئاراستەیەکی تر واتای نییە (لە لاندسکەیپدا دەکەوێتە شوێنی هەڵە).
 * بۆیە بۆ هەر ئاراستەیەک ڕووبەرێکی جیاواز هەیە: ئەوەی بەکارهێنەر دیاری کردووە، یان ئەگەر نەبوو بارێکی بنەڕەتی
 * لە خوارەوەی ڤیدیۆ (شوێنی ئاسایی ژێرنووس).
 */
object LiveGeometry {
    class Box(val left: Float, val top: Float, val right: Float, val bottom: Float)
    class Size(val w: Int, val h: Int)

    /** قەبارەی شاشە لە ئاراستەی [landscape]، لەسەر بنەمای قەبارەی فیزیکی (ڕووبەری گرتن لە ئاراستەکانی تر هەمان پیکسێلە) */
    fun screenFor(landscape: Boolean, anyW: Int, anyH: Int): Size {
        val long = maxOf(anyW, anyH).coerceAtLeast(2)
        val short = minOf(anyW, anyH).coerceAtLeast(2)
        return if (landscape) Size(long, short) else Size(short, long)
    }

    /** باری بنەڕەتی: لاندسکەیپ = ژێرەوەی ڤیدیۆی فوڵسکرین؛ پۆرترەیت = خوارەوەی ڤیدیۆی سەرەوەی شاشە */
    fun defaultBand(w: Int, h: Int): Box =
        if (w > h) Box(w * 0.10f, h * 0.70f, w * 0.90f, h * 0.96f)
        else Box(w * 0.04f, h * 0.20f, w * 0.96f, h * 0.34f)
}
