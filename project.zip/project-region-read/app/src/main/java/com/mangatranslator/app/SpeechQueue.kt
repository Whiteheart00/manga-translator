package com.mangatranslator.app

/**
 * ڕیزی دەنگی ژێرنووسی زیندوو: FIFO ی ڕاستەقینە (فەنکشنی پاک، بێ Android، تاقیکراو).
 *
 * یاسا: **هیچ ڕستەیەک ناسڕدرێتەوە، ناپەڕێنرێت و نابڕدرێت.** هەموو ڕستەیەک بە ڕیزی دەرکەوتنی دەخوێنرێتەوە.
 * کاتێک چەند ڕستە لە ڕیزدا چاوەڕێن، لە یەک خوێندنەوەدا (بە هەمان ڕیز، تا [maxChars] پیت) پێکەوە دەنێردرێن بۆ
 * ئەوەی نێوانیان بێدەنگی و داواکاری TTS کەم بێت؛ و کەمێک خێراتر دەخوێنرێنەوە ([Batch.boost]، تا [maxBoost])
 * بۆ ئەوەی ڕیزەکە کۆ نەبێتەوە. هیچ کاتژمێرێکی «کۆن بوو» و هیچ سنوورێک بۆ ژمارەی ڕستەکان نییە.
 */
class SpeechQueue(
    private val maxChars: Int = 300,
    private val maxBoost: Float = 1.3f
) {
    class Batch(val text: String, val boost: Float, val count: Int)

    private val q = ArrayDeque<String>()

    fun isEmpty() = q.isEmpty()
    fun size() = q.size
    fun clear() = q.clear()

    /** ڕستەیەک کە نەخوێندرایەوە دەگەڕێتەوە سەرەتای ڕیز، تا لەگەڵ ڕستەی دواتر بلکێت و پێکەوە بخوێنرێتەوە */
    fun addFirst(text: String) {
        val t = text.trim()
        if (t.isNotEmpty()) q.addFirst(t)
    }

    /** هەموو ئەوەی لە ڕیزدا ماوە کورتە (کۆی وشەکان ≤٣): دەبێت چاوەڕێی ڕستەی دواتر بکرێت */
    fun onlyShort(): Boolean = q.isNotEmpty() && SpeechMerge.isShort(q.joinToString(" "))

    fun add(text: String) {
        val t = text.trim()
        if (t.isNotEmpty()) q.addLast(t)
    }

    /**
     * یەکەم ڕستەی چاوەڕێ (+ ئەوانەی دوای ئەو کە لە [maxChars] دا جێ دەبنەوە)؛ null ئەگەر ڕیز بەتاڵ بێت.
     * ڕستەی کورت (≤٣ وشە) لەگەڵ ڕستەی دواتر دەلکێت تا لانیکەم ٤ وشە دەبن (فایلی دەنگی کوردی بۆ کورتەکان دەنگی نییە):
     * «براکەم» «ئازایە» «گەورەیە» «براوەیە» «من زۆر خۆشم دەوێت» ← «براکەم ئازایە گەورەیە براوەیە. من زۆر خۆشم دەوێت.»
     */
    /** Same text and speed that take() will use, without removing any lines. */
    fun peek(): Batch? = next(remove = false)

    fun take(): Batch? = next(remove = true)

    private fun next(remove: Boolean): Batch? {
        if (q.isEmpty()) return null
        val pending = q.size
        val units = ArrayList<String>()
        var taken = 0
        var len = 0
        while (taken < q.size) {
            var end = taken
            var w = 0
            while (end < q.size && w < SpeechMerge.MIN_WORDS) { w += SpeechMerge.words(q[end]); end++ }
            val unit = SpeechMerge.joinUnit(q.subList(taken, end))
            if (units.isNotEmpty() && len + 1 + unit.length > maxChars) break
            units.add(unit)
            len += unit.length + 1
            taken = end
        }
        if (remove) repeat(taken) { q.removeFirst() }
        val text = when {
            taken == 1 -> units[0]
            units.size == 1 -> SpeechMerge.ensureEnd(units[0])
            else -> units.joinToString(" ") { SpeechMerge.ensureEnd(it) }
        }
        val boost = (1f + 0.06f * (pending - 1)).coerceIn(1f, maxBoost)
        return Batch(text, boost, taken)
    }
}
