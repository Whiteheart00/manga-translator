package com.mangatranslator.app

import android.content.Context
import android.os.PowerManager

/** Stops automatic capture only while the screen is off; active cadence is unchanged. */
internal class CaptureLoad(context: Context) {
    private val power = context.applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager
    val interactive: Boolean get() = power.isInteractive
}
