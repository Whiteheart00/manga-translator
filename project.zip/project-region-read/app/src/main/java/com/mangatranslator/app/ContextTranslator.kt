package com.mangatranslator.app

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

/**
 * وەرگێڕانی دەقی OCR → سۆرانی بە Gemini، بۆ هەموو زمانەکان (ئینگلیزی، جاپانی، چینی، کۆری، عەرەبی، هیندی، خۆکار).
 *
 *  - هەموو بابلەکانی شاشە لە یەک داواکاریدا دەنێردرێن، بۆ ئەوەی Gemini ڕستەی تەواو و دراوسێکان ببینێت
 *    (ڕێگری لە وەرگێڕانی وشە بە وشە و ماناگۆڕینی وشە فرەماناکان).
 *  - هەر بابڵێک ژمارەی خۆی (i) هەیە: ئەگەر مۆدێل بابڵێک بپەڕێنێت، تەنها ئەو یەک بابڵە دەچێتە یەدەگ (Google)، نەک هەمووی.
 *  - stream: هەر بابڵێک هەر کە ئامادە بوو لەسەر شاشە دەردەکەوێت.
 *  - فەرهەنگی وشە ناڕوونەکان وەک ئاماژەی ڕێنمایی (نەک جێگرتنەوە) دەنێردرێت.
 * لە thread ی پاشبنەما بانگ بکرێت.
 */
object ContextTranslator {

    private const val TAG = "ContextTranslator"
    private const val CHUNK_ITEMS = 28
    private const val CHUNK_CHARS = 3500

    /** ڕێساکانی وەرگێڕان: بۆ وەرگێڕانی دەق (لێرە) و بۆ پرۆمپتی وێنەی ڕووبەر (RegionTranslator) هاوبەشن */
    const val VISION_RULES =
        "Translate the MEANING of each whole sentence in context, never word by word or literally. " +
            "Words with several unrelated meanings (bank, light, spring, bat, match, bar, fan, ring, scale, plant...) must be understood " +
            "from the whole sentence and the neighbouring blocks; if still unclear prefer the meaning that fits manga, comics, stories or app screens. " +
            "If one sentence continues across consecutive blocks, still output one item per block but make them read naturally together. " +
            "Abstract or modern concepts (accountability, privacy, burnout, user-friendly...) get a natural Kurdish equivalent that carries the idea, not a literal calque. "

    private val SYSTEM =
        "You are a professional translator into natural, fluent, SPOKEN Central Kurdish (Sorani, Arabic script). " +
            "The input is text read by OCR from ONE phone screen (manga, comics, webtoons, games, chat, video subtitles, apps, web pages). " +
            "It is a JSON array of {\"i\": number, \"t\": text}; every item is a separate text block in reading order and the blocks are context for each other.\n" +
            "RULES:\n" +
            "1. " + VISION_RULES + "Keep the tone (casual, angry, formal, funny, shouting).\n" +
            "2. OCR may have small mistakes (missing letters, look-alike characters, missing diacritics, hyphenated line breaks): infer the intended text. Arabic may be Modern Standard or any dialect.\n" +
            "3. Use correct Sorani letters (ی ک ە ێ ۆ ڵ ڕ ڤ), never Arabic/Persian ي ك ى. Keep names consistent as Kurdish-script transliterations. Keep numbers, emoji and Latin-script brand names unchanged.\n" +
            "4. Sound effects: a short natural Kurdish equivalent, or keep as is.\n" +
            "5. If a block is already Sorani Kurdish, copy it unchanged. If it is Sorani written in Latin letters, write the same sentence in Sorani script by meaning.\n" +
            "6. If a block is only noise (watermark, page number, stray symbols, UI button), return an empty string for it.\n" +
            "7. Optional disambiguation hints may follow: use a hint only when its meaning fits the context; never output the hint lists.\n" +
            "OUTPUT: only a JSON array with exactly one {\"i\", \"t\"} object per input item, same i values. Never merge, split, skip or add items."

    private val SCHEMA: JSONObject = JSONObject()
        .put("type", "ARRAY")
        .put(
            "items", JSONObject()
                .put("type", "OBJECT")
                .put(
                    "properties", JSONObject()
                        .put("i", JSONObject().put("type", "INTEGER"))
                        .put("t", JSONObject().put("type", "STRING"))
                )
                .put("required", JSONArray().put("i").put("t"))
        )

    private val WS = Regex("\\s+")

    private val cache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 600
    }

    private fun langName(lang: String) = when (lang) {
        "en" -> "English"
        "ar" -> "Arabic"
        "ja" -> "Japanese (manga text may come from vertical lettering)"
        "zh" -> "Chinese"
        "ko" -> "Korean"
        "hi" -> "Hindi"
        else -> "unknown; detect it for each block (may be mixed)"
    }

    /** کلیلی cache: دەق + دراوسێکانی (چونکە هەمان وشە لە چوارچێوەی جیاواز مانای جیاوازە) */
    private fun cacheKey(lang: String, clean: List<String>, i: Int): String =
        "$lang|${clean.getOrNull(i - 1).orEmpty().hashCode()}|${clean[i]}|${clean.getOrNull(i + 1).orEmpty().hashCode()}"

    /**
     * دەگەڕێتەوە لیستێک بە درێژیی [texts]:
     *   دەق = وەرگێڕدراو، "" = ڕاگەیاندنی مۆدێل کە ئەوە دەق نییە (noise)، null = وەرنەگێڕدرا (بانگکەر Google بەکاربهێنێت).
     * [onItem] لە هەر thread ێکەوە بانگ دەکرێت هەر کە بابڵێک ئامادە بوو (index ی ناو [texts]).
     * هەڵە فڕێدەدات تەنها ئەگەر هیچ بابڵێک وەرنەگێڕدرابێت.
     */
    fun translate(
        ctx: Context,
        texts: List<String>,
        lang: String,
        keysRaw: String,
        fast: Boolean,
        strict: Boolean = false,
        onItem: (Int, String) -> Unit
    ): List<String?> {
        if (keysRaw.isBlank()) throw IOException("no Gemini key")
        val clean = texts.map { it.replace('\n', ' ').replace(WS, " ").trim() }
        val result = arrayOfNulls<String>(clean.size)
        val todo = ArrayList<Int>()
        for ((i, t) in clean.withIndex()) {
            if (t.isEmpty() || (t.length < 2 && !TextPrep.hasCjk(t))) {
                result[i] = ""
                continue
            }
            val hit = synchronized(cache) { cache[cacheKey(lang, clean, i)] }
            if (hit != null) {
                result[i] = hit
                onItem(i, hit)
            } else todo.add(i)
        }
        if (todo.isEmpty()) return result.toList()

        // دابەشکردن بۆ پارچەی گونجاو (بەزۆری تەنها یەک پارچە)
        val chunks = ArrayList<List<Int>>()
        var cur = ArrayList<Int>()
        var chars = 0
        for (i in todo) {
            if (cur.isNotEmpty() && (cur.size >= CHUNK_ITEMS || chars + clean[i].length > CHUNK_CHARS)) {
                chunks.add(cur); cur = ArrayList(); chars = 0
            }
            cur.add(i)
            chars += clean[i].length
        }
        if (cur.isNotEmpty()) chunks.add(cur)

        var firstError: Throwable? = null
        if (chunks.size == 1) {
            firstError = runChunk(ctx, clean, chunks[0], lang, keysRaw, fast, result, strict, onItem)
        } else {
            val errs = java.util.concurrent.ConcurrentLinkedQueue<Throwable>()
            val latch = CountDownLatch(chunks.size)
            val pool = Executors.newFixedThreadPool(chunks.size.coerceAtMost(3))
            try {
                for (c in chunks) pool.execute {
                    try {
                        runChunk(ctx, clean, c, lang, keysRaw, fast, result, strict, onItem)?.let { errs.add(it) }
                    } finally {
                        latch.countDown()
                    }
                }
                latch.await()
            } finally {
                pool.shutdownNow()
            }
            firstError = errs.peek()
        }

        if (strict && firstError != null) throw (firstError as? IOException ?: IOException(firstError.message, firstError))
        if (strict && todo.any { result[it] == null }) throw IOException("Gemini: وەرگێڕانەکە ناتەواوە")
        val delivered = todo.count { result[it] != null }
        if (delivered == 0 && firstError != null) throw (firstError as? IOException ?: IOException(firstError.message, firstError))
        return result.toList()
    }

    /** یەک پارچە. null = سەرکەوت (یان بەشێکی سەرکەوت)؛ Throwable = هەڵە */
    private fun runChunk(
        ctx: Context,
        clean: List<String>,
        idx: List<Int>,
        lang: String,
        keysRaw: String,
        fast: Boolean,
        result: Array<String?>,
        strict: Boolean,
        onItem: (Int, String) -> Unit
    ): Throwable? {
        val input = JSONArray()
        idx.forEachIndexed { k, g -> input.put(JSONObject().put("i", k).put("t", clean[g])) }
        val hints = try { AmbiguityGlossary.hintsFor(ctx, idx.map { clean[it] }) } catch (_: Throwable) { "" }
        val user = buildString {
            append("Source language: ").append(langName(lang)).append('\n')
            if (hints.isNotEmpty()) append("Disambiguation hints (only if the meaning fits):\n").append(hints).append('\n')
            append("Input:\n").append(input.toString())
        }

        fun body(model: String, think: Boolean): String {
            val gen = JSONObject()
                .put("temperature", 0.2)
                .put("maxOutputTokens", 4096)
                .put("responseMimeType", "application/json")
                .put("responseSchema", SCHEMA)
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            return JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", user)))
                    )
                )
                .put("generationConfig", gen)
                .toString()
        }

        val got = BooleanArray(idx.size)
        return try {
            GeminiKeys.withKeys(keysRaw) { key ->
                GeminiModels.call(fast, quotaSensitive = strict) { m, think ->
                    RegionTranslator.streamPost(body(m, think), key, m) { o ->
                        val k = o.optInt("i", -1)
                        if (k in idx.indices && !got[k]) {
                            got[k] = true
                            val g = idx[k]
                            val out = TextPrep.finish(o.optString("t", ""))
                            result[g] = out
                            if (out.isNotBlank()) {
                                synchronized(cache) { cache[cacheKey(lang, clean, g)] = out }
                            }
                            if (strict || out.isNotBlank()) onItem(g, out)
                        }
                    }
                }
            }
            if (got.any { !it }) Log.w(TAG, "model skipped ${got.count { !it }}/${idx.size} blocks → fallback")
            null
        } catch (t: Throwable) {
            Log.w(TAG, "Gemini text translate failed: ${t.message}")
            t
        }
    }
}
