package com.mangatranslator.app

/**
 * ڕستەی زۆر کورت (١-٣ وشە) لەلایەن دەنگی ئۆفلاین (Piper / TTS ی سیستەم) بێدەنگ دەبێت یان نابیسترێت.
 * بۆیە ڕستەی کورت دەلکێنرێت بە ڕستەی دواتر (یان ئەگەر دوایین بوو، بە ڕستەی پێشوو) و وەک یەک خوێندنەوە دەخوێنرێتەوە.
 */
object SpeechMerge {

    /** ڕستە بە کەمتر لەم ژمارە وشەیە «کورت»ە و دەلکێنرێت */
    const val MIN_WORDS = 4   // ٣ وشە یان کەمتر = کورت (فایلی دەنگی کوردی بۆ ئەمانە دەنگی نییە)

    // Count in one pass, without compiling a regex or allocating a token list.
    // Match Java Regex \s (ASCII whitespace), preserving existing word boundaries.
    fun words(s: String): Int {
        var count = 0
        var counted = false
        for (ch in s) {
            if (ch == ' ' || ch in '\t'..'\r') {
                counted = false
            } else if (!counted && ch.isLetterOrDigit()) {
                count++
                counted = true
            }
        }
        return count
    }

    fun isShort(s: String): Boolean = words(s) < MIN_WORDS

    /** نیشانەی کۆتایی ڕستە (ئەگەر هەبوو، خاڵ زیاد ناکرێت) */
    private const val END = ".!?؟…"
    /** نیشانە لاوازەکان: کاتێک ڕستەی کورت دەلکێت بە ڕستەی دواتر لەکۆتایی لادەبرێن (براکەم. ئازایە → براکەم ئازایە) */
    private val WEAK = charArrayOf('.', '،', ',', ';', ':', '…', ' ')

    /** ئەگەر ڕستەکە نیشانەی کۆتایی نییە، خاڵی بۆ دادەنێت (بۆ وچانی سروشتی لە دەنگدا) */
    fun ensureEnd(s: String): String {
        val t = s.trimEnd()
        return if (t.isEmpty() || t.last() in END) t else "$t."
    }

    /** چەند ڕستەی کورت دەکاتە یەک ڕستە: بە بۆشایی (نەک کۆما) و بێ نیشانەی کۆتایی لە نێوان بەشەکان */
    fun joinUnit(frags: List<String>): String {
        if (frags.size == 1) return frags[0]
        val sb = StringBuilder()
        for ((i, f) in frags.withIndex()) {
            if (i > 0) sb.append(' ')
            sb.append(if (i < frags.size - 1) f.trimEnd(*WEAK) else f)
        }
        return sb.toString()
    }

    /**
     * «یەکە»: ڕستەی کورت پێکەوە کۆ دەکرێنەوە تا لانیکەم [MIN_WORDS] وشە دەبن.
     * نموونە: «براکەم» «ئازایە» «گەورەیە» «براوەیە» «من زۆر خۆشم دەوێت» ← «براکەم ئازایە گەورەیە براوەیە. من زۆر خۆشم دەوێت.»
     */
    fun merge(texts: List<String>): List<String> {
        val clean = texts.map { it.trim() }.filter { it.isNotEmpty() }
        val units = ArrayList<String>()
        var i = 0
        while (i < clean.size) {
            var end = i
            var w = 0
            while (end < clean.size && w < MIN_WORDS) { w += words(clean[end]); end++ }
            val frags = clean.subList(i, end)
            val unit = joinUnit(frags)
            if (w < MIN_WORDS && units.isNotEmpty()) {
                // کۆتا و هێشتا کورتە: دەلکێت بە ڕستەی پێشوو
                units[units.size - 1] = ensureEnd(units.last()) + " " + unit
            } else {
                units.add(if (frags.size > 1) ensureEnd(unit) else unit)
            }
            i = end
        }
        return units
    }
}

/**
 * دەرچوونەکانی خۆمان (ئەو وەرگێڕانانەی لەسەر شاشە نیشان دراون) بیر دەکاتەوە، بۆ ئەوەی ئەگەر OCR/Accessibility
 * دووبارە هەمان دەق بخوێنێتەوە، دووبارە وەرنەگێڕدرێتەوە (لووپ).
 */
object OwnOutput {
    private const val MAX = 200
    private val exact = HashSet<String>()
    private val recent = ArrayDeque<String>()

    private fun norm(s: String): String =
        s.lowercase()
            .replace('ي', 'ی').replace('ى', 'ی').replace('ك', 'ک')
            .filter { it.isLetterOrDigit() }

    @Synchronized
    fun note(text: String) {
        if (!exact.add(text)) return
        val n = norm(text)
        if (n.length < 6) return
        recent.addLast(n)
        if (recent.size > MAX) {
            recent.removeFirst()
            if (exact.size > MAX * 3) exact.clear()
        }
    }

    @Synchronized
    fun matches(text: String): Boolean {
        val n = norm(text)
        if (n.length < 6) return false
        for (r in recent) {
            if (r == n) return true
            val lo = minOf(r.length, n.length)
            val hi = maxOf(r.length, n.length)
            if (lo >= 8 && lo * 10 >= hi * 7 && (r.contains(n) || n.contains(r))) return true
        }
        return false
    }

    @Synchronized
    fun clear() { exact.clear(); recent.clear() }
}
