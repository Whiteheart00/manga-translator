package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.concurrent.Callable
import java.util.concurrent.Executors

class TranslationCacheTest {
    @Before fun reset() = TranslationCache.clear()

    @Test fun normalizesWhitespaceAndSeparatesLanguages() {
        TranslationCache.put("en", " hello\n world ", " سڵاو ")
        assertEquals("سڵاو", TranslationCache.get("en", "hello world"))
        assertNull(TranslationCache.get("ar", "hello world"))
    }

    @Test fun ignoresEmptySourcesPlaceholdersAndOversizedSources() {
        for (text in listOf("", " \n ", "x".repeat(801))) TranslationCache.put("en", text, "result")
        for (translation in listOf("", " ", "؟", "…")) TranslationCache.put("en", "hello", translation)
        assertEquals(0, TranslationCache.size())
    }

    @Test fun evictsLeastRecentlyUsedEntry() {
        repeat(600) { TranslationCache.put("en", "text$it", "result$it") }
        assertEquals("result0", TranslationCache.get("en", "text0"))
        TranslationCache.put("en", "new", "result")
        assertNull(TranslationCache.get("en", "text1"))
        assertEquals("result0", TranslationCache.get("en", "text0"))
        assertEquals(600, TranslationCache.size())
    }

    @Test fun concurrentAccessStaysBounded() {
        val pool = Executors.newFixedThreadPool(4)
        try {
            val futures = pool.invokeAll((0..3).map { worker -> Callable {
                repeat(1000) {
                    TranslationCache.put("en", "$worker:$it", "result")
                    TranslationCache.get("en", "$worker:$it")
                }
            } })
            futures.forEach { it.get() }
            assertEquals(600, TranslationCache.size())
        } finally { pool.shutdownNow() }
    }
}
