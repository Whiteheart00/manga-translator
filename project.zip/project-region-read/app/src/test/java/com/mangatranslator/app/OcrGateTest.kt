package com.mangatranslator.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OcrGateTest {

    private fun run(
        first: Boolean = false, settled: Boolean = false, sinceChange: Long = 0, sinceOcr: Long = 10_000,
        busy: Boolean = false, kurdish: Boolean = false
    ) = OcrGate.shouldRun(first, settled, sinceChange, sinceOcr, busy, kurdish)

    @Test fun firstOcrRunsImmediatelyEvenIfNotSettled() {
        assertTrue(run(first = true, settled = false, sinceChange = 0, sinceOcr = 0))
    }

    @Test fun busyOcrNeverRunsTwice() {
        assertFalse(run(first = true, busy = true))
        assertFalse(run(settled = true, busy = true))
    }

    @Test fun settledRegionRunsAfterGap() {
        assertTrue(run(settled = true, sinceOcr = 300))
        assertFalse(run(settled = true, sinceOcr = 100))      // < ٢٢٠ms
    }

    @Test fun movingBackgroundIsForcedAfterForceMs() {
        assertFalse(run(settled = false, sinceChange = 300))
        assertTrue(run(settled = false, sinceChange = 450))
    }

    @Test fun kurdishIsFaster() {
        assertTrue(run(settled = false, sinceChange = 250, kurdish = true))
        assertFalse(run(settled = false, sinceChange = 250, kurdish = false))
        assertTrue(run(settled = true, sinceOcr = 150, kurdish = true))
        assertFalse(run(settled = true, sinceOcr = 150, kurdish = false))
    }
}
