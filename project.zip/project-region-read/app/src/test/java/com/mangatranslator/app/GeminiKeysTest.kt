package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.util.UUID

class GeminiKeysTest {
    private fun keys() = List(3) { UUID.randomUUID().toString() }

    @Test fun parsesSeparatorsAndRemovesDuplicates() {
        val k = keys()
        assertEquals(k, GeminiKeys.parse("${k[0]},${k[1]};${k[0]}\n${k[2]} short"))
    }

    @Test fun eachKeyIsAttemptedOnceEvenWhenOneIsCoolingDown() {
        val k = keys()
        GeminiKeys.rest(k[0], 401)
        val tried = mutableListOf<String>()
        try {
            GeminiKeys.withKeys<Unit>(k.joinToString("\n")) {
                tried += it
                throw ApiException(404, "missing model")
            }
            fail("Expected API failure")
        } catch (e: ApiException) {
            assertEquals(404, e.code)
        }
        assertEquals(3, tried.size)
        assertEquals(k.toSet(), tried.toSet())
        assertNotEquals(k[0], tried.first())
    }

    @Test fun stopsAfterSuccess() {
        val k = keys()
        var calls = 0
        val result = GeminiKeys.withKeys(k.joinToString("\n")) {
            if (++calls == 1) throw ApiException(429, "quota")
            "success"
        }
        assertEquals("success", result)
        assertEquals(2, calls)
    }

    @Test fun missingKeysNeverSendARequest() {
        var called = false
        try {
            GeminiKeys.withKeys(" , short ; ") { called = true }
            fail("Expected missing key failure")
        } catch (_: IOException) { }
        assertFalse(called)
    }

    @Test fun ordinaryIoFailureIsNotRetried() {
        var calls = 0
        val error = IOException("offline")
        try {
            GeminiKeys.withKeys<Unit>(keys().joinToString("\n")) { calls++; throw error }
            fail("Expected IO failure")
        } catch (e: IOException) { assertSame(error, e) }
        assertEquals(1, calls)
    }
}
