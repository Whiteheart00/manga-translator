package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Test

class NameFilterScopeTest {
    private val names = NameFilter.parse("John\nAlex\nSarah")
    private fun all(text: String, chosen: List<String> = names, strict: Boolean = false) =
        NameFilter.strip(text, chosen, strict, everywhere = true)

    @Test fun defaultModeStillKeepsNamesInsideAndAtTheEnd() {
        assertEquals("Tell Sarah to call Alex.", NameFilter.strip("John: Tell Sarah to call Alex.", names))
    }
    @Test fun startModeNeverContinuesRemovingNamesAfterSpeakerSeparator() {
        assertEquals("Sarah is here.", NameFilter.strip("John: Sarah is here.", names))
        assertEquals("Sarah is here.", NameFilter.strip("John - Sarah is here.", names))
    }
    @Test fun everywhereRemovesStartMiddleAndEnd() {
        assertEquals("Tell to call.", all("John: Tell Sarah to call Alex."))
    }
    @Test fun everyOccurrenceIsRemovedWithoutMatchingPartOfAWord() {
        assertEquals("Johnson told Johnny that John2 and _John are here.",
            all("John: Johnson told Johnny that John2 and _John are here."))
        assertEquals("and are here.", all("John and John are here."))
    }
    @Test fun possessivesAndNamesEmbeddedInApostropheWordsStayIntact() {
        assertEquals("John's book and John’s pen belong to O'John.",
            all("John's book and John’s pen belong to O'John."))
    }
    @Test fun caseIsIgnoredEverywhere() {
        assertEquals("Come with and.", all("Come with JOHN and sArAh."))
    }
    @Test fun fullMultiwordNamesMatchBeforeSentenceSplitting() {
        val chosen = NameFilter.parse("Smith\nDr. Smith")
        assertEquals("I met and today.", all("I met Dr. Smith and Smith today.", chosen))
    }
    @Test fun regexCharactersInANameAreLiteral() {
        assertEquals("Call and keep AAB.", all("Call A+B and keep AAB.", listOf("A+B")))
    }
    @Test fun unicodeNamesUseUnicodeWordBoundaries() {
        assertEquals("سڵاو و ئەحمەدی و ئەحمەد٢.",
            all("سڵاو ئەحمەد و ئەحمەدی و ئەحمەد٢.", listOf("ئەحمەد")))
    }
    @Test fun namesOnlyAndPunctuationOnlyRemaindersBecomeEmpty() {
        assertEquals("", all("John, Sarah, Alex."))
        assertEquals("", all("(John)"))
        assertEquals("", all("John: Alex!"))
    }
    @Test fun punctuationAndEmptyNameBracketsAreCleaned() {
        assertEquals("Hello!", all("Hello, John!"))
        assertEquals("Hello!", all("Hello (John)!"))
        assertEquals("My friends.", all("My friends John, Sarah, Alex."))
        assertEquals("Hello!", all("Hello 'John'!"))
    }
    @Test fun strictCheckboxDoesNotLimitEverywhereMode() {
        assertEquals("Tell to come.", all("Tell John to come.", strict = true))
        assertEquals("Tell John to come.", NameFilter.strip("Tell John to come.", names, strict = true))
    }
    @Test fun multipleLinesAndSentencesAreHandled() {
        assertEquals("Hello. How are you?", all("John: Hello.\nSarah: How are you Alex?"))
    }
    @Test fun editedNameListsReplaceTheCompiledMatcher() {
        assertEquals("Tell Sarah.", all("Tell John Sarah.", listOf("John")))
        assertEquals("Tell John.", all("Tell John Sarah.", listOf("Sarah")))
        assertEquals("Tell Sarah.", all("Tell John Sarah.", listOf("John")))
    }
    @Test fun noMatchOrEmptyNamesNeverAlterTheInput() {
        val text = "  Johnson: stay here.\nKeep this line.  "
        assertEquals(text, all(text))
        assertEquals(text, all(text, emptyList()))
        assertEquals(text, all(text, listOf("", " ")))
    }
}
