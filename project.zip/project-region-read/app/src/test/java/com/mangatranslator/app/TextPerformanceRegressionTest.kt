package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.random.Random

class TextPerformanceRegressionTest {
    private fun originalWords(s: String): Int =
        s.trim().split(Regex("\\s+")).count { word -> word.any { it.isLetterOrDigit() } }

    @Test fun wordBoundariesMatchOriginalIncludingUnicode() {
        val samples = listOf("", " \t\n", "hello world", "براکەم ئازایە", "123 ! ? abc",
            "a\u00a0b", "a\u2003b", "a\tb\nc\u000bd\u000ce\rf", "你好、世界", "😀 !!!")
        samples.forEach { assertEquals(it, originalWords(it), SpeechMerge.words(it)) }
    }

    @Test fun randomizedWordCountsMatchOriginal() {
        val random = Random(72)
        val alphabet = "abc123!? براکەم\t\n\r\u000b\u000c\u00a0\u2003你好"
        repeat(3000) {
            val text = buildString { repeat(random.nextInt(250)) { append(alphabet[random.nextInt(alphabet.length)]) } }
            assertEquals(text, originalWords(text), SpeechMerge.words(text))
        }
    }

    @Test fun preparationKeepsFormattingAndCaseBehavior() {
        assertEquals("What are you doing?!", TextPrep.prepare("WHAT ARE\n YOU DOING?!"))
        assertEquals("Hello I am here. I know!", TextPrep.prepare("HELLO I AM HERE. I KNOW!"))
        assertEquals("Hello world", TextPrep.prepare("  Hello\tworld  "))
        assertEquals("کوردی", TextPrep.finish("**كوردی** ¤\u200e"))
        assertEquals("ی ی ک", TextPrep.fixSorani("ي ى ك"))
    }
}
