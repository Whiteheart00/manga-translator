package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveSubtitleProgressTest {
    @Test fun cumulativeFramesEmitOnlyNewParts() {
        val p = LiveSubtitleProgress()
        assertEquals("Hello everyone", p.next("Hello everyone", 0).text)
        assertEquals("welcome", p.next("Hello everyone welcome", 100).text)
        assertEquals("back home.", p.next("Hello everyone welcome back home.", 200).text)
    }
    @Test fun shortAdditionToLongLineIsNeverLostToSimilarity() {
        val p = LiveSubtitleProgress()
        val line = "We have been searching for the old house outside the village all day"
        p.next(line, 0)
        assertEquals("now", p.next("$line now", 100).text)
    }
    @Test fun shortExactRepeatIsSilentEvenAfterBlank() {
        val p = LiveSubtitleProgress()
        p.next("Yes", 0)
        p.absent()
        assertTrue(p.next("YES!", 100).repeated)
    }
    @Test fun repeatedRollingFramesDoNotRestartSpeech() {
        val p = LiveSubtitleProgress()
        p.next("Where are you going?", 0)
        p.next("Where are you going? I will come with you.", 100)
        val result = p.next("I will come with you. Wait for me!", 200)
        assertTrue(result.continuation)
        assertEquals("Wait for me!", result.text)
    }
    @Test fun shortenedFrameDoesNotReplayOldPrefix() {
        val p = LiveSubtitleProgress()
        p.next("Hello everyone welcome back", 0)
        assertTrue(p.next("Hello everyone", 100).repeated)
        assertEquals("today", p.next("Hello everyone welcome back today", 200).text)
    }
    @Test fun caseLineWrapAndPunctuationAreIgnored() {
        val p = LiveSubtitleProgress()
        p.next("HELLO, EVERYONE!", 0)
        assertTrue(p.next("Hello\neveryone", 100).repeated)
        assertEquals("welcome.", p.next("Hello everyone welcome.", 200).text)
    }
    @Test fun unrelatedLineIsImmediateAndNotCutInMiddle() {
        val p = LiveSubtitleProgress()
        p.next("where are you going", 0)
        val line = "Then he asked where are you going again"
        assertEquals(line, p.next(line, 1).text)
    }
    @Test fun commonSingleWordIsNotRollingOverlap() {
        val p = LiveSubtitleProgress()
        p.next("Bring it to the gate", 0)
        assertEquals("gate is closed now", p.next("gate is closed now", 100).text)
    }
    @Test fun differentShortSentencesAreNeverFuzzyDuplicates() {
        val p = LiveSubtitleProgress()
        p.next("I can go", 0)
        assertEquals("I can't go", p.next("I can't go", 100).text)
    }
    @Test fun longCaptionsKeepTheirEndBeyondTwoHundredCharacters() {
        val p = LiveSubtitleProgress()
        val line = "The villagers have waited outside for a long time. ".repeat(6).trim()
        p.next(line, 0)
        assertEquals("Finally he arrived.", p.next("$line Finally he arrived.", 100).text)
    }
    @Test fun completesTruncatedWordWithoutRestartingThePhrase() {
        val p = LiveSubtitleProgress()
        p.next("I will protec", 0)
        assertEquals("protect you.", p.next("I will protect you.", 100).text)
    }
    @Test fun translatedDifferentSourceSameCleanedOutputIsSilent() {
        val p = LiveSubtitleProgress()
        val first = LiveTranslationFilter.clean("بەڵێ John 123")
        val second = LiveTranslationFilter.clean("بەڵێ Alex 456")
        assertFalse(p.next(first, 0, allowOverlap = false).repeated)
        assertTrue(p.next(second, 100, allowOverlap = false).repeated)
    }
    @Test fun independentTranslationsDoNotStripCommonOpeningWords() {
        val p = LiveSubtitleProgress()
        p.next("من ئێرەم", 0, allowOverlap = false)
        assertEquals("من ئێرەم بەڵام تۆ لە کوێیت؟", p.next("من ئێرەم بەڵام تۆ لە کوێیت؟", 100, allowOverlap = false).text)
    }
    @Test fun expiredLineMayBeSpokenInANewScene() {
        val p = LiveSubtitleProgress(100)
        p.next("Hello everyone", 0)
        p.absent()
        assertFalse(p.next("Hello everyone", 101).repeated)
    }
    @Test fun sameVisibleCaptionStaysSilentAfterMemoryWindow() {
        val p = LiveSubtitleProgress(100)
        p.next("Hello everyone", 0)
        assertTrue(p.next("Hello everyone", 101).repeated)
    }
    @Test fun unchangedCaptionCanGrowAfterLongStaticDisplay() {
        val p = LiveSubtitleProgress(100)
        p.next("Welcome", 0)
        assertEquals("back", p.next("Welcome back", 1000).text)
    }
    @Test fun boundedHistoryDoesNotBlockNewLines() {
        val p = LiveSubtitleProgress(capacity = 3)
        repeat(10) { assertFalse(p.next("New subtitle number $it", it.toLong(), allowOverlap = false).repeated) }
        assertFalse(p.next("New subtitle number 0", 11, allowOverlap = false).repeated)
    }
    @Test fun cjkWithoutSpacesEmitsOnlyTheNewCharacters() {
        val p = LiveSubtitleProgress()
        p.next("今天", 0)
        assertEquals("下雨了", p.next("今天下雨了", 100).text)
    }
    @Test fun kurdishCumulativeCaptionsContinueInPlace() {
        val p = LiveSubtitleProgress()
        p.next("سڵاو هاوڕێ", 0)
        assertEquals("چۆنی؟", p.next("سڵاو هاوڕێ چۆنی؟", 100).text)
    }
    @Test fun immediatelyGrowingShortWordIsNotSpokenAgain() {
        val p = LiveSubtitleProgress()
        p.next("Hi", 0)
        assertEquals("there friend", p.next("Hi there friend", 100).text)
    }
    @Test fun repeatedWordsUseTheLongestRollingOverlap() {
        val p = LiveSubtitleProgress()
        p.next("Outside alpha beta alpha beta", 0)
        assertEquals("gamma", p.next("alpha beta alpha beta gamma", 100).text)
    }
}
