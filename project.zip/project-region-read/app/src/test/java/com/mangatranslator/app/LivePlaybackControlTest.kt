package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LivePlaybackControlTest {
    @Test fun stoppedCannotResume() {
        val c = LivePlaybackControl<String>()
        assertEquals(LivePlaybackControl.Phase.STOPPED, c.phase)
        assertNull(c.resume())
        assertFalse(c.pause("old"))
        assertFalse(c.accepts(c.generation))
    }
    @Test fun pauseBlocksOldCallbacksAndPreservesLastLine() {
        val c = LivePlaybackControl<Pair<String, String>>()
        val first = c.start("portrait" to "first")
        assertTrue(c.accepts(first))
        assertTrue(c.pause("landscape" to "last sentence"))
        var callbacks = 0
        c.withCurrent(first) { callbacks++ }
        assertEquals(0, callbacks)
        assertEquals("landscape" to "last sentence", c.resume())
        assertFalse(c.accepts(first))
        c.withCurrent(c.generation) { callbacks++ }
        assertEquals(1, callbacks)
        assertNull(c.resume())
    }
    @Test fun repeatedPauseDoesNotOverwriteSavedSelection() {
        val c = LivePlaybackControl<String>()
        c.start("initial")
        assertTrue(c.pause("saved"))
        assertFalse(c.pause("wrong"))
        assertEquals("saved", c.resume())
    }
    @Test fun stopWhilePausedClearsResumeAndRejectsDeferredAttach() {
        val c = LivePlaybackControl<String>()
        val old = c.start("old")
        c.pause("last")
        c.stop()
        assertNull(c.resume())
        c.start("new")
        var attached = false
        c.withCurrent(old) { attached = true }
        assertFalse(attached)
    }
    @Test fun rapidCyclesNeverAcceptEarlierRuns() {
        val c = LivePlaybackControl<Int>()
        val tokens = mutableListOf(c.start(0))
        repeat(50) { i ->
            assertTrue(c.pause(i))
            assertEquals(i, c.resume())
            tokens.forEach { assertFalse(c.accepts(it)) }
            tokens.add(c.generation)
            assertTrue(c.accepts(c.generation))
        }
    }
    @Test fun preservesBothOrientationsWithoutRequiringASelectionAgain() {
        val c = LivePlaybackControl<Map<Boolean, String>>()
        val regions = mapOf(false to "portrait region", true to "landscape region")
        c.start(regions)
        c.pause(regions)
        assertEquals(regions, c.resume())
    }
}
