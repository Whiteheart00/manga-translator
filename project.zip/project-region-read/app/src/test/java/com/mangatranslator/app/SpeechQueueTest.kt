package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechQueueTest {

    private fun drain(q: SpeechQueue): List<SpeechQueue.Batch> {
        val out = ArrayList<SpeechQueue.Batch>()
        while (true) out.add(q.take() ?: break)
        return out
    }

    @Test fun singleLineIsTakenAsIsAtNormalSpeed() {
        val q = SpeechQueue()
        q.add("سڵاو چۆنی")
        val b = q.take()!!
        assertEquals("سڵاو چۆنی", b.text)
        assertEquals(1, b.count)
        assertEquals(1f, b.boost, 0.001f)
        assertTrue(q.isEmpty())
        assertNull(q.take())
    }

    @Test fun nothingIsEverDroppedAndOrderIsKept() {
        val q = SpeechQueue(maxChars = 60)
        val lines = (1..200).map { "ئەمە ڕستەی ژمارە $it دەبێت." }
        lines.forEach { q.add(it) }
        val spoken = drain(q).joinToString(" ") { it.text }
        // هەموو ٢٠٠ ڕستە، بەو ڕیزەی هاتوون
        var pos = 0
        for (l in lines) {
            val i = spoken.indexOf(l, pos)
            assertTrue("ونبوو: $l", i >= 0)
            pos = i + l.length
        }
        assertEquals(lines.size, drain(SpeechQueue()).size + lines.size) // drain ی ڕیزی بەتاڵ = ٠
    }

    @Test fun manyLinesAreMergedInOrderWithinLimit() {
        val q = SpeechQueue(maxChars = 300)
        q.add("یەکەم ڕستە زۆر درێژە."); q.add("دووەم ڕستە زۆر درێژە"); q.add("سێیەم ڕستە زۆر درێژە؟")
        val b = q.take()!!
        assertEquals("یەکەم ڕستە زۆر درێژە. دووەم ڕستە زۆر درێژە. سێیەم ڕستە زۆر درێژە؟", b.text)
        assertEquals(3, b.count)
    }

    @Test fun shortSentencesChainThenLongOneFollows() {
        val q = SpeechQueue()
        listOf("براکەم", "ئازایە", "گەورەیە", "براوەیە", "من زۆر خۆشم دەوێت").forEach { q.add(it) }
        val b = q.take()!!
        assertEquals("براکەم ئازایە گەورەیە براوەیە. من زۆر خۆشم دەوێت.", b.text)
        assertEquals(5, b.count)
    }

    @Test fun lonelyShortWaitsForNext() {
        val q = SpeechQueue()
        q.add("براکەم"); q.add("ئازایە")
        assertTrue(q.onlyShort())
        q.add("گەورەیە براوەیە")
        assertTrue(!q.onlyShort())
    }

    @Test fun mergeStopsAtMaxCharsButRemainderStaysQueued() {
        val q = SpeechQueue(maxChars = 50)
        val a = "ا".repeat(30)
        q.add("$a یەک دوو سێ."); q.add("$a یەک دوو سێ."); q.add("$a یەک دوو سێ.")
        val b1 = q.take()!!
        assertEquals(1, b1.count)
        assertEquals(2, q.size())
        assertEquals(1, q.take()!!.count)
        assertEquals(1, q.take()!!.count)
        assertTrue(q.isEmpty())
    }

    @Test fun overlongSingleLineIsStillSpoken() {
        val q = SpeechQueue(maxChars = 50)
        val long = "ب".repeat(500)
        q.add(long)
        assertEquals(long, q.take()!!.text)
    }

    @Test fun backlogSpeedsUpButIsCapped() {
        val q = SpeechQueue(maxChars = 10, maxBoost = 1.3f)
        for (i in 1..3) q.add("l$i a b c.")
        assertEquals(1.12f, q.take()!!.boost, 0.001f)     // ٣ لە ڕیزدا
        val q2 = SpeechQueue(maxChars = 10, maxBoost = 1.3f)
        for (i in 1..20) q2.add("l$i a b c.")
        assertEquals(1.3f, q2.take()!!.boost, 0.001f)     // سنوور
    }

    @Test fun blankIsIgnored() {
        val q = SpeechQueue()
        q.add("   "); q.add("")
        assertTrue(q.isEmpty())
    }
    @Test fun prefetchPreviewMatchesNextPlaybackWithoutConsumingIt() {
        val q = SpeechQueue()
        q.add("باشە."); q.add("سڵاو.")
        val preview = q.peek()!!
        assertEquals(2, q.size())
        val actual = q.take()!!
        assertEquals(preview.text, actual.text)
        assertEquals(preview.boost, actual.boost, 0.001f)
        assertEquals(preview.count, actual.count)
        assertTrue(q.isEmpty())
    }

    @Test fun previewSupportsASingleWordAndAnEmptyQueue() {
        val q = SpeechQueue()
        assertNull(q.peek())
        q.add("نا.")
        assertEquals("نا.", q.peek()!!.text)
        assertEquals(1, q.size())
        assertEquals("نا.", q.take()!!.text)
    }

}
