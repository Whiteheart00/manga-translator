package com.mangatranslator.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class RegionVisionReadTest {
    private fun parse(original: String?, translated: String, lang: String): RegionItem {
        val obj = JSONObject().put("lang", lang).put("kurdish", translated)
        if (original != null) obj.put("original", original)
        return RegionTranslator.parse(JSONArray().put(obj).toString(), 400, 400).single()
    }
    @Test fun providerCannotReplaceTheReportedPostWithOnlyTranslatedProductNames() {
        val item = parse(RegionReadPolicyTest.FIRST, "سیستەمی پلاندانانی سەرچاوە", "en")
        assertEquals(RegionReadPolicyTest.FIRST, item.kurdish)
        assertTrue(item.alreadyKurdish)
    }
    @Test fun nativeCopyPreservesNewlinesLatinSpellingAndPunctuationExactly() {
        val item = parse(RegionReadPolicyTest.SECOND, "دەقێکی گۆڕاو", "ckb")
        assertEquals(RegionReadPolicyTest.SECOND, item.kurdish)
        assertTrue(item.kurdish.contains("profolio"))
    }
    @Test fun sourceInAnotherLanguageStillGetsTranslated() {
        val item = parse("We need a programmer", "پێویستمان بە پڕۆگرامەرە", "en")
        assertEquals("پێویستمان بە پڕۆگرامەرە", item.kurdish)
        assertFalse(item.alreadyKurdish)
    }
    @Test fun compactOrLegacyResponsesWithoutOriginalStillParse() {
        assertEquals("سڵاو ERPNext", parse(null, "سڵاو ERPNext", "ckb").kurdish)
    }
}
