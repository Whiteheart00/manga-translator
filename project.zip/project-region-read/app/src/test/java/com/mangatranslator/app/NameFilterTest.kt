package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Test

class NameFilterTest {

    private val john = listOf("John")

    @Test fun parseTrimsDedupesAndSortsLongestFirst() {
        val l = NameFilter.parse("John:\n sarah \nJOHN\n\nMr Smith")
        assertEquals(listOf("mr smith", "sarah", "john"), l.map { it.lowercase() })
    }

    @Test fun nameAtSentenceStartWithColonIsRemoved() {
        assertEquals("Where are you going?", NameFilter.strip("John: Where are you going?", john))
    }

    @Test fun nameInsideTheSentenceIsKept() {
        assertEquals("Where is John going?", NameFilter.strip("Where is John going?", john))
    }

    @Test fun longerWordsAndPossessivesAreNotTheName() {
        assertEquals("Johnson went home.", NameFilter.strip("Johnson went home.", john))
        assertEquals("John's car is red.", NameFilter.strip("John's car is red.", john))
    }

    @Test fun eachSentenceStartIsChecked() {
        assertEquals("Hello there. How are you?", NameFilter.strip("Hello there. John: How are you?", john))
    }

    @Test fun nameAloneDisappears() {
        assertEquals("", NameFilter.strip("John", john))
        assertEquals("Where?", NameFilter.strip("John. Where?", john))
    }

    @Test fun caseDoesNotMatter() {
        assertEquals("hello", NameFilter.strip("john, hello", john))
    }

    @Test fun literalModeRemovesEvenWithoutSeparator() {
        assertEquals("went home", NameFilter.strip("John went home", john, strict = false))
    }

    @Test fun strictModeNeedsASeparatorOrNameAlone() {
        assertEquals("John went home", NameFilter.strip("John went home", john, strict = true))
        assertEquals("hi", NameFilter.strip("John: hi", john, strict = true))
        assertEquals("", NameFilter.strip("John", john, strict = true))
    }

    @Test fun multiWordNamesWork() {
        assertEquals("Good morning", NameFilter.strip("Mr Smith: Good morning", listOf("Mr Smith")))
    }

    @Test fun twoNamesInARowAreBothRemoved() {
        assertEquals("hi", NameFilter.strip("John Mary: hi", listOf("Mary", "John")))
    }

    @Test fun noNamesMeansNoChange() {
        assertEquals("John: hi", NameFilter.strip("John: hi", emptyList()))
    }
}
