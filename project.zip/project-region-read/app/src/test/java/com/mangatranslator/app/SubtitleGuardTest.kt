package com.mangatranslator.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SubtitleGuardTest {

    // ---------- دەقی OCR ----------
    @Test fun realTextPasses() {
        for (t in listOf("Hello world", "I'm ok", "Go!", "هەڵبژاردن", "مرحبا بك", "你好", "はい")) {
            assertTrue(t, SubtitleGuard.looksLikeRealText(t))
        }
    }

    @Test fun noiseFails() {
        for (t in listOf("", "   ", "|||", ". .", "1234", "l l I i |", "ptkrs", "aaaa", "ااااا", "一", "--- ~~~ ///")) {
            assertFalse("\"$t\"", SubtitleGuard.looksLikeRealText(t))
        }
    }

    // ---------- وەرگێڕان ----------
    @Test fun normalTranslationIsPlausible() {
        assertTrue(SubtitleGuard.plausibleTranslation("Where are you going?", "تۆ بۆ کوێ دەچیت؟"))
        assertTrue(SubtitleGuard.plausibleTranslation("你好吗", "چۆنیت؟ باشیت؟ من زۆر دڵخۆشم بە بینینت"))
    }

    @Test fun noneAndRefusalsAreRejected() {
        assertFalse(SubtitleGuard.plausibleTranslation("xyz", ""))
        assertFalse(SubtitleGuard.plausibleTranslation("xyz", "<NONE>"))
        assertFalse(SubtitleGuard.plausibleTranslation("xyz", "There is no text in this image"))
        assertFalse(SubtitleGuard.plausibleTranslation("xyz", "I'm sorry, I cannot translate this"))
    }

    @Test fun inventedLongTextIsRejected() {
        val long = "ئەمە دەقێکی زۆر درێژە کە مۆدێل داهێناوە و هیچ پەیوەندییەکی بە سەرچاوەکەوە نییە ".repeat(3)
        assertFalse(SubtitleGuard.plausibleTranslation("Hi", long))
    }

    // ---------- ڕووبەری بێ نووسین ----------
    @Test fun flatRegionHasNoTextEdges() {
        val w = 100; val h = 30
        assertFalse(SubtitleGuard.hasTextLikeEdges(IntArray(w * h) { 20 }, w, h))        // ڕەش
        assertFalse(SubtitleGuard.hasTextLikeEdges(IntArray(w * h) { 130 }, w, h))       // خۆڵەمێشی
        // گرادیێنتی نەرم (دیمەنی ئاسایی) هیچ لێوارێکی بەهێزی نییە
        assertFalse(SubtitleGuard.hasTextLikeEdges(IntArray(w * h) { i -> (i % w) }, w, h))
    }

    @Test fun strokesAreTextLikeEdges() {
        val w = 100; val h = 30
        // نووسینی سپی لەسەر ڕەش: هێڵی ستوونی ٣ پیکسێل هەر ٨ پیکسێل جارێک
        val img = IntArray(w * h) { i -> if ((i % w) % 8 < 3) 240 else 10 }
        assertTrue(SubtitleGuard.hasTextLikeEdges(img, w, h))
    }

    @Test fun tinyOrBrokenInputIsSafe() {
        assertFalse(SubtitleGuard.hasTextLikeEdges(IntArray(1), 1, 1))
        assertFalse(SubtitleGuard.hasTextLikeEdges(IntArray(0), 10, 10))
    }
}
