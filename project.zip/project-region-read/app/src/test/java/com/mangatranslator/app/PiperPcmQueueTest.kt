package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class PiperPcmQueueTest {
    @Test(timeout = 1000) fun fullQueueCannotLoseCompletionOrAudio() {
        val q = PiperPcmQueue(3)
        val clips = List(3) { floatArrayOf(it.toFloat()) }
        clips.forEach { assertTrue(q.offer(it, 0)) }
        q.finish()
        assertFalse(q.isDrained)
        clips.forEach { assertSame(it, q.poll(0)) }
        assertTrue(q.isDrained)
        assertNull(q.poll(0))
    }
    @Test fun idleConsumerReceivesCompletionWithNoAudio() {
        val q = PiperPcmQueue()
        q.finish()
        assertNull(q.poll(0))
        assertTrue(q.isDrained)
    }
    @Test fun temporaryEmptyQueueDoesNotMeanEndOfSpeech() {
        val q = PiperPcmQueue()
        assertNull(q.poll(0))
        assertFalse(q.isDrained)
        val clip = floatArrayOf(.1f)
        q.offer(clip, 0)
        assertSame(clip, q.poll(0))
        assertFalse(q.isDrained)
    }
}
