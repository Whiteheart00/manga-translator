package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import java.util.UUID

class GeminiQuotaPolicyTest {
    @Test fun quotaSensitiveCallsKeep429VisibleForProviderRouting() {
        var calls = 0
        val error = assertThrows(ApiException::class.java) {
            GeminiModels.call<String>(true, quotaSensitive = true) { _, _ -> calls++; throw ApiException(429, "quota") }
        }
        assertEquals(429, error.code)
        assertEquals(1, calls)
    }
    @Test fun legacyArabicModelFallbackRemainsUnchanged() {
        var calls = 0
        assertThrows(ApiException::class.java) {
            GeminiModels.call<String>(true) { _, _ -> calls++; throw ApiException(429, "quota") }
        }
        assertTrue(calls > 1)
    }
    @Test fun anotherValidKeyIsTriedBeforeGoogleFallback() {
        val keys = List(2) { UUID.randomUUID().toString() }
        val attempted = mutableListOf<String>()
        val result = TranslationRouter().run(TranslationProvider.GEMINI_QUOTA_GOOGLE, keys.joinToString("\n"),
            gemini = { GeminiKeys.withKeys(keys.joinToString("\n")) { key ->
                attempted += key
                GeminiModels.call(true, quotaSensitive = true) { _, _ ->
                    if (attempted.size == 1) throw ApiException(429, "quota")
                    "gemini"
                }
            } }, google = { error("The second key works") })
        assertEquals("gemini", result)
        assertEquals(2, attempted.distinct().size)
    }
}
