package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class PiperPlaybackProgressTest {
    @Test fun fullBufferWithFrozenHeadTimesOut() {
        val p = PiperPlaybackProgress(100)
        assertTrue(p.update(0, 200, true, 0))
        assertTrue(p.update(0, 200, true, 99))
        assertFalse(p.update(0, 200, true, 100))
    }
    @Test fun realPlaybackProgressResetsTheStallDeadline() {
        val p = PiperPlaybackProgress(100)
        p.update(0, 200, true, 0)
        assertTrue(p.update(50, 200, true, 90))
        assertTrue(p.update(100, 200, true, 180))
        assertFalse(p.update(100, 200, true, 280))
    }
    @Test fun synthesizingNextChunkDoesNotCountAsAnAudioStall() {
        val p = PiperPlaybackProgress(100)
        p.update(100, 100, true, 0)
        assertTrue(p.update(100, 100, true, 10_000))
        assertTrue(p.update(100, 200, true, 10_001))
        assertTrue(p.update(150, 200, true, 10_050))
    }
    @Test fun notPlayingHasNoFalseBufferTimeout() {
        val p = PiperPlaybackProgress(100)
        assertTrue(p.update(0, 200, false, 0))
        assertTrue(p.update(0, 200, false, 10_000))
        assertTrue(p.update(0, 200, true, 10_001))
    }
    @Test fun headPositionIsUnsignedAndWrapsWithoutAFalseFinish() {
        val p = PiperPlaybackProgress(100)
        val total = (1L shl 32) + 100
        assertTrue(p.update(-16, total, true, 0))
        assertEquals((1L shl 32) - 16, p.playedFrames)
        assertTrue(p.update(16, total, true, 50))
        assertEquals((1L shl 32) + 16, p.playedFrames)
    }
    @Test fun aSmallBackwardsCounterCannotClaimMorePlayback() {
        val p = PiperPlaybackProgress(100)
        p.update(100, 200, true, 0)
        assertTrue(p.update(90, 200, true, 99))
        assertEquals(100, p.playedFrames)
        assertFalse(p.update(90, 200, true, 100))
    }
}
