package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveTypingWindowTest {
    private val same: (String, String) -> Boolean = { a, b -> a == b }
    @Test fun fullSubtitleIsImmediateFromTheFirstObservation() {
        val gate = LiveTypingWindow()
        val decision = gate.observe("thewholelineisalreadyvisible", 100, same)
        assertFalse(decision.wait)
        assertFalse(decision.growing)
    }
    @Test fun typewriterStillWaitsButDoesNotDelayNextFullLine() {
        val gate = LiveTypingWindow()
        gate.observe("hello", 100, same)
        assertTrue(gate.observe("hellothere", 200, same).wait)
        assertTrue(gate.observe("hellothere", 300, same).wait)
        assertFalse(gate.observe("runforthegatebeforeitcloses", 400, same).wait)
    }
    @Test fun blankClearsTypingMemory() {
        val gate = LiveTypingWindow()
        gate.observe("hello", 100, same)
        assertTrue(gate.observe("hellothere", 200, same).wait)
        gate.reset()
        assertFalse(gate.observe("hellotherefriend", 300, same).wait)
    }
    @Test fun memoryExpiresAndOcrJitterDoesNotExtendIt() {
        val gate = LiveTypingWindow(1000)
        gate.observe("hello", 100, same)
        gate.observe("hellothere", 200, same)
        val jitter: (String, String) -> Boolean = { _, _ -> true }
        assertTrue(gate.observe("hellothere!", 300, jitter).wait)
        assertFalse(gate.observe("hellothere!", 1300, jitter).wait)
    }
}
