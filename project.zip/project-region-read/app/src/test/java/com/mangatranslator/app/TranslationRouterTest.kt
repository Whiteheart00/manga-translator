package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class TranslationRouterTest {
    private val key = "test-key-long-enough"
    private val hybrid = TranslationProvider.GEMINI_QUOTA_GOOGLE

    @Test fun googleModeNeverCallsGeminiEvenWithAKey() {
        val router = TranslationRouter()
        assertEquals("google", router.run(TranslationProvider.GOOGLE, key,
            gemini = { error("Gemini must not run") }, google = { "google" }))
    }
    @Test fun geminiSuccessNeverStartsGoogle() {
        for (mode in listOf(TranslationProvider.GEMINI, hybrid)) {
            assertEquals("gemini", TranslationRouter().run(mode, key,
                gemini = { "gemini" }, google = { error("Google must not run") }))
        }
    }
    @Test fun onlyQuotaCanTriggerSequentialFallback() {
        val events = mutableListOf<String>()
        val result = TranslationRouter().run(hybrid, key,
            gemini = { events += "gemini"; throw ApiException(429, "quota") },
            google = { events += "google"; "ok" })
        assertEquals("ok", result)
        assertEquals(listOf("gemini", "google"), events)
    }
    @Test fun authServerAndModelErrorsNeverFallBack() {
        for (code in listOf(400, 401, 403, 404, 500, 503, 504)) {
            val error = ApiException(code, "failure")
            val thrown = assertThrows(ApiException::class.java) {
                TranslationRouter().run(hybrid, key,
                    gemini = { throw error }, google = { fail("Unexpected Google call"); "bad" })
            }
            assertSame(error, thrown)
        }
    }
    @Test fun offlineAndParseFailuresDoNotTriggerGoogle() {
        for (error in listOf(IOException("offline"), IllegalStateException("bad response"))) {
            val thrown = assertThrows(error.javaClass) {
                TranslationRouter().run(hybrid, key,
                    gemini = { throw error }, google = { fail("Unexpected Google call"); "bad" })
            }
            assertSame(error, thrown)
        }
    }
    @Test fun geminiOnlyNeverFallsBackOnQuota() {
        assertThrows(ApiException::class.java) {
            TranslationRouter().run(TranslationProvider.GEMINI, key,
                gemini = { throw ApiException(429, "quota") }, google = { fail("Unexpected Google call"); "bad" })
        }
    }
    @Test fun missingKeyIsAnErrorNotAnImplicitGoogleChoice() {
        for (mode in listOf(TranslationProvider.GEMINI, hybrid)) {
            assertThrows(IOException::class.java) {
                TranslationRouter().run(mode, "short",
                    gemini = { error("No valid key") }, google = { error("Must not fall back") })
            }
        }
    }
    @Test fun quotaCooldownIsScopedToKeysAndExpires() {
        var clock = 100L
        val router = TranslationRouter({ clock }, 1000)
        router.run(hybrid, key, gemini = { throw ApiException(429, "quota") }, google = { "google" })
        assertEquals("google", router.run(hybrid, key, gemini = { error("Cooldown") }, google = { "google" }))
        assertEquals("gemini", router.run(hybrid, "different-key-long-enough", gemini = { "gemini" }, google = { error("No quota") }))
        clock = 1100
        assertEquals("gemini", router.run(hybrid, key, gemini = { "gemini" }, google = { error("Expired") }))
    }
    @Test fun geminiOnlyIgnoresHybridCooldown() {
        val router = TranslationRouter()
        router.run(hybrid, key, gemini = { throw ApiException(429, "quota") }, google = { "google" })
        assertEquals("gemini", router.run(TranslationProvider.GEMINI, key, gemini = { "gemini" }, google = { error("Gemini-only") }))
    }
    @Test fun negativeMonotonicClockDoesNotCauseUnconfirmedFallback() {
        assertEquals("gemini", TranslationRouter({ -1000L }).run(hybrid, key,
            gemini = { "gemini" }, google = { error("No confirmed quota") }))
    }
    @Test fun quotaAfterPartialBatchTranslatesOnlyMissingBlocks() {
        val emitted = mutableListOf<Pair<Int, String>>()
        val result = TranslationRouter().batch(hybrid, key, listOf("first", "noise", "last"),
            gemini = { emit -> emit(0, "یەکەم"); emit(1, ""); throw ApiException(429, "quota") },
            google = { texts -> assertEquals(listOf("last"), texts); listOf("کۆتایی") },
            onItem = { i, value -> emitted += i to value })
        assertEquals(listOf("یەکەم", "", "کۆتایی"), result)
        assertEquals(listOf(0 to "یەکەم", 1 to "", 2 to "کۆتایی"), emitted)
    }
    @Test fun incompleteGeminiBatchDoesNotUseGoogleOnOtherErrors() {
        assertThrows(IOException::class.java) {
            TranslationRouter().batch(hybrid, key, listOf("first", "second"),
                gemini = { emit -> emit(0, "یەکەم"); throw IOException("incomplete") },
                google = { error("Not a quota failure") }, onItem = { _, _ -> })
        }
    }
    @Test fun providerIdentifiersRoundTripAndUnknownDefaultsToGoogle() {
        for (mode in TranslationProvider.values()) assertEquals(mode, TranslationProvider.fromId(mode.id))
        assertEquals(TranslationProvider.GOOGLE, TranslationProvider.fromId(null))
        assertEquals(TranslationProvider.GOOGLE, TranslationProvider.fromId("invalid"))
    }
    @Test fun warmupCannotContactGoogleBeforeQuotaInGeminiModes() {
        assertTrue(TranslationProvider.GOOGLE.warmGoogle("en"))
        assertFalse(TranslationProvider.GEMINI.warmGoogle("en"))
        assertFalse(hybrid.warmGoogle("en"))
        for (mode in TranslationProvider.values()) assertTrue(mode.warmGoogle("ar"))
    }
}
