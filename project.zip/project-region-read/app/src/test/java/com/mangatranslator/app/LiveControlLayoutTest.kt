package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Test

class LiveControlLayoutTest {
    @Test fun rightOfStopWhenSpaceExists() {
        assertEquals(LiveControlLayout.Point(64, 20), LiveControlLayout.position(400, 800, 10, 20, 46, 46, 8))
    }
    @Test fun leftOfStopAtRightEdge() {
        assertEquals(LiveControlLayout.Point(296, 20), LiveControlLayout.position(400, 800, 350, 20, 46, 46, 8))
    }
    @Test fun clampsAfterRotation() {
        assertEquals(LiveControlLayout.Point(354, 154), LiveControlLayout.position(400, 200, 700, 500, 46, 46, 8))
    }
    @Test fun tinyScreenDoesNotProduceNegativeCoordinates() {
        assertEquals(LiveControlLayout.Point(0, 0), LiveControlLayout.position(20, 20, 0, 0, 46, 46, 8))
    }
}
