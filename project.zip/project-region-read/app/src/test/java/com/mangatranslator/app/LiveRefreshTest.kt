package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveRefreshTest {
    @Test fun nonArabicLiveCaptureUsesShorterIntervals() {
        assertTrue(LiveRefresh.captureMs(false) < 150)
        assertTrue(LiveRefresh.captureMs(true) < 220)
    }
    @Test fun accessibilityNeverExceedsItsScreenshotRateLimit() {
        assertTrue(LiveRefresh.accessibilityMs(false) >= 333)
        assertTrue(LiveRefresh.accessibilityMs(true) >= 333)
        assertTrue(LiveRefresh.accessibilityMs(false) < 400)
        assertTrue(LiveRefresh.accessibilityMs(true) < 550)
    }
    @Test fun liveRefreshAllowsEarlierOcrButNeverConcurrentOcr() {
        assertTrue(OcrGate.shouldRun(false, true, 0, 120, false, false, fastRefresh = true))
        assertFalse(OcrGate.shouldRun(false, true, 0, 120, false, false))
        assertFalse(OcrGate.shouldRun(true, true, 1000, 1000, true, false, fastRefresh = true))
        assertTrue(OcrGate.shouldRun(false, false, 250, 300, false, false, fastRefresh = true))
        assertFalse(OcrGate.shouldRun(false, false, 250, 300, false, false))
    }
    @Test fun unchangedArabicOcrStillUsesItsExistingThresholds() {
        assertEquals(450L, OcrGate.forceMs(false))
        assertEquals(220L, OcrGate.gapMs(false))
        assertFalse(OcrGate.shouldRun(false, false, 300, 300, false, false))
    }
}
