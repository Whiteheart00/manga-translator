package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReadOnceTest {

    private val norm: (String) -> String = { s -> s.lowercase().filter { it.isLetterOrDigit() } }
    private val sim: (String, String) -> Boolean = { a, b -> a == b }

    private fun strip(text: String, vararg handled: String) =
        ReadOnce.strip(text, handled.toList(), norm, sim)

    @Test fun nextSentenceWrittenWithPreviousOnlyKeepsTheNewPart() {
        val r = strip("Where are you going? I will come with you.", "Where are you going?")
        assertTrue(r.stripped)
        assertEquals("I will come with you.", r.text)
    }

    @Test fun growingSubtitleKeepsOnlyTheNewWords() {
        val r = strip("Hello everyone welcome back", "Hello everyone")
        assertEquals("welcome back", r.text)
    }

    @Test fun punctuationAndCaseDoNotMatter() {
        val r = strip("WHERE ARE YOU GOING I will come", "where are you going?")
        assertTrue(r.stripped)
        assertEquals("I will come", r.text)
    }

    @Test fun twoHandledSentencesAreBothStripped() {
        val r = strip("First sentence here. Second sentence there. Third one new.", "First sentence here.", "Second sentence there.")
        assertEquals("Third one new.", r.text)
        assertEquals(2, r.matched.size)
    }

    @Test fun everythingAlreadyReadLeavesNothing() {
        val r = strip("Where are you going? I will come with you.", "Where are you going?", "I will come with you.")
        assertTrue(r.stripped)
        assertEquals("", r.text)
    }

    @Test fun unrelatedTextIsUntouched() {
        val r = strip("A completely different line", "Where are you going?")
        assertFalse(r.stripped)
        assertEquals("A completely different line", r.text)
    }

    @Test fun onlyThePrefixIsStrippedNotTheMiddle() {
        val r = strip("Then he asked where are you going again", "where are you going")
        assertFalse(r.stripped)
    }

    @Test fun veryShortPreviousTextIsNeverStripped() {
        val r = strip("Yes I did it yesterday", "Yes")
        assertFalse(r.stripped)
        assertEquals("Yes I did it yesterday", r.text)
    }

    @Test fun nothingHandledMeansNothingStripped() {
        assertFalse(strip("Some new line of text").stripped)
    }
}
