package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveFastPathRegressionTest {
    @Test fun normalizedRepeatCannotReuseOldOffsetsForGrowingText() {
        val p = LiveSubtitleProgress()
        p.next("HELLO,   EVERYONE!", 0)
        assertTrue(p.next("hello everyone", 10).repeated)
        assertEquals("welcome back", p.next("hello everyone welcome back", 20).text)
    }
    @Test fun rawKeyCacheStillHonorsExpiryAndBlankFrames() {
        val p = LiveSubtitleProgress(memoryMs = 100)
        p.next("Same subtitle", 0)
        assertTrue(p.next("Same subtitle", 50).repeated)
        p.absent()
        assertFalse(p.next("Same subtitle", 151).repeated)
    }
    @Test fun expiredCjkCurrentFrameStillProvidesThePrefix() {
        val p = LiveSubtitleProgress(memoryMs = 100)
        p.next("今天", 0)
        assertEquals("下雨了", p.next("今天下雨了", 1000).text)
    }
    @Test fun formattingFallbackRetainsSoraniNormalization() {
        assertEquals("کوردی", LiveTranslationFilter.clean("**كوردی** ¤\u200e John 42"))
        assertEquals("سڵاو هاوڕێ", LiveTranslationFilter.clean("\tسڵاو\n  هاوڕێ\r"))
        assertEquals("سڵاو، چۆنی؟", LiveTranslationFilter.clean("سڵاو ، چۆنی ؟"))
    }
    @Test fun filterCacheNeverLeaksAnotherCaptionsResult() {
        repeat(100) {
            assertEquals("سڵاو هاوڕێ", LiveTranslationFilter.clean("سڵاو John123 هاوڕێ"))
            assertEquals("چۆنی؟", LiveTranslationFilter.clean("Alex چۆنی؟ 456"))
            assertEquals("سڵاو هاوڕێ", LiveTranslationFilter.clean("سڵاو John123 هاوڕێ"))
        }
    }
    @Test fun alreadyCleanPathKeepsNumeralsAndZeroWidthWordJoiner() {
        val text = "ژمارە ١٢٣ و ۱۲۳، هاو\u200cڕێ؟"
        assertEquals(text, LiveTranslationFilter.clean(text))
    }
}
