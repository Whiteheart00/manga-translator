package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Test

class NameFilterMarkedTest {
    private val names = NameFilter.parse("John\nSarah\nDr. Smith\nئەحمەد")
    private fun marked(text: String, selected: List<String> = names, strict: Boolean = false) =
        NameFilter.strip(text, selected, strict = strict, followedByMarker = true)

    @Test fun eachRequestedMarkerQualifiesAListedName() {
        for (marker in listOf(":", ",", "؛")) {
            assertEquals("Hello.", marked("John${marker} Hello."))
            assertEquals("Hello.", marked("John${marker}Hello."))
        }
    }
    @Test fun appliesAtStartMiddleAndEndButUnmarkedNamesStay() {
        assertEquals("Tell Sarah to come. John is here.", marked("John: Tell Sarah to come. John is here."))
        assertEquals("I heard hello.", marked("I heard John: hello."))
        assertEquals("Hello.", marked("Hello John؛."))
        assertEquals("John", marked("John"))
    }
    @Test fun aMarkerIsRequiredEvenAtTheStartOrForANameAlone() {
        assertEquals("John went home.", marked("John went home."))
        assertEquals("John.", marked("John."))
        assertEquals("", marked("John:"))
        assertEquals("", marked("John,"))
        assertEquals("", marked("John؛"))
    }
    @Test fun doesNotSilentlyAcceptOtherSeparators() {
        for (marker in listOf("-", "–", "—", "|", ";", "،", "!", "؟")) {
            val text = "John$marker Hello."
            assertEquals(text, marked(text))
        }
    }
    @Test fun supportsSpacesTabsAndUnicodeSpacesBeforeTheMarker() {
        assertEquals("Hello.", marked("John : Hello."))
        assertEquals("Hello.", marked("John\t, Hello."))
        assertEquals("Hello.", marked("John\u00a0؛ Hello."))
    }
    @Test fun unlistedNamesAreNeverRemoved() {
        assertEquals("Alex: Hello Sarah.", marked("Alex: Hello Sarah."))
    }
    @Test fun wordBoundariesAndPossessivesRemainProtected() {
        val text = "Johnson: John2, _John؛ John's: John’s, O'John: hello."
        assertEquals(text, marked(text))
    }
    @Test fun caseMultiwordAndUnicodeNamesWork() {
        assertEquals("hello.", marked("jOhN: hello."))
        assertEquals("Hello.", marked("Dr. Smith: Hello."))
        assertEquals("سڵاو.", marked("ئەحمەد؛ سڵاو."))
    }
    @Test fun ignoresLegacyStrictCheckboxAndHasPriorityOverEverywhereFlag() {
        assertEquals("Tell Sarah hello.", marked("Tell John: Sarah hello.", strict = true))
        assertEquals("John went home.", NameFilter.strip("John went home.", names,
            everywhere = true, followedByMarker = true))
    }
    @Test fun switchingScopesCannotReuseTheWrongCompiledRule() {
        assertEquals("Hello.", NameFilter.strip("Hello John.", names, everywhere = true))
        assertEquals("Hello John.", marked("Hello John."))
        assertEquals("Hello.", marked("Hello John؛."))
        assertEquals("Hello.", NameFilter.strip("Hello John.", names, everywhere = true))
    }
    @Test fun namesEnteredWithATrailingMarkerAreHandledInThisScope() {
        assertEquals("Hello.", marked("John؛ Hello.", NameFilter.parse("John؛")))
        assertEquals("John is here.", marked("John is here.", NameFilter.parse("John؛")))
    }
    @Test fun literalRegexCharactersAndRepeatedLabelsWork() {
        assertEquals("Hello AAB: there.", marked("A+B: Hello AAB: there.", listOf("A+B")))
        assertEquals("Hello.", marked("John: Sarah, John؛ Hello."))
        assertEquals("", marked("John: Sarah, ئەحمەد؛"))
    }
}
