package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.io.Closeable
import java.util.concurrent.atomic.AtomicReference

class ModelFileDownloadTest {
    @get:Rule val folder = TemporaryFolder()
    private val data = "model contents".toByteArray()

    private fun serve(handler: (HttpExchange) -> Unit, test: (String) -> Unit) {
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        server.soTimeout = 5000
        val failure = AtomicReference<Throwable?>(null)
        val thread = Thread {
            try {
                server.accept().use { socket ->
                    socket.soTimeout = 5000
                    HttpExchange(socket).use(handler)
                }
            } catch (error: Throwable) {
                if (!server.isClosed) failure.set(error)
            }
        }
        thread.start()
        try { test("http://127.0.0.1:${server.localPort}/model") }
        finally {
            server.close()
            thread.join(5000)
        }
        failure.get()?.let { throw AssertionError("Test HTTP server failed", it) }
    }

    // Plain Java sockets keep the tests compatible with Android's compile classpath.
    private class Headers {
        private val values = linkedMapOf<String, String>()
        fun add(name: String, value: String) { values[name.lowercase()] = value }
        fun getFirst(name: String): String? = values[name.lowercase()]
        fun entries() = values.entries
    }

    private class HttpExchange(private val socket: Socket) : Closeable {
        val requestHeaders = Headers()
        val responseHeaders = Headers()
        val responseBody get() = socket.getOutputStream()
        init {
            val reader = socket.getInputStream().bufferedReader(Charsets.US_ASCII)
            check(reader.readLine() != null)
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) break
                val colon = line.indexOf(':')
                if (colon > 0) requestHeaders.add(line.substring(0, colon), line.substring(colon + 1).trim())
            }
        }
        fun sendResponseHeaders(code: Int, length: Long) {
            val headers = buildString {
                append("HTTP/1.1 $code Test\r\nContent-Length: $length\r\nConnection: close\r\n")
                for ((name, value) in responseHeaders.entries()) append("$name: $value\r\n")
                append("\r\n")
            }
            responseBody.write(headers.toByteArray(Charsets.US_ASCII))
        }
        override fun close() { socket.close() }
    }

    private fun HttpExchange.respond(code: Int, body: ByteArray) {
        sendResponseHeaders(code, body.size.toLong())
        responseBody.use { it.write(body) }
    }

    @Test fun resumesFromVerifiedOffset() {
        val dst = File(folder.root, "model")
        File(folder.root, "model.part").writeBytes(data.copyOfRange(0, 5))
        var range: String? = null
        serve({
            range = it.requestHeaders.getFirst("Range")
            it.responseHeaders.add("Content-Range", "bytes 5-${data.lastIndex}/${data.size}")
            it.respond(206, data.copyOfRange(5, data.size))
        }) { url -> ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        assertEquals("bytes=5-", range)
        assertArrayEquals(data, dst.readBytes())
        assertFalse(File(folder.root, "model.part").exists())
    }

    @Test fun restartsWhenServerIgnoresRange() {
        val dst = File(folder.root, "model")
        File(folder.root, "model.part").writeText("wrong")
        serve({ it.respond(200, data) }) { url -> ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        assertArrayEquals(data, dst.readBytes())
    }

    @Test fun rejectsWrongRangeWithoutChangingExistingFiles() {
        val dst = File(folder.root, "model").apply { writeText("installed") }
        val part = File(folder.root, "model.part").apply { writeText("model") }
        serve({
            it.responseHeaders.add("Content-Range", "bytes 0-${data.lastIndex}/${data.size}")
            it.respond(206, data)
        }) { url ->
            assertThrows(IOException::class.java) { ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        }
        assertEquals("model", part.readText())
        assertEquals("installed", dst.readText())
    }

    @Test fun truncatedBodyRemainsResumable() {
        val dst = File(folder.root, "model")
        serve({ it.respond(200, data.copyOfRange(0, 5)) }) { url ->
            assertThrows(IOException::class.java) { ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        }
        assertFalse(dst.exists())
        assertEquals(5L, File(folder.root, "model.part").length())
    }

    @Test fun oversizedResponseCannotReplaceInstalledModel() {
        val dst = File(folder.root, "model").apply { writeText("installed") }
        serve({ it.respond(200, ByteArray(100)) }) { url ->
            assertThrows(IOException::class.java) { ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        }
        assertEquals("installed", dst.readText())
        assertTrue(File(folder.root, "model.part").length() <= data.size)
    }

    @Test fun completedPartIsPublishedWithoutAnotherNetworkRequest() {
        val dst = File(folder.root, "model")
        File(folder.root, "model.part").writeBytes(data)
        ModelFileDownload.fetch("http://127.0.0.1:1/unreachable", dst, data.size.toLong()) {}
        assertArrayEquals(data, dst.readBytes())
    }
}
