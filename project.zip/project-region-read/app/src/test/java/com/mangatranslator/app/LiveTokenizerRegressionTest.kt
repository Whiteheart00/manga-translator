package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveTokenizerRegressionTest {
    private fun extension(first: String, second: String, expected: String) {
        val p = LiveSubtitleProgress()
        p.next(first, 0)
        val r = p.next(second, 10)
        assertTrue(r.continuation)
        assertEquals(expected, r.text)
    }
    @Test fun contractionsRemainWhole() {
        extension("We're ready", "We're ready let's go!", "let's go!")
    }
    @Test fun combiningMarksAndZeroWidthNonJoinerKeepBoundaries() {
        extension("cafe\u0301 please", "cafe\u0301 please come", "come")
        extension("سڵاو هاو\u200cڕێ", "سڵاو هاو\u200cڕێ چۆنی؟", "چۆنی؟")
    }
    @Test fun supplementaryLettersUseTheFullUnicodeFallback() {
        extension("Hello 𝒜world", "Hello 𝒜world welcome", "welcome")
    }
    @Test fun numericUnicodeCategoriesKeepTheirOriginalTokenPositions() {
        extension("Gate Ⅳ is open", "Gate Ⅳ is open today", "today")
        extension("Gate ½ is open", "Gate ½ is open today", "today")
    }
    @Test fun caseExpansionStillFiltersCombiningMarks() {
        extension("İSTANBUL is ready", "İSTANBUL is ready today", "today")
    }
    @Test fun reusedRollingMatcherHandlesChangingLengths() {
        val p = LiveSubtitleProgress()
        p.next("Outside alpha beta alpha beta", 0)
        assertEquals("gamma", p.next("alpha beta alpha beta gamma", 10).text)
        assertEquals("delta", p.next("beta gamma delta", 20).text)
        assertEquals("epsilon zeta eta theta", p.next("gamma delta epsilon zeta eta theta", 30).text)
    }
    @Test fun refreshingRecentLinesMaintainsExpiryOrder() {
        val p = LiveSubtitleProgress(memoryMs = 100)
        p.next("First subtitle", 0, false)
        p.next("Second subtitle", 20, false)
        assertTrue(p.next("First subtitle", 70, false).repeated)
        p.absent()
        assertFalse(p.next("Second subtitle", 121, false).repeated)
        assertTrue(p.next("First subtitle", 150, false).repeated)
    }
}
