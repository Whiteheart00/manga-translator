package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveGeometryTest {

    @Test fun landscapeSwapsPhysicalDimensions() {
        val l = LiveGeometry.screenFor(landscape = true, anyW = 1080, anyH = 2400)
        assertEquals(2400, l.w); assertEquals(1080, l.h)
        val p = LiveGeometry.screenFor(landscape = false, anyW = 2400, anyH = 1080)
        assertEquals(1080, p.w); assertEquals(2400, p.h)
    }

    @Test fun landscapeDefaultBandIsInsideScreenAtTheBottom() {
        val sz = LiveGeometry.screenFor(true, 1080, 2400)
        val b = LiveGeometry.defaultBand(sz.w, sz.h)
        assertTrue(b.left >= 0 && b.right <= sz.w && b.top >= 0 && b.bottom <= sz.h)
        assertTrue(b.right > b.left && b.bottom > b.top)
        assertTrue("باری ژێرنووس لە نیوەی خوارەوەیە", b.top >= sz.h * 0.5f)
        assertTrue("پانیی باکە لانیکەم ٦٠٪", (b.right - b.left) >= sz.w * 0.6f)
    }

    @Test fun portraitDefaultBandIsInsideScreen() {
        val sz = LiveGeometry.screenFor(false, 2400, 1080)
        val b = LiveGeometry.defaultBand(sz.w, sz.h)
        assertTrue(b.left >= 0 && b.right <= sz.w && b.top >= 0 && b.bottom <= sz.h)
        assertTrue(b.right > b.left && b.bottom > b.top)
    }

    @Test fun degenerateSizesAreSafe() {
        val s = LiveGeometry.screenFor(true, 0, 0)
        assertTrue(s.w >= 2 && s.h >= 2)
    }
}
