package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveSpeechPartsTest {
    @Test fun completeShortSentenceCanStartBeforeTheNextSentence() {
        assertEquals(listOf("Go!", "We have to leave this place right now."),
            LiveSpeechParts.split("Go! We have to leave this place right now."))
    }
    @Test fun soraniAndCjkSentenceBoundariesWork() {
        assertEquals(listOf("تۆ چۆنی؟", "من باشم."), LiveSpeechParts.split("تۆ چۆنی؟ من باشم."))
        assertEquals(listOf("你好！", "你好吗？"), LiveSpeechParts.split("你好！ 你好吗？"))
    }
    @Test fun namesAndInitialsAreNotSplitAtAbbreviations() {
        assertEquals(listOf("Dr. Smith is here.", "Go!"), LiveSpeechParts.split("Dr. Smith is here. Go!"))
        assertEquals(listOf("U.S. Army arrived.", "Go!"), LiveSpeechParts.split("U.S. Army arrived. Go!"))
    }
    @Test fun longLineCanStartAtANaturalClauseBoundaryWithoutLosingWords() {
        val text = "We need to leave the western gate before the guards get back, " +
            "otherwise everyone in the village will be in serious danger."
        val parts = LiveSpeechParts.split(text)
        assertTrue(parts.size >= 2)
        assertEquals(text, parts.joinToString(" "))
        assertTrue(parts.first().endsWith(','))
    }
    @Test fun singleUnbrokenSentenceIsNotCutAtArbitraryWordGroups() {
        assertEquals(emptyList<String>(), LiveSpeechParts.split("This is one complete sentence without any clause boundary."))
    }
    @Test fun maximumFourPartsKeepsAllSentencesInOrder() {
        val text = "Go! Run! Stop! Come! Leave! Wait!"
        val parts = LiveSpeechParts.split(text)
        assertEquals(4, parts.size)
        assertEquals(text, parts.joinToString(" "))
    }
}
