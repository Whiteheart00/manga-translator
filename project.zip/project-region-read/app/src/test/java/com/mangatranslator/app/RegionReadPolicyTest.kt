package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class RegionReadPolicyTest {
    companion object {
        const val FIRST = "سڵاو لە تۆش برام، نامە بنێرە ئێمە وەک Nwebeen نوێبین نمونەی ئەپ و ERP پێشترمان هەیە و ERPNext بەکارئەهێنین"
        const val SECOND = "سڵاوی خواتان لێبێ هاوڕێیان\nپێویستم بە پڕۆگرامەری زۆر شارەزاهەیە بۆ دروستکردنی سیستەمێکی ERP و ئەپێک.\nتەنها نمونەی کاری جوان بێ …کێشەی نرخم نییە .\nبێزەحمەت لە کۆمێنت profolio خۆتان دانێن با نمونەی کارەکانتان ببینم"
    }
    @Test fun bothReportedPostsAreNativeWithEveryLatinTermIntact() {
        for (text in listOf(FIRST, SECOND)) {
            assertTrue(RegionReadPolicy.isSorani(text))
            assertEquals(setOf(0), RegionReadPolicy.nativeIndices(listOf(text)))
            assertEquals(text, RegionReadPolicy.visionText(text, "وەرگێڕانی هەڵە"))
        }
    }
    @Test fun separateProductBoxesBelongToTheirSoraniParagraph() {
        val lines = listOf("ئێمە نمونەی ئەپ پێشترمان هەیە", "ERP", "ERPNext", "Nwebeen", "و بەکاری دەهێنین")
        assertEquals(lines.indices.toSet(), RegionReadPolicy.nativeIndices(lines))
    }
    @Test fun separateLowercasePortfolioTermIsKept() {
        assertEquals(setOf(0, 1, 2), RegionReadPolicy.nativeIndices(listOf("خۆتان دانێن با نمونەی کارەکانتان ببینم", "profolio", "سڵاو هاوڕێیان")))
    }
    @Test fun anIndependentEnglishParagraphStillRequiresTranslation() {
        val lines = listOf("سڵاو هاوڕێ", "I need an experienced programmer to build a new application for my business.")
        assertEquals(setOf(0), RegionReadPolicy.nativeIndices(lines))
    }
    @Test fun englishOnlyAndArabicOnlyAreNotTreatedAsNativeSorani() {
        assertFalse(RegionReadPolicy.isSorani("ERPNext is an ERP application"))
        assertFalse(RegionReadPolicy.isSorani("مرحبا بكم نحتاج إلى برنامج جديد"))
        assertTrue(RegionReadPolicy.nativeIndices(listOf("ERPNext", "Nwebeen")).isEmpty())
    }
    @Test fun shortMixedSoraniCanContainALongerProductName() {
        assertTrue(RegionReadPolicy.isSorani("ئەمە ERPNext ـە"))
    }
    @Test fun aKurdishQuotationDoesNotTurnAnEnglishArticleIntoNativeText() {
        assertFalse(RegionReadPolicy.isSorani("The Kurdish word سڵاو means hello in this example."))
    }
    @Test fun foreignVisionTranslationIsStillUsed() {
        assertEquals("وەرگێڕانی کوردی", RegionReadPolicy.visionText("We use ERPNext", "وەرگێڕانی کوردی"))
    }
    @Test fun speechPreparationKeepsTheWholeSoraniBodyAndVoicesAcronyms() {
        val spoken = KurdishSpeechPrep.prepare(FIRST)
        assertTrue(spoken.startsWith("سڵاو لە تۆش برام"))
        assertTrue(spoken.contains("ئی ئار پی"))
        assertTrue(spoken.contains("نمونەی ئەپ"))
        assertTrue(spoken.endsWith("بەکارئەهێنین"))
        assertEquals("ئی ئار پی نێکست", KurdishSpeechPrep.prepare("ERPNext"))
    }
    @Test fun systemVoiceLeavesTheOriginalEnglishTermsInTheUtterance() {
        val text = KurdishVoiceText.toEnglish(FIRST)
        assertTrue(text.contains("Nwebeen"))
        assertTrue(text.contains("ERPNext"))
    }
    @Test fun liveSubtitleCleanupIsNotAppliedToRegionSourceText() {
        assertTrue(RegionReadPolicy.visionText(FIRST, "").contains("ERPNext"))
        assertFalse(LiveTranslationFilter.clean(FIRST).contains("ERPNext"))
    }
}
