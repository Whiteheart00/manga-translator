package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveTranslationFilterTest {
    @Test fun removesEnglishWordsAndAsciiNumbersFromMiddle() {
        assertEquals("سڵاو هاوڕێ، چۆنی؟", LiveTranslationFilter.clean("سڵاو John هاوڕێ، 123 چۆنی؟"))
    }
    @Test fun contractionsAndIdentifiersLeaveNoLatinFragments() {
        val result = LiveTranslationFilter.clean("من don't و HP100 و player_2 دەبینم")
        assertFalse(result.any { it in 'A'..'Z' || it in 'a'..'z' || it in '0'..'9' })
        assertTrue(result.contains("دەبینم"))
    }
    @Test fun removesFormattedNumbersAndTimes() {
        assertEquals("کات و پارە", LiveTranslationFilter.clean("کات 12:30 و پارە 1,234.56"))
    }
    @Test fun preservesKurdishNumbersAndLetters() {
        assertEquals("ژمارە ١٢٣ و ۱۲۳", LiveTranslationFilter.clean("ژمارە ١٢٣ و ۱۲۳"))
    }
    @Test fun mixedAdjacentScriptsDoNotDestroyKurdish() {
        assertEquals("سڵاو هاوڕێ", LiveTranslationFilter.clean("سڵاوJohn123هاوڕێ"))
    }
    @Test fun cleansEmptyBrackets() {
        assertEquals("سڵاو هاوڕێ", LiveTranslationFilter.clean("سڵاو (John) [123] هاوڕێ"))
    }
    @Test fun latinOnlyDoesNotProduceSpeechOrCaptionNoise() {
        assertEquals("", LiveTranslationFilter.clean("John 123 HP100!"))
        assertEquals("", LiveTranslationFilter.clean("123 ..."))
    }
    @Test fun normalSoraniRemainsUnchanged() {
        assertEquals("سڵاو، چۆنی هاوڕێ؟", LiveTranslationFilter.clean("سڵاو، چۆنی هاوڕێ؟"))
    }
    @Test fun finishNormalizesArabicLettersAndMarkdown() {
        assertEquals("کوردی", LiveTranslationFilter.clean("**كوردي** English 42"))
    }
    @Test fun blankAndSymbolOnlyDoNotReachOutput() {
        assertEquals("", LiveTranslationFilter.clean(""))
        assertEquals("", LiveTranslationFilter.clean("- [123] -"))
    }
    @Test fun idempotentAndRetainsShortWord() {
        val once = LiveTranslationFilter.clean("بەڵێ Yes 42")
        assertEquals("بەڵێ", once)
        assertEquals(once, LiveTranslationFilter.clean(once))
    }
    @Test fun accentedLatinAndCombiningMarksDoNotLeakFragments() {
        assertEquals("سڵاو هاوڕێ", LiveTranslationFilter.clean("سڵاو Pokémon cafe\u0301 هاوڕێ"))
    }
    @Test fun negativeNumbersAndDuplicateSeparatorsAreCleaned() {
        assertEquals("سڵاو، هاوڕێ", LiveTranslationFilter.clean("سڵاو، John، -12 هاوڕێ"))
    }
}
