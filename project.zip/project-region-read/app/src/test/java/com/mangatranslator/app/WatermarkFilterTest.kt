package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WatermarkFilterTest {
    private val lines = listOf("we march at dawn", "where is the king hiding", "I never asked for this fate",
        "bring me the blade now", "the gods have abandoned us", "hold the gate at all costs")

    @Test fun handlesAreDetected() {
        assertTrue(WatermarkFilter.looksLikeHandle("MKIceAndFire"))
        assertTrue(WatermarkFilter.looksLikeHandle("@MKIceAndFire"))
        assertFalse(WatermarkFilter.looksLikeHandle("My Brothers"))
        assertFalse(WatermarkFilter.looksLikeHandle("Hello"))
    }

    @Test fun staticWatermarkIsDroppedButSubtitlesStay() {
        val w = WatermarkFilter()
        var t = 0L
        var kept = emptyList<Blk>()
        for (i in 0 until 40) {
            t += 400
            val sub = Blk(lines[i % lines.size], 300, 1000, 1700, 1060)
            val wm = Blk(if (i % 2 == 0) "Mklceand" else "MKceAnd", 1500, 1100, 1800, 1160)
            kept = w.filter(listOf(sub, wm), t, 2000, 1200)
        }
        assertEquals(1, kept.size)
        assertEquals(lines[39 % lines.size], kept[0].text)
    }

    @Test fun changingSubtitlesAreNeverDropped() {
        val w = WatermarkFilter()
        var t = 0L
        for (i in 0 until 60) {
            t += 400
            assertEquals(1, w.filter(listOf(Blk(lines[i % lines.size], 300, 1000, 1700, 1060)), t, 2000, 1200).size)
        }
    }
}
