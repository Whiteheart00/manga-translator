# Live subtitle text processing speed

This update reduces CPU work and transient allocations in the live filtering and duplicate-detection stages. It adds no network requests, waits, capture polling or speech-rate changes.

- Ordinary clean Sorani captions bypass regex replacements and string copies after a simple scan. The last filter input/result is cached in a single immutable entry; repeated results return directly.
- Mixed captions skip TextPrep formatting passes when the input has no formatting to fix. Empty-bracket matching is skipped when no opening bracket or quote exists.
- Repeated source frames reuse their normalization and token keys. The previous frame's token offsets never cut a new frame, so punctuation/spacing changes remain safe.
- Cumulative matching iterates bounded history directly, and skips rolling-overlap work when the already matched prefix cannot be improved. The word regex is compiled once across sessions.
- Identical quiet captions do not redraw the overlay. New continuations still update and speak in FIFO order.

## Desktop JVM measurements

Compared with the delivered project-live-clean source using the same JVM, inputs, warmup, alternating measurement order and median of seven rounds. Allocations measured with ThreadMXBean. These are local code timings, not phone or full OCR/network/audio latency measurements.

| Workload | Before (µs/op) | After (µs/op) | Before → after allocated bytes/op |
| --- | ---: | ---: | ---: |
| Clean Sorani, four alternating captions | 5.727 | 0.124 | 2592 → 24 |
| Mixed-language caption repeated | 10.838 | 0.003 | 3672 → 0 |
| Mixed-language captions alternating | 7.199 | 4.151 | 3464 → 2316 |
| Repeated source caption | 2.003 | 0.027 | 6904 → 56 |
| Cumulative source captions | 5.759 | 5.300 | 10865 → 10694 |

The very small cached-call timings reflect repeated identical input; they do not apply to a new translation request. These figures do not imply the whole app is faster by the same ratios. Device hardware, OCR, translation service and voice synthesis still affect end-to-end time.

Before measurement, 20,000 randomized filter results and 20,000 randomized subtitle transitions were compared against the previous implementation, with no differences. Existing semantic tests and six new regression tests also check cache expiry, punctuation changes, CJK growth, Arabic-letter normalization and alternating inputs.

Reproduce with `LIVE_BENCH_KOTLINC=/path/to/kotlinc bash benchmarks/run.sh` on a JDK with ThreadMXBean allocation support. The reference source and raw output are in `benchmarks/`. No Android model or network connection is needed for this benchmark.
