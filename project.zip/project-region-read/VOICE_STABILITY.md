# Offline Kurdish Piper voice stability

This revision addresses code paths that can leave playback waiting or restart already spoken text. The user's exact quiet stretched-vowel sound was not recorded or reproduced on an Android device, so this is not a claim that every audible artifact is eliminated.

## Concrete fixes

- End-of-stream cannot be lost when the three-clip PCM queue is full. Previously `offer(endMark, 1 second)` could fail while the consumer was busy playing a long clip; later polls would wait forever. Completion is now separate from queue capacity, while a marker still wakes an idle consumer.
- Nonblocking AudioTrack writes and final draining check actual playback-head progress. A playing track with pending frames and no progress for two seconds returns an error and releases its buffer instead of spinning indefinitely. An empty track waiting for synthesis is not considered stalled. Timing is monotonic and playback-head counters are treated as unsigned, including wraparound.
- Pause/stop immediately pause and flush the current track. Playback startup shares a short lock with stop, so a late writer cannot restart a track after cancellation.
- Piper records whether playback may have begun. System-voice fallback and live sentence retries remain allowed before playback; a partially played paragraph is not automatically read again from its beginning after a failure. A playback failure is reported, then the live queue can advance. This does not reconstruct or guarantee recovery of an unspoken tail after a native audio-device failure.
- Offline completion/error callbacks check their run ID when delivered on the UI thread. Canceled queued jobs cannot synthesize or finish a newer job.

## Work and resource use

Warmup, rendering and prefetch share a synthesis gate, including cache lookup, so concurrent misses do not synthesize the same clip twice. Warmup is skipped once native inference has succeeded. Prefetch has one running job and at most one latest queued job; old pending work is cleared on stop. Prefetch waits without spinning when inference is busy and does not cold-load the model at background thread priority.

CPU synthesis runs at ordinary priority rather than urgent audio priority. The PCM consumer uses audio priority and restores its original priority afterward. The existing voice speed, chunking, native inference thread count and short-word punctuation retries are retained. No network request or arbitrary normal-playback delay is added. These changes reduce unnecessary competing work; device temperature, power draw and end-to-end speed were not measured.

Native session loading/closing shares the inference gate. Shutdown closes the model on a daemon after active inference finishes, avoiding a session-close race and a UI wait. ONNX session options are released after session creation.

## PCM check

Constant DC output is rejected by checking AC energy in addition to peak/RMS/active samples. This protects against non-speech offsets being mistaken for quiet speech. It is not a general vowel/tone detector: legitimate sustained speech is not discarded simply because it sounds like a vowel. Invalid raw long-clip output is checked before polishing/caching.

## Validation

Full Android source compilation and JVM tests are recorded in VALIDATION.md. Added tests cover full-queue completion, temporary empty queues, frozen/advancing/unsigned/wrapping playback heads, partial-playback retry suppression, and DC rejection. The new PCM and short-word checks accepted all seven existing recorded outputs from the user's model on the first attempt. These were recorded files, not new on-device inference or playback tests; the local validation harness/result is in `verification/`.

Device checks still needed: sustained live use on the affected phone, the exact low buzzing sound, speech during CPU load, pause/resume during synthesis and playback, short words, and a long multi-clip paragraph. The source-only ZIP contains no APK.
