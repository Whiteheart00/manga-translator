> Historical patch notes. Current provider/capture behavior is documented in TRANSLATION_PROVIDERS.md.

# Live subtitle replay and startup latency

This patch builds on the verified short-speech fix. Its behavior follows the user's
choice: a disappearing source subtitle does not stop an utterance already being
spoken. Legitimate pending lines remain queued; this is not a latest-only/drop-old
speech mode.

## Replay fixes

The previous completion callback used elapsed time to guess whether speech had
been silent. A quick successful utterance could be placed back at the front of
the queue. The watchdog could also replay a line whose completion callback was
late. These are identifiable replay paths, independent of any OCR hallucination.

- LiveSpeechAttempt makes completion idempotent and invalidates stale completion,
  error, and watchdog callbacks. A normal completion never requeues the text,
  regardless of its duration.
- Watchdog/timeout recovery advances without replaying audio that may already have
  been spoken. The existing timeout still stops a genuinely stuck TTS run.
- An explicit TTS error may retry a line once while source text is still present.
  Errors after blank OCR do not restart old text. Retry exhaustion does not loop.
- Blank OCR does not call TTS stop or clear the speech queue. A genuinely new held
  source line is still released once, preserving the existing no-drop policy for
  valid pending lines. Recent-source deduplication policy is unchanged, including
  the treatment of genuinely repeated short words.

## Earlier first audio

- A remembered typewriter subtitle no longer imposes its settle delay on an
  unrelated full next subtitle. Blank OCR resets that typing window. Actual
  growing/typewriter text still waits for settling rather than reading fragments.
- Early speech keeps complete short sentences (e.g. `Go!`) instead of forcing them
  into the next long sentence. Sorani question punctuation is recognized. Common
  titles/initials stay with their following names.
- A long subtitle can also split at natural comma/semicolon/colon boundaries.
  Arbitrary word-group cuts are not used. Maximum four requests and source order
  are preserved. Joining the pieces preserves all source text.
- A full-line cache entry is created only when every translated part succeeded;
  a partial translation is never cached as the full subtitle.
- SpeechQueue.peek() previews exactly the next text/boost used by take(), without
  consuming anything. Prefetch now uses that batch and includes short utterances,
  avoiding the previous text/speed cache mismatch.

Capture cadence, OCR implementation, Google endpoints/timeouts, voice model,
selected speech rate and the existing 1.3x catch-up limit are unchanged.

## Verification and practical limits

See VALIDATION.md. New deterministic tests cover rapid successful completion,
late callbacks, disappearing subtitles, explicit failure retry limits, watchdog
recovery, typewriter-to-full-line transitions, natural-boundary splitting, and
prefetch/playback batch equivalence.

No end-to-end latency number or physical-phone result is claimed. Google/network
latency and the duration of spoken Kurdish still affect synchronization. Keeping
all pending lines may produce backlog when speech arrives faster than it can be
spoken; this patch does not silently discard lines to conceal that backlog.

## Phone acceptance checks

1. In a game scene, show a short subtitle and then let it disappear. The current
   Kurdish utterance should finish once; it must not restart after completion.
2. Leave the subtitle region blank for several seconds after speech ends. It
   should not restart the previous completed utterance from a timer/watchdog.
3. Play a scene with complete subtitles displayed at the beginning of each line.
   Check that a preceding typewriter line does not cause an extra settle delay.
4. Test `Go! We have to leave this place right now.` and a longer comma-separated
   line. First audio should be eligible as soon as its first translation is ready,
   while later parts stay in order.
5. Test a genuinely typewriter-animated subtitle, a new unrelated full line, a
   one-word line, repeated short dialogue in different contexts, and stopping/
   restarting live mode. No clipped words or stale callbacks should cross runs.
6. Compare the same scene on the same phone/network before and after this patch.
   Separate source-to-OCR, translation, first-audio, and any pre-existing backlog
   when investigating remaining delay.
