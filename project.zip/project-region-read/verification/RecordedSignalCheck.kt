package com.mangatranslator.app

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

fun main() {
    val files = File("/workspace/voice-investigation/samples").listFiles()!!.filter { it.extension == "f32" }
    check(files.size == 7)
    for (file in files) {
        val buffer = ByteBuffer.wrap(file.readBytes()).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        val pcm = FloatArray(buffer.remaining())
        buffer.get(pcm)
        check(PcmSignal.hasSignal(pcm, 22050)) { "Rejected recorded Piper output: ${file.name}" }
        var attempts = 0
        val result = PiperShortSpeech.render(file.nameWithoutExtension + ".", file.nameWithoutExtension, 22050,
            synthesize = { attempts++; pcm }, polish = { it })
        check(result === pcm && attempts == 1)
    }
    check(!PcmSignal.hasSignal(FloatArray(22050) { .01f }, 22050))
    println("PASS: all 7 existing recorded Piper model outputs accepted on the first short-speech attempt; constant DC rejected.")
    println("This validates PCM/short-word handling, not native Android playback or the reported noise.")
}
