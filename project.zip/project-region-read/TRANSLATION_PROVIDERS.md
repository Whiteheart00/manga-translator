# وەرگێڕی هەڵبژێردراو و نوێبوونەوەی خێراتری زیندوو

لە «ڕێکخستنی دەنگ» کارتی «وەرگێڕی زمانەکان — جگە لە عەرەبی» زیاد کراوە:

1. **تەنها Google**: وەرگێڕانی دەق Gemini بانگ ناکات؛ کلیلی Gemini پێویست نییە.
2. **تەنها Gemini**: تەنها Gemini؛ ئەگەر کلیل، تۆڕ، quota یان وەڵام کێشەی هەبێت، هەڵە پیشان دەدرێت و Google خۆکارانە بەکارنایەت.
3. **Gemini؛ Google تەنها لە تەواوبوونی quota**: Gemini یەکەمە. Google هاوکات یان دوای چاوەڕوانییەکی دیاریکراو دەست پێناکات؛ تەنها دوای HTTP 429 ـی Gemini بەکار دێت. کلیلی دیکەی Gemini ئەگەر هەبێت پێش Google تاقی دەکرێتەوە. هەڵەی 400/401/403/404/500، پچڕانی تۆڕ یان وەڵامی ناتەواو ئەم گۆڕینە چالاک ناکەن.

هەڵبژاردنەکە دەپارێزرێت و بۆ داواکارییە نوێکانی زیندوو، شاشە، خۆکار، ڕووبەر و وەرگێڕانی کوردی بۆ ئینگلیزی بەکاردێت. بنەڕەت Google ـە. گۆڕینی دۆخ ڕستەی دەستپێکردوو دووبارە ناخوێنێتەوە. کلیلی Gemini لە هەمان خانەی پێشووی کلیل دادەنرێت؛ ناوی وەرگێڕ دەنگی هەڵبژێردراو ناگۆڕێت.

**دۆخی زمانی سەرچاوەی عەرەبی (`ar`)** ڕێگای OCR/وەرگێڕانی پێشوو و هەڵبژاردنە پێشووییەکانی خۆی دەپارێزێت. دوو checkbox ـی پێشووی Google/Gemini ـی زیندوو ئێستا بە ڕوونی «تایبەت بە عەرەبی» ناونراون. هەڵبژاردنی نوێ ئەوانە ناگۆڕێت. STT، چاکسازی نووسین و موتورەکانی دەنگ لەم هەڵبژاردنەدا ناگۆڕدرێن.

## نوێبوونەوەی خێراتر

تەنها لە دۆخی زیندووی زمانەکانی جگە لە `ar`:

- MediaProjection: نێوان گرتنی فرەیم لە 150ms بۆ 90ms؛ ڕامی کەم لە 220ms بۆ 140ms.
- Accessibility: لە 400ms بۆ 350ms؛ ڕامی کەم لە 550ms بۆ 450ms. سنووری نزیکەی 333ms ـی Android پارێزراوە.
- OCR: نێوانی کارەکان 120ms؛ کوردی 100ms. لە باگراوندی جووڵاودا سنووری چاوەڕوانی 250ms؛ کوردی 180ms.
- یەکەم OCR هەر دەستبەجێیە، OCR ـە هاوکاتەکان ڕێگەپێدراو نین، و شاشەی نەگۆڕاو دووبارە بێهۆکار OCR ناکرێت. وەستاندنی زیندوو نرخی ئاسایی گرتن دەگەڕێنێتەوە. دۆخی عەرەبی سنوورە پێشووییەکانی خۆی هەیە.

ئەم ژمارانە ڕێکخستنی کۆدن، نەک FPS یان دواکەوتنی پێوانەکراوی مۆبایل. تۆڕ، خزمەتگوزاری و توانای ئامێر هێشتا کاریگەرن. Google ـی بێ کلیل بەڵێنی بێ‌سنووری نییە.

## Implementation notes

- A shared provider enum/settings preference and typed routing policy replace the non-Arabic hedged race. Only a confirmed ApiException(429) enables Google in hybrid mode. The exception retains 429 through Gemini model selection; all configured keys can still be tried before provider fallback.
- After confirmed quota, hybrid requests for the same key set use Google for a 30-second process-local cooldown, then probe Gemini again. Changing keys uses a separate cooldown. Gemini-only ignores this hybrid cooldown. Credentials are never logged by the new router.
- Gemini-only and hybrid do not issue even Google's translation-based preconnect request before quota. Arabic keeps its legacy warmup behavior.
- Screen/auto/region use the same text translation policy. Region uses local OCR with crop-relative rectangles mapped back to the screen; the full-screen Accessibility shortcut is disabled for a cropped bitmap. Local Kurdish detection remains available, with owned probe copies and bounded waiting. Google mode does not skip local OCR in favor of an unused Gemini key.
- Streamed Gemini blocks are retained if later quota exhaustion occurs; Google translates only missing blocks and does not retranslate explicit empty/noise results. Non-quota failures and incomplete Gemini output never silently trigger Google. Arabic context translation keeps its old permissive fallback behavior.
- Live cache keys include language/provider; screen caches are likewise scoped. Gemini's own context cache stays separate from Google's. Request provider/credentials are captured before asynchronous work, so a UI switch applies to new requests without mixing modes inside one batch.
- Existing short-speech, no-replay, FIFO ordering, model weights and selected voice speed remain intact. Shared API additions are optional `quotaSensitive`/`strict` flags (default false) and `allowAccessibility` (default true); FrameSource has a no-op default live-refresh hook.

## Phone checks

- Select each provider, close/reopen settings and confirm it remains selected. Test live, screen, auto, region and the English-translation button on non-Arabic input.
- Google mode must work without a Gemini key. Gemini-only without a valid key must show an error, not silently use Google.
- Test a valid Gemini key in Gemini-only/hybrid. Test actual exhausted quota only if already available; do not consume quota deliberately to validate the UI. Automated fake-provider tests verify 429-only fallback, request ordering, cooldown and non-quota errors without charging an API.
- Switch provider while live mode is active. New subtitle requests should use the new mode; currently playing speech should not restart.
- Explicitly select Arabic and compare its previous scene/settings. The new selector should not change that path or its capture/OCR cadence.
- Compare the same live scene on the same phone/network. Also verify single-word speech and blank-scene non-replay still work.

No physical-phone UI/playback test or real keyed Gemini/Google translation test is claimed in this workspace. See VALIDATION.md for build/test evidence.
