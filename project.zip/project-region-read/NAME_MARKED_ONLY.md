# دۆخی سێیەمی لابردنی ناو: ناو + نیشانە

لە «👤 ناو و پڕکەرەوە» هەڵبژاردنێکی سێیەم زیاد کراوە:

**تەنها ناوەکانی پاشیان : یان , یان ؛ ـە**

لە هەر شوێنێکی ڕستەدا تەنها ناوێکی ناو لیستەکەت لادەبرێت کە دوای ناوەکە
یەکێک لە `:`، `,` یان `؛` هەبێت. بۆشایی نێوان ناو و نیشانە ڕێگەپێدراوە؛
ناو و نیشانەکە پێکەوە لادەبرێن. ناوی بێ نیشانە و ناوی نەنووسراو لە لیست
وەک خۆیان دەمێننەوە.

ئەگەر John و Sarah لە لیستەکە بن:

| دەقی سەرچاوە | دۆخی سێیەم |
|---|---|
| John: Hello. | Hello. |
| John, Hello. | Hello. |
| John؛ Hello. | Hello. |
| John went home. | John went home. |
| John: Sarah is here. | Sarah is here. |
| I heard John: hello. | I heard hello. |
| John | John |
| Alex: Hello. | Alex: Hello. |

دوو دۆخی پێشوو هەر ماون: «تەنها سەرەتا» و «هەموو شوێنێک». هەڵبژاردنی
پێشووت لە update ـدا دەمێنێتەوە؛ دۆخی سێیەم خۆکارانە چالاک نابێت. مەرجی
checkbox ـی پێشووی `:`/`-` تەنها بۆ دۆخی یەکەمە و لە دۆخی سێیەم ناچالاکە.
دوای هەڵگرتن هەڵبژاردنەکە بۆ ژێرنووسە نوێکان کاریگەرە.

## Implementation notes

- Add the saved boolean `skip_names_marked_only` (default false). The selector
  saves this only for index 2 and the existing everywhere preference only for
  index 1. Existing name lists, scope and separator checkbox are retained.
- NameFilter.strip adds an optional followedByMarker flag. It has precedence over
  everywhere for consistency if both preferences are ever set externally.
- The new scope matches literal whole names anywhere, case-insensitively, followed
  by optional horizontal whitespace and exactly the requested marker set:
  colon U+003A, comma U+002C, Arabic semicolon U+061B. Other separators, including
  hyphens, ASCII semicolon and Arabic comma, do not qualify in this scope.
- The marker is consumed with the name. The existing whitespace/punctuation
  cleanup is reused. Larger tokens, possessives and unlisted names stay intact.
- A listed name with a trailing requested marker is normalized only when compiling
  this new scope. Existing parsing/matching behavior for the other scopes remains
  unchanged. The compiled matcher cache includes both the list and scope so a
  selector change cannot reuse an unrestricted matcher accidentally.
- Only the live-subtitle name filter changes. Provider choices/quota policy,
  refresh, voice engines, short-word support and replay fixes remain unchanged.

## Checks

Twelve new unit tests cover all three markers, start/middle/end, mandatory marker,
non-qualifying separators, whitespace, unlisted names, word/possessive boundaries,
mixed case, Unicode/multiword names, strict-mode independence, scope switching,
marked list entries, repeated labels and literal regex characters.

Phone acceptance: select the third scope and save; test the examples, close/reopen
settings to verify persistence, and switch back to each prior scope. Physical UI
and playback are not tested in this workspace. See VALIDATION.md for the build
and full JVM suite results.
