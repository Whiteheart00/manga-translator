#!/usr/bin/env bash
set -euo pipefail
benchmark_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source_root="$benchmark_root/../app/src/main/java/com/mangatranslator/app"
benchmark_tmp="$(mktemp -d)"
trap 'rm -rf "$benchmark_tmp"' EXIT
"${LIVE_BENCH_KOTLINC:-kotlinc}" \
  "$source_root/TextPrep.kt" "$source_root/LiveTranslationFilter.kt" "$source_root/LiveSubtitleProgress.kt" \
  "$benchmark_root/BaselineLiveTranslationFilter.kt" "$benchmark_root/BaselineLiveSubtitleProgress.kt" \
  "$benchmark_root/LivePerformance.kt" -include-runtime -d "$benchmark_tmp/benchmark.jar"
"${LIVE_BENCH_JAVA:-java}" -Xms128m -Xmx256m -jar "$benchmark_tmp/benchmark.jar"
