package com.mangatranslator.app

import kotlin.random.Random
import java.lang.management.ManagementFactory

private var sink = 0L
private fun same(old: BaselineLiveSubtitleProgress.Result, new: LiveSubtitleProgress.Result) {
    check(old.text == new.text && old.continuation == new.continuation && old.repeated == new.repeated) { "$old != $new" }
}
fun main() {
    val random = Random(3007)
    val parts = listOf("سڵاو", "هاوڕێ", "چۆنی؟", "کوردی", "1,200", "John", " ", "  ", "\n", "،", "؛", ":", ".", "ك", "ي", "ى", "١٢٣", "۱۲۳", "[123]", "**", "Pokémon", "\u200e", "\u200c", "؟", "!", "…")
    repeat(20_000) {
        val text = buildString { repeat(random.nextInt(1, 15)) { append(parts.random(random)) } }
        val old = BaselineLiveTranslationFilter.clean(text)
        val new = LiveTranslationFilter.clean(text)
        check(old == new) { "Filter changed: <$text> old=<$old> new=<$new>" }
    }
    repeat(100) {
        val old = BaselineLiveSubtitleProgress()
        val new = LiveSubtitleProgress()
        var text = "Hello everyone"
        var time = 0L
        repeat(200) {
            when (random.nextInt(7)) {
                0 -> { old.absent(); new.absent() }
                1 -> text += " " + listOf("welcome", "back", "friend", "today", "again").random(random)
                2 -> text = text.uppercase()
                3 -> text = listOf("Hi", "Wait for me please", "alpha beta alpha beta", "سڵاو هاوڕێ", "今天").random(random)
                4 -> text = text.split(" ").drop(1).joinToString(" ")
                5 -> text += "."
            }
            time += random.nextLong(1, 400)
            val overlap = random.nextBoolean()
            same(old.next(text, time, overlap), new.next(text, time, overlap))
        }
    }
    val unicodeTokens = listOf("can't", "we’re", "هاو\u200cڕێ", "کوردی", "سڵا\u0651و", "cafe\u0301", "ΟΣ", "İSTANBUL", "Ⅳ", "½", "١٢٣", "你好", "𝒜world", "😀", "\u0301")
    repeat(200) {
        val old = BaselineLiveSubtitleProgress()
        val new = LiveSubtitleProgress()
        val tokens = mutableListOf("Hello")
        var time = 0L
        repeat(100) {
            when (random.nextInt(6)) {
                0 -> { old.absent(); new.absent() }
                1 -> if (tokens.size > 1) tokens.removeAt(0)
                2 -> { tokens.clear(); tokens.add("Hello") }
                else -> tokens.add(unicodeTokens.random(random))
            }
            val text = tokens.joinToString(if (random.nextBoolean()) " " else ", ")
            time += random.nextLong(1, 500)
            val overlap = random.nextBoolean()
            same(old.next(text, time, overlap), new.next(text, time, overlap))
        }
    }
    println("Differential checks: 20,000 filter results + 40,000 subtitle transitions (including Unicode) matched baseline")
    val bean = ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean
    bean.isThreadAllocatedMemoryEnabled = true
    val thread = Thread.currentThread().id
    fun measure(name: String, ops: Int, factory: (Boolean) -> (() -> Unit)) {
        val old = factory(false); val new = factory(true)
        repeat(4) { repeat(maxOf(ops / 5, 20_000)) { old(); new() } }
        val timings = Array(2) { mutableListOf<Double>() }
        val allocations = Array(2) { mutableListOf<Double>() }
        repeat(7) { round ->
            val order = if (round % 2 == 0) intArrayOf(0, 1) else intArrayOf(1, 0)
            for (which in order) {
                val action = if (which == 0) old else new
                val allocated = bean.getThreadAllocatedBytes(thread)
                val start = System.nanoTime()
                repeat(ops) { action() }
                timings[which].add((System.nanoTime() - start).toDouble() / ops)
                allocations[which].add((bean.getThreadAllocatedBytes(thread) - allocated).toDouble() / ops)
            }
        }
        fun median(values: List<Double>) = values.sorted()[values.size / 2]
        val oldNs = median(timings[0]); val newNs = median(timings[1])
        println("%s | %.0f -> %.0f ns/op | %.0f -> %.0f bytes/op | %.2fx".format(name, oldNs, newNs, median(allocations[0]), median(allocations[1]), oldNs/newNs))
    }
    measure("progress repeated", 30_000) { fast ->
        val old = BaselineLiveSubtitleProgress(); val new = LiveSubtitleProgress(); var time = 0L
        ({ val text = "Where are you going? I will come with you."; sink += if (fast) new.next(text, time++).text.length else old.next(text, time++).text.length })
    }
    measure("progress cumulative", 20_000) { fast ->
        var old = BaselineLiveSubtitleProgress(); var new = LiveSubtitleProgress(); var count = 0
        var text = "Hello everyone"; var time = 0L
        ({ if (count++ % 20 == 0) { old = BaselineLiveSubtitleProgress(); new = LiveSubtitleProgress(); text = "Hello everyone" }
           text += " welcome"
           sink += if (fast) new.next(text, time++).text.length else old.next(text, time++).text.length })
    }
    measure("progress Kurdish cumulative", 20_000) { fast ->
        var old = BaselineLiveSubtitleProgress(); var new = LiveSubtitleProgress(); var count = 0
        var text = "سڵاو هاوڕێ"; var time = 0L
        ({ if (count++ % 20 == 0) { old = BaselineLiveSubtitleProgress(); new = LiveSubtitleProgress(); text = "سڵاو هاوڕێ" }
           text += " بەڵێ"
           sink += if (fast) new.next(text, time++).text.length else old.next(text, time++).text.length })
    }
    measure("progress rolling", 20_000) { fast ->
        var old = BaselineLiveSubtitleProgress(); var new = LiveSubtitleProgress(); var count = 0; var time = 0L
        ({ if (count++ % 20 == 0) { old = BaselineLiveSubtitleProgress(); new = LiveSubtitleProgress() }
           val text = "This is subtitle number ${count - 1} This is subtitle number $count"
           sink += if (fast) new.next(text, time++).text.length else old.next(text, time++).text.length })
    }
    println("Benchmark checksum: $sink; desktop JVM microbenchmark, not phone or end-to-end latency")
}
