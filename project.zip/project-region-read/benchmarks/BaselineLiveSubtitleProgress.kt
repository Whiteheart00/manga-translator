package com.mangatranslator.app

/** Bounded, clock-injected progress for cumulative / rolling live subtitles. */
internal class BaselineLiveSubtitleProgress(private val memoryMs: Long = 20_000L, private val capacity: Int = 40) {
    data class Result(val text: String, val continuation: Boolean, val repeated: Boolean)
    private data class Word(val key: String, val end: Int)
    private data class Seen(val key: String, val words: List<Word>, val at: Long)
    private val recent = ArrayDeque<Seen>()
    private var current: Seen? = null
    private companion object {
        val REPEATED = Result("", false, true)
        val wordPattern = Regex("[\\p{L}\\p{M}\\p{N}\\u200C]+(?:['’][\\p{L}\\p{M}\\p{N}\\u200C]+)*")
    }
    private var lastRaw: String? = null
    private var lastKey = ""
    private fun key(text: String) = text.lowercase().filter { it.isLetterOrDigit() }
    private fun words(text: String) = wordPattern.findAll(text).map { Word(key(it.value), it.range.last + 1) }.toList()

    /** A blank hides the caption but retains recent speech memory. */
    fun absent() { current = null }

    fun next(raw: String, now: Long, allowOverlap: Boolean = true): Result {
        val text = raw.trim()
        val normalized = if (lastRaw == text) lastKey else key(text).also {
            lastRaw = text
            lastKey = it
        }
        if (normalized.isEmpty()) return REPEATED
        while (recent.isNotEmpty() && now - recent.first().at > memoryMs) recent.removeFirst()
        val previous = current
        val duplicate = if (previous?.key == normalized) previous else recent.firstOrNull { it.key == normalized }
        if (duplicate != null) {
            // Matching keys need no regex tokenization. Previous token offsets
            // are never used to cut the incoming string on this return path.
            val item = Seen(normalized, duplicate.words, now)
            current = item
            remember(item)
            return REPEATED
        }
        val incoming = words(text)
        val item = Seen(normalized, incoming, now)
        // Temporarily shortened OCR / typewriter frames cannot replay an
        // already handled prefix. Match whole words, never a partial word.
        if (allowOverlap && previous != null && incoming.size < previous.words.size &&
            prefix(incoming, previous.words, incoming.size) && normalized.length >= 5) {
            return REPEATED
        }
        var consumed = 0
        if (allowOverlap) {
            // Use full observed frames rather than only the last delta, so
            // A -> A B -> A B C always emits A, B, C once.
            for (old in recent) consumed = maxOf(consumed, prefixConsumed(old, incoming, previous, consumed))
            if (previous != null && recent.lastOrNull() !== previous) {
                consumed = maxOf(consumed, prefixConsumed(previous, incoming, previous, consumed))
            }
            if (previous != null && consumed < minOf(previous.words.size, incoming.size)) {
                // Rolling two-line captions may drop their beginning while
                // retaining the end: A B -> B C. Require a meaningful overlap.
                val count = overlap(previous.words, incoming)
                var overlapChars = 0
                for (i in 0 until count) overlapChars += incoming[i].key.length
                if (count >= 2 && overlapChars >= 8) {
                    consumed = maxOf(consumed, count)
                }
            }
        }
        current = item
        remember(item)
        var cutEnd = if (consumed > 0) incoming[consumed - 1].end else 0
        // CJK scripts often have no spaces: character boundaries are valid
        // there, while Latin/Kurdish partial words must remain whole.
        if (allowOverlap && text.any { it.code in 0x2E80..0x9FFF }) {
            for (old in recent) {
                if (old.key.length >= 2 && normalized.length > old.key.length && normalized.startsWith(old.key)) {
                    var letters = 0
                    val boundary = text.indexOfFirst { ch ->
                        if (ch.isLetterOrDigit()) letters++
                        letters == old.key.length
                    } + 1
                    cutEnd = maxOf(cutEnd, boundary)
                }
            }
        }
        if (allowOverlap && previous != null && recent.lastOrNull() !== previous &&
            text.any { it.code in 0x2E80..0x9FFF } && previous.key.length >= 2 &&
            normalized.length > previous.key.length && normalized.startsWith(previous.key)) {
            var letters = 0
            for (i in text.indices) {
                if (text[i].isLetterOrDigit()) letters++
                if (letters == previous.key.length) { cutEnd = maxOf(cutEnd, i + 1); break }
            }
        }
        if (cutEnd == 0) return Result(text, false, false)
        val remainder = text.substring(cutEnd)
            .trimStart { !it.isLetterOrDigit() }
        return Result(remainder, true, remainder.isBlank())
    }
    private fun prefixConsumed(old: Seen, incoming: List<Word>, previous: Seen?, consumed: Int): Int {
        val n = old.words.size
        if (n < incoming.size && n > consumed && (old.key.length >= 5 || old === previous) &&
            prefix(old.words, incoming, n)) return n
        if (n >= 2 && n - 1 > consumed && incoming.size >= n && prefix(old.words, incoming, n - 1) &&
            old.words.last().key.length >= 3 && incoming[n - 1].key.length > old.words.last().key.length &&
            incoming[n - 1].key.startsWith(old.words.last().key)) return n - 1
        return consumed
    }
    /** Longest suffix/prefix in linear time, including repeated-word captions. */
    private fun overlap(old: List<Word>, incoming: List<Word>): Int {
        if (incoming.isEmpty()) return 0
        val failure = IntArray(incoming.size)
        for (i in 1 until incoming.size) {
            var j = failure[i - 1]
            while (j > 0 && incoming[i].key != incoming[j].key) j = failure[j - 1]
            if (incoming[i].key == incoming[j].key) j++
            failure[i] = j
        }
        var matched = 0
        for (word in old) {
            while (matched > 0 && (matched == incoming.size || word.key != incoming[matched].key)) {
                matched = failure[matched - 1]
            }
            if (word.key == incoming[matched].key) matched++
        }
        return matched
    }
    private fun prefix(a: List<Word>, b: List<Word>, count: Int) =
        count > 0 && a.size >= count && b.size >= count && (0 until count).all { a[it].key == b[it].key }
    private fun remember(item: Seen) {
        // Refresh repeated frames without growing memory at capture frequency.
        recent.removeAll { it.key == item.key }
        recent.addLast(item)
        while (recent.size > capacity) recent.removeFirst()
    }
}
