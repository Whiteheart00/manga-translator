# Selected-region mixed Sorani reading — 2026-11-08

- Gradle `testDebugUnitTest --offline`: BUILD SUCCESSFUL, including Android app/test source compilation.
- 275 JVM tests across 38 suites; 0 failures, 0 errors, 0 skips.
- 15 added regression tests include both exact user posts, separate Latin term boxes, full Kurdish body preservation, independent foreign paragraphs, provider rewrites, original text/newlines, legacy responses, system-voice English retention and Piper acronym boundaries.
- Existing live-filter, provider routing, short-word, voice stability and Pause/Play tests pass.
- Local Android SDK 34 / Gradle 8.9 / Kotlin 1.9.24; JVM target 17.
- Native screenshot OCR, accessibility geometry and actual audio were not tested on a phone. OCR accuracy and the Sorani model's approximate name pronunciation remain practical limits.
- Full final log: region-read-test.log.
- Source-only delivery; no APK assembled or included.

See REGION_NATIVE_READING.md for the fix and its scope. This update is for the Manga Translator screen/region app (com.mangatranslator.app).
