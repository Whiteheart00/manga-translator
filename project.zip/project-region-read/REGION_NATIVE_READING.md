# Selected-region reading of mixed Sorani text

Sorani posts containing Latin names such as ERP, ERPNext, Nwebeen and profolio are read directly. A borrowed English term does not turn the whole paragraph into foreign text, and the app does not translate just that term while dropping the Kurdish body.

The previous accessibility shortcut rejected mixed Sorani because `worthTranslating` treated any English word as requiring translation. The following Latin-only OCR route could then recognize only product names. Selected-region processing now has a separate native-reading policy:

- Accessibility keeps the complete native paragraph and short separate product-name boxes. It does not discard those names or send the native selection for translation. An independent foreign paragraph can still take the normal translation route.
- Region OCR marks native mixed boxes before deciding what needs translation. Its local Kurdish OCR probe accepts sufficiently confident mixed Sorani; other OCR callers retain their existing policy.
- When the low-device setting skips local native-script OCR, the region uses its existing multilingual vision route instead of relying on Latin-only recognition to read a Kurdish post.
- Full vision responses include the original text. If that original is Sorani, it overrides a rewritten/translated model output. Prompts explicitly preserve Latin names/acronyms in native Sorani blocks.
- The original spelling stays in the selected text/overlay data. The system voice keeps English terms. Piper, whose model accepts Kurdish-script symbols, uses the existing local pronunciation preparation; camel/acronym boundaries let ERPNext be pronounced as ERP + Next without translating its meaning. Proper-name pronunciation remains approximate with this model.

The live-subtitle post-translation English/numeral filter remains scoped to live subtitles. It is not used to erase words from selected-region native text. No new toggle or translation request is required for the accessibility fast path. A selected image still depends on OCR quality/model availability; native reading cannot recover characters the recognizer did not capture.

## Validation

The user's two complete reported posts are included as regression inputs. Tests verify native classification, split product-name boxes, exact source retention including newlines and Latin spelling, foreign paragraphs, legacy/compact vision results, provider rewrites, system-voice English retention, Piper acronym pronunciation and the separate live-filter policy.

Full totals and the final Android source compilation result are in VALIDATION.md. No phone screenshot/OCR/audio run was performed for this change. This fixes source selection/routing; it does not claim native English pronunciation from a Sorani-only Piper model.
