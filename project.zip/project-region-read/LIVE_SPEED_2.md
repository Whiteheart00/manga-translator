# Further live subtitle progress optimization

This revision compares against the delivered project-live-fast source. Filtering rules, capture intervals, translation requests, typewriter settling, speech speed and Pause/Play behavior retain their existing settings.

The remaining source/output progress work is cheaper:

- Word boundaries are scanned directly instead of allocating a regex MatchResult for every word. The scanner preserves letters, all Unicode number/mark categories, ZWNJ and internal straight/curly apostrophes. Supplementary Unicode characters use the original regex implementation.
- Ordinary ASCII word keys avoid an extra filtering pass. Combining marks and Unicode case expansions retain the original normalization.
- Repeated frames refresh the existing recent entry instead of allocating a new one and rebuilding the deque. The expiry order and bounded recent history are retained.
- Rolling-caption matching reuses its prefix table instead of allocating an IntArray on every call.

## Reproducible desktop JVM measurements

Reference source, benchmark harness and raw results are in `benchmarks/`. Both versions run in the same process with identical inputs, at least 80,000 warmup calls per version/workload, alternating measurement order, and the median of seven rounds. Allocation counts use ThreadMXBean. The warmup allows the JVM to finish optimizing the changed scanner before timing.

| Workload | Previous → current µs/op | Speed ratio | Previous → current allocated bytes/op |
| --- | ---: | ---: | ---: |
| Repeated caption | 0.135 → 0.055 | 2.43x | 56 → 0 |
| Growing English caption | 5.180 → 1.520 | 3.41x | 10297 → 2389 |
| Growing Kurdish caption | 5.369 → 2.313 | 2.32x | 11332 → 2816 |
| Rolling two-line caption | 4.003 → 1.183 | 3.38x | 8129 → 1640 |

These figures describe progress-processing code on a desktop JVM, not full app speed or mobile OCR/network/audio latency. Filtering code is unchanged from project-live-fast and is not included in this round's timing comparison. Actual device performance remains unmeasured.

Before timing, 20,000 randomized filter results and 40,000 subtitle transitions matched project-live-fast exactly. The transitions include contractions, punctuation, line growth/shortening, expiry, combining marks, Greek/Turkish case behavior, Kurdish ZWNJ, Unicode number categories, CJK and supplementary letters/emoji. Seven additional unit tests cover the scanner and reused state; full test totals are in VALIDATION.md.

Run with `LIVE_BENCH_KOTLINC=/path/to/kotlinc bash benchmarks/run.sh`. The source-only ZIP contains no APK.
