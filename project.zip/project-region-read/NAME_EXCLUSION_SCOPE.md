> Two-scope patch notes. The third marked-name option is documented in NAME_MARKED_ONLY.md.

# هەڵبژاردنی شوێنی لابردنی ناو لە ژێرنووسی زیندوو

لە «👤 ناو و پڕکەرەوە» دوو هەڵبژاردن هەیە:

- **تەنها سەرەتای ڕستە — وەک ئێستا**: بنەڕەتەکەیە. ناوی دیاریکراو لە سەرەتای ڕستە لادەبرێت؛ ناوی ناوەڕاست و کۆتایی دەمێنێتەوە. مەرجی «تەنها ئەگەر دوای ناو : یان - یان کۆما بێت» هەر دەتوانرێت بۆ ئەم دۆخە بەکاربهێنرێت.
- **هەموو شوێنێکی ڕستە**: ناوە دیاریکراوەکان لە سەرەتا، ناوەڕاست و کۆتایی لادەبرێن. لەم دۆخەدا مەرجی جیاکەرەوە ناچالاکە، بەڵام هەڵبژاردنی پێشووی دەپارێزرێت بۆ گەڕانەوە بۆ دۆخی سەرەتا.

دوای هەڵگرتن، ڕێکخستنەکە بۆ ژێرنووسە نوێکان کاریگەرە؛ دەنگی دەستپێکردوو دووبارە ناکرێتەوە. ناوە پێشووەکان و دۆخی سەرەتای پێشوو لە update ـدا دەمێننەوە.

## نموونە

ئەگەر John و Sarah لە لیستەکە بن:

| دەقی سەرچاوە | تەنها سەرەتا | هەموو شوێنێک |
|---|---|---|
| John: Tell Sarah to come. | Tell Sarah to come. | Tell to come. |
| I saw John. | I saw John. | I saw. |
| Sarah: John is here. | John is here. | is here. |

هەر دێڕێک ناوێک بە هەمان نووسینی ژێرنووس/دەقی ناسراو دابنێ. پیتی بچووک و گەورە گرنگ نییە. ناوی تەواو دەسڕدرێتەوە، نەک بەشێکی وشە: John لە Johnson، John2، _John یان John's لادەنابرێت. ئەگەر مەبەستت John's یان نووسینی وەرگێڕدراوی ناوەکەیە، ئەو شێوەیەش بە دێڕێکی جیا بنووسە.

وەک ڕێگای پێشوو، لابردن پێش وەرگێڕان دەکرێت: ناوی لابراو نە وەردەگێڕدرێت، نە لە وەرگێڕانی سەر شاشە پیشان دەدرێت و نە دەخوێنرێتەوە. ئەگەر هیچ وشەیەک نەما، وەرگێڕان/دەنگێکی نوێ بۆ ئەو دەقە دروست نابێت. ڕستەکە دووبارە نانووسرێتەوە یان وشەی جێگرەوە زیاد ناکرێت.

## Implementation

- New SharedPreferences boolean `skip_names_everywhere`, default false. Existing
  name list and separator-only preference are retained without a migration.
- NameFilter.strip gains an optional everywhere flag. The start-only branch keeps
  the existing matching behavior and now stops after an explicit speaker separator:
  `John: Sarah is here` no longer removes Sarah as though she were another prefix.
  Existing contiguous prefix-label support (`John Mary: hi`) remains intact.
- Anywhere matching uses escaped literal alternatives, longest names first,
  case-insensitive Unicode word boundaries, and protection against possessives/
  larger tokens. A single compiled rule is reused until the name list changes.
- Match before sentence splitting so full names such as Dr. Smith can match.
  Clean up whitespace, orphaned label punctuation and empty brackets/quotes left
  by removal, without inserting new words.
- Only live subtitles pass the new preference to the filter. Voice engines,
  provider selection/quota fallback, refresh cadence and other translation paths
  are unchanged.

## Phone checks

1. Install the update; existing excluded names and start-only behavior should remain.
2. Add John and Sarah, save start-only mode, and test the first example above.
3. Select everywhere, save, and repeat; Sarah should also be omitted from the body.
4. Verify the separator checkbox is disabled in everywhere mode. Switch back and
   confirm its previous checked state is retained.
5. Close/reopen settings to verify the chosen scope persists. Test a multiword
   name, a Kurdish-script name, Johnson, and a sentence made entirely of names.

Build and JVM test results are in VALIDATION.md. Phone UI/playback has not been
tested in this workspace.
