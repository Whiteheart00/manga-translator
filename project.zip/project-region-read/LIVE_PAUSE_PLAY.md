# Live subtitle Pause / Play

The floating ⏸ / ▶ button beside ✕ controls live subtitles.

- Pause stops current speech, discards the old speech/translation backlog, detaches frame listeners, and suspends screen capture polling. MediaProjection also detaches its output surface so it stops producing images. An already requested screenshot/network request may finish, but its result cannot update captions or start speech.
- Play reads the last translated sentence saved before Pause, then continues scanning the selected region. The saved source fingerprint prevents reading the same unchanged source immediately again.
- Both portrait and landscape region selections survive Pause. There is no region picker or new screen capture permission on Play. The existing VirtualDisplay is retained, including on Android 14.
- ✕ ends the session and clears the saved sentence/selection. Starting another mode also ends the paused live session.

Pause invalidates the run generation before stopping workers/audio. Deferred frame attachment uses the same synchronized generation check, so callbacks from an old run cannot attach after Pause or affect a later run. Resume creates a new LiveSubtitle worker instance; closed executors are never reused. A fresh ImageReader surface replaces any pre-Pause cached frame. Accessibility screenshot callbacks use their own generation to prevent duplicate polling loops after rapid toggling.

The latest line is replayed from its beginning, not from an audio sample position. Older queued lines are discarded to avoid falling behind the game. Translation provider, voice, speech speed and name exclusion settings remain available as before.

## Validation

JVM lifecycle and control placement tests cover stale callbacks, rapid Pause/Play cycles, stopping while paused, preserving both orientations and keeping controls on screen. The full Android unit suite and debug APK build are recorded in VALIDATION.md.

No phone/emulator was connected. Device checks still needed: pause during speech, leave the game running, resume and hear the last saved line once; rapid toggling; rotation while paused; stop while paused; MediaProjection and Accessibility capture paths.
