import com.mangatranslator.app.SpeechMerge
import kotlin.system.measureNanoTime

@Volatile var checksum = 0
fun oldWords(s: String) = s.trim().split(Regex("\\s+")).count { word -> word.any { it.isLetterOrDigit() } }
fun main() {
    val inputs = listOf("براکەم ئازایە گەورەیە براوەیە", "Where are you going? I am here!", "你好 世界 123 !", "hello\nworld\tand friends")
    fun run(old: Boolean): Long = measureNanoTime {
        var sum = 0
        repeat(100000) { val s = inputs[it % inputs.size]; sum += if (old) oldWords(s) else SpeechMerge.words(s) }
        checksum = sum
    }
    repeat(4) { run(true); run(false) }
    val old = mutableListOf<Long>(); val updated = mutableListOf<Long>()
    repeat(7) { old += run(true); updated += run(false) }
    println("100000 calls; median of 7 after warmup")
    println("Before: ${old.sorted()[3] / 1000000.0} ms")
    println("After: ${updated.sorted()[3] / 1000000.0} ms")
    println("Microbenchmark only; not an Android end-to-end speed measurement. Checksum: $checksum")
}
