"""Local model check. Requires numpy and onnxruntime; never calls a hosted API.

Usage: python tools/verify_short_speech.py MODEL_DIR OUTPUT_DIR
MODEL_DIR must contain the existing model.onnx and model.onnx.json.
"""
import json
import sys
import unicodedata
import wave
from pathlib import Path

import numpy as np
import onnxruntime as ort


def main():
    model_dir, output_dir = map(Path, sys.argv[1:])
    output_dir.mkdir(parents=True, exist_ok=True)
    config = json.loads((model_dir / "model.onnx.json").read_text())
    ids_map = {symbol: values[0] for symbol, values in config["phoneme_id_map"].items()}
    rate = config["audio"]["sample_rate"]
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    session = ort.InferenceSession(str(model_dir / "model.onnx"), options, providers=["CPUExecutionProvider"])
    results = []
    texts = ["نا.", "من.", "باشە.", "سڵاو.", "سوپاس.", "تۆ چۆنی.", "من ئەمڕۆ زۆر دڵخۆشم."]
    for text in texts:
        # Match PiperTts.toIds. Encoding is intentionally unchanged by this fix.
        normalized = unicodedata.normalize("NFD", text)
        ids = [ids_map.get("^", 1)]
        for char in normalized:
            if char in ids_map and char not in "^$_":
                ids += [ids_map[char], ids_map.get("_", 0)]
        ids.append(ids_map.get("$", 2))
        for low_latency in [False, True]:
            for speed in [0.5, 1.0, 2.0]:
                effective_speed = max(0.55, speed * (0.9 if low_latency else 0.72))
                feeds = {
                    "input": np.array([ids], dtype=np.int64),
                    "input_lengths": np.array([len(ids)], dtype=np.int64),
                    "scales": np.array([0.4, config["inference"]["length_scale"] * 1.08 / effective_speed, 0.55], dtype=np.float32),
                }
                if "sid" in {item.name for item in session.get_inputs()}:
                    feeds["sid"] = np.array([0], dtype=np.int64)
                audio = session.run(None, feeds)[0].flatten()
                peak = float(np.max(np.abs(audio))) if audio.size else 0
                rms = float(np.sqrt(np.mean(audio * audio))) if audio.size else 0
                valid = bool(np.isfinite(audio).all() and peak >= 0.0001 and rms >= 0.00001 and
                             np.count_nonzero(np.abs(audio) >= 0.0001) >= max(1, rate // 50))
                assert valid, (text, speed, low_latency, peak, rms)
                results.append(dict(text=text, speed=speed, low_latency=low_latency,
                                    seconds=round(audio.size / rate, 4), peak=peak, rms=rms, has_signal=valid))
                if speed == 1.0 and low_latency:
                    stem = text.rstrip(".")
                    audio.astype("<f4").tofile(output_dir / (stem + ".f32"))
                    gain = min(2.5, 0.9 / max(peak, 1e-9), 0.1 / max(rms, 1e-9))
                    with wave.open(str(output_dir / (stem + ".wav")), "wb") as wav:
                        wav.setnchannels(1)
                        wav.setsampwidth(2)
                        wav.setframerate(rate)
                        wav.writeframes((np.clip(audio * gain, -1, 1) * 32767).astype("<i2").tobytes())
    (output_dir / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2))
    print(f"PASS: {len(results)} real-model runs without filler. Signal presence does not verify pronunciation or phone playback.")


if __name__ == "__main__":
    main()
