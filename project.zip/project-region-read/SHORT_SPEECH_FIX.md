> Historical patch notes. Current provider/capture behavior is documented in TRANSLATION_PROVIDERS.md.

# Short Kurdish speech fix

This patch is based on the latest uploaded project. It changes only the Piper
speech path and its tests. Capture, OCR, Google translation, live queue policy,
voice speed settings, text-to-ID encoding, and the ONNX model are unchanged.

## Behavior

- Piper receives standalone utterances without the four-word merge or filler
  words. Existing preparation is retained for the system voice. Piper prefetch
  receives the same unpadded text as playback.
- Short synthesis accepts the first usable PCM signal instead of using array
  duration as a proxy for speech. Punctuation-only variants retry when the model
  returns silence; retries do not slow the selected synthesis rate. No spoken
  word is added or repeated.
- Silent/invalid output is rejected before caching. If no utterance can be
  synthesized, the existing system-voice fallback remains available.
- Short clips use a native buffer sized for the first clip, with the existing
  two-second maximum retained for long audio. If a device allocates a larger
  initial buffer, only trailing PCM silence fills it. All written frames remain
  included in the existing end-of-playback drain. AudioTrack write failures are
  reported instead of being silently treated as success.
- The previous blanket half-second PCM padding is removed.

The earlier test `SpeechPadTest.offOrBlankWordChangesNothing` had a contradictory
assertion: its last call used default active padding, but expected padding to be
off. It now checks that trimming leaves default behavior unchanged. This does not
change SpeechPad or the other voices' settings.

## Verification

See VALIDATION.md for build/test results. The model used was the user's existing
Berfin/Piper model from:
https://github.com/Whiteheart00/manga-translator/releases/download/v1.0.1/kurdish_onnx_model.zip

The ONNX weights are not included in this source archive and do not need to be
replaced for this patch. Non-silent PCM is evidence of a signal, not proof of
correct pronunciation or actual playback on a phone.

## Phone acceptance check

1. Install the APK built from this project and select the existing offline Piper
   voice/model.
2. Speak each of `نا`, `من`, `باشە`, `سڵاو`, and `سوپاس` on its own. Each should play
   once, without waiting for another subtitle or adding filler words.
3. Repeat with the user's normal speed and a faster setting, then test a longer
   sentence. Check that speech is not cut off and that the longer sentence retains
   the selected speed.
4. Test with the existing offline-padding checkbox both enabled and disabled:
   neither should add filler to Piper. System/other voices retain their own
   preparation behavior.
5. Verify stopping mid-playback still cancels immediately. If the phone remains
   silent, collect the relevant `PiperTts` and `AudioTrack` log messages to separate
   a model/input problem from native audio routing or playback.

A physical-phone acceptance check cannot be performed in this workspace because
no Android device or emulator is attached.

## Reproduce the checks

```sh
gradle testDebugUnitTest assembleDebug --no-daemon
```

For an independent CPU model check, install numpy and onnxruntime into a local
Python environment, then run:

```sh
python tools/verify_short_speech.py /path/to/model-directory /path/to/results
```

The script checks the unchanged ID sequence with 7 utterances, 3 speed settings,
and both latency modes (42 model runs). It saves metrics and sample WAVs.
