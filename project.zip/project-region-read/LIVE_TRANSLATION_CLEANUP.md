# Live translated text cleanup and progress

Live subtitle results are cleaned once, in delivery order, before either the caption or speech queue receives them. Latin words (including contractions, accented names and identifiers) and ASCII digits `0–9` are removed. Numeric separators, empty brackets and surplus whitespace are cleaned. Kurdish letters and Kurdish/Arabic numerals are preserved. A result with no surviving text is silent; it cannot block the next ordered result. The original OCR source is retained for translation and matching.

Progress matching now remembers full observed source captions, rather than only the last spoken delta:

- `Hello everyone` → `Hello everyone welcome` → `Hello everyone welcome back` speaks the first phrase, then `welcome`, then `back`.
- Rolling captions such as `Where are you going? I will come with you.` → `I will come with you. Wait for me!` emit only `Wait for me!` on the second frame.
- Case, punctuation and line wrapping do not restart the same text. A shortened prefix from a fluctuating frame stays silent. A newly completed word is preserved whole rather than emitting a word fragment.
- Long source lines retain their complete keys: an addition after character 200 is no longer lost. Broad fuzzy similarity no longer suppresses a genuinely new short ending.
- Cleaned translations also have repeat memory, so two source/provider results that reduce to the same Kurdish text do not speak twice. Prefix removal on translated output is limited to source continuations, so independent lines keep their opening words.

Recent memory is bounded to 40 entries / 20 seconds in each stage. An unchanged currently visible caption remains suppressed beyond that window. Blank frames hide captions while retaining recent memory; an intentionally repeated line in a later scene can be read again after the recent window. Single-word rolling overlaps are kept conservatively to avoid deleting a genuine new word. Rolling overlap uses a linear prefix/suffix matcher. There is no extra network request or added waiting interval; existing typewriter settling and FIFO speech continue to apply.

Pause/Play behavior remains available. Explicit Play intentionally reads the last saved sentence once, now cleaned by the same filter; ordinary duplicate frames do not trigger that replay. Region selections and provider/voice settings remain intact.

## Validation

The added JVM tests cover Latin and numeric filtering, empty results, Kurdish numerals, cumulative and rolling captions, short extensions, short repeats after blanks, long captions, partial-word completion, repeated-word overlap, CJK text without spaces, memory expiry and output-level repeats. Full Android build and test totals are in VALIDATION.md. Actual capture, overlay interaction and audio must still be checked on a phone.
