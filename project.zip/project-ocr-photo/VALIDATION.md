# Supplied screenshot OCR validation — 2026-11-09

- Gradle `testDebugUnitTest --offline`: Android application/test Kotlin source compilation and unit tests.
- 302 JVM tests across 39 suites; 0 failures, 0 errors, 0 skips.
- 27 MixedOcrFilter tests, including 9 added after inspecting the actual screenshot: split 18 digits, Silo/مانگ conflict, phone-only row, Kurdish و/9 conflict, price tokens, unknown confidence, Latin-only logos, unmatched brackets and number-heavy artwork.
- Supplied screenshot: bundled ckb model run with desktop Tesseract and first-pass equivalent preprocessing; captured word boxes run through actual Kotlin filter before and after.
- Desktop eng OCR is a diagnostic surrogate. Android ML Kit was NOT executed; Android optional binarized retry, device latency and audio were NOT tested.
- Exact ckb model SHA256 and all user dictionaries remain unchanged.
- Reproduction, raw captured boxes, before/after output and known remaining image recognition errors: verification/photo-ocr/README.md.
- Final Gradle log: ocr-photo-test.log.
- Source-only delivery; no APK assembled or included.

The filter improves retention and ordering. It cannot reconstruct letters the provided model fails to recognize; see the photo report for unrecovered headline, logo, price and spelling errors.
