package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class PiperVoiceProfileTest {
    @Test fun differentTonesCannotReuseOneAnothersProcessedAudio() {
        val keys = (0..2).map {
            PiperVoiceProfile.cacheKey(1f, true, PiperVoiceProfile.get(it), "سڵاو")
        }
        assertEquals(3, keys.toSet().size)
        assertEquals(keys[2], PiperVoiceProfile.cacheKey(1f, true, PiperVoiceProfile.get(2), "سڵاو"))
        assertNotEquals(keys[2], PiperVoiceProfile.cacheKey(1f, false, PiperVoiceProfile.get(2), "سڵاو"))
    }
    @Test fun unknownPersistedToneKeepsTheOriginalVoice() {
        for (invalid in listOf(-1, 3, Int.MAX_VALUE)) {
            assertEquals(PiperVoiceProfile.get(0), PiperVoiceProfile.get(invalid))
        }
    }
}
