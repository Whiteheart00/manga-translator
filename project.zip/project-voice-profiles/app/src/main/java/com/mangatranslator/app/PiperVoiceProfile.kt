package com.mangatranslator.app

/** Playback tones derived from the existing speaker, not newly trained speakers. */
internal object PiperVoiceProfile {
    data class Preset(val id: Int, val label: String, val pitch: Float,
                      val cutoffHz: Float, val targetRms: Float)
    private val presets = listOf(
        Preset(0, "دەنگی ڕەسەن", 1f, 7000f, 0.1f),
        Preset(1, "پیاوانەی نەرم", 1f, 5600f, 0.095f),
        Preset(2, "تۆنی ژنانەی نەرم (گۆڕینی دەنگ)", 1.22f, 6000f, 0.095f)
    )
    val labels: List<String> = presets.map { it.label }
    fun get(id: Int): Preset = presets.getOrElse(id) { presets[0] }
    fun cacheKey(speed: Float, lowLatency: Boolean, preset: Preset, text: String) =
        "${(speed * 100).toInt()}|${if (lowLatency) 1 else 0}|tone=${preset.id}|$text"
}
