# Voice profile validation — 2026-11-09

- Gradle testDebugUnitTest --offline: BUILD SUCCESSFUL; Android app/test Kotlin source compilation passed.
- 304 tests across 40 suites; 0 failures, 0 errors, 0 skipped.
- Added regression checks for processed-audio cache separation between tones and safe original-tone behavior for unknown IDs.
- Same original traineddata/dictionaries/model architecture; no ONNX model download or retraining.
- Preview WAVs: equal duration, 22050 Hz mono PCM16, no clipped samples. These are desktop previews, not device recordings.
- Android pitch, listening quality, output routing and mobile latency/battery/heat remain unverified on a device. See VOICE_PROFILES.md.
- Final Gradle log: voice-profiles-test.log.
- Source only; no APK assembled or included.
