# Optional female audition profile

Existing model directories, defaults, presets 0–2 and other speech providers are retained. Preset 3 is opt-in. The new import shortcut selects the trained slot and preset 3, enables offline Piper, and disables Pawan for that selection. A SHA-256 check at model load restricts this recipe to the full Sorani female compact ONNX model. The generic model importer and original slot are retained.

The original desktop audition used Praat Change gender (formants 1.04, requested pitch median 215 Hz), FFmpeg high-pass 90 Hz, 4-kHz +3-dB peaking EQ, ratio-2 compression and loudness normalization. This Android-independent Kotlin implementation uses linear resampling plus WSOLA to couple pitch and formants at +4%, restoring sample count. It is an approximation, not a Praat port, and does not guarantee perceptual equivalence or set every sentence to 215 Hz. No reverb or artificial breath noise is added.

The PCM processing replaces the old denoise/RMS branch only for preset 3; AudioTrack receives pitch 1.0, avoiding a second pitch shift. The new profile has a separate cache key. Missing/wrong models report an error rather than falling back to the English system voice; fallback behaviour of the old profiles is retained.

Validation:
- 47 JVM unit tests passed, including the old model slots/presets, encoding/configuration and new DSP tests.
- The fixture has exactly 65,536 samples before and after processing (4.096 s, 16 kHz).
- Praat median F0: raw 205.86 Hz, desktop audition 214.85 Hz, mobile approximation 214.00 Hz.
- FFmpeg measurement of the exported mobile fixture: integrated loudness -18.34 LUFS, true peak -1.45 dBTP. The code's limiter is a sample-peak cap, not a certified oversampled true-peak limiter.
- An ONNX Runtime 1.19.2 JVM probe executes the app's encoder/config plus the actual Kotlin recipe on six text cases; results are in this directory.
- The JVM fixture took 0.165 s to process on this server. This is not an Android benchmark.

The source can be built using the existing Android Gradle workflow. No Android SDK/Gradle toolchain is installed in this workspace, so a complete Android build, APK signing and physical-device playback were not verified. The original app/debug.keystore was not supplied; use the existing owner's key for an update-compatible APK. No signing key is generated or included here.

The ONNX model weights and pronunciation are unchanged. This change does not fix the reported ر/ڕ confusion. Automatic acoustic measures and unit tests are not listening evaluations.

## Version 1.3.22 timing change

The mobile DSP fixture above measures the recipe itself. In the complete app path, boundary silence is now trimmed before that recipe; the fixture's unchanged sample-count claim does not describe silence trimming. Reference-model chunks use the short-first/longer-following planner and boundary-based pauses. Whole-utterance internal pauses and model weights are retained. See `../playback-latency/` for the user's matched-text regression and ONNX timing results. The new timings are server observations, not phone guarantees. The original-model planner is unchanged.
