package com.mangatranslator.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Future
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * خوێندنەوەی دەقی وەرگێڕدراوی سۆرانی بە Gemini TTS.
 * دەنگ لە API ـی خۆڕایی Gemini (لە سنووری quota ـی Google) داوا دەکرێت.
 * Callbackـەکان لە main thread بانگ دەکرێن؛ speak() و stop() لە main thread بانگ بکرێن.
 */
class SoraniTts(
    private val ctx: Context,
    private val settings: TranslatorSettings
) {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val pool: ExecutorService = Executors.newFixedThreadPool(3)

    @Volatile
    private var pending: List<Future<*>> = emptyList()

    @Volatile
    private var runId = 0

    @Volatile
    var speaking = false
        private set

    @Volatile
    private var connection: HttpURLConnection? = null

    @Volatile var canRetryLastFailure = true
        private set

    @Volatile
    private var player: MediaPlayer? = null

    private var piperEngine: PiperTts? = null
    private val piper: PiperTts
        get() = synchronized(this) { piperEngine ?: PiperTts(ctx).also { piperEngine = it } }

    private var offlineEngine: OfflineKurdishTts? = null
    private val offline: OfflineKurdishTts
        get() = offlineEngine ?: OfflineKurdishTts(ctx).also { it.lowLatency = lowLat; offlineEngine = it }
    @Volatile private var lowLat = false

    // ---------- Pawan: ئەگەر ئینتەرنێت هەبوو Pawan، ئەگینا ئۆفلاین ----------

    private fun isOnline() = PawanTts.isOnline(ctx)
    private fun usePawan() = settings.pawanTts && isOnline()
    /** ئۆفلاین: یان هەڵبژێردراوە، یان Pawan چالاکە بەڵام ئینتەرنێت نییە */
    private fun useOffline() = settings.offlineTts || (settings.pawanTts && !isOnline())

    private class PawanStream(val onState: (Boolean) -> Unit, val onError: (String) -> Unit) {
        val q = ArrayDeque<String>()
        var playing = false
        var ended = false
    }

    @Volatile
    private var pStream: PawanStream? = null

    private fun beginPawanStream(onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        runId++
        stopPlayback()
        streamQ?.offer(SpeechMsg(null))
        streamQ = null
        PawanTts.stop()
        val s = PawanStream(onState, onError)
        pStream = s
        speaking = true
        onState(true)
    }

    private fun pawanNext(s: PawanStream) {
        if (pStream !== s || s.playing) return
        val t = s.q.removeFirstOrNull()
        if (t == null) {
            if (s.ended) { pStream = null; speaking = false; s.onState(false) }
            return
        }
        s.playing = true
        val speakIt: (String) -> Unit = { txt ->
            if (pStream === s) {
                PawanTts.speak(
                    ctx, txt,
                    onState = { on -> if (!on) main.post { s.playing = false; pawanNext(s) } },
                    onError = { m ->
                        if (pStream === s) { pStream = null; speaking = false; s.onError(m); s.onState(false) }
                    }
                )
            }
        }
        if (LatinKurdish.needsConversion(settings, t)) {
            pool.execute {
                val c = try { LatinKurdish.convert(ctx, settings, t) } catch (_: Throwable) { LatinKurdish.rough(t) }
                main.post { speakIt(c) }
            }
        } else speakIt(LatinKurdish.clean(t))
    }

    private fun speakPawan(texts: List<String>, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        val clean = texts.map { it.trim() }.filter { it.isNotEmpty() }.map { padFor(it, settings.padPawan) }
        if (clean.isEmpty()) return
        PawanTts.stop()
        val id = ++runId
        speaking = true
        val joined = clean.joinToString("\n")
        val go: (String) -> Unit = { txt ->
            if (id == runId) {
                PawanTts.speak(
                    ctx, txt,
                    { on -> speaking = on; onState(on) },
                    { m -> speaking = false; onState(false); onError(m) }
                )
            }
        }
        if (LatinKurdish.needsConversion(settings, joined)) {
            // کوردیی لاتینی: دەگۆڕدرێت بۆ پیتی کوردی (Gemini)، پاشان دەخوێنرێتەوە
            onState(true)
            pool.execute {
                val c = try { LatinKurdish.convert(ctx, settings, joined) } catch (_: Throwable) { LatinKurdish.rough(joined) }
                main.post { go(c) }
            }
        } else {
            go(LatinKurdish.clean(joined))
        }
    }

    /** دۆخی ئۆفلاین: دەق بە لاتینی دەکرێت و بە دەنگی ناو مۆبایل دەخوێنرێتەوە، بێ ئینتەرنێت و بێ کلیل. */
    private fun speakOffline(texts: List<String>, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        canRetryLastFailure = true
        if (settings.piperVoiceProfile == FemaleVoiceRecipe.PROFILE_ID &&
            settings.offlineVoice == KurdishVoiceText.PIPER && !PiperTts.isInstalled(ctx)) {
            onError("سەرەتا مۆدێلی ئافرەت لە ڕێکخستنی دەنگ بهێنە.")
            return
        }
        val wantPiper = settings.offlineVoice == KurdishVoiceText.PIPER && PiperTts.isInstalled(ctx)
        // Piper accepts standalone words without merging or filler words.
        // Preserve the existing preparation for the system voice.
        val clean = if (wantPiper) texts.map { it.trim() }.filter { it.isNotEmpty() }
                    else SpeechMerge.merge(texts).map { padForVoice(it) }
        if (clean.isEmpty()) return
        val id = ++runId
        stopPlayback()
        speaking = true
        onState(true)
        worker.execute {
            if (id != runId) return@execute
            var error: String? = null
            var retryAllowed = true
            try {
                if (wantPiper) {
                    error = piper.speakBlocking(clean, spd()) { id == runId }
                    retryAllowed = !piper.playbackMayHaveStarted
                    // System fallback is safe only before any Piper audio may
                    // have played. Never restart a partly spoken paragraph.
                    if (error != null && retryAllowed && id == runId &&
                        settings.piperVoiceProfile != FemaleVoiceRecipe.PROFILE_ID) {
                        error = offline.speakBlocking(clean, KurdishVoiceText.EN, spd()) { id == runId }
                    }
                } else {
                    error = offline.speakBlocking(clean, settings.offlineVoice, spd()) { id == runId }
                }
            } catch (t: Throwable) {
                error = "خوێندنەوە سەرنەکەوت: " + (t.message ?: t.javaClass.simpleName).take(180)
                if (wantPiper) retryAllowed = !piper.playbackMayHaveStarted
            } finally {
                val message = error
                val mayRetry = retryAllowed
                main.post {
                    if (id == runId) {
                        speaking = false
                        canRetryLastFailure = mayRetry
                        if (message != null) onError(message)
                        if (id == runId) onState(false)
                    }
                }
            }
        }
    }

    /**
     * پەیامێکی کورت بە دەنگی ئۆفلاین دەخوێنێتەوە (بێ ئینتەرنێت، بێ Pawan)، بۆ ئەو کاتانەی ئینتەرنێت/Pawan کار ناکات.
     * ئەگەر دەنگی ئۆفلاین دانەبەزێندرابێت هەڵەکە بێدەنگ دەبێت (دوگمەی سەر شاشە هەر دەمێنێت).
     */
    fun speakNotice(text: String) {
        speakOffline(listOf(text), { }, { })
    }

    /**
     * خێراکردنی کاتیی دەنگ (ژێرنووسی زیندوو: کاتێک ڕستەی نوێ زۆر دێت و دەنگ دەبێت بگات). 1 = ئاسایی.
     * لەسەر خێرایی بەکارهێنەر (settings.speechSpeed) زیاد دەکرێت و هەمیشە لە 0.5..2 دەمێنێتەوە.
     */
    @Volatile
    var speedBoost = 1f

    /** پڕکەرەوە تەنها بۆ دەنگی سیستەم و موتورەکانی جگە لە Piper */
    private fun padFor(t: String, on: Boolean): String =
        if (on) SpeechPad.pad(t, settings.padWord, settings.padMinChars) else t.trim()
    private fun padForVoice(t: String): String = padFor(t, settings.padOffline)

    private fun spd(): Float = (settings.speechSpeed * speedBoost).coerceIn(0.5f, 2f)

    /** دۆخی دواکەوتنی کەم بۆ Piper (ژێرنووسی زیندوو): دەنگی کورت هێواش ناکرێت. */
    fun setLowLatency(on: Boolean) {
        piper.lowLatency = on
        lowLat = on
        offlineEngine?.lowLatency = on   // دەنگی سیستەم (یەکەم دەنگ): لە ژێرنووسی زیندوو خێراتر و بێ وچانی زیادە
    }

    /**
     * ژێرنووسی زیندوو: ڕستەی دواتر لە پاشبنەما دروست دەکرێت لەکاتێکدا ڕستەی ئێستا دەپەخشرێت، بۆ ئەوەی نێوانیان وچان نەبێت.
     * `boost` = خێراکردنی ئەو خوێندنەوەیەی کە دواتر دێت (بە هەمان فۆرمولی spd()).
     */
    fun prefetch(text: String, boost: Float) {
        if (usePawan() || !useOffline()) return
        if (settings.offlineVoice != KurdishVoiceText.PIPER || !PiperTts.isInstalled(ctx)) return
        piper.prefetch(text.trim(), (settings.speechSpeed * boost).coerceIn(0.5f, 2f))
    }

    /** مۆدێلی کوردیی نیورالی پێشوەختە بار دەکات، تا یەکەم خوێندنەوە دوا نەکەوێت. */
    fun warmUp() {
        if (useOffline() && settings.offlineVoice == KurdishVoiceText.PIPER && PiperTts.isInstalled(ctx)) piper.warmUp()
    }

    @Volatile
    private var streamQ: LinkedBlockingQueue<SpeechMsg>? = null

    /**
     * خوێندنەوەی پارچە پارچە: beginStream() دەست پێدەکات، feed() هەر دەقێک کە ئامادە بوو دەنێرێت و دەستبەجێ
     * دەخوێنرێتەوە (بێ چاوەڕێی دەقەکانی تر)، endStream() کۆتایی دەڵێت. ئەگەر ڕیزەکە نوێ کرایەوە، کۆنەکە دەوەستێت.
     */
    fun beginStream(fast: Boolean, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        if (usePawan()) { beginPawanStream(onState, onError); return }
        pStream = null
        val useOff = useOffline()
        val id = ++runId
        stopPlayback()
        streamQ?.offer(SpeechMsg(null))
        val q = LinkedBlockingQueue<SpeechMsg>()
        streamQ = q
        speaking = true
        onState(true)
        worker.execute {
            try {
                if (id != runId) return@execute
                val err: String? = when {
                    useOff && settings.offlineVoice == KurdishVoiceText.PIPER ->
                        piper.speakStream(q, spd()) { id == runId }
                    useOff -> {
                        var e: String? = null
                        while (id == runId && e == null) {
                            val m = q.poll(150, TimeUnit.MILLISECONDS) ?: continue
                            val t = m.text ?: break
                            e = offline.speakBlocking(listOf(t), settings.offlineVoice, spd()) { id == runId }
                        }
                        e
                    }
                    else -> geminiStream(q, fast, id)
                }
                if (err != null && id == runId) main.post { onError(err) }
            } catch (t: Throwable) {
                if (id == runId) {
                    val c = t.cause ?: t
                    Log.e(TAG, "stream failed", c)
                    main.post { onError("خوێندنەوە سەرنەکەوت:\n" + (c.message ?: c.javaClass.simpleName).take(200)) }
                }
            } finally {
                if (id == runId) {
                    speaking = false
                    main.post { onState(false) }
                }
            }
        }
    }

    fun feed(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val ps = pStream
        if (ps != null) { main.post { if (pStream === ps) { ps.q.addLast(t); pawanNext(ps) } }; return }
        streamQ?.offer(SpeechMsg(t))
    }

    fun endStream() {
        val ps = pStream
        if (ps != null) { main.post { if (pStream === ps) { ps.ended = true; pawanNext(ps) } }; return }
        streamQ?.offer(SpeechMsg(null))
    }

    /** Gemini TTS: هەر دەقێک کە دێت دەنگی بۆ دروست دەکرێت (بە چەند thread)؛ بە ڕیزی ڕاستەقینە دەپەخشرێت. */
    private fun geminiStream(q: LinkedBlockingQueue<SpeechMsg>, fast: Boolean, id: Int): String? {
        if (settings.geminiTtsKey.isBlank()) {
            return "سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ. کلیلی Google Translate جیاوازە."
        }
        val futs = LinkedBlockingQueue<Any>()
        val endMark = Any()
        val producer = Thread({
            try {
                var first = true
                while (id == runId) {
                    val m = q.poll(150, TimeUnit.MILLISECONDS) ?: continue
                    val t = m.text ?: break
                    val parts = splitForSpeech(listOf(t))
                    // یەکەم پارچە کورت بێت تا دەنگ زووتر دەست پێبکات (دەقی درێژی بێ خاڵبەندی بە یەک داواکاری هێواش دەبوو)
                    for (part in if (first) shortenFirst(parts) else parts) futs.put(pool.submit(Callable { synthesize(part, fast) }))
                    first = false
                }
            } finally {
                futs.put(endMark)
            }
        }, "gemini-tts-feed")
        producer.start()
        try {
            while (id == runId) {
                val f = futs.poll(150, TimeUnit.MILLISECONDS) ?: continue
                if (f === endMark) break
                @Suppress("UNCHECKED_CAST")
                val audio = try {
                    (f as Future<ByteArray>).get()
                } catch (e: java.util.concurrent.ExecutionException) {
                    throw e.cause ?: e
                }
                if (id == runId) play(audio, id)
            }
        } finally {
            producer.interrupt()
        }
        return null
    }

    private val audioCache = object : LinkedHashMap<String, ByteArray>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>?) = size > 30
    }

    /** هەموو دەقەکان بە ڕیز دەخرێنە ناو یەک داواکاریی TTS بۆ کەمکردنەوەی API calls. */
    fun speak(texts: List<String>, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        canRetryLastFailure = true
        if (usePawan()) { speakPawan(texts, onState, onError); return }
        if (useOffline()) { speakOffline(texts, onState, onError); return }
        val clean = texts.map { it.trim() }.filter { it.length >= 2 }.map { padFor(it, settings.padGemini) }
        if (clean.isEmpty()) return
        // ئەگەر کلیلی Gemini نییە، هەوڵی ئۆفلاین بدە (ئەگەر دامەزرابوو)
        if (settings.geminiTtsKey.isBlank()) {
            // هەوڵی ئۆفلاین (Piper یان TTS ی سیستەم) — تەنها کلیلی Gemini مەبەستە نەک
            speakOffline(texts, onState, onError)
            return
        }

        val text = clean.joinToString("\n")
        val id = ++runId
        stopPlayback()
        speaking = true
        onState(true)

        worker.execute {
            try {
                val audio = synthesize(text)
                if (id == runId) play(audio, id)
            } catch (t: Throwable) {
                Log.e(TAG, "Gemini TTS failed", t)
                if (id == runId) {
                    val why = (t.message ?: t.javaClass.simpleName).take(220)
                    main.post { onError("خوێندنەوەی Gemini سەرنەکەوت:\n$why") }
                }
            } finally {
                if (id == runId) {
                    speaking = false
                    main.post { onState(false) }
                }
            }
        }
    }

    /**
     * خێرا: دەقەکە دەکرێتە پارچەی کورت (ڕستە ڕستە) و هەموو پارچەکان پێکەوە (بە چەند کلیل) دەنگیان بۆ دروست دەکرێت؛
     * یەکەم پارچە کە ئامادە بوو دەستبەجێ دەپەخشرێت و ئەوانی تر بە ڕیز دەچنە دوای.
     */
    fun speakParts(texts: List<String>, fast: Boolean, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        canRetryLastFailure = true
        if (usePawan()) { speakPawan(texts, onState, onError); return }
        if (useOffline()) { speakOffline(texts, onState, onError); return }
        val parts = splitForSpeech(texts)
        if (parts.isEmpty()) return
        if (settings.geminiTtsKey.isBlank()) {
            onError("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ. کلیلی Google Translate جیاوازە.")
            return
        }
        val id = ++runId
        stopPlayback()
        speaking = true
        onState(true)

        val fs = parts.map { t -> pool.submit(Callable { synthesize(t, fast) }) }
        pending = fs
        worker.execute {
            try {
                for (f in fs) {
                    if (id != runId) break
                    val audio = f.get()
                    if (id == runId) play(audio, id)
                }
            } catch (t: Throwable) {
                if (id == runId) {
                    val c = t.cause ?: t
                    Log.e(TAG, "Gemini TTS failed", c)
                    val why = (c.message ?: c.javaClass.simpleName).take(220)
                    main.post { onError("خوێندنەوەی Gemini سەرنەکەوت:\n$why") }
                }
            } finally {
                if (id == runId) {
                    speaking = false
                    main.post { onState(false) }
                }
            }
        }
    }

    /** ئەگەر یەکەم پارچە لە ٩٠ پیت درێژتر بوو، لە نزیکی ٤٠-٨٠ پیت (کۆما یان بۆشایی) دەبڕدرێت بۆ ئەوەی یەکەم دەنگ خێراتر بێت. */
    private fun shortenFirst(parts: List<String>): List<String> {
        if (parts.isEmpty()) return parts
        val f = parts[0]
        if (f.length <= 90) return parts
        var cut = -1
        for (i in 80 downTo 40) {
            val c = f[i]
            if (c == '\u060C' || c == ',') { cut = i + 1; break }
        }
        if (cut < 0) {
            for (i in 70 downTo 40) {
                if (f[i] == ' ') { cut = i; break }
            }
        }
        if (cut < 0) return parts
        val a = f.substring(0, cut).trim()
        val b = f.substring(cut).trim()
        if (a.length < 2 || b.length < 2) return parts
        return listOf(a, b) + parts.drop(1)
    }

    /** هەر دەقێک بە ڕستە دابەش دەکرێت؛ ڕستەی زۆر کورت دەخرێتە سەر ڕستەی دواتر. */
    private fun splitForSpeech(texts: List<String>): List<String> {
        val out = ArrayList<String>()
        val re = Regex("(?<=[.!?؟۔…])\\s+")
        for (t0 in texts) {
            val t = t0.trim()
            if (t.length < 2) continue
            val sent = t.split(re).map { it.trim() }.filter { it.isNotEmpty() }
            var acc = ""
            for (x in sent) {
                acc = if (acc.isEmpty()) x else "$acc $x"
                if (acc.length >= 30) {
                    out.add(acc)
                    acc = ""
                }
            }
            if (acc.isNotEmpty()) {
                if (out.isNotEmpty() && acc.length < 12 && out.last().length + acc.length < 200) out[out.size - 1] = out.last() + " " + acc
                else out.add(acc)
            }
        }
        return out.filter { it.length >= 2 }
    }

    fun stop() {
        runId++
        streamQ?.offer(SpeechMsg(null))
        streamQ = null
        offlineEngine?.stop()
        piperEngine?.stop()
        pending.forEach { it.cancel(true) }
        pending = emptyList()
        speaking = false
        stopPlayback()
        pStream = null
        PawanTts.stop()
    }

    /** مۆدێلی Piper لە ڕام دەردەهێنێت (ئەگەر نەخوێندرابێتەوە)؛ دواتر خۆکارانە دووبارە بار دەبێت. */
    fun releaseModels() {
        if (speaking) return
        val e = synchronized(this) { piperEngine.also { piperEngine = null } }
        try { e?.shutdown() } catch (_: Throwable) {}
    }

    fun shutdown() {
        stop()
        offlineEngine?.shutdown()
        offlineEngine = null
        piperEngine?.shutdown()
        piperEngine = null
        worker.shutdownNow()
        pool.shutdownNow()
    }

    private fun synthesize(text: String, fast: Boolean = false): ByteArray {
        val models = if (fast) listOf(MODEL_LITE, MODEL) else listOf(MODEL)
        var last: ApiException? = null
        for (m in models) {
            try {
                return GeminiKeys.withKeys(settings.geminiTtsKey) { k -> synthesizeWith(text, k, m) }
            } catch (e: ApiException) {
                last = e
                if (e.code != 404 && e.code != 400) throw e   // مۆدێلەکە نییە یان قبوڵی ناکات ← مۆدێلی دواتر
            }
        }
        throw last ?: IOException("TTS")
    }

    private fun synthesizeWith(text: String, apiKey: String, model: String = MODEL): ByteArray {
        val voice = settings.geminiTtsVoice
        val cacheKey = "$model\u0000$voice\u0000$text"
        synchronized(audioCache) { audioCache[cacheKey] }?.let { return it }

        val speech = JSONObject()
            .put("voice", voice)
        val content = JSONObject()
            .put("type", "text")
            .put("text", text)
            .put(
                "annotations",
                JSONArray().put(
                    JSONObject()
                        .put("type", "speech_metadata")
                        .put(
                            "style",
                            "Read this text verbatim in Central Kurdish (Sorani), clearly and naturally. " +
                                "Do not translate, summarize, explain, or add words."
                        )
                )
            )
        val input = JSONObject()
            .put("type", "user_input")
            .put("content", JSONArray().put(content))
        val body = JSONObject()
            .put("model", model)
            .put("input", JSONArray().put(input))
            .put("response_format", JSONObject().put("type", "audio"))
            .put("generation_config", JSONObject().put("speech_config", JSONArray().put(speech)))

        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", apiKey)
            setRequestProperty("User-Agent", "MangaTranslator-Android")
        }
        connection = conn
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val responseText = if (code in 200..299) {
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else {
                conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            }
            if (code !in 200..299) {
                val detail = try {
                    JSONObject(responseText).optJSONObject("error")?.optString("message").orEmpty()
                } catch (_: Exception) {
                    responseText.take(180)
                }
                val hint = when (code) {
                    400 -> " (داواکاری یان مۆدێل هەڵەیە)"
                    401, 403 -> " (کلیلی Gemini API هەڵەیە یان مۆدێل بۆی چالاک نییە)"
                    429 -> " (سنووری خۆڕایی/خێرایی بەکارهێنان گەیشتووە؛ کەمێک چاوەڕێ بکە)"
                    else -> ""
                }
                throw ApiException(code, "Gemini API $code$hint ${detail.take(180)}".trim())
            }

            val json = JSONObject(responseText)
            val encoded = extractAudio(json) ?: throw IOException("Gemini API دەنگی نەگەڕاندەوە")
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            if (bytes.isEmpty()) throw IOException("دەنگی بەتاڵە")
            synchronized(audioCache) { audioCache[cacheKey] = bytes }
            return bytes
        } finally {
            conn.disconnect()
            if (connection === conn) connection = null
        }
    }

    private fun extractAudio(response: JSONObject): String? {
        response.optJSONObject("output_audio")?.optString("data")
            ?.takeIf { it.isNotBlank() }?.let { return it }
        response.optJSONObject("outputAudio")?.optString("data")
            ?.takeIf { it.isNotBlank() }?.let { return it }

        val steps = response.optJSONArray("steps") ?: return null
        for (i in steps.length() - 1 downTo 0) {
            val parts = steps.optJSONObject(i)?.optJSONArray("content") ?: continue
            for (j in parts.length() - 1 downTo 0) {
                val part = parts.optJSONObject(j) ?: continue
                if (part.optString("type") == "audio") {
                    return part.optString("data").takeIf { it.isNotBlank() }
                }
            }
        }
        return null
    }

    private fun play(bytes: ByteArray, id: Int) {
        val file = File(ctx.cacheDir, "gemini_tts.wav")
        file.writeBytes(bytes)

        val finished = CountDownLatch(1)
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(VoiceOutput.attributes(settings.voiceOutput))
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener { finished.countDown() }
            mp.setOnErrorListener { _, _, _ ->
                finished.countDown()
                true
            }
            mp.prepare()
            if (id != runId) return
            var curSpeed = spd()
            mp.start()
            if (curSpeed != 1f) setSpeed(mp, curSpeed)
            while (id == runId && !finished.await(100, TimeUnit.MILLISECONDS)) {
                // خێرایی لە کاتی خوێندنەوەدا دەگۆڕدرێت (وەک YouTube)
                val sp = spd()
                if (sp != curSpeed) { curSpeed = sp; setSpeed(mp, sp) }
            }
        } finally {
            try {
                if (mp.isPlaying) mp.stop()
            } catch (_: Exception) {
            }
            try {
                mp.release()
            } catch (_: Exception) {
            }
            if (player === mp) player = null
        }
    }

    private fun setSpeed(mp: MediaPlayer, speed: Float) {
        try {
            mp.playbackParams = android.media.PlaybackParams().setSpeed(speed).setPitch(1f)
        } catch (_: Exception) {
        }
    }

    private fun stopPlayback() {
        try { offlineEngine?.stop() } catch (_: Exception) {}
        try { piperEngine?.stop() } catch (_: Exception) {}
        try {
            connection?.disconnect()
        } catch (_: Exception) {
        }
        try {
            player?.let { if (it.isPlaying) it.stop() }
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val TAG = "SoraniTts"
        private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/interactions"
        private const val MODEL = "gemini-3.8-flash-tts"
        private const val MODEL_LITE = "gemini-3.8-flash-lite-tts"
    }
}
