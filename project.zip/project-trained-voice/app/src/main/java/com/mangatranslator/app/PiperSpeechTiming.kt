package com.mangatranslator.app

import kotlin.math.*

/** Reference VITS input is capped at 180 characters. Keep a short first phrase,
 * then use longer, word-complete chunks to avoid repeated inference and extra pauses.
 * The legacy model's chunking and timing remain in PiperTts.
 */
internal object PiperSpeechTiming {
    const val FIRST_LIMIT = 64
    const val STEADY_LIMIT = 160

    fun chunks(text: String): List<String> {
        val normalized = text.trim().replace(Regex("\\s+"), " ")
        val sentences = normalized.split(Regex("(?<=[.!?؟])\\s*"))
            .map { it.trim() }.filter { it.isNotEmpty() }
        val result = ArrayList<String>()
        for (sentence in sentences) {
            var remaining = sentence
            while (remaining.isNotEmpty()) {
                val limit = if (result.isEmpty()) FIRST_LIMIT else STEADY_LIMIT
                if (remaining.length <= limit) { result.add(remaining); break }
                // Prefer a clause boundary near the end, rather than every comma.
                val minimum = if (result.isEmpty()) 28 else 80
                val clause = (minimum until limit).lastOrNull { i ->
                    remaining[i] in "،,٫" && remaining.getOrNull(i+1)?.isWhitespace() == true
                }
                val word = remaining.lastIndexOf(' ', limit)
                val end = if (clause != null) clause+1 else if (word>0) word else limit
                result.add(remaining.substring(0,end).trim())
                remaining = remaining.substring(end).trimStart()
            }
        }
        return result
    }

    /** Only explicit punctuation receives 20 ms; wrapping/newlines/technical splits add none. */
    @Suppress("UNUSED_PARAMETER")
    fun pauseMs(text: String, lowLatency: Boolean): Int =
        if (text.trimEnd().lastOrNull() in listOf('.', '،', '؟', '!', '٫', ',', '?')) 20 else 0

    /** Only trim boundary silence; never delete pauses inside speech or low-energy consonants.
     * 10-ms RMS frames, -40 dB relative threshold, 40-ms context on either side.
     */
    fun trimEdges(input: FloatArray, rate: Int): FloatArray {
        if (input.isEmpty()) return input.copyOf()
        val window=max(1,rate/100)
        val energy=DoubleArray((input.size+window-1)/window) { frame ->
            val start=frame*window;val end=min(input.size,start+window)
            var sum=0.0
            for (i in start until end) sum+=input[i].toDouble()*input[i]
            sqrt(sum/(end-start))
        }
        val peak=energy.maxOrNull() ?: return input.copyOf()
        if (peak<1e-8) return input.copyOf()
        val threshold=max(1e-6,peak*.01)
        val first=energy.indexOfFirst { it>=threshold };val last=energy.indexOfLast { it>=threshold }
        if (first<0 || last<first) return input.copyOf()
        val context=rate*40/1000
        val start=max(0,first*window-context)
        val end=min(input.size,(last+1)*window+context)
        return input.copyOfRange(start,end)
    }
}
