package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.SystemClock
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

/**
 * وەرگێڕانی زیندووی ژێرنووس (ڤیدیۆ / یاری): ڕووبەرێکی دیاریکراو بەردەوام دەگیرێت ← OCR ← وەرگێڕان ← دەنگ.
 * تەنها دەق بەکاردێت (OCR)، نەک وەرگێڕانی دەنگ بۆ دەنگ.
 *
 *  1. onFrame()   — لە thread ی گرتنەوە، بۆ هەر فرەیمێک (≈٦ جار لە چرکەیەکدا). تەنها ڕووبەرەکە دەبڕێت و بە
 *                   واژۆی ٣٢×٣٢ بەراوردی دەکات. تەنها کاتێک OCR دەکات کە ڕووبەرەکە گۆڕابێت و (ڕاوەستابێت یان ٤٥٠ms تێپەڕیبێت).
 *  2. OCR         — ML Kit ی ئۆفلاین (OcrEngine.recognizeLive)؛ عەرەبی بە Gemini بینین (ئەگەر کلیل هەبێت) یان Tesseract.
 *  3. دووبارەنەبوونەوە — هەمان ژێرنووس (یان OCR ی کەمێک جیاواز) دووبارە وەرناگێڕدرێتەوە.
 *  4. وەرگێڕان    — Gemini (بە ٣ دێڕی پێشوو وەک چوارچێوە)؛ ئەگەر لە ٧٠٠ms زیاتر خایاند Google بەهاوڕێی دەست پێدەکات
 *                   و یەکەم وەڵام دەبات (hedged request). cache بۆ دێڕە دووبارەکان.
 *  5. دەنگ        — هیچ ڕستەیەک لەبیر ناکرێت: هەموو ڕستەیەک (OCR ← وەرگێڕان) بە ڕیزی دەرکەوتنی دەخوێنرێتەوە. وەرگێڕانی
 *                   ڕستەکان پارالێل دەکرێت بەڵام بە هەمان ڕیز ئازاد دەکرێن؛ [SpeechQueue] FIFO ی بێ سنوور و بێ
 *                   «کۆن بوو» و بێ بڕین. ئەگەر چەند ڕستە کۆ بوون پێکەوە و کەمێک خێراتر دەخوێنرێنەوە.
 *
 * ئۆڤەرلەی وەرگێڕان لە دەرەوەی ڕووبەرەکە دەکێشرێت (OverlayService)، نەک لەسەری، بۆ ئەوەی OCR دەقی خۆمان نەخوێنێتەوە (لووپ).
 */
class LiveSubtitle(
    private val ctx: Context,
    private val ocr: OcrEngine,
    private val tts: SoraniTts,
    private val settings: TranslatorSettings,
    private val main: Handler,
    /** null = ژێرنووس نەما (بار بسڕەوە). لەسەر main thread. */
    private val onCaption: (String?) -> Unit,
    private val onError: (String) -> Unit
) {
    // ---------- ڕووبەر و دۆخی گرتن (thread ی گرتنەوە) ----------
    @Volatile private var region = RectF()
    @Volatile private var screenW = 1
    @Volatile private var screenH = 1

    /** ڕووبەر و قەبارەی شاشەی ئێستا (دوای سووڕانەوەی شاشە دەگۆڕێت) بۆ شوێنی نووسینی وەرگێڕدراو */
    class Geom(val region: RectF, val w: Int, val h: Int)
    @Volatile var geom: Geom = Geom(RectF(), 1, 1)
        private set
    /** لەسەر main: شاشە سوڕایەوە و ڕووبەری نوێ دانرا */
    @Volatile var onGeomChanged: (() -> Unit)? = null
    /** ڕووبەری دیاریکراو بۆ هەر ئاراستەیەک (true = لاندسکەیپ)؛ تەنها لە thread ی گرتن */
    private val savedRegions = java.util.concurrent.ConcurrentHashMap<Boolean, RectF>()
    private var lang = "auto"
    data class Selection(val region: LiveGeometry.Box, val w: Int, val h: Int,
                         val orientations: Map<Boolean, LiveGeometry.Box> = emptyMap(),
                         val replayText: String = "", val sourceNorm: String = "", val sourceText: String = "")

    /** Preserve geometry and the last line, discarding the old backlog. */
    fun snapshotSelection(): Selection {
        val current = geom
        fun box(r: RectF) = LiveGeometry.Box(r.left, r.top, r.right, r.bottom)
        val regions = savedRegions.mapValues { box(it.value) }.toMutableMap()
        regions[current.w > current.h] = box(current.region)
        return Selection(box(current.region), current.w, current.h, regions.toMap(), resumeText, lastNorm, latestSourceText)
    }
    /** کلیلی Gemini بۆ ژێرنووسی زیندوو؛ ئەگەر بەکارهێنەر کوژاندبێتییەوە بەتاڵە (هەر ئێستا کاریگەرە، بێ دەستپێکردنەوە) */
    private val key: String get() = if (lang == "ar") settings.liveKey()
        else if (settings.translationProvider == TranslationProvider.GOOGLE) "" else settings.geminiTtsKey

    @Volatile private var running = false
    @Volatile private var ocrBusy = false
    @Volatile private var changedSince = 0L
    @Volatile private var lastOcrAt = 0L
    /** دوایین دێڕی خوێندراو کوردی بوو (وەرگێڕان پێویست نەبوو) ← OCR و دەنگ بە خێراتری */
    @Volatile private var kurdishMode = false
    private var prevSig: IntArray? = null
    private var ocrSig: IntArray? = null

    // واژۆی ڕووبەر بێ دروستکردنی bitmap: لە bitmap ێکی ٣٢×٣٢ ی دووبارەبەکارهاتوو دەکێشرێت (کەمکردنەوەی GC)
    private val sigBmp = Bitmap.createBitmap(SIG_N, SIG_N, Bitmap.Config.ARGB_8888)
    private val sigCanvas = Canvas(sigBmp)
    private val sigPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val sigPx = IntArray(SIG_N * SIG_N)
    private val sigDst = Rect(0, 0, SIG_N, SIG_N)
    private val cropRect = Rect()
    private var cropFw = -1
    private var cropFh = -1
    /** سەرەتای پرۆمپت: یەکجار لە start() دروست دەکرێت، نەک بۆ هەر دێڕێک */
    private var promptHead = ""

    // ---------- بەرهەمهێنان ----------
    private val seq = AtomicInteger(0)
    private val latestId = AtomicInteger(0)
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "live-sub").apply { isDaemon = true } }
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "live-sub-net").apply { isDaemon = true } }
    @Volatile private var lastNorm = ""                       // تەنها لە worker
    /** Separate bounded progress for source frames (worker) and cleaned speech (main). */
    private val sourceProgress = LiveSubtitleProgress()
    private val outputProgress = LiveSubtitleProgress()
    @Volatile private var latestSourceText = ""
    private val history = ArrayList<String>()       // دێڕە سەرچاوەکانی پێشوو (worker)
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 200
    }

    // ---------- دەنگ (تەنها main thread) ----------
    private val speechQ = SpeechQueue(MAX_MERGED_CHARS, MAX_BOOST)
    private var speaking = false
    private val speechAttempt = LiveSpeechAttempt()
    @Volatile private var sourceVisible = false

    // ---------- ئازادکردنی ڕیزبەند (تەنها main thread) ----------
    // وەرگێڕانەکان پارالێل دەڕۆن؛ ئەنجامەکان بە ڕیزی ژمارەی خۆیان (order) ئازاد دەکرێن، بۆ ئەوەی ڕستە ڕیزی خۆی نەشکێنێت.
    private var resumeText = ""
    private var lastCaption = ""
    private var captionVisible = false     // نووسینێک ئێستا پیشان دراوە (main)
    private val ready = HashMap<Int, String?>()
    private var nextRelease = 0
    private var nextOrder = 0          // تەنها لە worker

    fun start(regionPx: RectF, screenWidth: Int, screenHeight: Int,
              savedSelections: Map<Boolean, LiveGeometry.Box> = emptyMap(),
              replayText: String = "", sourceNorm: String = "", sourceText: String = "") {
        region = RectF(regionPx)
        screenW = screenWidth.coerceAtLeast(1)
        screenH = screenHeight.coerceAtLeast(1)
        lang = settings.sourceLang
        savedRegions.clear()
        for ((landscape, box) in savedSelections) {
            savedRegions[landscape] = RectF(box.left, box.top, box.right, box.bottom)
        }
        savedRegions[screenW > screenH] = RectF(region)
        geom = Geom(RectF(region), screenW, screenH)
        promptHead = buildPromptHead()
        try { tts.setLowLatency(true) } catch (_: Throwable) {}
        running = true
        lastNorm = sourceNorm
        latestSourceText = sourceText
        if (sourceText.isNotBlank()) sourceProgress.next(sourceText, SystemClock.elapsedRealtime())
        val replay = LiveTranslationFilter.clean(replayText)
        if (replay.isNotBlank()) {
            outputProgress.next(replay, SystemClock.elapsedRealtime())
            lastCaption = replay
            captionVisible = true
            sourceVisible = true
            onCaption(replay)
            enqueueSpeech(replay)
        }
        if (settings.liveFastGoogle) {
            GoogleTranslator.fast = true
            if (settings.translationProvider.warmGoogle(lang)) {
                try { pool.execute { GoogleTranslator.preconnect() } } catch (_: Throwable) {}
            }
        }
        main.postDelayed(watchdog, WATCHDOG_MS)
    }

    /**
     * پاسەوانی دەنگ: ئەگەر callback ی کۆتایی دەنگ ون بوو (speaking=true بەڵام TTS ڕاستەوخۆ بێدەنگە) یان ڕیز پڕە و کەس
     * نایخوێنێتەوە، دەستبەجێ (نەک دوای ١٠ چرکە) چاک دەکرێتەوە و ڕستەی دواتر دەخوێنرێت — پێشتر ڕستەی دووەم دواکەوت و لەگەڵ سێیەم تێکەڵ دەبوو.
     */
    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.elapsedRealtime()
            if (speaking && !tts.speaking) {
                if (desyncSince == 0L) desyncSince = now
                else if (now - desyncSince > DESYNC_MS) {
                    desyncSince = 0L
                    speaking = false
                    // Completion state can arrive before its callback. Never
                    // replay a possibly already spoken line based on timing.
                    speechAttempt.complete(speechAttempt.token)
                    try { tts.speedBoost = 1f } catch (_: Throwable) {}
                }
            } else desyncSince = 0L
            if (!speaking && !speechQ.isEmpty()) pumpSpeech()
            main.postDelayed(this, WATCHDOG_MS)
        }
    }
    private var desyncSince = 0L

    fun stop() {
        running = false
        main.removeCallbacks(watchdog)
        GoogleTranslator.fast = false
        settleRun?.let { main.removeCallbacks(it) }
        worker.shutdownNow()
        pool.shutdownNow()
        // پێشتر main.post بوو: ئەگەر یەکسەر ژێرنووسێکی نوێ دەستی پێکردبا، ئەم پاککردنەوەیە دواتر دەهات و دەنگ و
        // low-latency و ژێرنووسی نوێی دەکوشت (یان دوای tts.shutdown() ی onDestroy). ئێستا لەسەر main هاوکات جێبەجێ دەبێت.
        val cleanup = Runnable {
            speechAttempt.cancel()
            sourceVisible = false
            speaking = false
            speechQ.clear(); captionVisible = false
            ready.clear()
            try { tts.stop() } catch (_: Throwable) {}
            try { tts.speedBoost = 1f } catch (_: Throwable) {}
            try { tts.setLowLatency(false) } catch (_: Throwable) {}
            try { onCaption(null) } catch (_: Throwable) {}
        }
        if (android.os.Looper.myLooper() === android.os.Looper.getMainLooper()) cleanup.run() else main.post(cleanup)
    }

    // =====================================================================
    // 1) فرەیم → ڕووبەر → بڕیاری OCR
    // =====================================================================

    /** ڕێگای کۆن (AccessibilityCapturer): کۆپی دەدرێت؛ لێرە recycle دەکرێت. */
    fun onFrame(frame: Bitmap) {
        try { onRawFrame(frame, true) } finally { frame.recycle() }
    }

    /**
     * ڕێگای خێرا (ScreenCapturer.rawFrameListener): هیچ کۆپییەک نییە. `frame` هی گرتنەوەیە — recycle مەکە و مەیهێڵەوە.
     * تەنها واژۆی ٣٢×٣٢ ی ڕووبەرەکە حیساب دەکرێت؛ bitmap ی ڕووبەر تەنها کاتێک دروست دەبێت کە OCR بەڕاستی پێویست بێت.
     */
    @Volatile private var frameErrorShown = false

    fun onRawFrame(frame: Bitmap, isNew: Boolean) {
        try {
            onRawFrameInner(frame, isNew)
        } catch (t: Throwable) {
            Log.e(TAG, "onRawFrame failed", t)
            ocrBusy = false
            if (!frameErrorShown) {
                frameErrorShown = true
                main.post { if (running) onError("هەڵەی ژێرنووسی زیندوو: ${t.javaClass.simpleName} ${t.message ?: ""}".trim()) }
            }
        }
    }

    private fun onRawFrameInner(frame: Bitmap, isNew: Boolean) {
        if (!running) return
        val now = SystemClock.elapsedRealtime()
        // شاشە سوڕایەوە (یوتوب فوڵسکرین): ڕووبەری ئاراستەی نوێ بەکاربهێنە، نەک ڕووبەری پۆرترەیت
        val landscape = frame.width > frame.height
        if (landscape != (screenW > screenH)) adaptOrientation(landscape)

        // فرەیمی دووبارە (شاشە نەگۆڕاوە): ئەگەر هیچ گۆڕانکارییەک چاوەڕێ نییە هیچ مەکە (٠ کار)؛
        // ئەگەر چاوەڕێی ڕاوەستانە، فرەیمی دووبارە خۆی ڕاوەستانە ← واژۆی پێشوو بەکاربهێنە
        val prev = prevSig
        val sig: IntArray
        val settled: Boolean
        if (!isNew && prev != null) {
            if (changedSince == 0L) return
            sig = prev
            settled = true
        } else {
            sig = regionSig(frame)
            settled = prev != null && ChangeDetector.distance(sig, prev) < STABLE_THRESHOLD
            prevSig = sig
        }

        val base = ocrSig
        // هیچ گۆڕانکارییەک نییە لە دوایین OCR ← ژێرنووسەکە هەمان ماوەتەوە
        val changed = base == null || ChangeDetector.changedFraction(sig, base) >= CHANGED_FRACTION
        if (!changed) { changedSince = 0L; return }
        if (changedSince == 0L) changedSince = now

        // یەکەم OCR دوای دیاریکردنی ڕووبەر یەکسەر دەکرێت؛ دواتر: ڕاوەستاو (ژێرنووس تەواو دەرکەوتووە) یان باگراوندی جووڵاو
        // (ڤیدیۆ) ← بە زۆرەملێ OCR. دەقی کوردی چاوەڕێی کەمتر دەکات (OcrGate)
        if (!OcrGate.shouldRun(base == null, settled, now - changedSince, now - lastOcrAt, ocrBusy, kurdishMode, fastRefresh = lang != "ar")) return

        val crop = cropRegion(frame) ?: return
        ocrBusy = true
        ocrSig = sig
        lastOcrAt = now
        runOcr(crop)
    }

    /**
     * ڕووبەری ئاراستەی نوێ: ئەوەی پێشتر بۆی دیاری کراوە، یان بارێکی بنەڕەتی لە خوارەوەی ڤیدیۆ ([LiveGeometry.defaultBand]).
     * هەموو دۆخی OCR/ڕاوەستان دەست پێدەکاتەوە بۆ ئەوەی یەکەم OCR یەکسەر بێت ([OcrGate]).
     */
    private fun adaptOrientation(landscape: Boolean) {
        savedRegions[screenW > screenH] = RectF(region)
        val sz = LiveGeometry.screenFor(landscape, screenW, screenH)
        val saved = savedRegions[landscape]
        val r = saved ?: LiveGeometry.defaultBand(sz.w, sz.h).let { RectF(it.left, it.top, it.right, it.bottom) }
        savedRegions[landscape] = RectF(r)
        region = r
        screenW = sz.w
        screenH = sz.h
        cropFw = -1
        cropFh = -1
        prevSig = null
        ocrSig = null
        changedSince = 0L
        geom = Geom(RectF(r), sz.w, sz.h)
        Log.d(TAG, "orientation → ${if (landscape) "landscape" else "portrait"} ${sz.w}x${sz.h} saved=${saved != null}")
        main.post { if (running) onGeomChanged?.invoke() }
    }

    /** ڕووبەرەکە بە پیکسێلی فرەیم؛ تەنها کاتێک قەبارەی فرەیم بگۆڕێت دووبارە حیساب دەکرێت */
    private fun frameRegion(frame: Bitmap): Rect {
        val fw = frame.width
        val fh = frame.height
        if (fw != cropFw || fh != cropFh) {
            val kx = fw.toFloat() / screenW
            val ky = fh.toFloat() / screenH
            val l = (region.left * kx).toInt().coerceIn(0, fw - 2)
            val t = (region.top * ky).toInt().coerceIn(0, fh - 2)
            cropRect.set(l, t, (region.right * kx).toInt().coerceIn(l + 2, fw), (region.bottom * ky).toInt().coerceIn(t + 2, fh))
            cropFw = fw
            cropFh = fh
        }
        return cropRect
    }

    /** واژۆی ٣٢×٣٢ ی خۆڵەمێشی ی ڕووبەر، بێ bitmap ی نوێ */
    private fun regionSig(frame: Bitmap): IntArray {
        sigCanvas.drawBitmap(frame, frameRegion(frame), sigDst, sigPaint)
        sigBmp.getPixels(sigPx, 0, SIG_N, 0, 0, SIG_N, SIG_N)
        return IntArray(SIG_N * SIG_N) { i ->
            val c = sigPx[i]
            (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
        }
    }

    /** کۆپییەکی سەربەخۆی ڕووبەرەکە (بۆ OCR ی ناو thread ی تر)؛ تەنها کاتی پێویست */
    private fun cropRegion(frame: Bitmap): Bitmap? {
        return try {
            val r = frameRegion(frame)
            val c = Bitmap.createBitmap(frame, r.left, r.top, r.width(), r.height())
            if (c === frame) frame.copy(Bitmap.Config.ARGB_8888, false) else c
        } catch (_: Throwable) {
            null
        }
    }

    /** ڕووبەرەکە (بچووک کراوە بۆ ≤٢٠٠px) لێواری بەهێزی وەک-نووسینی تێدایە؟ لە شکستدا true (دوودڵی = بەردەوامبە). */
    private fun cropHasText(crop: Bitmap): Boolean {
        return try {
            val w = minOf(crop.width, GATE_W).coerceAtLeast(2)
            val h = (crop.height.toFloat() * w / crop.width.coerceAtLeast(1)).toInt().coerceAtLeast(2)
            val sm = if (w == crop.width && h == crop.height) crop else Bitmap.createScaledBitmap(crop, w, h, true)
            val sw = sm.width
            val sh = sm.height
            val px = IntArray(sw * sh)
            sm.getPixels(px, 0, sw, 0, 0, sw, sh)
            if (sm !== crop) sm.recycle()
            val gray = IntArray(px.size) { i ->
                val c = px[i]
                (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            }
            SubtitleGuard.hasTextLikeEdges(gray, sw, sh)
        } catch (_: Throwable) {
            true
        }
    }

    // =====================================================================
    // 2) OCR
    // =====================================================================

    // ---------- دەقی ڕاستەقینە لە Accessibility (بێ OCR) ----------
    private var accFails = 0                     // تەنها لە pool: چەند جار لە دووی یەک دەقی نەدۆزییەوە
    @Volatile private var accSkipUntil = 0L

    /** دەقی ناو ڕووبەر لە Accessibility؛ null = هیچ نییە (یاریی زۆرینە دەقی Accessibility نادەن) */
    private fun accessibilityText(): String? {
        val all = try { ScreenText.collect(ctx, screenW, screenH, lite = true) } catch (_: Throwable) { return null }
        if (all.isEmpty()) return null
        val rg = Rect(region.left.toInt(), region.top.toInt(), region.right.toInt(), region.bottom.toInt())
        val hit = all.filter { b ->
            val i = Rect()
            if (!i.setIntersect(b.rect, rg)) false
            else {
                val ia = i.width().toLong() * i.height()
                val ba = (b.rect.width().toLong() * b.rect.height()).coerceAtLeast(1)
                ia * 2 >= ba          // زۆرینەی نۆدەکە لەناو ڕووبەرەکەیە
            }
        }.filter { TextFilter.worthTranslating(it.text) || TextFilter.isLikelySorani(it.text) }
        if (hit.isEmpty()) return null
        val t = hit.sortedWith(compareBy({ it.rect.top }, { it.rect.left })).joinToString(" ") { it.text }.trim()
        return t.takeIf { it.length >= 2 }
    }

    private fun runOcr(crop: Bitmap) {
        val id = seq.incrementAndGet()
        val startedAt = SystemClock.elapsedRealtime()
        if (settings.liveAccText && startedAt >= accSkipUntil && MangaAccessibilityService.instance != null) {
            try {
                pool.execute {
                    val t = try { accessibilityText() } catch (_: Throwable) { null }
                    if (t != null) {
                        accFails = 0
                        crop.recycle()
                        ocrBusy = false
                        changedSince = 0L
                        if (running) submit(id, t, startedAt, alreadyKurdish = false)
                    } else {
                        // ٣ جار لە دووی یەک دەقی نەبوو (یاری) ← ١٠ چرکە Accessibility مەپرسە، OCR ی ئاسایی
                        if (++accFails >= 3) { accFails = 0; accSkipUntil = SystemClock.elapsedRealtime() + 10_000L }
                        if (running) runOcrReal(crop, id, startedAt)
                        else { crop.recycle(); ocrBusy = false }
                    }
                }
            } catch (_: Throwable) {   // دوای stop() ی pool
                crop.recycle()
                ocrBusy = false
            }
            return
        }
        runOcrReal(crop, id, startedAt)
    }

    private fun runOcrReal(crop: Bitmap, id: Int, startedAt: Long) {

        // ڕووبەری بێ هیچ لێوارێکی وەک-نووسین (تەخت/ڕەش/دیمەنی بێ دەق): نە OCR نە Gemini ← هیچ نووسینێکی لەحۆوە دروست نابێت
        if (!cropHasText(crop)) {
            crop.recycle()
            ocrBusy = false
            changedSince = 0L
            if (running) submit(id, "", startedAt, alreadyKurdish = false)
            return
        }

        // عەرەبی + کلیلی Gemini: OCR و وەرگێڕان بە یەک داواکاری (Tesseract ی عەرەبی زۆر هێواش و خراپە)
        if (lang == "ar" && key.isNotBlank()) {
            try { pool.execute {
                var text = ""
                try {
                    val items = RegionTranslator.run(crop, key, true).sortedBy { it.rect?.top ?: 0 }
                    val cw = crop.width
                    val chh = crop.height
                    val kept = wmFilter(items.map {
                        val r = it.rect
                        Blk(it.kurdish, r?.left ?: 0, r?.top ?: 0, r?.right ?: cw, r?.bottom ?: chh)
                    }, cw, chh)
                    val keptSet = kept.map { it.l to it.t }.toSet()
                    text = items.filter { ((it.rect?.left ?: 0) to (it.rect?.top ?: 0)) in keptSet }
                        .joinToString(" ") { it.kurdish }.trim()
                } catch (t: Throwable) {
                    Log.w(TAG, "Gemini vision failed: ${t.message}")
                } finally {
                    crop.recycle()
                    ocrBusy = false
                    changedSince = 0L
                }
                if (running) submit(id, text, startedAt, alreadyKurdish = true)
            } } catch (_: Throwable) {   // دوای stop() ی pool: داوا ڕەتدەکرێتەوە
                crop.recycle()
                ocrBusy = false
            }
            return
        }

        val cw = crop.width
        val chh = crop.height
        ocr.recognizeLiveBoxes(crop) { boxes ->
            crop.recycle()
            ocrBusy = false
            changedSince = 0L
            // واتەرمارک/نووسینی جێگیر (ناوی کەناڵ، X=SELECT...) لادەبرێت و ناچێتە وەرگێڕان
            val kept = wmFilter(boxes.map { Blk(it.text, it.rect.left, it.rect.top, it.rect.right, it.rect.bottom) }, cw, chh)
            val keptSet = kept.map { it.l to it.t }.toSet()
            val text = boxes.filter { (it.rect.left to it.rect.top) in keptSet }
                .sortedWith(compareBy({ it.rect.top }, { it.rect.left })).joinToString(" ") { it.text }.trim()
            if (running) submit(id, text, startedAt, alreadyKurdish = false)
        }
    }

    private val wm = WatermarkFilter()

    private fun wmFilter(blocks: List<Blk>, cw: Int, ch: Int): List<Blk> =
        synchronized(wm) { wm.filter(blocks, SystemClock.elapsedRealtime(), cw, ch) }

    private fun submit(id: Int, raw: String, startedAt: Long, alreadyKurdish: Boolean) {
        latestId.set(id)
        try {
            worker.execute {
                // stop() ی لە ناوەڕاستی وەرگێڕان: latch.await ← InterruptedException و pool.execute ← RejectedExecutionException
                // ئەگەر نەگیرابان دەبوونە uncaught exception ی thread ی live-sub و ئەپەکە داخرا
                try { handle(id, raw, startedAt, alreadyKurdish) }
                catch (_: InterruptedException) { Thread.currentThread().interrupt() }
                catch (t: Throwable) { Log.w(TAG, "handle after stop: ${t.message}") }
            }
        } catch (_: Throwable) {
        }
    }

    // =====================================================================
    // 3+4) دووبارەنەبوونەوە → وەرگێڕان
    // =====================================================================

    // ---------- ژێرنووسی وشە بە وشە (typewriter) ----------
    // لە هەندێک یاری ژێرنووس لەگەڵ دەنگ وشە بە وشە دەردەکەوێت. بێ ئەمە هەر وشەیەکی نیوەچڵ وەردەگێڕدرا و دەخوێنرایەوە.
    // ئێستا: ئەگەر دەقەکە گەشە بکات (دەقی پێشوو سەرەتای دەقی نوێیە)، چاوەڕێ دەکرێت تا جێگیر دەبێت، پاشان تەواوەکەی یەکجار.
    private val typingWindow = LiveTypingWindow(TYPING_MEMORY_MS)
    private var heldText: String? = null        // تەنها لە worker
    private var heldNorm = ""
    private val holdToken = AtomicInteger(0)
    private var settleRun: Runnable? = null

    private fun endsSentence(t: String): Boolean {
        val c = t.trimEnd().lastOrNull() ?: return false
        return c in ".!?…。！？”\"»؟"
    }

    /** دەقی ڕاگیراو بەپێی ڕیز بنێرە (worker) */
    private fun flushHeld() {
        val t = heldText ?: return
        heldText = null
        holdToken.incrementAndGet()
        settleRun?.let { main.removeCallbacks(it) }
        process(t, heldNorm)
    }

    private fun hold(text: String, norm: String) {
        heldText = text
        heldNorm = norm
        val tok = holdToken.incrementAndGet()
        settleRun?.let { main.removeCallbacks(it) }
        val r = Runnable {
            try {
                worker.execute {
                    try { if (tok == holdToken.get() && running) flushHeld() } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
        }
        settleRun = r
        main.postDelayed(r, if (endsSentence(text)) SETTLE_DONE_MS else SETTLE_MS)
    }

    private fun handle(id: Int, raw: String, startedAt: Long, alreadyKurdish: Boolean) {
        if (!running) return
        // ناوە نەخوێندراوەکان لە سەرەتای ڕستە لادەبرێن (نە وەردەگێڕدرێن، نە دەنووسرێن، نە دەخوێنرێنەوە)
        val text = NameFilter.strip(TextPrep.prepare(raw), skipNamesList(), settings.skipNamesStrict,
            everywhere = settings.skipNamesEverywhere, followedByMarker = settings.skipNamesMarkedOnly)
        // دەقی نادروست (خشت/هێما/پیتی دووبارە) وەک «دەق نەما» مامەڵەی لەگەڵ دەکرێت
        if (text.isBlank() || !SubtitleGuard.looksLikeRealText(text)) {
            sourceVisible = false
            flushHeld()      // Preserve a genuinely new pending line, not an audio retry.
            typingWindow.reset()
            sourceProgress.absent()
            // ژێرنووس نەما: بار دەشاردرێتەوە (بە ڕیزی ئازادکردن، دوای ئەو ڕستانەی پێشتر هاتوون) و هەمان دێڕ دووبارە دەبێتەوە
            if (lastNorm.isNotEmpty()) {
                lastNorm = ""
                deliver(nextOrder++, HIDE)
            }
            return
        }
        sourceVisible = true
        // کوردیی تەواو و بێ وشەی ئینگلیزی ← وەرناگێڕدرێت؛ ئەگەر وشەی ئینگلیزیشی تێدا بوو، وەردەگێڕدرێت
        val kurdishAlready = (alreadyKurdish || TextFilter.isLikelySorani(text)) && !TextFilter.hasEnglishWord(text)
        if (!kurdishAlready && !TextFilter.worthTranslating(text)) return   // ژمارە، هێما، S/M/L...

        val norm = norm(text)
        if (norm.length < 2) return
        kurdishMode = kurdishAlready

        if (settings.liveWaitTyping && !kurdishAlready) {
            val now = SystemClock.elapsedRealtime()
            val decision = typingWindow.observe(norm, now, ::similar)
            val growing = decision.growing
            val typing = decision.wait
            val held = heldText
            if (growing) { hold(text, norm); return }
            if (held != null && similar(norm, heldNorm)) return    // هەمان دەقی ڕاگیراو (OCR ی کەمێک جیاواز): کاتەکە درێژ مەکەرەوە
            if (held != null) flushHeld()                           // دێڕێکی تر هات: ئەوەی پێشوو تەواو بوو
            if (typing) { hold(text, norm); return }                // دۆخی وشە بە وشە: چاوەڕێ بکە تا جێگیر دەبێت
        } else {
            typingWindow.reset()
        }
        process(text, norm)
    }

    private fun process(textIn: String, normIn: String) {
        val provider = settings.translationProvider
        // Snapshot credentials independently of a concurrent UI mode change.
        val requestKeys = if (lang == "ar") settings.liveKey() else settings.geminiTtsKey
        val cacheScope = if (lang == "ar") "arabic-legacy" else provider.id
        fun ck(value: String) = "$lang|$cacheScope|$value"
        lastNorm = normIn
        latestSourceText = textIn
        val progress = sourceProgress.next(textIn, SystemClock.elapsedRealtime())
        if (progress.repeated) {
            val again = if (TextFilter.isLikelySorani(textIn) && !TextFilter.hasEnglishWord(textIn)) textIn
                else synchronized(cache) { cache[ck(normIn)] }
            if (again != null) deliver(nextOrder++, QUIET + again)
            return
        }
        val text = progress.text
        val norm = norm(text)
        val cont = progress.continuation
        val kurdishAlready = TextFilter.isLikelySorani(text) && !TextFilter.hasEnglishWord(text)

        // هەر ڕستەیەکی جیاواز ژمارەیەکی ڕیزبەندی وەردەگرێت؛ هیچ ڕستەیەک نافڕێدرێت (پێشتر «زۆر کۆنە» دەفڕێدرا)
        val order = nextOrder++
        if (kurdishAlready) {
            deliver(order, if (cont) CONT + text else FAST + text)      // کوردی: یەکسەر، بێ چاوەڕێی ڕستەی دواتر
            return
        }
        val prev = ArrayList(history)
        history.add(text)
        while (history.size > 3) history.removeAt(0)

        // دەنگی زوو: ڕستەی درێژ دەکرێتە چەند ڕستە، هەر یەک بە پارالێل وەردەگێڕدرێت و بە ڕیز ئازاد دەکرێت؛
        // یەکەم ڕستە هەر کە ئامادە بوو دەنگی دەست پێدەکات
        val parts = if (settings.liveEarlySpeak) splitSentences(text) else emptyList()
        if (parts.size >= 2) {
            val orders = IntArray(parts.size) { if (it == 0) order else nextOrder++ }
            val results = arrayOfNulls<String>(parts.size)
            val remaining = AtomicInteger(parts.size)
            for ((k, part) in parts.withIndex()) {
                val pn = norm(part)
                pool.execute {
                    var o: String? = null
                    var failure: String? = null
                    try {
                        o = synchronized(cache) { cache[ck(pn)] }
                            ?: translateHedged(part, prev, provider, requestKeys)?.also { synchronized(cache) { cache[ck(pn)] = it } }
                    } catch (t: Throwable) {
                        failure = t.message
                        Log.w(TAG, "translate part: ${t.message}")
                    }
                    val ok = o != null && SubtitleGuard.plausibleTranslation(part, o)
                    results[k] = if (ok) o else null
                    if (o == null) main.post { if (running && k == 0) onError(if (lang == "ar") "وەرگێڕان سەرنەکەوت (ئینتەرنێت؟)" else failure ?: "وەرگێڕان سەرنەکەوت") }
                    deliver(orders[k], if (ok) (if (k == 0 && !cont) o else CONT + o) else null)
                    if (remaining.decrementAndGet() == 0) {
                        // Never cache a partial translation under the full line.
                        if (results.all { !it.isNullOrBlank() }) {
                            val all = results.joinToString(" ") { it!! }
                            synchronized(cache) { cache[ck(norm)] = all }
                        }
                    }
                }
            }
            return
        }

        // وەرگێڕان بە پارالێل: ڕستەی دواتر چاوەڕێی وەرگێڕانی ئەمە ناکات (خێرایی)، ڕیزبەندی بە deliver دەپارێزرێت
        pool.execute {
            var out: String? = null
            var failure: String? = null
            try {
                out = synchronized(cache) { cache[ck(norm)] }
                    ?: translateHedged(text, prev, provider, requestKeys)?.also { synchronized(cache) { cache[ck(norm)] = it } }
            } catch (t: Throwable) {
                failure = t.message
                Log.w(TAG, "translate: ${t.message}")
            }
            val o = out
            when {
                o == null -> {
                    main.post { if (running) onError(if (lang == "ar") "وەرگێڕان سەرنەکەوت (ئینتەرنێت؟)" else failure ?: "وەرگێڕان سەرنەکەوت") }
                    deliver(order, null)
                }
                // نەگونجاو بەپێی سەرچاوە (<NONE>، «no text»، درێژیی زۆر) ← بێدەنگ، تەنها شوێنی ڕیزبەندی ئازاد دەکرێت
                !SubtitleGuard.plausibleTranslation(text, o) -> {
                    Log.d(TAG, "implausible translation dropped")
                    deliver(order, null)
                }
                else -> deliver(order, if (cont) CONT + o else o)
            }
        }
    }

    /** ئەنجامی ڕستەی [order] (null = هیچ؛ HIDE = شاردنەوەی نووسین) بە ڕیز ئازاد دەکات: نووسین + دەنگ. */
    private fun deliver(order: Int, value: String?) {
        main.post {
            if (!running) return@post
            ready[order] = value
            while (ready.containsKey(nextRelease)) {
                val v = ready.remove(nextRelease)
                nextRelease++
                if (v == null) continue
                if (v == HIDE) {
                    captionVisible = false
                    try { onCaption(null) } catch (_: Throwable) {}
                    continue
                }
                val quiet = v.startsWith(QUIET)
                val continuation = v.startsWith(CONT)
                val marked = quiet || continuation || v.startsWith(FAST)
                val clean = LiveTranslationFilter.clean(if (marked) v.substring(1) else v)
                if (clean.isBlank()) {
                    // A new line with no surviving text must not leave an old
                    // caption on screen, or block subsequent ordered results.
                    if (!continuation && !quiet) {
                        captionVisible = false
                        try { onCaption(null) } catch (_: Throwable) {}
                    }
                    continue
                }
                if (quiet) {
                    if (captionVisible && lastCaption == clean) continue
                    lastCaption = clean
                    captionVisible = true
                    try { onCaption(clean) } catch (_: Throwable) {}
                    continue
                }
                val progress = outputProgress.next(clean, SystemClock.elapsedRealtime(), allowOverlap = continuation)
                if (progress.repeated) {
                    if (!captionVisible) {
                        lastCaption = clean
                        captionVisible = true
                        try { onCaption(clean) } catch (_: Throwable) {}
                    }
                    continue
                }
                val spoken = progress.text
                lastCaption = if (continuation && captionVisible) "$lastCaption $spoken".trim() else spoken
                captionVisible = true
                try { onCaption(lastCaption) } catch (_: Throwable) {}
                enqueueSpeech(spoken)
            }
        }
    }

    /** Gemini (٣ دێڕی پێشوو وەک چوارچێوە) + Google ی دواخراو (٧٠٠ms) ← یەکەم وەڵامی بێگەرد دەبات. */
    private fun translateHedged(
        text: String, prev: List<String>, provider: TranslationProvider, requestKeys: String
    ): String? {
        if (lang != "ar") {
            return TranslationRouter.shared.run(provider, requestKeys,
                gemini = { geminiLine(text, prev, requestKeys, quotaSensitive = true) },
                google = { TextPrep.fixSorani(GoogleTranslator.translateBubble(text, lang).orEmpty()).takeIf { it.isNotBlank() } })
        }
        // Arabic alone retains the original hedged behavior and existing settings.
        val winner = AtomicReference<String?>(null)
        val latch = CountDownLatch(1)
        fun offer(v: String?) {
            if (!v.isNullOrBlank() && winner.compareAndSet(null, v)) latch.countDown()
        }
        val hasKey = requestKeys.isNotBlank()
        if (hasKey) {
            pool.execute { try { offer(geminiLine(text, prev, requestKeys)) } catch (t: Throwable) { Log.w(TAG, "gemini: ${t.message}") } }
        }
        pool.execute {
            try {
                if (hasKey) {
                    // Gemini ی خێرا ئەگەر لە HEDGE_MS دا وەڵامی دایەوە، Google پێویست نییە
                    if (latch.await(HEDGE_MS, TimeUnit.MILLISECONDS)) return@execute
                }
                offer(TextPrep.fixSorani(GoogleTranslator.translateBubble(text, lang) ?: ""))
            } catch (t: Throwable) {
                Log.w(TAG, "google: ${t.message}")
            }
        }
        latch.await(if (settings.liveFastGoogle) FAST_TIMEOUT_MS else TIMEOUT_MS, TimeUnit.MILLISECONDS)
        return winner.get()
    }

    private fun langName(code: String) = when (code) {
        "en" -> "English"; "ar" -> "Arabic"; "ja" -> "Japanese"; "zh" -> "Chinese"; "ko" -> "Korean"; "hi" -> "Hindi"
        else -> "auto-detect"
    }

    private fun buildPromptHead(): String =
        "Translate ONE video/game subtitle line (" + langName(lang) + ") into natural SPOKEN Central Kurdish (Sorani, Arabic script). " +
            "Translate the meaning of the whole line, never word by word; keep the tone; keep it short enough to speak in the original's time; " +
            "use Sorani letters (ی ک ە ێ ۆ ڵ ڕ ڤ); names transliterated; numbers unchanged; silently fix small OCR mistakes. " +
            "Translate ONLY the given line: never invent, complete or continue text, never repeat the previous lines, never explain. " +
            "If the line is not real readable subtitle text (random characters, symbols, interface noise), output exactly " + SubtitleGuard.NONE + ". " +
            "Output ONLY the Kurdish.\n"

    private fun geminiLine(text: String, prev: List<String>, keysRaw: String, quotaSensitive: Boolean = false): String? {
        val sb = StringBuilder(promptHead)
        if (prev.isNotEmpty()) {
            sb.append("Previous lines (context only, do NOT translate):\n")
            for (p in prev) sb.append("- ").append(p).append('\n')
        }
        val hints = try { AmbiguityGlossary.hintsFor(ctx, listOf(text), 5, 360) } catch (_: Throwable) { "" }
        if (hints.isNotBlank()) {
            sb.append("Hints for ambiguous words (use a hint only if its meaning fits this sentence):\n").append(hints).append('\n')
        }
        sb.append("Subtitle line:\n").append(text)
        val prompt = sb.toString()

        fun body(model: String, think: Boolean): String {
            val gen = JSONObject().put("temperature", 0.2).put("maxOutputTokens", 256)
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            return JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", gen)
                .toString()
        }

        val out = GeminiKeys.withKeys(keysRaw) { k ->
            GeminiModels.call(true, quotaSensitive = quotaSensitive) { m, think -> post(body(m, think), k, m) }
        }
        val t = TextPrep.fixSorani(out).trim().trim('"', '«', '»')
        if (t.contains(SubtitleGuard.NONE, ignoreCase = true)) return SubtitleGuard.NONE   // یەکلاکەرەوەیە: Google چاوەڕێ نەکرێت
        return t.takeIf { it.isNotBlank() }
    }

    private fun post(body: String, apiKey: String, model: String): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        var ok = false
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 3_000
            c.readTimeout = 6_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try { JSONObject(resp).getJSONObject("error").getString("message") } catch (_: Exception) { resp }
                throw ApiException(code, "Gemini $code ${why.take(120)}".trim())
            }
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").optJSONArray("parts") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            ok = true
            return sb.toString()
        } finally {
            // دوای وەڵامی تەواو disconnect ناکەین: پەیوەندی TLS دەمێنێتەوە بۆ دێڕی دواتر (≈١٠٠-٣٠٠ms کەمتر)
            if (!ok) c.disconnect()
        }
    }

    // =====================================================================
    // 5) دەنگ: ڕیزبەندی بەبێ دووبارەکردنەوەی خوێندنەوەی تەواوبوو
    // =====================================================================

    private var namesRaw = ""
    private var namesParsed: List<String> = emptyList()
    private fun skipNamesList(): List<String> {
        val raw = settings.skipNames
        if (raw != namesRaw) { namesRaw = raw; namesParsed = NameFilter.parse(raw) }
        return namesParsed
    }

    private fun enqueueSpeech(t: String) {
        // دەقی زۆر کورت: tts.speak() هیچ callback ێک نادات و دەنگ قفڵ دەبوو
        if (t.trim().length < 2) return
        // نیشانەی کۆتایی: هەموو ڕستەیەک خاڵی هەبێت، بۆ ئەوەی prefetch و خوێندنەوەی ڕاستەقینە هەمان cache key بەکاربهێنن
        resumeText = t.trim()
        val s = SpeechMerge.ensureEnd(resumeText)
        speechQ.add(s)
        // Prefetch the actual next batch, including single-word lines. Its
        // text and boost must match take(), otherwise Piper misses the cache.
        if (speaking) speechQ.peek()?.let { batch ->
            try { tts.prefetch(batch.text, batch.boost) } catch (_: Throwable) {}
        }
        pumpSpeech()
    }

    /** ئەگەر دەنگ بەتاڵە، ڕستە(کان)ی دواتر لە ڕیزدا دەخوێنێتەوە. هەرگیز ڕستەی ئێستا ناپچڕێنێت. */
    private fun pumpSpeech() {
        if (speaking || !running) return
        val batch = speechQ.take() ?: return
        speaking = true
        val token = speechAttempt.begin(batch.text)
        try { tts.speedBoost = batch.boost } catch (_: Throwable) {}
        // پاسەوانی تەنها بۆ کاتی نەهاتنی callback ی کۆتایی (دەنگ قفڵ نەبێت): ماوەیەکی دڵنیا درێژ، بەپێی درێژی دەق
        val speed = (settings.speechSpeed * batch.boost).coerceAtLeast(0.5f)
        val guardMs = (batch.text.length * 90L / speed + SPEAK_SLACK_MS).toLong().coerceIn(SPEAK_SLACK_MS, MAX_SPEAK_MS)
        main.postDelayed({
            if (speaking && speechAttempt.complete(token)) {
                speaking = false
                try { tts.stop() } catch (_: Throwable) {}
                pumpSpeech()
            }
        }, guardMs)
        tts.speak(
            listOf(batch.text),
            onState = { on ->
                if (!on) main.post {
                    if (speechAttempt.complete(token)) {
                        speaking = false
                        // A successful finish is authoritative even for a short
                        // word; elapsed time is not proof of silent playback.
                        if (speechQ.isEmpty()) { try { tts.speedBoost = 1f } catch (_: Throwable) {} }
                        pumpSpeech()
                    }
                }
            },
            onError = { msg ->
                val retryAllowed = tts.canRetryLastFailure
                main.post {
                    val failure = speechAttempt.fail(token, sourceVisible, retryAllowed)
                    if (failure != null) {
                        speaking = false
                        failure.retryText?.let { speechQ.addFirst(it) }
                        if (running) onError(msg)
                        pumpSpeech()
                    }
                }
            }
        )
    }

    // =====================================================================
    // یارمەتیدەرەکان
    // =====================================================================

    /**
     * Split at complete sentences or natural clauses for earlier first audio.
     * Keep complete short sentences and every word; at most four requests.
     */
    private fun splitSentences(t: String): List<String> {
        return LiveSpeechParts.split(t)
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** OCR ی هەمان ژێرنووس کەمێک جیاوازە (پیتێک ون یان هەڵە) ← وەک هەمان دێڕ ئەژمار بکە */
    private fun similar(a: String, b: String): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        if (a == b) return true
        val m = maxOf(a.length, b.length)
        if (m > 512) return false // Bound edit-distance work; full exact/growth checks remain linear.
        if (abs(a.length - b.length) > m / 4) return false
        // ڕستەی کورت (٤-٥ وشە ≈ ١٢-٣٩ پیت): ٠.١٨ زۆر شل بوو و ڕستەی جیاواز («he is» / «she is»، «can» / «can't») وەک دووبارە
        // دەژمێردرا و بێدەنگ دەفڕێدرا. OCR ی ژێرنووسی کورت زۆرجار هەر ١-٢ پیت هەڵەیە، بۆیە لێرە تەنگتر.
        val allowed = when {
            m < 12 -> 0
            m < 40 -> (m * 0.08f).toInt().coerceAtLeast(1)
            else -> (m * 0.18f).toInt()
        }
        return lev(a, b) <= allowed
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    companion object {
        private const val TAG = "LiveSubtitle"
        private const val SIG_N = 32
        /** پانیی وێنەی پشکنینی «نووسینی تێدایە؟» */
        private const val GATE_W = 200
        /** ڕێژەی خانە گۆڕاوەکانی واژۆ کە بە «ڕووبەر گۆڕا» دەژمێردرێت */
        private const val CHANGED_FRACTION = 0.03f
        private const val STABLE_THRESHOLD = 4f
        /** ژێرنووسی وشە بە وشە: چەند چاوەڕێ بکرێت دوای دوایین گەشە (بێ خاڵ / بە خاڵ)، و تا کەی دۆخەکە بیر بێت */
        private const val SETTLE_MS = 650L
        private const val SETTLE_DONE_MS = 250L
        private const val TYPING_MEMORY_MS = 6_000L
        private const val HEDGE_MS = 700L
        private const val TIMEOUT_MS = 3500L
        private const val FAST_TIMEOUT_MS = 2500L
        /** زۆرترین پیت لە یەک خوێندنەوەدا کاتێک چەند ڕستە کۆ بوونەوە (بە هەمان ڕیز پێکەوە دەنێردرێن) */
        private const val MAX_MERGED_CHARS = 300
        /** زۆرترین خێراکردنی کاتی بۆ گەیشتن بە ڕیز (لەسەر خێرایی بەکارهێنەر زیاد دەکرێت) */
        private const val MAX_BOOST = 1.3f
        /** پاسەوانی دەنگ (تەنها ئەگەر callback ی کۆتایی نەهات): کەمترین و زۆرترین ماوە */
        private const val SPEAK_SLACK_MS = 10_000L
        private const val MAX_SPEAK_MS = 60_000L
        /** نیشانەی «نووسین بشارەوە» لە ڕیزی ئازادکردندا */
        private const val HIDE = "\u0000HIDE"
        /** پێشگری ڕستەی کوردیی ڕاستەوخۆ (بێ وەرگێڕان): یەکسەر دەخوێنرێتەوە، تەنانەت ئەگەر کورت بێت */
        private const val FAST = "\u0003"
        /** پێشگری «تەنها نووسین پیشان بدە، مەیخوێنەوە» (ڕستەی دووبارە) */
        private const val QUIET = "\u0001"
        /** نیشانەی بەشی دووەم و دواتر لە ڕستەی دابەشکراو */
        private const val CONT = "\u0002"
        private const val WATCHDOG_MS = 300L
        /** Recover a missing callback without replaying audio that may have finished. */
        private const val DESYNC_MS = 700L
    }
}
