package com.mangatranslator.app

/** Local word-level cleanup and geometric fusion; no dictionary guesses for Latin names. */
internal object MixedOcrFilter {
    data class Word(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int,
                    val confidence: Float, val latin: Boolean = false) {
        val height get() = (bottom - top).coerceAtLeast(1)
    }
    private val marks = Regex("[\\u200e\\u200f\\u202a-\\u202e\\u2066-\\u2069]")
    private val latinToken = Regex("(?=.*\\p{IsLatin})[\\p{IsLatin}\\p{N}][\\p{IsLatin}\\p{M}\\p{N}._+#’'/-]*")
    private val numberToken = Regex("[0-9]+(?:[,.][0-9]+)*")
    private fun digits(text: String) = text.filter(Char::isDigit).map { Character.digit(it, 10) }.joinToString("")
    private val beforePunctuation = Regex("\\s+([،؛؟!.,:])")
    private fun cleaned(word: Word): Word {
        val text = word.text.replace(marks, "").trim()
        return if (text == word.text) word else word.copy(text = text)
    }
    private fun valid(word: Word) = word.right > word.left && word.bottom > word.top &&
        word.confidence.isFinite() && (word.confidence >= 0 || word.latin && word.confidence == -1f) && word.text.isNotBlank()
    private fun repeatedNoise(text: String): Boolean {
        var first = '\u0000'
        var count = 0
        for (c in text) if (c.isLetter()) {
            if (count == 0) first = c else if (c != first) return false
            count++
        }
        return count >= 4
    }
    private fun numericPrefix(native: Word, latin: Word): Boolean {
        if (!native.text.all(Char::isDigit)) return false
        val a = native.text.map { Character.digit(it, 10) }.joinToString("")
        val b = latin.text.filter(Char::isDigit).map { Character.digit(it, 10) }.joinToString("")
        return a.isNotEmpty() && a == b
    }
    private fun rows(words: List<Word>): List<List<Word>> {
        val lines = ArrayList<MutableList<Word>>()
        for (word in words.sortedWith(compareBy({ it.top }, { it.left }))) {
            val line = lines.lastOrNull { row ->
                val reference = row.first()
                val overlap = minOf(reference.bottom, word.bottom) - maxOf(reference.top, word.top)
                overlap * 2 >= minOf(reference.height, word.height)
            }
            if (line == null) lines.add(arrayListOf(word)) else line.add(word)
        }
        return lines.sortedBy { row -> row.minOf { it.top } }
    }
    fun nativeWords(raw: List<Word>): List<Word> {
        val words = raw.map(::cleaned).filter { valid(it) && !repeatedNoise(it.text) }
        return rows(words).flatMap { row ->
            val anchored = row.any { it.confidence >= 45 && it.text.count(Char::isLetter) >= 2 }
            val letters = row.filter { it.text.any(Char::isLetter) }
            val digits = row.count { it.text.any(Char::isDigit) && !it.text.any(Char::isLetter) }
            // Latin artwork read by a ckb-only model often becomes many numbers
            // around one weak two-letter guess. Do not let that guess anchor noise.
            val numericNoise = digits >= 2 && digits >= letters.size && letters.none { it.confidence >= 70 || it.confidence >= 45 && it.text.count(Char::isLetter) >= 3 }
            if (!anchored || numericNoise) emptyList() else row.filter { word ->
                when {
                    word.text.any(Char::isLetter) -> word.confidence >= 25
                    word.text.any(Char::isDigit) -> word.confidence >= 40
                    else -> word.confidence >= 35 && word.text.all { it in "،؛؟!.,:()«»" } &&
                        when (word.text) {
                            ")" -> row.any { it.text.contains('(') }
                            "(" -> row.any { it.text.contains(')') }
                            else -> true
                        }
                }
            }
        }
    }
    private fun overlap(a: Word, b: Word): Boolean {
        val width = (minOf(a.right, b.right) - maxOf(a.left, b.left)).coerceAtLeast(0)
        val height = (minOf(a.bottom, b.bottom) - maxOf(a.top, b.top)).coerceAtLeast(0)
        val area = minOf((a.right - a.left).toLong() * a.height, (b.right - b.left).toLong() * b.height)
        return width.toLong() * height * 100 >= area * 40
    }
    fun merge(native: List<Word>, english: List<Word>): List<Word> {
        val out = nativeWords(native).toMutableList()
        val candidates = english.map(::cleaned).filter { valid(it) && (it.confidence >= 60 || it.confidence == -1f) &&
            (latinToken.matches(it.text) || numberToken.matches(it.text) && (it.confidence >= 85 || it.confidence == -1f)) && !repeatedNoise(it.text) }
        for (latin in candidates.sortedByDescending { it.confidence }) {
            val collisions = out.filter { overlap(it, latin) }
            if (collisions.any { it.latin }) continue // Duplicate detector boxes.
            // Confidence scores from two recognizers are not calibrated equally.
            // Require strong Latin evidence before replacing an actual Kurdish word.
            if (latin.confidence < 90 && collisions.any { it.text.count(Char::isLetter) >= 2 }) continue
            val numeric = numberToken.matches(latin.text)
            // A number detector must never turn a Kurdish letter (e.g. و) into 9.
            if (numeric && collisions.any { it.text.any(Char::isLetter) }) continue
            // Tesseract can split a large 18 into separate 8 / 1 boxes in RTL order.
            // Confirm the entire sequence geometrically, rather than dropping its 1.
            val sameNumber = numeric && collisions.isNotEmpty() &&
                collisions.all { it.text.all(Char::isDigit) } &&
                collisions.sortedBy { it.left }.joinToString("") { digits(it.text) } == digits(latin.text)
            // Do not replace a confident Kurdish reading with Latin-shaped
            // hallucinations. A clearly stronger Latin reading can repair a
            // ckb-only model's guess over a genuine English product name.
            if (!sameNumber && collisions.any { !numericPrefix(it, latin) && (latin.confidence < 0 || it.confidence + 15 > latin.confidence) }) continue
            out.removeAll { overlap(it, latin) }
            out.add(latin.copy(latin = true))
        }
        return out
    }
    fun text(words: List<Word>): String = rows(words).joinToString("\n") { row ->
        // A wholly Latin row (names, logos) reads left-to-right even across gaps.
        val rtl = if (row.all { it.latin }) row.sortedBy { it.left } else row.sortedByDescending { it.right }
        if (row.all { it.latin }) return@joinToString rtl.joinToString(" ") { it.text }.replace(beforePunctuation, "$1")
        val ordered = ArrayList<Word>()
        var i = 0
        while (i < rtl.size) {
            if (!rtl[i].latin && !rtl[i].text.all(Char::isDigit)) { ordered.add(rtl[i++]); continue }
            val start = i++
            while (i < rtl.size && (rtl[i].latin || rtl[i].text.all(Char::isDigit)) && rtl[i - 1].left - rtl[i].right <= maxOf(rtl[i - 1].height, rtl[i].height) * 2) i++
            ordered.addAll(rtl.subList(start, i).sortedBy { it.left })
        }
        ordered.joinToString(" ") { it.text }.replace(beforePunctuation, "$1")
    }.trim()
}
