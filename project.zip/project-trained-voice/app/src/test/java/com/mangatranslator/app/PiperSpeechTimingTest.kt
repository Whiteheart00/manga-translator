package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.*

class PiperSpeechTimingTest {
    @Test fun userParagraphRetainsEveryWordWithinModelLimits() {
        val text=checkNotNull(javaClass.getResourceAsStream("/latency-example.txt"))
            .bufferedReader().use { it.readText() }
        val chunks=PiperSpeechTiming.chunks(text)
        assertTrue(chunks.isNotEmpty())
        assertTrue(chunks.first().length<=PiperSpeechTiming.FIRST_LIMIT)
        assertTrue(chunks.all { it.length<=PiperSpeechTiming.STEADY_LIMIT })
        assertEquals(text.trim().replace(Regex("\\s+")," "),chunks.joinToString(" "))
        assertTrue(chunks.none { it.isBlank() })
    }
    @Test fun firstPhraseIsShortButFollowingPhrasesDoNotBreakEveryEightyCharacters() {
        val text=List(60) { "هاوڕێ" }.joinToString(" ")
        val chunks=PiperSpeechTiming.chunks(text)
        assertTrue(chunks.first().length<=64)
        assertTrue(chunks.drop(1).any { it.length>100 })
        assertEquals(text,chunks.joinToString(" "))
    }
    @Test fun commasDoNotCauseRepeatedTinyChunks() {
        val text="هاوڕێ، "+List(28) { "باشە،" }.joinToString(" ")
        val chunks=PiperSpeechTiming.chunks(text)
        assertTrue(chunks.first().length>=28)
        assertTrue(chunks.drop(1).dropLast(1).all { it.length>=80 })
    }
    @Test fun pausesFollowSentenceBoundariesRatherThanLength() {
        assertEquals(25,PiperSpeechTiming.pauseMs("ئەو کارە",false))
        assertEquals(110,PiperSpeechTiming.pauseMs("ئەو کارە؟",false))
        assertEquals(10,PiperSpeechTiming.pauseMs("ئەو کارە",true))
        assertEquals(40,PiperSpeechTiming.pauseMs("ئەو کارە.",true))
    }
    @Test fun edgeTrimmingKeepsInternalPauseAndQuietConsonants() {
        val rate=16000
        val speech=FloatArray(rate) { i -> if(i in 6400..8000) 0f else (.1*sin(2*PI*200*i/rate)).toFloat() }
        // Quiet onset and offset are above the RMS activity threshold.
        for(i in 0 until 800) { speech[i]*=.03f;speech[speech.lastIndex-i]*=.03f }
        val input=FloatArray(4000)+speech+FloatArray(8000)
        val output=PiperSpeechTiming.trimEdges(input,rate)
        assertTrue(output.size<input.size)
        assertTrue(output.size>=speech.size)
        val offset=output.indexOfFirst { abs(it)>1e-5f }
        assertTrue(offset>=0)
        // A complete copy of the original speech, including the pause, must remain.
        val start=output.size-speech.size-640
        assertTrue(start>=0)
        assertArrayEquals(speech,output.copyOfRange(start,start+speech.size),0f)
    }
    @Test fun emptyOrSilentInputDoesNotBecomeAnInvalidBuffer() {
        assertEquals(0,PiperSpeechTiming.trimEdges(floatArrayOf(),16000).size)
        assertArrayEquals(FloatArray(800),PiperSpeechTiming.trimEdges(FloatArray(800),16000),0f)
        assertTrue(PiperSpeechTiming.chunks(" \n ").isEmpty())
    }
}
