plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mangatranslator.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mangatranslator.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 13
        versionName = "1.1.0"

        // تەنها مۆبایلی ٦٤ بیت: APK بچووکتر دەبێت
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    // ناوی APK ـەکە
    applicationVariants.all {
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName = "وەڕگێڕی_شاشە.apk"
        }
    }

    // واژۆی جێگیر: هەموو وەشانەکان بە یەک keystore واژۆ دەکرێن، بۆیە update بێ سڕینەوە کار دەکات
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // مۆدێلە ONNX ـەکان لە APK دا فشار نادرێن (خێراتر)
    androidResources {
        noCompress += listOf("onnx")
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")

    // دەنگی نیورالی Piper/VITS (ONNX) بە onnxruntime
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")

    // OCR ئۆفلاین بۆ پیتی لاتین (ئینگلیزی)
    implementation("com.google.mlkit:text-recognition:16.0.0")

    // ناسینەوەی خێرای کوردیی سۆرانی لەسەر مۆبایل (Tesseract، زمانی ckb)
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.7.0")
}
