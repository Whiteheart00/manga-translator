plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mangatranslator.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mangatranslator.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")

    // OCR ئۆفلاین بۆ پیتی لاتین (ئینگلیزی). مۆدێلەکە لەناو ئەپەکەدایە.
    implementation("com.google.mlkit:text-recognition:16.0.0")
}
