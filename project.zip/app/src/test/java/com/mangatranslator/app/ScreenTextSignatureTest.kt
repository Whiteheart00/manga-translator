package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class ScreenTextSignatureTest {

    private val page = listOf(
        "This is the first long caption of the page",
        "And here is another sentence on the screen",
        "A third block makes the text trustworthy"
    )

    @Test fun fewBlocksAreNotTrusted() {
        assertEquals(0, ScreenText.signatureOf(emptyList()))
        assertEquals(0, ScreenText.signatureOf(page.take(2)))
    }

    @Test fun tooFewLettersAreNotTrusted() {
        assertEquals(0, ScreenText.signatureOf(listOf("Chapter 5", "1/20", "Menu")))
    }

    @Test fun sameTextGivesSameNonZeroSignature() {
        val a = ScreenText.signatureOf(page)
        assertNotEquals(0, a)
        assertEquals(a, ScreenText.signatureOf(page.toList()))
    }

    @Test fun changedTextChangesSignature() {
        val changed = page.toMutableList().also { it[2] = "A different third block appears here now" }
        assertNotEquals(ScreenText.signatureOf(page), ScreenText.signatureOf(changed))
    }

    @Test fun addedBlockChangesSignature() {
        assertNotEquals(ScreenText.signatureOf(page), ScreenText.signatureOf(page + "One more new message arrived"))
    }
}
