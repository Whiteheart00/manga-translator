package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechBacklogTest {

    @Test fun singleLineIsSpokenAsIsAtNormalSpeed() {
        val b = SpeechBacklog()
        b.add("سڵاو چۆنی", 0)
        val r = b.take(100)!!
        assertEquals("سڵاو چۆنی", r.text)
        assertEquals(1, r.count)
        assertEquals(1f, r.boost, 0.001f)
        assertTrue(b.isEmpty())
    }

    @Test fun waitingLinesAreMergedInOrderNotDropped() {
        val b = SpeechBacklog()
        b.add("یەکەم.", 0)
        b.add("دووەم", 100)
        b.add("سێیەم؟", 200)
        val r = b.take(300)!!
        assertEquals("یەکەم. دووەم، سێیەم؟", r.text)   // خاڵبەندی هەیە ناگۆڕدرێت؛ نەبوو "،" دەخرێتە سەر
        assertEquals(3, r.count)
    }

    @Test fun backlogSpeedsUpButIsCapped() {
        val b = SpeechBacklog()
        b.add("a1", 0); b.add("a2", 0)
        assertEquals(1.12f, b.take(10)!!.boost, 0.001f)
        for (i in 1..4) b.add("line$i", 0)
        assertEquals(1.35f, b.take(10)!!.boost, 0.001f)     // ٤ دێڕ ← 1.36 ← سنوور 1.35
    }

    @Test fun longWaitAddsExtraBoost() {
        val b = SpeechBacklog()
        b.add("a1", 0); b.add("a2", 500)
        assertEquals(1.22f, b.take(2_000)!!.boost, 0.001f)
    }

    @Test fun staleLinesAreDropped() {
        val b = SpeechBacklog(staleMs = 7_000)
        b.add("کۆنە", 0)
        assertNull(b.take(8_000))
        b.add("کۆنە", 0); b.add("نوێ", 7_500)
        val r = b.take(8_000)!!
        assertEquals("نوێ", r.text)
        assertEquals(1, r.count)
    }

    @Test fun queueKeepsNewestOnly() {
        val b = SpeechBacklog(maxQueue = 4)
        for (i in 1..6) b.add("l$i", i.toLong())
        assertEquals(4, b.size())
        assertTrue(b.take(10)!!.text.startsWith("l3"))
    }

    @Test fun overlongMergeDropsOldestKeepsNewest() {
        val b = SpeechBacklog(maxChars = 260)
        val x = "ا".repeat(100)
        b.add("$x 1", 0); b.add("$x 2", 0); b.add("$x 3", 0)
        val r = b.take(10)!!
        assertEquals(2, r.count)
        assertTrue(r.text.contains(" 3") && !r.text.contains(" 1"))
    }

    @Test fun blankIsIgnoredAndEmptyTakeIsNull() {
        val b = SpeechBacklog()
        b.add("   ", 0)
        assertTrue(b.isEmpty())
        assertNull(b.take(0))
        assertEquals(0L, b.oldestWait(100))
    }

    @Test fun oldestWaitTracksFirstLine() {
        val b = SpeechBacklog()
        b.add("a1", 100); b.add("a2", 900)
        assertEquals(1_900L, b.oldestWait(2_000))
        assertNotNull(b.take(2_000))
        assertEquals(0L, b.oldestWait(2_000))
    }
}
