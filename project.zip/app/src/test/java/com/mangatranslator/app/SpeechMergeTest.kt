package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechMergeTest {
    @Test fun shortSentenceJoinsNext() {
        assertEquals(listOf("باشە، من دەچمە ماڵەوە"), SpeechMerge.merge(listOf("باشە", "من دەچمە ماڵەوە")))
    }
    @Test fun trailingShortJoinsPrevious() {
        assertEquals(listOf("من دەچمە ماڵەوە بۆ خوێندن، باشە"), SpeechMerge.merge(listOf("من دەچمە ماڵەوە بۆ خوێندن", "باشە")))
    }
    @Test fun longSentencesUntouched() {
        assertEquals(2, SpeechMerge.merge(listOf("یەک دوو سێ", "چوار پێنج شەش")).size)
    }
    @Test fun ownOutputIsRecognised() {
        OwnOutput.clear()
        OwnOutput.note("چیاکەمان لە پرۆپاگەندەو ناسازیدا سەریهەڵدا")
        assertTrue(OwnOutput.matches("چیاکەمان لە پرۆپاگەندەو ناسازیدا سەریهەڵدا، MkIceandfire"))
        assertFalse(OwnOutput.matches("Our mountain emerged out of the Chaos"))
    }
    @Test fun kurdishWithoutEnglishIsNotRetranslated() {
        assertFalse(TextFilter.worthTranslating("چیاکەمان لە پرۆپاگەندەو ناسازیدا سەریهەڵدا. MkIceandfire"))
        assertTrue(TextFilter.worthTranslating("ئەمە بۆ user-friendly و hello دەگۆڕێت ڕۆژ"))
    }
}
