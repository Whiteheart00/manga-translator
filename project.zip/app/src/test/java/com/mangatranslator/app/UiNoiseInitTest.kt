package com.mangatranslator.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * پاراستن لە کڕاشی «keeps stopping»: UiNoise لە یەکەم بانگدا دروست دەبێت. ئەگەر WS/EDGE دوای UI_WORDS
 * دابنرێن، دروستبوونی لیستەکە NullPointerException دەدات. ئەم تێستە بەتەنها یەکەم بانگ دەکات.
 */
class UiNoiseInitTest {
    @Test fun firstCallDoesNotCrash() {
        assertTrue(UiNoise.isNoise("Like", ui = true))
        assertTrue(UiNoise.isNoise("Create story", ui = true))
    }

    @Test fun mangaWordsSurviveStrictMode() {
        assertFalse(UiNoise.isNoise("Like", ui = false))
        assertFalse(UiNoise.isNoise("HOW DID I GET HERE...?!", ui = true))
        assertTrue(UiNoise.isNoise("2h", ui = false))
    }
}
