package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Test

class ReadingOrderTest {

    private data class B(val id: String, val top: Int, val left: Int)

    private fun order(items: List<B>, rtl: Boolean) =
        ReadingOrder.sort(items, frameH = 1200, rtl = rtl, top = { it.top }, left = { it.left }).map { it.id }

    @Test fun rowsComeTopToBottom() {
        val items = listOf(B("low", 600, 0), B("high", 50, 900), B("mid", 300, 400))
        assertEquals(listOf("high", "mid", "low"), order(items, rtl = false))
        assertEquals(listOf("high", "mid", "low"), order(items, rtl = true))
    }

    @Test fun sameRowIsLeftToRightByDefault() {
        val items = listOf(B("right", 50, 700), B("left", 60, 100), B("mid", 40, 400))
        assertEquals(listOf("left", "mid", "right"), order(items, rtl = false))
    }

    @Test fun sameRowIsRightToLeftWhenRtl() {
        val items = listOf(B("right", 50, 700), B("left", 60, 100), B("mid", 40, 400))
        assertEquals(listOf("right", "mid", "left"), order(items, rtl = true))
    }

    @Test fun nextRowAlwaysAfterPreviousRow() {
        // 90 → ڕیزی ٠ ، 150 → ڕیزی ١ (frameH=1200 ← هەر ڕیزێک ١٠٠پیکسێل)
        val items = listOf(B("row1", 150, 0), B("row0", 90, 999))
        assertEquals(listOf("row0", "row1"), order(items, rtl = false))
    }

    @Test fun emptyAndZeroHeightAreSafe() {
        assertEquals(emptyList<String>(), order(emptyList(), rtl = false))
        val r = ReadingOrder.sort(listOf(B("a", 5, 1)), frameH = 0, top = { it.top }, left = { it.left })
        assertEquals(1, r.size)
    }
}
