package com.mangatranslator.app

import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress

class ModelFileDownloadTest {
    @get:Rule val folder = TemporaryFolder()
    private val data = "model contents".toByteArray()

    private fun serve(handler: (HttpExchange) -> Unit, test: (String) -> Unit) {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/model") { exchange ->
            try { handler(exchange) } finally { exchange.close() }
        }
        server.start()
        try { test("http://127.0.0.1:${server.address.port}/model") }
        finally { server.stop(0) }
    }

    private fun HttpExchange.respond(code: Int, body: ByteArray) {
        sendResponseHeaders(code, body.size.toLong())
        responseBody.use { it.write(body) }
    }

    @Test fun resumesFromVerifiedOffset() {
        val dst = File(folder.root, "model")
        File(folder.root, "model.part").writeBytes(data.copyOfRange(0, 5))
        var range: String? = null
        serve({
            range = it.requestHeaders.getFirst("Range")
            it.responseHeaders.add("Content-Range", "bytes 5-${data.lastIndex}/${data.size}")
            it.respond(206, data.copyOfRange(5, data.size))
        }) { url -> ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        assertEquals("bytes=5-", range)
        assertArrayEquals(data, dst.readBytes())
        assertFalse(File(folder.root, "model.part").exists())
    }

    @Test fun restartsWhenServerIgnoresRange() {
        val dst = File(folder.root, "model")
        File(folder.root, "model.part").writeText("wrong")
        serve({ it.respond(200, data) }) { url -> ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        assertArrayEquals(data, dst.readBytes())
    }

    @Test fun rejectsWrongRangeWithoutChangingExistingFiles() {
        val dst = File(folder.root, "model").apply { writeText("installed") }
        val part = File(folder.root, "model.part").apply { writeText("model") }
        serve({
            it.responseHeaders.add("Content-Range", "bytes 0-${data.lastIndex}/${data.size}")
            it.respond(206, data)
        }) { url ->
            assertThrows(IOException::class.java) { ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        }
        assertEquals("model", part.readText())
        assertEquals("installed", dst.readText())
    }

    @Test fun truncatedBodyRemainsResumable() {
        val dst = File(folder.root, "model")
        serve({ it.respond(200, data.copyOfRange(0, 5)) }) { url ->
            assertThrows(IOException::class.java) { ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        }
        assertFalse(dst.exists())
        assertEquals(5L, File(folder.root, "model.part").length())
    }

    @Test fun oversizedResponseCannotReplaceInstalledModel() {
        val dst = File(folder.root, "model").apply { writeText("installed") }
        serve({ it.respond(200, ByteArray(100)) }) { url ->
            assertThrows(IOException::class.java) { ModelFileDownload.fetch(url, dst, data.size.toLong()) {} }
        }
        assertEquals("installed", dst.readText())
        assertTrue(File(folder.root, "model.part").length() <= data.size)
    }

    @Test fun completedPartIsPublishedWithoutAnotherNetworkRequest() {
        val dst = File(folder.root, "model")
        File(folder.root, "model.part").writeBytes(data)
        ModelFileDownload.fetch("http://127.0.0.1:1/unreachable", dst, data.size.toLong()) {}
        assertArrayEquals(data, dst.readBytes())
    }
}
