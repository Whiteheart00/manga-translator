package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechPadTest {

    @Test fun shortSentenceGetsTheFillerWord() {
        // «من ئەو وێب ئاپەم» = ١٦ پیت ← ٢٤ دوای زیادکردن
        assertEquals("من ئەو وێب ئاپەم هەرکردم", SpeechPad.pad("من ئەو وێب ئاپەم"))
    }

    @Test fun neverShorterThanMinChars() {
        for (t in listOf("باشە", "نا", "ئەری", "من ئەو وێب ئاپەم", "ئەمە ١٧ پیتە ١٧ پیت")) {
            assertTrue("\"$t\"", SpeechPad.pad(t).length >= 20)
        }
    }

    @Test fun longEnoughSentenceIsUntouched() {
        val t = "ئەمە ڕستەیەکی درێژە و پێویستی بە پڕکردنەوە نییە"
        assertEquals(t, SpeechPad.pad(t))
    }

    @Test fun endPunctuationStaysAtTheEnd() {
        val r = SpeechPad.pad("باشە؟")
        assertTrue(r.startsWith("باشە "))
        assertTrue(r.endsWith("؟"))
        assertTrue(r.length >= 20)
        assertEquals(1, r.count { it == '؟' })
    }

    @Test fun offOrBlankWordChangesNothing() {
        assertEquals("باشە", SpeechPad.pad("باشە", "هەرکردم", 0))
        assertEquals("باشە", SpeechPad.pad("باشە", "  ", 20))
        assertEquals("باشە", SpeechPad.pad("  باشە  "))
    }

    @Test fun customWordAndLimit() {
        assertEquals("باشە ئەرێبەرز", SpeechPad.pad("باشە", "ئەرێبەرز", 10))
    }

    // ---------- یاسای حەوت پیت ----------
    @Test fun wordMustHaveAtLeastSevenLetters() {
        assertTrue(SpeechPad.isValidWord("هەرکردم"))          // ٧ پیت
        assertTrue(SpeechPad.isValidWord("  هەرکردم  "))
        assertTrue(SpeechPad.isValidWord("ئەرێبەرز"))        // ٨ پیت
        assertFalse(SpeechPad.isValidWord("هەرکرد"))          // ٦ پیت
        assertFalse(SpeechPad.isValidWord("دەی"))
        assertFalse(SpeechPad.isValidWord("   "))
        assertFalse(SpeechPad.isValidWord(null))
    }

    @Test fun letterCountIgnoresSpacesAndPunctuation() {
        assertEquals(7, SpeechPad.letterCount("هەرکردم"))
        assertEquals(7, SpeechPad.letterCount("هەر. کردم!"))      // ٣ + ٤ پیت؛ بۆشایی و خاڵبەندی ناژمێردرێن
    }

    @Test fun sanitizeFallsBackToDefaultWhenTooShort() {
        assertEquals(SpeechPad.DEFAULT_WORD, SpeechPad.sanitizeWord("دەی"))
        assertEquals(SpeechPad.DEFAULT_WORD, SpeechPad.sanitizeWord(""))
        assertEquals(SpeechPad.DEFAULT_WORD, SpeechPad.sanitizeWord(null))
        assertEquals("ئەرێبەرز", SpeechPad.sanitizeWord(" ئەرێبەرز "))
    }

    @Test fun padNeverUsesAWordShorterThanSeven() {
        // وشەی ٣ پیتی «دەی» بەکارنایەت؛ بنەڕەت دێتە جێی
        assertEquals("باشە هەرکردم", SpeechPad.pad("باشە", "دەی", 10))
    }

    @Test fun defaultWordSatisfiesItsOwnRule() {
        assertTrue(SpeechPad.isValidWord(SpeechPad.DEFAULT_WORD))
    }

    @Test fun punctuationOnlyIsLeftAlone() {
        assertEquals("...", SpeechPad.pad("..."))
        assertEquals("", SpeechPad.pad("   "))
    }
}
