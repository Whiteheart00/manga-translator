package com.mangatranslator.app

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.sqrt

class VoiceShaperTest {
    private val rate = 22050

    private fun tone(hz: Double): FloatArray =
        FloatArray(rate) { (0.3 * sin(2.0 * PI * hz * it / rate)).toFloat() }

    private fun rms(x: FloatArray): Double {
        var s = 0.0
        for (i in 2000 until x.size) s += x[i].toDouble() * x[i]
        return sqrt(s / (x.size - 2000))
    }

    @Test fun zeroMeansUnchanged() {
        val x = tone(1000.0)
        val y = x.copyOf()
        VoiceShaper.apply(y, y.size, rate, edge = 0, soft = 0)
        assertArrayEquals(x, y, 0f)
    }

    @Test fun softReducesHighKeepsLow() {
        val lowIn = tone(300.0); val highIn = tone(6000.0)
        val low = lowIn.copyOf(); val high = highIn.copyOf()
        VoiceShaper.apply(low, low.size, rate, edge = 0, soft = 100)
        VoiceShaper.apply(high, high.size, rate, edge = 0, soft = 100)
        assertTrue(rms(low) > 0.85 * rms(lowIn))
        assertTrue(rms(high) < 0.5 * rms(highIn))
    }

    @Test fun edgeLiftsHighRelativeToLow() {
        val low = tone(300.0); val high = tone(4000.0)
        VoiceShaper.apply(low, low.size, rate, edge = 100, soft = 0)
        VoiceShaper.apply(high, high.size, rate, edge = 100, soft = 0)
        assertTrue(rms(high) / rms(low) > 1.2)
    }

    @Test fun outputStaysFiniteAndBounded() {
        val x = FloatArray(rate) { if (it % 7 == 0) 1f else -1f }
        VoiceShaper.apply(x, x.size, rate, edge = 100, soft = 100)
        assertTrue(x.all { it.isFinite() && kotlin.math.abs(it) <= 1.5f })
    }
}
