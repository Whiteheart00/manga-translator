package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechQueueTest {

    private fun drain(q: SpeechQueue): List<SpeechQueue.Batch> {
        val out = ArrayList<SpeechQueue.Batch>()
        while (true) out.add(q.take() ?: break)
        return out
    }

    @Test fun singleLineIsTakenAsIsAtNormalSpeed() {
        val q = SpeechQueue()
        q.add("سڵاو چۆنی")
        val b = q.take()!!
        assertEquals("سڵاو چۆنی", b.text)
        assertEquals(1, b.count)
        assertEquals(1f, b.boost, 0.001f)
        assertTrue(q.isEmpty())
        assertNull(q.take())
    }

    @Test fun nothingIsEverDroppedAndOrderIsKept() {
        val q = SpeechQueue(maxChars = 60)
        val lines = (1..200).map { "ڕستەی ژمارە $it." }
        lines.forEach { q.add(it) }
        val spoken = drain(q).joinToString(" ") { it.text }
        // هەموو ٢٠٠ ڕستە، بەو ڕیزەی هاتوون
        var pos = 0
        for (l in lines) {
            val i = spoken.indexOf(l, pos)
            assertTrue("ونبوو: $l", i >= 0)
            pos = i + l.length
        }
        assertEquals(lines.size, drain(SpeechQueue()).size + lines.size) // drain ی ڕیزی بەتاڵ = ٠
    }

    @Test fun manyLinesAreMergedInOrderWithinLimit() {
        val q = SpeechQueue(maxChars = 300)
        q.add("یەکەم."); q.add("دووەم"); q.add("سێیەم؟")
        val b = q.take()!!
        assertEquals("یەکەم. دووەم، سێیەم؟", b.text)
        assertEquals(3, b.count)
    }

    @Test fun mergeStopsAtMaxCharsButRemainderStaysQueued() {
        val q = SpeechQueue(maxChars = 50)
        val a = "ا".repeat(30)
        q.add("$a 1."); q.add("$a 2."); q.add("$a 3.")
        val b1 = q.take()!!
        assertEquals(1, b1.count)
        assertEquals(2, q.size())
        assertEquals(1, q.take()!!.count)
        assertEquals(1, q.take()!!.count)
        assertTrue(q.isEmpty())
    }

    @Test fun overlongSingleLineIsStillSpoken() {
        val q = SpeechQueue(maxChars = 50)
        val long = "ب".repeat(500)
        q.add(long)
        assertEquals(long, q.take()!!.text)
    }

    @Test fun backlogSpeedsUpButIsCapped() {
        val q = SpeechQueue(maxChars = 10, maxBoost = 1.3f)
        for (i in 1..3) q.add("l$i.")
        assertEquals(1.12f, q.take()!!.boost, 0.001f)     // ٣ لە ڕیزدا
        val q2 = SpeechQueue(maxChars = 10, maxBoost = 1.3f)
        for (i in 1..20) q2.add("l$i.")
        assertEquals(1.3f, q2.take()!!.boost, 0.001f)     // سنوور
    }

    @Test fun blankIsIgnored() {
        val q = SpeechQueue()
        q.add("   "); q.add("")
        assertTrue(q.isEmpty())
    }
}
