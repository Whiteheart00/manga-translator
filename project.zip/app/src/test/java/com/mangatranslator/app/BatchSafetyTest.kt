package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class BatchSafetyTest {

    // ---------- Google: باتش ----------

    @Test fun exactCountIsAccepted() {
        assertEquals(listOf("a", "b", "c"), GoogleTranslator.splitBatchResult("a ¤ b ¤ c", 3))
    }

    @Test fun extraPartsAreRejectedNotTruncated() {
        // پێشتر take(expected) دەکرا ← بابڵێک دەچووە ژێر بابڵێکی تر
        assertNull(GoogleTranslator.splitBatchResult("a ¤ b ¤ c ¤ d", 3))
    }

    @Test fun missingPartsAreRejected() {
        assertNull(GoogleTranslator.splitBatchResult("a ¤ b", 3))
        assertNull(GoogleTranslator.splitBatchResult("a b c", 3))
    }

    @Test fun emptyPartIsRejected() {
        assertNull(GoogleTranslator.splitBatchResult("a ¤  ¤ c", 3))
        assertNull(GoogleTranslator.splitBatchResult("   ", 2))
    }

    @Test fun singleItemNeverSplits() {
        assertEquals(listOf("hello ¤ world"), GoogleTranslator.splitBatchResult("hello ¤ world", 1))
    }

    // ---------- Gemini: دەرچوون بە id ----------

    @Test fun outOfOrderIdsStayWithTheirBlock() {
        val raw = """[{"id":2,"kurdish":"سێ"},{"id":0,"kurdish":"یەک"},{"id":1,"kurdish":"دوو"}]"""
        assertEquals(listOf("یەک", "دوو", "سێ"), ArabicGemini.parse(raw, 3))
    }

    @Test fun missingBlockStaysEmptyInsteadOfFailingAll() {
        val raw = """[{"id":0,"kurdish":"یەک"},{"id":2,"kurdish":"سێ"}]"""
        assertEquals(listOf("یەک", "", "سێ"), ArabicGemini.parse(raw, 3))
    }

    @Test fun invalidAndDuplicateIdsAreIgnored() {
        val raw = """[{"id":0,"kurdish":"یەک"},{"id":0,"kurdish":"دووبارە"},{"id":9,"kurdish":"نادروست"},{"id":-1,"kurdish":"x"}]"""
        assertEquals(listOf("یەک", ""), ArabicGemini.parse(raw, 2))
    }

    @Test fun noIdsAtAllThrows() {
        var thrown = false
        try { ArabicGemini.parse("""[{"kurdish":"x"}]""", 1) } catch (_: IOException) { thrown = true }
        assertTrue(thrown)
    }

    @Test fun fencedJsonIsAccepted() {
        assertEquals(listOf("باشە"), ArabicGemini.parse("```json\n[{\"id\":0,\"kurdish\":\"باشە\"}]\n```", 1))
    }
}
