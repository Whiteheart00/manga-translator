package com.mangatranslator.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextFilterTest {

    @Test fun soraniWithSpecialLettersIsDetected() {
        assertTrue(TextFilter.isLikelySorani("سڵاو چۆنی"))   // ڵ + ۆ
        assertTrue(TextFilter.isLikelySorani("ئەمڕۆ"))       // ە ڕ ۆ
    }

    @Test fun shortSoraniWithOneSpecialLetterIsDetected() {
        assertTrue(TextFilter.isLikelySorani("بۆ"))
    }

    @Test fun plainArabicWithoutSoraniLettersIsNotSorani() {
        assertFalse(TextFilter.isLikelySorani("مرحبا بك"))
        assertFalse(TextFilter.isLikelySorani("من"))
    }

    @Test fun latinAndMixedTextIsNotSorani() {
        assertFalse(TextFilter.isLikelySorani("hello"))
        assertFalse(TextFilter.isLikelySorani("Hello ئەو"))
    }

    @Test fun tooShortOrEmptyIsNotSorani() {
        assertFalse(TextFilter.isLikelySorani(""))
        assertFalse(TextFilter.isLikelySorani("a"))
        assertFalse(TextFilter.isLikelySorani("   "))
    }
}
