package com.mangatranslator.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UiNoiseLoadingTest {

    @Test fun loadingTextIsDetected() {
        assertTrue(UiNoise.isLoading("Loading…"))
        assertTrue(UiNoise.isLoading("Loading..."))
        assertTrue(UiNoise.isLoading("Please wait"))
        assertTrue(UiNoise.isLoading("جاري التحميل"))
        assertTrue(UiNoise.isLoading("بارکردن..."))
        assertTrue(UiNoise.isLoading("لۆدینگ"))
    }

    @Test fun loadingIsNoiseInBothModes() {
        assertTrue(UiNoise.isNoise("Loading...", ui = false))
        assertTrue(UiNoise.isNoise("Loading...", ui = true))
    }

    @Test fun realDialogueIsNotLoading() {
        assertFalse(UiNoise.isLoading("Wait!"))
        assertFalse(UiNoise.isLoading("انتظر"))
        assertFalse(UiNoise.isLoading("چاوەڕێبە"))
        assertFalse(UiNoise.isLoading("Loading the gun, give me a second"))
        assertFalse(UiNoise.isLoading(""))
    }
}
