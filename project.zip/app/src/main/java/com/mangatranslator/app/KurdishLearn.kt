package com.mangatranslator.app

import android.content.Context
import org.json.JSONObject

/**
 * فێربوونی ناوخۆیی: هەر جارێک Gemini وشەیەکی دەقی ئۆفلاینی چاک بکات، جووتەکە (هەڵە ← ڕاست) پاشەکەوت دەکرێت.
 * کاتێک هەمان چاککردن دووجار یان زیاتر دووبارە بووەوە، جاری داهاتوو یەکسەر و بێ ئینتەرنێت لە دەقی ئۆفلاین جێبەجێ دەکرێت
 * (هیچ دواکەوتنێکی نییە، تەنها گەڕان لە خشتەیەکی بچووک).
 *
 * ئەمە مۆدێلی Whisper دووبارە ڕانایەنێتەوە؛ تەنها خشتەیەکی «هەڵەکانی من»ـە کە دوای مۆدێلەکە بەکاردێت.
 */
object KurdishLearn {

    private const val PREFS = "kurdish_learn"
    private const val KEY = "pairs"
    private const val MIN_SEEN = 2          // پێویستە ٢ جار دووپات ببێتەوە تا جێبەجێ بکرێت
    private const val MAX_PAIRS = 2000
    private const val MAX_WORDS = 120

    private val PUNCT = "،.؟!؛,.?!;:\"«»()"

    @Volatile
    private var cache: JSONObject? = null

    private fun load(ctx: Context): JSONObject {
        cache?.let { return it }
        val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        val o = try { if (s.isNullOrEmpty()) JSONObject() else JSONObject(s) } catch (_: Exception) { JSONObject() }
        cache = o
        return o
    }

    private fun save(ctx: Context, o: JSONObject) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    /** ژمارەی ئەو وشانەی تا ئێستا فێربووە و جێبەجێ دەکرێن. */
    @Synchronized
    fun learnedCount(ctx: Context): Int {
        val o = load(ctx)
        var c = 0
        val it = o.keys()
        while (it.hasNext()) if (o.getJSONObject(it.next()).optInt("n") >= MIN_SEEN) c++
        return c
    }

    /** ئایا ئەم ناوە پێشتر لە لیستی شاراوەی ناوەکاندا تۆمارکراوە؟ */
    fun isRegistered(name: String): Boolean = KurdishBuiltinNames.contains(name)

    /**
     * دەقی خانەی «ناوەکانم» پاک دەکاتەوە: ناوی تۆمارکراو و ناوی دووبارە دەسڕێتەوە.
     * [keepLast] = true: ناوی کۆتایی (کە هێشتا دەنووسرێت) دەست لێ نادرێت.
     * دەگەڕێنێتەوە (دەقی پاککراو، ئایا شتێک سڕایەوە).
     */
    fun cleanNames(text: String, keepLast: Boolean): Pair<String, Boolean> {
        val parts = Regex("[^\\n,،;؛]+|[\\n,،;؛]+").findAll(text).map { it.value }.toList()
        val seen = HashSet<String>()
        val sb = StringBuilder()
        var removed = false
        for ((i, part) in parts.withIndex()) {
            val isSep = part.isNotEmpty() && part.all { it in "\n,،;؛" }
            if (isSep) { sb.append(part); continue }
            val name = part.trim()
            val isLast = i == parts.lastIndex
            if (name.isEmpty() || (keepLast && isLast)) { sb.append(part); continue }
            val key = KurdishEntities.norm(name)
            if (isRegistered(name) || !seen.add(key)) { removed = true; continue }
            sb.append(part)
        }
        if (!removed) return text to false
        val cleaned = sb.toString().replace(Regex("^[\\n,،;؛\\s]+"), "").replace(Regex("([\\n,،;؛])[\\s,،;؛]*([\\n,،;؛])"), "$1")
        return cleaned to true
    }

    @Synchronized
    fun clear(ctx: Context) {
        cache = JSONObject()
        save(ctx, cache!!)
    }

    // ---------- بەکارهێنان ----------

    private class Tok(val pre: String, val core: String, val post: String)

    private fun split(w: String): Tok {
        var a = 0
        var b = w.length
        while (a < b && w[a] in PUNCT) a++
        while (b > a && w[b - 1] in PUNCT) b--
        return Tok(w.substring(0, a), w.substring(a, b), w.substring(b))
    }

    /** وشە فێربووەکان لە دەقی ئۆفلاین چاک دەکات. خێرایە و بێ ئینتەرنێت. */
    @Synchronized
    fun apply(ctx: Context, text: String): String {
        val o = load(ctx)
        if (o.length() == 0 || text.isBlank()) return text
        val words = text.split(' ')
        val out = ArrayList<String>(words.size)
        var changed = false
        for (w in words) {
            val t = split(w)
            val e = if (t.core.isEmpty()) null else o.optJSONObject(t.core)
            if (e != null && e.optInt("n") >= MIN_SEEN) {
                out.add(t.pre + e.getString("to") + t.post)
                changed = true
            } else out.add(w)
        }
        return if (changed) out.joinToString(" ") else text
    }

    // ---------- فێربوون ----------

    /** دەقی خاوی ئۆفلاین بەرامبەر دەقی چاککراوی Gemini: جیاوازییە یەک-بە-یەکەکان فێر دەبێت. */
    @Synchronized
    fun learn(ctx: Context, raw: String, fixed: String) {
        val a = raw.trim().split(' ').filter { it.isNotEmpty() }.map { split(it).core }
        val b = fixed.trim().split(' ').filter { it.isNotEmpty() }.map { split(it).core }
        if (a.isEmpty() || b.isEmpty() || a.size > MAX_WORDS || b.size > MAX_WORDS) return

        // LCS لەسەر وشەکان
        val n = a.size
        val m = b.size
        val dp = Array(n + 1) { IntArray(m + 1) }
        for (i in n - 1 downTo 0) for (j in m - 1 downTo 0)
            dp[i][j] = if (a[i] == b[j]) dp[i + 1][j + 1] + 1 else maxOf(dp[i + 1][j], dp[i][j + 1])

        val pairs = ArrayList<Pair<String, String>>()
        var i = 0
        var j = 0
        while (i < n || j < m) {
            if (i < n && j < m && a[i] == b[j]) { i++; j++; continue }
            // کۆکردنەوەی بەشی جیاواز تا یەکەم وشەی هاوبەش
            val si = i
            val sj = j
            while ((i < n || j < m) && !(i < n && j < m && a[i] == b[j])) {
                if (j >= m || (i < n && dp[i + 1][j] >= dp[i][j + 1])) i++ else j++
            }
            if (i - si == 1 && j - sj == 1) pairs.add(a[si] to b[sj])
        }
        if (pairs.isEmpty()) return

        val o = load(ctx)
        for ((wrong, right) in pairs) if (worthLearning(wrong, right)) bump(o, wrong, right)
        trim(o)
        save(ctx, o)
    }

    private fun worthLearning(w: String, r: String): Boolean {
        if (w.length < 2 || r.isEmpty() || w == r) return false
        if (w.any { it in 'a'..'z' || it in 'A'..'Z' || it.isDigit() }) return false   // ئینگلیزی و ژمارە نا
        if (r.any { it in 'a'..'z' || it in 'A'..'Z' || it.isDigit() }) return false
        // نابێت وشەیەکی تەواو جیاواز بێت (ئەگەرنا دەبێتە شرۆڤەکردنەوە نەک چاککردنی هەڵە)
        return editDistance(w, r).toFloat() / maxOf(w.length, r.length) <= 0.6f
    }

    private fun bump(o: JSONObject, wrong: String, right: String) {
        val e = o.optJSONObject(wrong)
        if (e == null) {
            o.put(wrong, JSONObject().put("to", right).put("n", 1))
        } else if (e.getString("to") == right) {
            e.put("n", e.optInt("n") + 1)
        } else {
            // چاککردنێکی جیاواز: متمانە کەم دەکاتەوە؛ ئەگەر گەیشتە سفر ئەوەی نوێ جێی دەگرێتەوە
            val n = e.optInt("n") - 1
            if (n <= 0) o.put(wrong, JSONObject().put("to", right).put("n", 1)) else e.put("n", n)
        }
    }

    private fun trim(o: JSONObject) {
        if (o.length() <= MAX_PAIRS) return
        val list = ArrayList<Pair<String, Int>>()
        val it = o.keys()
        while (it.hasNext()) { val k = it.next(); list.add(k to o.getJSONObject(k).optInt("n")) }
        list.sortBy { it.second }
        for (p in list.take(o.length() - MAX_PAIRS + 200)) o.remove(p.first)
    }

    private fun editDistance(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = t
            }
        }
        return d[b.length]
    }
}
