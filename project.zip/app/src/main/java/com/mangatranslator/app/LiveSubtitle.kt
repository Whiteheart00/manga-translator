package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.SystemClock
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

/**
 * وەرگێڕانی زیندووی ژێرنووس (ڤیدیۆ / یاری): ڕووبەرێکی دیاریکراو بەردەوام دەگیرێت ← OCR ← وەرگێڕان ← دەنگ.
 * تەنها دەق بەکاردێت (OCR)، نەک وەرگێڕانی دەنگ بۆ دەنگ.
 *
 *  1. onFrame()   — لە thread ی گرتنەوە، بۆ هەر فرەیمێک (≈٦ جار لە چرکەیەکدا). تەنها ڕووبەرەکە دەبڕێت و بە
 *                   واژۆی ٣٢×٣٢ بەراوردی دەکات. تەنها کاتێک OCR دەکات کە ڕووبەرەکە گۆڕابێت و (ڕاوەستابێت یان ٤٥٠ms تێپەڕیبێت).
 *  2. OCR         — ML Kit ی ئۆفلاین (OcrEngine.recognizeLive)؛ عەرەبی بە Gemini بینین (ئەگەر کلیل هەبێت) یان Tesseract.
 *  3. دووبارەنەبوونەوە — هەمان ژێرنووس (یان OCR ی کەمێک جیاواز) دووبارە وەرناگێڕدرێتەوە.
 *  4. وەرگێڕان    — Gemini (بە ٣ دێڕی پێشوو وەک چوارچێوە)؛ ئەگەر لە ٧٠٠ms زیاتر خایاند Google بەهاوڕێی دەست پێدەکات
 *                   و یەکەم وەڵام دەبات (hedged request). cache بۆ دێڕە دووبارەکان.
 *  5. دەنگ        — هیچ ڕستەیەک لەبیر ناکرێت: هەموو ڕستەیەک (OCR ← وەرگێڕان) بە ڕیزی دەرکەوتنی دەخوێنرێتەوە. وەرگێڕانی
 *                   ڕستەکان پارالێل دەکرێت بەڵام بە هەمان ڕیز ئازاد دەکرێن؛ [SpeechQueue] FIFO ی بێ سنوور و بێ
 *                   «کۆن بوو» و بێ بڕین. ئەگەر چەند ڕستە کۆ بوون پێکەوە و کەمێک خێراتر دەخوێنرێنەوە.
 *
 * ئۆڤەرلەی وەرگێڕان لە دەرەوەی ڕووبەرەکە دەکێشرێت (OverlayService)، نەک لەسەری، بۆ ئەوەی OCR دەقی خۆمان نەخوێنێتەوە (لووپ).
 */
class LiveSubtitle(
    private val ctx: Context,
    private val ocr: OcrEngine,
    private val tts: SoraniTts,
    private val settings: TranslatorSettings,
    private val main: Handler,
    /** null = ژێرنووس نەما (بار بسڕەوە). لەسەر main thread. */
    private val onCaption: (String?) -> Unit,
    private val onError: (String) -> Unit
) {
    // ---------- ڕووبەر و دۆخی گرتن (thread ی گرتنەوە) ----------
    private var region = RectF()
    private var screenW = 1
    private var screenH = 1
    private var lang = "auto"
    /** کلیلی Gemini بۆ ژێرنووسی زیندوو؛ ئەگەر بەکارهێنەر کوژاندبێتییەوە بەتاڵە (هەر ئێستا کاریگەرە، بێ دەستپێکردنەوە) */
    private val key: String get() = if (settings.liveGemini) settings.geminiTtsKey else ""

    @Volatile private var running = false
    @Volatile private var ocrBusy = false
    @Volatile private var changedSince = 0L
    @Volatile private var lastOcrAt = 0L
    private var prevSig: IntArray? = null
    private var ocrSig: IntArray? = null

    // واژۆی ڕووبەر بێ دروستکردنی bitmap: لە bitmap ێکی ٣٢×٣٢ ی دووبارەبەکارهاتوو دەکێشرێت (کەمکردنەوەی GC)
    private val sigBmp = Bitmap.createBitmap(SIG_N, SIG_N, Bitmap.Config.ARGB_8888)
    private val sigCanvas = Canvas(sigBmp)
    private val sigPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val sigPx = IntArray(SIG_N * SIG_N)
    private val sigDst = Rect(0, 0, SIG_N, SIG_N)
    private val cropRect = Rect()
    private var cropFw = -1
    private var cropFh = -1
    /** سەرەتای پرۆمپت: یەکجار لە start() دروست دەکرێت، نەک بۆ هەر دێڕێک */
    private var promptHead = ""

    // ---------- بەرهەمهێنان ----------
    private val seq = AtomicInteger(0)
    private val latestId = AtomicInteger(0)
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "live-sub").apply { isDaemon = true } }
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "live-sub-net").apply { isDaemon = true } }
    private var lastNorm = ""                       // تەنها لە worker
    private val recent = ArrayDeque<Pair<String, Long>>()   // ڕستە وەرگێڕدراوەکانی ئەم دواییە (worker)
    private val history = ArrayList<String>()       // دێڕە سەرچاوەکانی پێشوو (worker)
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 200
    }

    // ---------- دەنگ (تەنها main thread) ----------
    private val speechQ = SpeechQueue(MAX_MERGED_CHARS, MAX_BOOST)
    private var speaking = false
    private var speakStart = 0L
    private var speakToken = 0
    private var holdSince = 0L

    // ---------- ئازادکردنی ڕیزبەند (تەنها main thread) ----------
    // وەرگێڕانەکان پارالێل دەڕۆن؛ ئەنجامەکان بە ڕیزی ژمارەی خۆیان (order) ئازاد دەکرێن، بۆ ئەوەی ڕستە ڕیزی خۆی نەشکێنێت.
    private val ready = HashMap<Int, String?>()
    private var nextRelease = 0
    private var nextOrder = 0          // تەنها لە worker

    fun start(regionPx: RectF, screenWidth: Int, screenHeight: Int) {
        region = RectF(regionPx)
        screenW = screenWidth.coerceAtLeast(1)
        screenH = screenHeight.coerceAtLeast(1)
        lang = settings.sourceLang
        promptHead = buildPromptHead()
        try { tts.setLowLatency(true) } catch (_: Throwable) {}
        running = true
        main.postDelayed(watchdog, WATCHDOG_MS)
    }

    /**
     * پاسەوانی دەنگ: ئەگەر callback ی کۆتایی دەنگ ون بوو (speaking=true بەڵام TTS ڕاستەوخۆ بێدەنگە) یان ڕیز پڕە و کەس
     * نایخوێنێتەوە، دەستبەجێ (نەک دوای ١٠ چرکە) چاک دەکرێتەوە و ڕستەی دواتر دەخوێنرێت — پێشتر ڕستەی دووەم دواکەوت و لەگەڵ سێیەم تێکەڵ دەبوو.
     */
    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.elapsedRealtime()
            if (speaking && !tts.speaking) {
                if (desyncSince == 0L) desyncSince = now
                else if (now - desyncSince > DESYNC_MS) {
                    desyncSince = 0L
                    speaking = false
                    speakToken++
                    try { tts.speedBoost = 1f } catch (_: Throwable) {}
                }
            } else desyncSince = 0L
            if (!speaking && !speechQ.isEmpty()) pumpSpeech()
            main.postDelayed(this, WATCHDOG_MS)
        }
    }
    private var desyncSince = 0L

    fun stop() {
        running = false
        worker.shutdownNow()
        pool.shutdownNow()
        // پێشتر main.post بوو: ئەگەر یەکسەر ژێرنووسێکی نوێ دەستی پێکردبا، ئەم پاککردنەوەیە دواتر دەهات و دەنگ و
        // low-latency و ژێرنووسی نوێی دەکوشت (یان دوای tts.shutdown() ی onDestroy). ئێستا لەسەر main هاوکات جێبەجێ دەبێت.
        val cleanup = Runnable {
            speakToken++
            speaking = false
            speechQ.clear(); holdSince = 0L
            ready.clear()
            try { tts.stop() } catch (_: Throwable) {}
            try { tts.speedBoost = 1f } catch (_: Throwable) {}
            try { tts.setLowLatency(false) } catch (_: Throwable) {}
            try { onCaption(null) } catch (_: Throwable) {}
        }
        if (android.os.Looper.myLooper() === android.os.Looper.getMainLooper()) cleanup.run() else main.post(cleanup)
    }

    // =====================================================================
    // 1) فرەیم → ڕووبەر → بڕیاری OCR
    // =====================================================================

    /** ڕێگای کۆن (AccessibilityCapturer): کۆپی دەدرێت؛ لێرە recycle دەکرێت. */
    fun onFrame(frame: Bitmap) {
        try { onRawFrame(frame, true) } finally { frame.recycle() }
    }

    /**
     * ڕێگای خێرا (ScreenCapturer.rawFrameListener): هیچ کۆپییەک نییە. `frame` هی گرتنەوەیە — recycle مەکە و مەیهێڵەوە.
     * تەنها واژۆی ٣٢×٣٢ ی ڕووبەرەکە حیساب دەکرێت؛ bitmap ی ڕووبەر تەنها کاتێک دروست دەبێت کە OCR بەڕاستی پێویست بێت.
     */
    fun onRawFrame(frame: Bitmap, isNew: Boolean) {
        if (!running) return
        val now = SystemClock.elapsedRealtime()

        // فرەیمی دووبارە (شاشە نەگۆڕاوە): ئەگەر هیچ گۆڕانکارییەک چاوەڕێ نییە هیچ مەکە (٠ کار)؛
        // ئەگەر چاوەڕێی ڕاوەستانە، فرەیمی دووبارە خۆی ڕاوەستانە ← واژۆی پێشوو بەکاربهێنە
        val prev = prevSig
        val sig: IntArray
        val settled: Boolean
        if (!isNew && prev != null) {
            if (changedSince == 0L) return
            sig = prev
            settled = true
        } else {
            sig = regionSig(frame)
            settled = prev != null && ChangeDetector.distance(sig, prev) < STABLE_THRESHOLD
            prevSig = sig
        }

        val base = ocrSig
        // هیچ گۆڕانکارییەک نییە لە دوایین OCR ← ژێرنووسەکە هەمان ماوەتەوە
        val changed = base == null || ChangeDetector.changedFraction(sig, base) >= CHANGED_FRACTION
        if (!changed) { changedSince = 0L; return }
        if (changedSince == 0L) changedSince = now

        // ڕاوەستاو (ژێرنووس تەواو دەرکەوتووە) یان باگراوندی جووڵاو (ڤیدیۆ) ← بە زۆرەملێ OCR هەر FORCE_MS جارێک
        val forced = now - changedSince >= FORCE_MS
        if (!(settled || forced) || ocrBusy || now - lastOcrAt < MIN_GAP_MS) return

        val crop = cropRegion(frame) ?: return
        ocrBusy = true
        ocrSig = sig
        lastOcrAt = now
        runOcr(crop)
    }

    /** ڕووبەرەکە بە پیکسێلی فرەیم؛ تەنها کاتێک قەبارەی فرەیم بگۆڕێت دووبارە حیساب دەکرێت */
    private fun frameRegion(frame: Bitmap): Rect {
        val fw = frame.width
        val fh = frame.height
        if (fw != cropFw || fh != cropFh) {
            val kx = fw.toFloat() / screenW
            val ky = fh.toFloat() / screenH
            val l = (region.left * kx).toInt().coerceIn(0, fw - 2)
            val t = (region.top * ky).toInt().coerceIn(0, fh - 2)
            cropRect.set(l, t, (region.right * kx).toInt().coerceIn(l + 2, fw), (region.bottom * ky).toInt().coerceIn(t + 2, fh))
            cropFw = fw
            cropFh = fh
        }
        return cropRect
    }

    /** واژۆی ٣٢×٣٢ ی خۆڵەمێشی ی ڕووبەر، بێ bitmap ی نوێ */
    private fun regionSig(frame: Bitmap): IntArray {
        sigCanvas.drawBitmap(frame, frameRegion(frame), sigDst, sigPaint)
        sigBmp.getPixels(sigPx, 0, SIG_N, 0, 0, SIG_N, SIG_N)
        return IntArray(SIG_N * SIG_N) { i ->
            val c = sigPx[i]
            (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
        }
    }

    /** کۆپییەکی سەربەخۆی ڕووبەرەکە (بۆ OCR ی ناو thread ی تر)؛ تەنها کاتی پێویست */
    private fun cropRegion(frame: Bitmap): Bitmap? {
        return try {
            val r = frameRegion(frame)
            val c = Bitmap.createBitmap(frame, r.left, r.top, r.width(), r.height())
            if (c === frame) frame.copy(Bitmap.Config.ARGB_8888, false) else c
        } catch (_: Throwable) {
            null
        }
    }

    /** ڕووبەرەکە (بچووک کراوە بۆ ≤٢٠٠px) لێواری بەهێزی وەک-نووسینی تێدایە؟ لە شکستدا true (دوودڵی = بەردەوامبە). */
    private fun cropHasText(crop: Bitmap): Boolean {
        return try {
            val w = minOf(crop.width, GATE_W).coerceAtLeast(2)
            val h = (crop.height.toFloat() * w / crop.width.coerceAtLeast(1)).toInt().coerceAtLeast(2)
            val sm = if (w == crop.width && h == crop.height) crop else Bitmap.createScaledBitmap(crop, w, h, true)
            val sw = sm.width
            val sh = sm.height
            val px = IntArray(sw * sh)
            sm.getPixels(px, 0, sw, 0, 0, sw, sh)
            if (sm !== crop) sm.recycle()
            val gray = IntArray(px.size) { i ->
                val c = px[i]
                (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            }
            SubtitleGuard.hasTextLikeEdges(gray, sw, sh)
        } catch (_: Throwable) {
            true
        }
    }

    // =====================================================================
    // 2) OCR
    // =====================================================================

    private fun runOcr(crop: Bitmap) {
        val id = seq.incrementAndGet()
        val startedAt = SystemClock.elapsedRealtime()

        // ڕووبەری بێ هیچ لێوارێکی وەک-نووسین (تەخت/ڕەش/دیمەنی بێ دەق): نە OCR نە Gemini ← هیچ نووسینێکی لەحۆوە دروست نابێت
        if (!cropHasText(crop)) {
            crop.recycle()
            ocrBusy = false
            changedSince = 0L
            if (running) submit(id, "", startedAt, alreadyKurdish = false)
            return
        }

        // عەرەبی + کلیلی Gemini: OCR و وەرگێڕان بە یەک داواکاری (Tesseract ی عەرەبی زۆر هێواش و خراپە)
        if (lang == "ar" && key.isNotBlank()) {
            try { pool.execute {
                var text = ""
                try {
                    val items = RegionTranslator.run(crop, key, true).sortedBy { it.rect?.top ?: 0 }
                    val cw = crop.width
                    val chh = crop.height
                    val kept = wmFilter(items.map {
                        val r = it.rect
                        Blk(it.kurdish, r?.left ?: 0, r?.top ?: 0, r?.right ?: cw, r?.bottom ?: chh)
                    }, cw, chh)
                    val keptSet = kept.map { it.l to it.t }.toSet()
                    text = items.filter { ((it.rect?.left ?: 0) to (it.rect?.top ?: 0)) in keptSet }
                        .joinToString(" ") { it.kurdish }.trim()
                } catch (t: Throwable) {
                    Log.w(TAG, "Gemini vision failed: ${t.message}")
                } finally {
                    crop.recycle()
                    ocrBusy = false
                    changedSince = 0L
                }
                if (running) submit(id, text, startedAt, alreadyKurdish = true)
            } } catch (_: Throwable) {   // دوای stop() ی pool: داوا ڕەتدەکرێتەوە
                crop.recycle()
                ocrBusy = false
            }
            return
        }

        val cw = crop.width
        val chh = crop.height
        ocr.recognizeLiveBoxes(crop) { boxes ->
            crop.recycle()
            ocrBusy = false
            changedSince = 0L
            // واتەرمارک/نووسینی جێگیر (ناوی کەناڵ، X=SELECT...) لادەبرێت و ناچێتە وەرگێڕان
            val kept = wmFilter(boxes.map { Blk(it.text, it.rect.left, it.rect.top, it.rect.right, it.rect.bottom) }, cw, chh)
            val keptSet = kept.map { it.l to it.t }.toSet()
            val text = boxes.filter { (it.rect.left to it.rect.top) in keptSet }
                .sortedWith(compareBy({ it.rect.top }, { it.rect.left })).joinToString(" ") { it.text }.trim()
            if (running) submit(id, text, startedAt, alreadyKurdish = false)
        }
    }

    private val wm = WatermarkFilter()

    private fun wmFilter(blocks: List<Blk>, cw: Int, ch: Int): List<Blk> =
        synchronized(wm) { wm.filter(blocks, SystemClock.elapsedRealtime(), cw, ch) }

    private fun submit(id: Int, raw: String, startedAt: Long, alreadyKurdish: Boolean) {
        latestId.set(id)
        try {
            worker.execute {
                // stop() ی لە ناوەڕاستی وەرگێڕان: latch.await ← InterruptedException و pool.execute ← RejectedExecutionException
                // ئەگەر نەگیرابان دەبوونە uncaught exception ی thread ی live-sub و ئەپەکە داخرا
                try { handle(id, raw, startedAt, alreadyKurdish) }
                catch (_: InterruptedException) { Thread.currentThread().interrupt() }
                catch (t: Throwable) { Log.w(TAG, "handle after stop: ${t.message}") }
            }
        } catch (_: Throwable) {
        }
    }

    // =====================================================================
    // 3+4) دووبارەنەبوونەوە → وەرگێڕان
    // =====================================================================

    private fun handle(id: Int, raw: String, startedAt: Long, alreadyKurdish: Boolean) {
        if (!running) return
        val text = TextPrep.prepare(raw)
        // دەقی نادروست (خشت/هێما/پیتی دووبارە) وەک «دەق نەما» مامەڵەی لەگەڵ دەکرێت
        if (text.isBlank() || !SubtitleGuard.looksLikeRealText(text)) {
            // ژێرنووس نەما: بار دەشاردرێتەوە (بە ڕیزی ئازادکردن، دوای ئەو ڕستانەی پێشتر هاتوون) و هەمان دێڕ دووبارە دەبێتەوە
            if (lastNorm.isNotEmpty()) {
                lastNorm = ""
                deliver(nextOrder++, HIDE)
            }
            return
        }
        // کوردیی تەواو و بێ وشەی ئینگلیزی ← وەرناگێڕدرێت؛ ئەگەر وشەی ئینگلیزیشی تێدا بوو، وەردەگێڕدرێت
        val kurdishAlready = (alreadyKurdish || TextFilter.isLikelySorani(text)) && !TextFilter.hasEnglishWord(text)
        if (!kurdishAlready && !TextFilter.worthTranslating(text)) return   // ژمارە، هێما، S/M/L...

        val norm = norm(text)
        if (norm.length < 2 || similar(norm, lastNorm)) return
        lastNorm = norm

        // ڕستەیەک کە نوێ وەرگێڕدراوە و دووبارە دەرکەوتەوە (OCR ی نەگۆڕ/لەرزۆک): دووبارە وەرناگێڕدرێت و دووبارە ناخوێنرێتەوە،
        // تەنها وەرگێڕانە هەڵگیراوەکە (ئەگەر نووسینەکە شاردرابووەوە) بێ دەنگ دەگەڕێتەوە
        val nowMs = SystemClock.elapsedRealtime()
        while (recent.isNotEmpty() && nowMs - recent.first().second > RECENT_MS) recent.removeFirst()
        if (norm.length >= 6 && recent.any { similar(norm, it.first) }) {
            val again = if (kurdishAlready) text else synchronized(cache) { cache[norm] }
            if (again != null) deliver(nextOrder++, QUIET + again)
            return
        }
        recent.addLast(norm to nowMs)
        if (recent.size > 40) recent.removeFirst()

        // هەر ڕستەیەکی جیاواز ژمارەیەکی ڕیزبەندی وەردەگرێت؛ هیچ ڕستەیەک نافڕێدرێت (پێشتر «زۆر کۆنە» دەفڕێدرا)
        val order = nextOrder++
        if (kurdishAlready) {
            deliver(order, text)
            return
        }
        val prev = ArrayList(history)
        history.add(text)
        while (history.size > 3) history.removeAt(0)

        // وەرگێڕان بە پارالێل: ڕستەی دواتر چاوەڕێی وەرگێڕانی ئەمە ناکات (خێرایی)، ڕیزبەندی بە deliver دەپارێزرێت
        pool.execute {
            var out: String? = null
            try {
                out = synchronized(cache) { cache[norm] }
                    ?: translateHedged(text, prev)?.also { synchronized(cache) { cache[norm] = it } }
            } catch (t: Throwable) {
                Log.w(TAG, "translate: ${t.message}")
            }
            val o = out
            when {
                o == null -> {
                    main.post { if (running) onError("وەرگێڕان سەرنەکەوت (ئینتەرنێت؟)") }
                    deliver(order, null)
                }
                // نەگونجاو بەپێی سەرچاوە (<NONE>، «no text»، درێژیی زۆر) ← بێدەنگ، تەنها شوێنی ڕیزبەندی ئازاد دەکرێت
                !SubtitleGuard.plausibleTranslation(text, o) -> {
                    Log.d(TAG, "implausible translation dropped")
                    deliver(order, null)
                }
                else -> deliver(order, o)
            }
        }
    }

    /** ئەنجامی ڕستەی [order] (null = هیچ؛ HIDE = شاردنەوەی نووسین) بە ڕیز ئازاد دەکات: نووسین + دەنگ. */
    private fun deliver(order: Int, value: String?) {
        main.post {
            if (!running) return@post
            ready[order] = value
            while (ready.containsKey(nextRelease)) {
                val v = ready.remove(nextRelease)
                nextRelease++
                when {
                    v == null -> {}
                    v == HIDE -> try { onCaption(null) } catch (_: Throwable) {}
                    v.startsWith(QUIET) -> try { onCaption(v.substring(QUIET.length)) } catch (_: Throwable) {}   // دووبارە: بێ دەنگ
                    else -> {
                        try { onCaption(v) } catch (_: Throwable) {}
                        enqueueSpeech(v)
                    }
                }
            }
        }
    }

    /** Gemini (٣ دێڕی پێشوو وەک چوارچێوە) + Google ی دواخراو (٧٠٠ms) ← یەکەم وەڵامی بێگەرد دەبات. */
    private fun translateHedged(text: String, prev: List<String>): String? {
        val winner = AtomicReference<String?>(null)
        val latch = CountDownLatch(1)
        fun offer(v: String?) {
            if (!v.isNullOrBlank() && winner.compareAndSet(null, v)) latch.countDown()
        }
        val hasKey = key.isNotBlank()
        if (hasKey) {
            pool.execute { try { offer(geminiLine(text, prev)) } catch (t: Throwable) { Log.w(TAG, "gemini: ${t.message}") } }
        }
        pool.execute {
            try {
                if (hasKey) {
                    // Gemini ی خێرا ئەگەر لە HEDGE_MS دا وەڵامی دایەوە، Google پێویست نییە
                    if (latch.await(HEDGE_MS, TimeUnit.MILLISECONDS)) return@execute
                }
                offer(TextPrep.fixSorani(GoogleTranslator.translateBubble(text, lang) ?: ""))
            } catch (t: Throwable) {
                Log.w(TAG, "google: ${t.message}")
            }
        }
        latch.await(TIMEOUT_MS, TimeUnit.MILLISECONDS)
        return winner.get()
    }

    private fun langName(code: String) = when (code) {
        "en" -> "English"; "ar" -> "Arabic"; "ja" -> "Japanese"; "zh" -> "Chinese"; "ko" -> "Korean"; "hi" -> "Hindi"
        else -> "auto-detect"
    }

    private fun buildPromptHead(): String =
        "Translate ONE video/game subtitle line (" + langName(lang) + ") into natural SPOKEN Central Kurdish (Sorani, Arabic script). " +
            "Translate the meaning of the whole line, never word by word; keep the tone; keep it short enough to speak in the original's time; " +
            "use Sorani letters (ی ک ە ێ ۆ ڵ ڕ ڤ); names transliterated; numbers unchanged; silently fix small OCR mistakes. " +
            "Translate ONLY the given line: never invent, complete or continue text, never repeat the previous lines, never explain. " +
            "If the line is not real readable subtitle text (random characters, symbols, interface noise), output exactly " + SubtitleGuard.NONE + ". " +
            "Output ONLY the Kurdish.\n"

    private fun geminiLine(text: String, prev: List<String>): String? {
        val sb = StringBuilder(promptHead)
        if (prev.isNotEmpty()) {
            sb.append("Previous lines (context only, do NOT translate):\n")
            for (p in prev) sb.append("- ").append(p).append('\n')
        }
        val hints = try { AmbiguityGlossary.hintsFor(ctx, listOf(text), 5, 360) } catch (_: Throwable) { "" }
        if (hints.isNotBlank()) {
            sb.append("Hints for ambiguous words (use a hint only if its meaning fits this sentence):\n").append(hints).append('\n')
        }
        sb.append("Subtitle line:\n").append(text)
        val prompt = sb.toString()

        fun body(model: String, think: Boolean): String {
            val gen = JSONObject().put("temperature", 0.2).put("maxOutputTokens", 256)
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            return JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", gen)
                .toString()
        }

        val out = GeminiKeys.withKeys(key) { k ->
            GeminiModels.call(true) { m, think -> post(body(m, think), k, m) }
        }
        val t = TextPrep.fixSorani(out).trim().trim('"', '«', '»')
        if (t.contains(SubtitleGuard.NONE, ignoreCase = true)) return SubtitleGuard.NONE   // یەکلاکەرەوەیە: Google چاوەڕێ نەکرێت
        return t.takeIf { it.isNotBlank() }
    }

    private fun post(body: String, apiKey: String, model: String): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        var ok = false
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 3_000
            c.readTimeout = 6_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try { JSONObject(resp).getJSONObject("error").getString("message") } catch (_: Exception) { resp }
                throw ApiException(code, "Gemini $code ${why.take(120)}".trim())
            }
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").optJSONArray("parts") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            ok = true
            return sb.toString()
        } finally {
            // دوای وەڵامی تەواو disconnect ناکەین: پەیوەندی TLS دەمێنێتەوە بۆ دێڕی دواتر (≈١٠٠-٣٠٠ms کەمتر)
            if (!ok) c.disconnect()
        }
    }

    // =====================================================================
    // 5) دەنگ: نوێترین دەبات
    // =====================================================================

    private fun enqueueSpeech(t: String) {
        // دەقی زۆر کورت: tts.speak() هیچ callback ێک نادات و دەنگ قفڵ دەبوو
        if (t.trim().length < 2) return
        speechQ.add(t)
        pumpSpeech()
    }

    /** ئەگەر دەنگ بەتاڵە، ڕستە(کان)ی دواتر لە ڕیزدا دەخوێنێتەوە. هەرگیز ڕستەی ئێستا ناپچڕێنێت. */
    private fun pumpSpeech() {
        if (speaking || !running) return
        // ڕستەی تەنیای کورت: کەمێک چاوەڕێ دەکرێت، ئەگەر ڕستەی دواتر هات پێکەوە دەلکێن و دەخوێنرێنەوە (دەنگی ئۆفلاین ڕستەی کورت ناخوێنێتەوە)
        if (speechQ.onlyShort()) {
            val now = SystemClock.elapsedRealtime()
            if (holdSince == 0L) {
                holdSince = now
                main.postDelayed({ pumpSpeech() }, SHORT_HOLD_MS)
                return
            }
            if (now - holdSince < SHORT_HOLD_MS - 50) return
        }
        holdSince = 0L
        val batch = speechQ.take() ?: return
        speaking = true
        val token = ++speakToken
        try { tts.speedBoost = batch.boost } catch (_: Throwable) {}
        // پاسەوانی تەنها بۆ کاتی نەهاتنی callback ی کۆتایی (دەنگ قفڵ نەبێت): ماوەیەکی دڵنیا درێژ، بەپێی درێژی دەق
        val speed = (settings.speechSpeed * batch.boost).coerceAtLeast(0.5f)
        val guardMs = (batch.text.length * 90L / speed + SPEAK_SLACK_MS).toLong().coerceIn(SPEAK_SLACK_MS, MAX_SPEAK_MS)
        main.postDelayed({
            if (token == speakToken && speaking) { speaking = false; pumpSpeech() }
        }, guardMs)
        tts.speak(
            listOf(batch.text),
            onState = { on ->
                if (!on) main.post {
                    if (token == speakToken) {
                        speaking = false
                        if (speechQ.isEmpty()) { try { tts.speedBoost = 1f } catch (_: Throwable) {} }
                        pumpSpeech()
                    }
                }
            },
            onError = { msg ->
                main.post {
                    if (token == speakToken) { speaking = false; pumpSpeech() }
                    if (running) onError(msg)
                }
            }
        )
    }

    // =====================================================================
    // یارمەتیدەرەکان
    // =====================================================================

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }.take(200)

    /** OCR ی هەمان ژێرنووس کەمێک جیاوازە (پیتێک ون یان هەڵە) ← وەک هەمان دێڕ ئەژمار بکە */
    private fun similar(a: String, b: String): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        if (a == b) return true
        val m = maxOf(a.length, b.length)
        if (abs(a.length - b.length) > m / 4) return false
        return lev(a, b) <= (m * 0.18f).toInt()
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    companion object {
        private const val TAG = "LiveSubtitle"
        private const val SIG_N = 32
        /** پانیی وێنەی پشکنینی «نووسینی تێدایە؟» */
        private const val GATE_W = 200
        /** ڕێژەی خانە گۆڕاوەکانی واژۆ کە بە «ڕووبەر گۆڕا» دەژمێردرێت */
        private const val CHANGED_FRACTION = 0.03f
        private const val STABLE_THRESHOLD = 4f
        /** باگراوندی جووڵاو: دوای ئەم ماوەیە بە زۆرەملێ OCR بکە */
        private const val FORCE_MS = 450L
        private const val MIN_GAP_MS = 220L
        private const val HEDGE_MS = 700L
        private const val TIMEOUT_MS = 3500L
        /** زۆرترین پیت لە یەک خوێندنەوەدا کاتێک چەند ڕستە کۆ بوونەوە (بە هەمان ڕیز پێکەوە دەنێردرێن) */
        private const val MAX_MERGED_CHARS = 300
        /** زۆرترین خێراکردنی کاتی بۆ گەیشتن بە ڕیز (لەسەر خێرایی بەکارهێنەر زیاد دەکرێت) */
        private const val MAX_BOOST = 1.3f
        /** پاسەوانی دەنگ (تەنها ئەگەر callback ی کۆتایی نەهات): کەمترین و زۆرترین ماوە */
        private const val SPEAK_SLACK_MS = 10_000L
        private const val MAX_SPEAK_MS = 60_000L
        /** نیشانەی «نووسین بشارەوە» لە ڕیزی ئازادکردندا */
        private const val HIDE = "\u0000HIDE"
        /** پێشگری «تەنها نووسین پیشان بدە، مەیخوێنەوە» (ڕستەی دووبارە) */
        private const val QUIET = "\u0001"
        /** ماوەی بیرکردنەوەی ڕستە وەرگێڕدراوەکان بۆ ڕێگری لە دووبارەوەرگێڕان */
        private const val RECENT_MS = 20_000L
        /** ڕستەی تەنیای کورت (≤٢ وشە) ئەم ماوەیە چاوەڕێ دەکرێت بۆ ڕستەی دواتر تا پێکەوە بخوێنرێنەوە */
        private const val SHORT_HOLD_MS = 900L
        private const val WATCHDOG_MS = 300L
        private const val DESYNC_MS = 700L
    }
}
