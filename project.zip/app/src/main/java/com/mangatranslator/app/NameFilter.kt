package com.mangatranslator.app

/**
 * خشتەی ناوە نەخوێندراوەکان لە وەرگێڕانی زیندوو: ناوێک (بە ئینگلیزی یان هەر زمانێک) کە لە سەرەتای ڕستەدایە لە دەقی سەرچاوە
 * لادەبرێت، بۆیە نە وەردەگێڕدرێت و نە دەنووسرێت و نە دەخوێنرێتەوە. ئەگەر ناوەکە لەناو ڕستەکەدا بێت (نەک سەرەتا) دەمێنێتەوە.
 * فەنکشنی پاک، بێ Android، تاقیکراو.
 *
 * @param strict ئەگەر true بێت، تەنها ئەو کاتە لادەبرێت کە دوای ناوەکە جیاکەرەوەیەک ( : - , | ) بێت یان ناوەکە تەنها بێت.
 *               false (بنەڕەت) = هەرکاتێک لە سەرەتای ڕستەدا بوو.
 */
object NameFilter {
    private val SENTENCES = Regex("(?<=[.!?؟…])\\s+|\\n+")
    private val SEP = Regex("^\\s*([:,;\\-–—|»>]+)?\\s*")

    /** هەر دێڕێک ناوێک؛ «John:» دەنووسرێت «John». دووبارە و بەتاڵ لادەبرێن، درێژترەکان یەکەم. */
    fun parse(raw: String): List<String> =
        raw.lines()
            .map { it.trim().trimEnd(':', ',', '-', '–', '—').trim() }
            .filter { it.isNotEmpty() }
            .distinctBy { it.lowercase() }
            .sortedByDescending { it.length }

    fun strip(text: String, names: List<String>, strict: Boolean = false): String {
        if (names.isEmpty() || text.isBlank()) return text
        val out = ArrayList<String>()
        for (seg in text.trim().split(SENTENCES)) {
            var s = seg.trim()
            var changed = true
            var guard = 0
            while (changed && guard++ < 3) {                  // «John Mary: hi»
                val r = stripLeading(s, names, strict)
                changed = r != s
                s = r
            }
            if (s.any { it.isLetterOrDigit() }) out.add(s)
        }
        return out.joinToString(" ")
    }

    private fun stripLeading(seg: String, names: List<String>, strict: Boolean): String {
        for (n in names) {
            if (seg.length < n.length || !seg.regionMatches(0, n, 0, n.length, ignoreCase = true)) continue
            val rest = seg.substring(n.length)
            // «Johnson» و «John's» ناوی «John» نین
            if (rest.isNotEmpty() && (rest[0].isLetterOrDigit() || rest[0] == '\'' || rest[0] == '’')) continue
            val m = SEP.find(rest)!!
            val hasSep = m.groups[1] != null
            if (strict && rest.isNotBlank() && !hasSep) continue
            return rest.substring(m.value.length)
        }
        return seg
    }
}
