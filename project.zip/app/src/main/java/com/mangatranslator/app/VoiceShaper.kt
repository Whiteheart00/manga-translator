package com.mangatranslator.app

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.tanh

/**
 * دوو دەستکاریی دەنگ بۆ Piper، بێ Android (تاقیکراو لە JVM):
 *  - گڕ (edge، ٠..١٠٠): بەشی بەرزی دەنگ (لە ~١.٥kHz بەرەو سەرەوە) بەهێز دەکات و گڕێکی کەمی تێدەکات؛ دەنگ تیژتر و زیندووتر دەبێت.
 *  - نەرمی (soft، ٠..١٠٠): تیژی و «سسسس»ی دەنگ کەم دەکاتەوە؛ دەنگ گەرمتر و ئارامتر دەبێت.
 * هەردووکیان ٠ = هیچ گۆڕانکارییەک (دەنگی پێشوو وەک خۆی). دەکرێت پێکەوە بەکاربهێنرێن (گڕی نەرم).
 * تەنها بەشی [0, len) دەگۆڕێت. ئاستی دەنگ لە دواتردا بە RMS ی polish یەکسان دەکرێتەوە.
 */
internal object VoiceShaper {
    private const val EDGE_SPLIT_HZ = 1500.0
    private const val SOFT_CUT_HZ = 2600.0

    fun apply(y: FloatArray, len: Int, rate: Int, edge: Int, soft: Int) {
        val n = min(len, y.size)
        if (n <= 0 || rate <= 0) return
        val e = (edge.coerceIn(0, 100)) / 100f
        val s = (soft.coerceIn(0, 100)) / 100f
        if (e > 0f) edge(y, n, rate, e)
        if (s > 0f) soften(y, n, rate, s)
    }

    private fun onePole(rate: Int, fc: Double): Float {
        val f = fc.coerceAtMost(rate * 0.45)
        return (1.0 - exp(-2.0 * PI * f / rate)).toFloat()
    }

    /** presence = دەنگ − بەشی نزم؛ زیادکردنی presence + saturation ی نەرم (tanh) */
    private fun edge(y: FloatArray, n: Int, rate: Int, e: Float) {
        val a = onePole(rate, EDGE_SPLIT_HZ)
        val boost = 1.6f * e
        val drive = 1f + 2.2f * e
        val norm = tanh(drive.toDouble()).toFloat()
        var lp = 0f
        for (i in 0 until n) {
            val x = y[i]
            lp += a * (x - lp)
            val presence = x - lp
            val v = x + presence * boost
            y[i] = tanh((v * drive).toDouble()).toFloat() / norm * (1f / (1f + 0.35f * e))
        }
    }

    /** تێکەڵکردنی دەنگ لەگەڵ وەشانی low-pass ی خۆی (دوو قۆناغ) = تیژی کەم دەبێتەوە */
    private fun soften(y: FloatArray, n: Int, rate: Int, s: Float) {
        val a = onePole(rate, SOFT_CUT_HZ)
        val mix = 0.85f * s
        var s1 = 0f
        var s2 = 0f
        for (i in 0 until n) {
            val x = y[i]
            s1 += a * (x - s1)
            s2 += a * (s1 - s2)
            y[i] = x * (1f - mix) + s2 * mix
        }
    }
}
