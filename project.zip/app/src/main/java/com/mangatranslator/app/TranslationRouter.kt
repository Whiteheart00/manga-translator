package com.mangatranslator.app

import android.util.Log

/**
 * هەڵدەبژێرێت کام وەرگێڕان بەکار بێت. ئەگەر ئۆنلاین شکستی هێنا (ئینتەرنێت نییە، کلیل هەڵەیە،
 * یان Claude وەرگێڕانی ڕەتکردەوە) → Google ئەگەر کلیلی هەبێت → ئۆفلاین NLLB.
 */
class TranslationRouter(
    private val settings: TranslatorSettings,
    private val offline: Translator
) {

    /** بۆ نیشاندانی "مۆدێل بار دەکرێت" تەنها کاتێک پێویستە کە ئۆفلاین بەکار دێت */
    val needsModelLoad: Boolean
        get() = settings.mode == TranslatorSettings.Mode.OFFLINE && !offline.isLoaded

    fun translate(raw: String): String? {
        val text = TextPrep.prepare(raw)
        if (text.length < 2) return null

        val mode = settings.mode
        if (mode == TranslatorSettings.Mode.CLAUDE && settings.claudeKey.isNotBlank()) {
            try {
                return TextPrep.fixSorani(
                    OnlineTranslator.claude(text, settings.claudeKey, settings.adultConfirmed)
                ).ifBlank { null }
            } catch (e: OnlineTranslator.RefusedException) {
                Log.w(TAG, "Claude declined this bubble, falling back")
            } catch (e: Exception) {
                Log.w(TAG, "Claude failed: ${e.message}, falling back")
            }
        }
        if ((mode == TranslatorSettings.Mode.GOOGLE || mode == TranslatorSettings.Mode.CLAUDE) && settings.googleKey.isNotBlank()) {
            try {
                return TextPrep.fixSorani(OnlineTranslator.google(text, settings.googleKey)).ifBlank { null }
            } catch (e: Exception) {
                Log.w(TAG, "Google failed: ${e.message}, falling back")
            }
        }
        // دواهەمین ڕێگە: ئۆفلاین (ئەگەر مۆدێلەکە دابەزێنرابێت)
        return offline.translate(raw)
    }

    fun close() = offline.close()

    companion object {
        private const val TAG = "TranslationRouter"
    }
}
