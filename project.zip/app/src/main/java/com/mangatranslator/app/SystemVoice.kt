package com.mangatranslator.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings

/** چالاک/ناچالاککردنی «دەنگی کوردی وەک دەنگی سیستەم» (KurdishTtsService) و کردنەوەی ڕێکخستنی دەنگی ئەندرۆید. */
object SystemVoice {
    private fun component(ctx: Context) = ComponentName(ctx, KurdishTtsService::class.java)

    fun isEnabled(ctx: Context): Boolean =
        ctx.packageManager.getComponentEnabledSetting(component(ctx)) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED

    /** service ـەکە لە لیستی Text-to-speech engine ی سیستەم دەردەکەوێت/ون دەبێت (بێ داخستنی ئەپەکە) */
    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.packageManager.setComponentEnabledSetting(
            component(ctx),
            if (on) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    /** ڕێکخستنی Text-to-speech ی سیستەم؛ ئەگەر ئەو ڕێکخستنە نەبوو (کۆمپانیاکانی تر)، ڕێکخستنی Accessibility */
    fun openSystemSettings(ctx: Context) {
        val tries = listOf(
            Intent("com.android.settings.TTS_SETTINGS"),
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        )
        for (i in tries) {
            try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Throwable) {}
        }
    }
}
