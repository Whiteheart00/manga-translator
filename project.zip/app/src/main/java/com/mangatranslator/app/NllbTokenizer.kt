package com.mangatranslator.app

import android.util.JsonReader
import android.util.JsonToken
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.text.Normalizer

/**
 * تۆکنایزەری NLLB (SentencePiece Unigram) کە لە tokenizer.json ی HuggingFace دەخوێنێتەوە.
 *
 * نیشانە: ئەمە ڕێکخستنی (normalization) ی SentencePiece بە NFKC نزیک دەکاتەوە،
 * نەک ١٠٠٪ هاوتا. بۆ دەقی ئینگلیزی ئاسایی جیاوازییەکە بێ کاریگەرییە.
 */
class NllbTokenizer(tokenizerFile: File) {

    private val pieceToId = HashMap<String, Int>(300_000)
    private var pieces = ArrayList<String>(262_144)
    private var scores = FloatArray(262_144)
    private val added = HashMap<String, Int>()

    private var unkId = 3
    private var maxPieceLen = 1
    private var minScore = 0f

    /** ژمارەی پارچە ئاساییەکان (بێ نیشانەی زمان). */
    val vocabSize: Int get() = pieces.size

    init {
        load(tokenizerFile)
    }

    fun langId(code: String): Int =
        added[code] ?: throw IllegalStateException("language token not found: $code")

    /** [زمانی سەرچاوە] + پارچەکان + [</s>] */
    fun encode(text: String, srcLang: String, maxTokens: Int = 120): LongArray {
        val body = tokenize(text)
        val limited = if (body.size > maxTokens) body.subList(0, maxTokens) else body
        val out = LongArray(limited.size + 2)
        out[0] = langId(srcLang).toLong()
        for (i in limited.indices) out[i + 1] = limited[i].toLong()
        out[out.size - 1] = EOS.toLong()
        return out
    }

    fun decode(ids: List<Int>): String {
        val sb = StringBuilder()
        for (id in ids) {
            if (id < 4 || id >= pieces.size) continue
            sb.append(pieces[id])
        }
        return sb.toString().replace('▁', ' ').trim()
    }

    // ---------- Unigram Viterbi ----------

    private fun tokenize(raw: String): List<Int> {
        var s = Normalizer.normalize(raw, Normalizer.Form.NFKC)
        s = s.replace(Regex("\\s+"), " ").trim()
        if (s.isEmpty()) return emptyList()
        s = "▁" + s.replace(' ', '▁')

        val n = s.length
        val best = FloatArray(n + 1) { Float.NEGATIVE_INFINITY }
        val backPos = IntArray(n + 1)
        val backId = IntArray(n + 1)
        best[0] = 0f
        val unkScore = minScore - 10f

        for (i in 0 until n) {
            if (best[i] == Float.NEGATIVE_INFINITY) continue
            var matchedSingle = false
            val maxLen = minOf(maxPieceLen, n - i)
            for (len in 1..maxLen) {
                val id = pieceToId[s.substring(i, i + len)] ?: continue
                if (len == 1) matchedSingle = true
                val cand = best[i] + scores[id]
                if (cand > best[i + len]) {
                    best[i + len] = cand
                    backPos[i + len] = i
                    backId[i + len] = id
                }
            }
            if (!matchedSingle) {
                val cand = best[i] + unkScore
                if (cand > best[i + 1]) {
                    best[i + 1] = cand
                    backPos[i + 1] = i
                    backId[i + 1] = unkId
                }
            }
        }

        val out = ArrayList<Int>()
        var pos = n
        while (pos > 0) {
            out.add(backId[pos])
            pos = backPos[pos]
        }
        out.reverse()
        return out
    }

    // ---------- خوێندنەوەی tokenizer.json بە stream ----------

    private fun load(file: File) {
        JsonReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8).buffered()).use { r ->
            r.beginObject()
            while (r.hasNext()) {
                when (r.nextName()) {
                    "added_tokens" -> readAdded(r)
                    "model" -> readModel(r)
                    else -> r.skipValue()
                }
            }
            r.endObject()
        }
        check(pieces.size > 1000) { "tokenizer vocab not loaded" }
    }

    private fun readAdded(r: JsonReader) {
        r.beginArray()
        while (r.hasNext()) {
            var id = -1
            var content = ""
            r.beginObject()
            while (r.hasNext()) {
                when (r.nextName()) {
                    "id" -> id = r.nextInt()
                    "content" -> content = r.nextString()
                    else -> r.skipValue()
                }
            }
            r.endObject()
            if (id >= 0) added[content] = id
        }
        r.endArray()
    }

    private fun readModel(r: JsonReader) {
        r.beginObject()
        while (r.hasNext()) {
            when (r.nextName()) {
                "unk_id" -> {
                    if (r.peek() == JsonToken.NULL) r.nextNull() else unkId = r.nextInt()
                }
                "vocab" -> {
                    r.beginArray()
                    var idx = 0
                    while (r.hasNext()) {
                        r.beginArray()
                        val piece = r.nextString()
                        val score = r.nextDouble().toFloat()
                        r.endArray()

                        if (idx >= scores.size) scores = scores.copyOf(scores.size * 2)
                        scores[idx] = score
                        pieces.add(piece)
                        if (idx >= 4) { // ٠..٣ = نیشانە تایبەتەکان
                            pieceToId[piece] = idx
                            if (piece.length > maxPieceLen) maxPieceLen = minOf(piece.length, 32)
                            if (score < minScore) minScore = score
                        }
                        idx++
                    }
                    r.endArray()
                }
                else -> r.skipValue()
            }
        }
        r.endObject()
    }

    companion object {
        const val EOS = 2
    }
}
