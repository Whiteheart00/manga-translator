package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * OCR بە Tesseract بۆ هەر زمانێک (ara، jpn، jpn_vert، chi_sim، chi_tra، kor، kor_vert).
 * - عەرەبی: ML Kit پشتیوانی ناکات، بۆیە Tesseract ی `ara` بەکاردێت.
 * - جاپانیی ستوونی (`jpn_vert`): یەدەگی ML Kit ـە ئەگەر ML Kit دەقی نەدۆزییەوە.
 * فایلی زمان (~١-٣MB) خۆکارانە دادەبەزێت (tessdata_fast) و دواتر ئۆفلاین کار دەکات.
 * هەموو بانگەکان دەبێت لە thread ی پاشبنەما بن.
 */
object TessOcr {
    private const val TAG = "TessOcr"

    const val ARA = "ara"
    const val JPN_VERT = "jpn_vert"

    /** فایلە زمانییەکان کە لە یەکەم کردنەوەدا دادەبەزێن (لەگەڵ شاشەی ئامادەکردن) */
    val FIRST_RUN = listOf(ARA, JPN_VERT)

    private val lock = Any()
    private val apis = HashMap<String, TessBaseAPI>()

    private fun dataFile(ctx: Context, lang: String) = File(ctx.filesDir, "tess/tessdata/$lang.traineddata")

    private fun urls(lang: String) = listOf(
        "https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata",
        "https://github.com/tesseract-ocr/tessdata/raw/main/$lang.traineddata"
    )

    private fun isCjk(lang: String) = lang.startsWith("jpn") || lang.startsWith("chi") || lang.startsWith("kor")

    private fun minConf(lang: String) = if (isCjk(lang)) 45 else 20

    /** ئایا دەقی دۆزراوە بەڕاستی بە پیتی ئەو زمانەیە (بۆ دەرکردنی تێکچوون و دەنگی وێنە) */
    private fun valid(lang: String, t: String): Boolean = when {
        lang == ARA -> t.count { it.code in 0x0600..0x06FF } >= 2
        lang.startsWith("jpn") -> t.count { it.code in 0x3040..0x30FF || it.code in 0x4E00..0x9FFF } >= 2
        lang.startsWith("chi") -> t.count { it.code in 0x4E00..0x9FFF } >= 2
        lang.startsWith("kor") -> t.count { it.code in 0xAC00..0xD7AF } >= 2
        else -> t.length >= 2
    }

    fun isInstalled(ctx: Context, lang: String = ARA): Boolean =
        dataFile(ctx, lang).let { it.exists() && it.length() > 100_000 }

    fun allInstalled(ctx: Context): Boolean = FIRST_RUN.all { isInstalled(ctx, it) }

    /** null = سەرکەوتوو، دەنا پەیامی هەڵە */
    fun download(ctx: Context, lang: String = ARA): String? {
        val f = dataFile(ctx, lang)
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, "$lang.tmp")
        val errs = ArrayList<String>()
        for (u in urls(lang)) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", "MangaTranslator/1.0")
                if (c.responseCode !in 200..299) { errs.add("HTTP ${c.responseCode}"); c.disconnect(); continue }
                c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                c.disconnect()
                if (tmp.length() < 100_000) { tmp.delete(); errs.add("فایلەکە بچووکە"); continue }
                if (f.exists()) f.delete()
                if (tmp.renameTo(f)) return null
                errs.add("نەتوانرا ناوەکەی بگۆڕدرێت")
            } catch (t: Throwable) {
                tmp.delete()
                errs.add(t.message ?: t.javaClass.simpleName)
            }
        }
        return "داگرتنی OCR ($lang) سەرنەکەوت (" + errs.distinct().joinToString("، ") + ")"
    }

    /** لە بانگکەرەوە لە ناو lock بانگ دەکرێت */
    private fun engine(ctx: Context, lang: String): TessBaseAPI? {
        apis[lang]?.let { return it }
        return try {
            TessBaseAPI().let {
                if (!it.init(File(ctx.filesDir, "tess").absolutePath, lang)) { it.recycle(); return null }
                it.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
                apis[lang] = it
                it
            }
        } catch (t: Throwable) {
            Log.e(TAG, "init failed ($lang)", t); null
        }
    }

    /**
     * ئامادەکردنی وێنە بۆ Tesseract: خۆڵەمێشی + کۆنتراستی زیاتر، و گەورەکردن ئەگەر وێنەکە بچووک بوو.
     * scale = چەند هێندە گەورە کراوە (بۆ گەڕاندنەوەی شوێنی بلۆکەکان بۆ وێنە ڕەسەنەکە).
     */
    private fun prepare(src: Bitmap, invert: Boolean = false): Pair<Bitmap, Float> {
        val longest = maxOf(src.width, src.height)
        val scale = if (longest in 1..1399) minOf(2f, 2000f / longest) else 1f
        val w = (src.width * scale).toInt().coerceAtLeast(1)
        val h = (src.height * scale).toInt().coerceAtLeast(1)
        return try {
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cm = ColorMatrix().apply { setSaturation(0f) }
            if (invert) {
                // دەقی سپی لەسەر باگراوندی ڕەش (وەک کاپشنی مانگا) ← ڕەش لەسەر سپی، چونکە Tesseract بەو شێوەیە باشە
                cm.postConcat(ColorMatrix(floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )))
            }
            val c = 1.4f              // کۆنتراست
            val t = (-0.5f * c + 0.5f) * 255f
            cm.postConcat(ColorMatrix(floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )))
            val p = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
            Canvas(out).drawBitmap(src, null, Rect(0, 0, w, h), p)
            out to scale
        } catch (t: Throwable) {
            Log.w(TAG, "prepare failed, using original", t)
            src to 1f
        }
    }

    /** بلۆکە دەقییەکان لەسەر وێنەکە. ئەگەر فایلی زمان نەبوو، هەوڵی داگرتن دەدات. */
    fun recognize(ctx: Context, bmp: Bitmap, lang: String = ARA, onNotice: (String) -> Unit = {}): List<TextBox> {
        if (!isInstalled(ctx, lang)) {
            onNotice("OCR ($lang) دادەبەزێت (یەکجار)…")
            val err = download(ctx, lang)
            if (err != null) { onNotice(err); return emptyList() }
        }
        var normal = pass(ctx, bmp, lang, false)
        // عەرەبی: بەشێکی زۆری مانگا دەقی سپییە لەسەر ڕەش؛ پاسێکی وەرگەڕاویش دەکرێت و ئەنجامە نوێیەکان زیاد دەکرێن
        if (lang != ARA) return normal
        // دەقی ڕەنگاوڕەنگ لە grayscale زۆرجار لەگەڵ باگراوند تێکەڵ دەبێت.
        // ئەم پاسە تەنها کاتێک بەکاردێت کە پیکسڵی ڕەنگاوڕەنگ هەبێت؛ دەقی سپی/خۆڵەمێشی پاسە کۆنەکە بەکار دەهێنێت.
        val colored = colorPass(ctx, bmp, lang)
        if (colored.isNotEmpty() && quality(colored) > quality(normal)) normal = colored
        // ڕامی کەم: پاسی وەرگەڕاو (کاتی دووقات + bitmap ی زیاتر) تەنها کاتێک ئەگەر یەکەم پاس کەمی دۆزییەوە
        if (DeviceProfile.low && normal.size >= 3) return normal
        val inv = pass(ctx, bmp, lang, true)
        if (inv.isEmpty()) return normal
        val extra = inv.filter { a -> normal.none { n -> TextFilter.overlapsMostly(a.rect, n.rect) } }
        return normal + extra
    }

    private fun quality(items: List<TextBox>): Int =
        items.sumOf { b -> b.text.count { it.code in 0x0600..0x06FF } + b.text.trim().split(Regex("\\s+")).count() * 2 }

    private data class ColoredPrepared(val bitmap: Bitmap, val scale: Float, val pad: Int)

    /** ڕەنگەکان ڕەش و پاشبنەما سپی دەکات؛ threshold ـەکان لە تاقیکردنەوەی colored subtitle هاتوون. */
    private fun prepareColored(src: Bitmap): ColoredPrepared? {
        val longest = maxOf(src.width, src.height)
        val scale = minOf(1f, 960f / longest.coerceAtLeast(1))
        val scaled = if (scale < 1f) Bitmap.createScaledBitmap(
            src, (src.width * scale).toInt().coerceAtLeast(1),
            (src.height * scale).toInt().coerceAtLeast(1), true
        ) else src
        val w = scaled.width
        val h = scaled.height
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        if (scaled !== src) scaled.recycle()
        var colored = 0
        val mask = IntArray(px.size)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val yes = maxOf(r, g, b) - minOf(r, g, b) > 75 && maxOf(r, g, b) > 115
            if (yes) { mask[i] = Color.BLACK; colored++ } else mask[i] = Color.WHITE
        }
        if (colored < (px.size / 500).coerceAtLeast(12)) return null
        val pad = 12
        val outW = w + pad * 2
        val outH = h + pad * 2
        val out = IntArray(outW * outH) { Color.WHITE }
        for (y in 0 until h) System.arraycopy(mask, y * w, out, (y + pad) * outW + pad, w)
        return ColoredPrepared(Bitmap.createBitmap(out, outW, outH, Bitmap.Config.ARGB_8888), scale, pad)
    }

    private fun colorPass(ctx: Context, bmp: Bitmap, lang: String): List<TextBox> {
        val prep = try { prepareColored(bmp) } catch (t: Throwable) {
            Log.w(TAG, "colored prepare failed", t); return emptyList()
        } ?: return emptyList()
        return try {
            synchronized(lock) {
                val t = engine(ctx, lang) ?: return emptyList()
                t.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK)
                t.setImage(prep.bitmap)
                t.getUTF8Text()
                val out = ArrayList<TextBox>()
                val it = t.resultIterator
                if (it != null) {
                    val lvl = TessBaseAPI.PageIteratorLevel.RIL_PARA
                    val minC = minConf(lang)
                    it.begin()
                    do {
                        val txt = (it.getUTF8Text(lvl) ?: "").replace(Regex("\\s+"), " ").trim()
                        val conf = it.confidence(lvl)
                        val r = it.getBoundingRect(lvl)
                        if (r != null && conf >= minC && valid(lang, txt)) {
                            val left = ((r.left - prep.pad) / prep.scale).toInt().coerceIn(0, bmp.width)
                            val top = ((r.top - prep.pad) / prep.scale).toInt().coerceIn(0, bmp.height)
                            val right = ((r.right - prep.pad) / prep.scale).toInt().coerceIn(left + 1, bmp.width)
                            val bottom = ((r.bottom - prep.pad) / prep.scale).toInt().coerceIn(top + 1, bmp.height)
                            out.add(TextBox(Rect(left, top, right, bottom), txt))
                        }
                    } while (it.next(lvl))
                    it.delete()
                }
                t.clear()
                t.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
                out
            }
        } catch (t: Throwable) {
            Log.e(TAG, "colored OCR failed", t); emptyList()
        } finally {
            prep.bitmap.recycle()
        }
    }

    private fun pass(ctx: Context, bmp: Bitmap, lang: String, invert: Boolean): List<TextBox> {
        val (img, scale) = prepare(bmp, invert)
        return try {
            synchronized(lock) {
                val t = engine(ctx, lang) ?: return emptyList()
                t.setImage(img)
                t.getUTF8Text() // دەبێتە هۆی ناسینەوە
                val out = ArrayList<TextBox>()
                val it = t.resultIterator
                if (it != null) {
                    val lvl = TessBaseAPI.PageIteratorLevel.RIL_PARA
                    val cjk = isCjk(lang)
                    val minC = minConf(lang)
                    it.begin()
                    do {
                        val txt = (it.getUTF8Text(lvl) ?: "").replace(Regex("\\s+"), if (cjk) "" else " ").trim()
                        val conf = it.confidence(lvl)
                        val r = it.getBoundingRect(lvl)
                        if (r != null && conf >= minC && valid(lang, txt)) {
                            val rect = if (scale == 1f) r else Rect(
                                (r.left / scale).toInt(), (r.top / scale).toInt(),
                                (r.right / scale).toInt(), (r.bottom / scale).toInt()
                            )
                            out.add(TextBox(rect, txt))
                        }
                    } while (it.next(lvl))
                    it.delete()
                }
                t.clear()
                out
            }
        } catch (t: Throwable) {
            Log.e(TAG, "recognize failed ($lang)", t)
            emptyList()
        } finally {
            if (img !== bmp) img.recycle()
        }
    }

    fun release() {
        synchronized(lock) {
            for (a in apis.values) try { a.recycle() } catch (_: Throwable) {}
            apis.clear()
        }
    }
}
