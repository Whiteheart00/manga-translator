package com.mangatranslator.app

import android.content.Context
import android.util.Log
import org.vosk.Model
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * ناسینەوەی قسەی ئینگلیزی بە شێوەی ئۆفلاین (Vosk) — بێ ئینتەرنێت و بێ کلیل.
 * تەنها وەرگێڕانی دەق بۆ کوردی ئینتەرنێت دەوێت.
 * مۆدێلی پێشنیارکراو: vosk-model-small-en-us-0.15 (نزیکەی ٤٠MB)، یەکجار دادەبەزێت.
 */
object LiveStt {
    private const val TAG = "LiveStt"
    const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    @Volatile private var model: Model? = null
    private val lock = Any()

    fun modelDir(filesDir: File) = File(filesDir, "vosk_en")

    /** فۆڵدەری مۆدێلی Vosk هەمیشە conf/model.conf و فۆڵدەری am ی تێدایە */
    private fun valid(d: File) = File(d, "conf/model.conf").exists() && File(d, "am").isDirectory

    fun isInstalled(filesDir: File) = valid(modelDir(filesDir))

    fun reset() {
        synchronized(lock) {
            try { model?.close() } catch (_: Throwable) {}
            model = null
        }
    }

    /** مۆدێلەکە یەکجار بار دەکات (لە یەکەم جاردا چەند چرکەیەک دەخایەنێت) */
    fun load(filesDir: File): Model {
        model?.let { return it }
        synchronized(lock) {
            model?.let { return it }
            val d = modelDir(filesDir)
            if (!valid(d)) throw RuntimeException("مۆدێلی گوێگرتنی ئینگلیزی نەهێنراوە")
            val m = Model(d.absolutePath)
            model = m
            return m
        }
    }

    /** zip ی مۆدێل دەکاتەوە؛ فۆڵدەری سەرووی zip (vosk-model-.../) لادەبرێت. */
    private fun unzip(ins: java.io.InputStream, dest: File): String? {
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        ZipInputStream(ins.buffered()).use { zin ->
            while (true) {
                val en = zin.nextEntry ?: break
                if (en.isDirectory) continue
                val target = File(tmp, en.name)
                // پاراستن لە zip-slip
                if (!target.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) continue
                target.parentFile?.mkdirs()
                target.outputStream().use { zin.copyTo(it) }
            }
        }
        val root = if (valid(tmp)) tmp else tmp.listFiles()?.firstOrNull { it.isDirectory && valid(it) }
        if (root == null) {
            tmp.deleteRecursively()
            return "ئەم zip ـە مۆدێلی Vosk نییە"
        }
        dest.deleteRecursively()
        if (!root.renameTo(dest)) {
            tmp.deleteRecursively()
            return "نەتوانرا مۆدێلەکە دابنرێت"
        }
        tmp.deleteRecursively()
        return null
    }

    /** مۆدێلی ئینگلیزی دادەبەزێنێت (تاکە جار کە گوێگرتن ئینتەرنێتی دەوێت). null = سەرکەوتوو. لە thread ی پاشبنەما بانگ بکرێت. */
    fun download(ctx: Context, progress: (Int) -> Unit): String? {
        reset()
        val zip = File(ctx.cacheDir, "vosk_en.zip")
        var c: HttpURLConnection? = null
        return try {
            c = URL(MODEL_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.instanceFollowRedirects = true
            val code = c.responseCode
            if (code !in 200..299) return "داگرتن سەرنەکەوت: HTTP $code"
            val total = c.contentLengthLong
            var got = 0L
            var last = -1
            c.inputStream.use { ins ->
                zip.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        if (total > 0) {
                            val p = (got * 100 / total).toInt()
                            if (p != last) { last = p; progress(p) }
                        }
                    }
                }
            }
            zip.inputStream().use { unzip(it, modelDir(ctx.filesDir)) }
        } catch (e: Throwable) {
            Log.e(TAG, "download failed", e)
            "داگرتن سەرنەکەوت: ${e.message}"
        } finally {
            try { c?.disconnect() } catch (_: Throwable) {}
            zip.delete()
        }
    }
}
