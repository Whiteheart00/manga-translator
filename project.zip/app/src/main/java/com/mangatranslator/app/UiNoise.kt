package com.mangatranslator.app

/**
 * فلتەری دەقی بێ پێویستی ڕووکاری ئەپەکان (فەیسبووک، مسنجەر، ئینستاگرام، تیکتۆک، تیلیگرام، واتسئاپ…):
 *  - کات و بەروار:  2h · 3 min ago · Yesterday at 5:30 PM · 10:45 · پێش ٢ کاتژمێر · منذ ساعتين
 *  - ژمارەی کارلێک: 1.2K · 34 likes · ٣ کۆمێنت
 *  - دوگمە و تابەکان: Like · Comment · Share · Reply · See more · Create story · بەدڵ · هاوبەشکردن
 *  - دۆخی چات:       Seen · Typing… · Active now · online · last seen · ئۆنلاین
 *
 * دوو ئاستی هەیە:
 *  - strict (ui=false): تەنها ئەو شتانەی ژمارەیان تێدایە (کات/بەروار/ژمارە). بۆ OCR ی وێنە/مانگا بەکاردێت،
 *    چونکە وشەی وەک "Now" یان "Back" لەوانەیە قسەی ڕاستەقینەی کارەکتەرێک بن.
 *  - ui=true: وشە و دەستەواژەی دوگمەکانیش. تەنها بۆ دەقی Accessibility (ئەو دەقانەی ڕاستەقینە لە ڕووکاری ئەپەوە دێن).
 * هەمیشە لە یەکسانبوونی تەواوی دەقەکە دەپشکنرێت (نەک بەشێکی)، و دەقی درێژ (>120 پیت) هەرگیز فلتەر ناکرێت.
 */
object UiNoise {

    private const val MAX_LABEL_LEN = 120
    private const val MON = "jan(uary)?|feb(ruary)?|mar(ch)?|apr(il)?|may|jun(e)?|jul(y)?|aug(ust)?|sep(t|tember)?|oct(ober)?|nov(ember)?|dec(ember)?"
    private const val WD = "mon(day)?|tue(s|sday)?|wed(nesday)?|thu(r|rs|rsday)?|fri(day)?|sat(urday)?|sun(day)?"
    private const val UNITS_EN = "sec|secs|second|seconds|min|mins|minute|minutes|hr|hrs|hour|hours|day|days|wk|wks|week|weeks|mo|mos|month|months|yr|yrs|year|years"
    private const val UNITS_KU = "چرکە|خولەک|کاتژمێر|سەعات|ڕۆژ|رۆژ|هەفتە|مانگ|ساڵ"
    private const val COUNT_UNITS = "likes?|comments?|shares?|views?|replies|reply|followers?|following|posts?|plays?|reactions?|retweets?|reposts?|members|subscribers|online|watching|saves?|تعلیق|تعلیقات|مشارکة|مشارکات|مشاهدة|مشاهدات|اعجاب|إعجاب|متابع|متابعین|ردود|بەدڵ|لایک|کۆمێنت|کۆمێنتەکان|هاوبەشکردن|شێر|بینین|بینەر|فۆڵۆوەر|وەڵام"

    private fun r(p: String) = Regex(p)

    // ⚠ ئەم دووانە دەبێت پێش UI_WORDS بن (نابێت بگوازرێنەوە خوارەوە)
    private val WS = Regex("\\s+")
    private val EDGE = Regex("^[\\s·•|:.…,'’\\-]+|[\\s·•|:.…,'’\\-]+$")

    // ---------- strict: هەمیشە (ژمارەیان تێدایە) ----------
    private val TIME: List<Regex> = listOf(
        r("""^\d{1,2}:\d{2}(:\d{2})?\s?(am|pm|ص|م)?$"""),                                              // 10:45 · 3:10 pm
        r("""^\d+(s|m|h|d|w|y)(\s+ago)?$"""),                                                           // 2h · 3m (پیتی تاک: بێ بۆشایی)
        r("""^\d+\s?(${UNITS_EN})(\s+ago)?$"""),                                                       // 5 min ago · 2 hours
        r("""^(today|yesterday|tomorrow|${WD})(,|\s+at)?\s*(\d{1,2}:\d{2}\s?(am|pm)?)?$"""),           // yesterday at 5:30 pm · mon 10:45  (تەنها ئەگەر کات هەبێت، خوارەوە)
        r("""^(${WD}),?\s+(${MON})\.?\s+\d{1,2}(st|nd|rd|th)?(,?\s+\d{4})?(\s+at\s+\d{1,2}:\d{2}\s?(am|pm)?)?$"""),
        r("""^(${MON})\.?\s+\d{1,2}(st|nd|rd|th)?(,?\s+\d{4})?(\s+at\s+\d{1,2}:\d{2}\s?(am|pm)?)?$"""),   // oct 27 · october 27, 2026 at 3:10 pm
        r("""^(${WD},?\s+)?\d{1,2}(st|nd|rd|th)?\s+(${MON})\.?(,?\s+\d{4})?(\s+at\s+\d{1,2}:\d{2}\s?(am|pm)?)?$"""), // 27 oct 2026
        r("""^(${MON})\.?,?\s+\d{4}$"""),
        r("""^\d{1,4}[/.\-]\d{1,2}[/.\-]\d{1,4}(\s+\d{1,2}:\d{2})?$"""),                                   // 27/10/2026 · 2026-10-27
        r("""^(منذ|قبل)\s+(\d+\s+)?(ثانی|ثوان|دقیق|دقائق|ساع|یوم|ایام|أیام|اسبوع|أسبوع|شهر|اشهر|أشهر|سن|عام|أعوام).{0,12}$"""), // منذ ساعتين
        r("""^(پێش\s+)?\d+\s?(${UNITS_KU})(ی|ێک)?(\s+(لەمەوپێش|لەمەوبەر|پێشتر|پێش))?$"""),                // پێش 2 کاتژمێر · 3 خولەک
        r("""^\d+\s?(${UNITS_KU})\s+(لەمەوپێش|لەمەوبەر|پێشتر|پێش)$""")
    )

    // ژمارەی کارلێک (strict)
    private val COUNT: List<Regex> = listOf(
        r("""^\d[\d.,]*[kmb]?(\s+(${COUNT_UNITS}))?$""")                                               // 1.2k · 34 likes · 12 بەدڵ
    )

    // "yesterday"/"today" بە تەنها (بێ کات) دەخرێتە ئاستی ui، چونکە لەوانەیە قسەی ڕاستەقینە بێت
    private val DAYWORD_ONLY = r("""^(today|yesterday|tomorrow|${WD})$""")

    // ---------- ui: وشە و دەستەواژەی ڕووکار (تەنها Accessibility) ----------
    private val UI_PATTERNS: List<Regex> = listOf(
        r("""^(just now|now|seen|delivered|sent|read|edited|active|typing|online|offline)( (now|just now|today|yesterday|\d+\s?\w+( ago)?)( at .*)?)?$"""),
        r("""^last (seen|active)\b.{0,30}$"""),
        r("""^(view|see|show|load)( all| more| previous| older| \d+)*( comments?| replies| reply| messages?)$"""),
        r("""^(add|write|type|leave)( a| an| your)? (comment|reply|message|story|note|friend|to story|to your story)\b.{0,20}$"""),
        r("""^(liked|reacted|replied|commented|shared) (by|to)\b.{0,40}$"""),
        r("""^(original (sound|audio)|suggested for you|people you may know|sponsored|promoted)\b.{0,50}$"""),
        r("""^(tap|swipe|double tap|click|press|hold) to\b.{0,25}$"""),
        r("""^swipe (up|left|right|down)\b.{0,20}$"""),
        r("""^(forwarded from|replying to|reply to)\b.{0,40}$"""),
        r("""^\d+ (new )?(messages?|notifications?|unread( messages?)?|mutual friends?)$"""),
        r("""^(#\S+\s*)+$"""),                                                                           // تەنها هاشتاگ
        r("""^@\S+$"""),                                                                              // تەنها @ناوی بەکارهێنەر
        r("""^(?=[a-z0-9._]*[0-9_.])[a-z0-9._]{4,30}$"""),                                            // hoshmand444 (ناوی بەکارهێنەر)
        r("""^(آخر ظهور|اخر ظهور)\b.{0,30}$"""),
        r("""^(متصل|نشط)( الان| الآن| منذ.*)?$"""),
        r("""^(اکتب|اکتبی)\s+(تعلیق|رسالة|رد).{0,20}$"""),
        r("""^(دوایین جار|دواین جار)\s+.{0,30}$"""),
        r("""^(چالاکە|ئۆنلاین)( ئێستا| پێش.*)?$"""),
        r("""^(کۆمێنتێک|نامەیەک|وەڵامێک)\s+(بنووسە|بنووسە).{0,20}$"""),
        r("""^(بینینی|پیشاندانی)\s+(هەموو\s+)?(کۆمێنت|وەڵام|وەرگێڕان|زیاتر)\S*$"""),
        r("""^(ئێستا|ئەمڕۆ|ئەمرۆ|دوێنێ|دوێنی|سبەی)$"""),
        r("""^(الان|الآن|امس|أمس|الیوم|البارحة|غدا|غداً)$""")
    )

    private val UI_WORDS: Set<String> = listOf(
        // English — فەیسبووک / مسنجەر / ئینستاگرام / تیکتۆک / تیلیگرام / واتسئاپ
        "like", "liked", "likes", "comment", "comments", "share", "shares", "send", "reply", "replies", "see more", "see less",
        "see translation", "see original", "see all", "view more", "view more comments", "view previous comments", "write a comment",
        "add a comment", "add comment", "add a reply", "follow", "following", "followed", "followers", "follower", "unfollow",
        "add friend", "add story", "add to story", "create story", "your story", "your note", "story", "stories", "reels", "reel",
        "marketplace", "notifications", "notification", "search", "settings", "edit",
        "delete", "report", "hide", "save", "saved", "copy", "forward", "pin", "pinned", "mute", "muted", "video call",
        "voice call", "message", "messages", "new message", "type a message", "chats", "chat", "calls", "contacts", "people",
        "discover", "inbox", "requests", "archive", "archived", "sponsored", "promoted", "ad", "ads", "advertisement", "joined", "invite",
        "groups", "pages", "events", "only me", "retry", "load more", "unread",
        "for you", "profile", "photo", "photos", "video", "videos", "gif", "sticker", "stickers", "camera", "gallery",
        "microphone", "emoji", "attach", "learn more",
        "not interested", "duet", "stitch", "remix", "original sound", "pinned message", "channel", "channels", "broadcast",
        "today", "yesterday", "tomorrow", "just now",
        // Arabic
        "اعجاب", "إعجاب", "أعجبني", "تعلیق", "تعلیقات", "مشارکة", "ارسال", "إرسال", "ردود", "عرض المزید", "شاهد المزید", "عرض الترجمة",
        "متابعة", "متابعون", "إضافة قصة", "إنشاء قصة", "قصتك", "الرئیسیة", "الإشعارات", "القائمة", "رسالة", "الرسائل", "اکتب رسالة",
        "متصل", "متصل الآن", "یکتب", "تمت المشاهدة", "تم التسلیم", "تم الإرسال", "إعلان", "ممول", "مقترح لک", "إلغاء", "حذف", "تعدیل",
        "مشاهدات", "أصدقاء", "الملف الشخصی", "الإعدادات", 
        // Kurdish (Sorani)
        "بەدڵ", "لایک", "کۆمێنت", "کۆمێنتەکان", "هاوبەشکردن", "ناردن", "وەڵامدانەوە", "وەڵام", 
        "پیشاندانی وەرگێڕان", "فۆڵۆ", "فۆڵۆو", "فۆڵۆوکردن", "چیرۆکەکەت", "چیرۆک زیادبکە", "ئاگادارکردنەوەکان",
        "مێنیو", "نامەکان", "نامەیەک بنووسە", "کۆمێنتێک بنووسە", "ئۆنلاین", "چالاکە", "ئێستا چالاکە", "دوایین جار بینراوە", "دەنووسێت",
        "بینراوە", "نێردرا", "ڕیکلام", "پەسەندکراو", "پێشنیارکراو", "هەڵگرتن", "لابردن", "سڕینەوە", "دەستکاری", "پاشگەزبوونەوە",
        "دۆستەکان", "چاتەکان", "پرۆفایل", "ڕێکخستنەکان", 
    ).map { norm(it) }.toHashSet()

    private val ID_NOISE = Regex("""(^|_)(time|timestamp|date|seen|badge|unread|counter|toolbar|tab|tabs|nav|navigation|bottom_bar|action_bar|status_bar|username|handle|avatar|reaction|reactions)(_|$)""")

    // ---------- ئامادەکردنی دەق ----------
    // WS و EDGE لە سەرەوەن (پێش UI_WORDS): ئۆبجێکتی Kotlin گۆڕاوەکان بە ڕیزی نووسین دروست دەکات،
    // ئەگەر دوای UI_WORDS بوونایە لەکاتی دروستکردنی لیستەکە null دەبوون ← NullPointerException ← کڕاشی ئەپ.
    private fun norm(raw: String): String = strip(clean(raw))

    /** ژمارەی عەرەبی/فارسی ← ئینگلیزی، ي/ك/ى ← ی/ک، ئیمۆجی و هێما و ڕیزبەند لادەبرێن، پیتی لاتینی بچووک دەکرێت */
    private fun clean(raw: String): String {
        val sb = StringBuilder(raw.length)
        for (ch0 in raw) {
            var ch = ch0
            when (ch) {
                in '\u0660'..'\u0669' -> ch = '0' + (ch - '\u0660')
                in '\u06F0'..'\u06F9' -> ch = '0' + (ch - '\u06F0')
                '\u064A', '\u0649' -> ch = '\u06CC'
                '\u0643' -> ch = '\u06A9'
            }
            if (ch.isLetterOrDigit() || ch.isWhitespace() || ch in ":/.,'’-#@·•|…") sb.append(Character.toLowerCase(ch))
        }
        return sb.toString().replace(WS, " ").trim()
    }

    private fun strip(s: String) = s.replace(EDGE, "").trim()

    // ---------- API ----------

    private fun isTime(c: String) = TIME.any { it.matches(c) } && !DAYWORD_ONLY.matches(c)

    // «لۆدینگ»: دەقی چاوەڕێکردن لە ئەپەکان (بۆ ئەوەی هەرگیز نەخوێندرێتەوە و وەرنەگێڕدرێت)
    // تێبینی: دەق پێش پشکنین بە clean() ئاسایی دەکرێت (ي→ی، ك→ک، نیشانەکانی دەنگ لادەچن)، بۆیە پیتی ئاسایکراو بەکاردێت.
    // وشەی وەک "wait" / "انتظر" / "چاوەڕێبە" بە ئەنقەست نین، چونکە قسەی ڕاستەقینەی کارەکتەرێکن لە مانگا.
    private val LOADING = Regex(
        """^(loading|please wait|buffering|translating|processing|refreshing|updating|connecting)( more| comments| messages| content)?$|""" +
            """^(جاری التحمیل|جار التحمیل|تحمیل|الرجاء الانتظار|یرجی الانتظار|جاری الارسال|جاری الإرسال|جاری البحث|جاری الاتصال)$|""" +
            """^(لۆدینگ|لۆد دەکرێت|بار دەکرێت|بارکردن|تکایە چاوەڕێ بکە)$"""
    )

    /** ئایا دەقەکە تەنها وشەی «لۆدینگ/چاوەڕێبە»یە؟ (نموونە "Loading…" · "جاري التحميل" · "بارکردن...") */
    fun isLoading(raw: String): Boolean {
        if (raw.length > 40) return false
        val c = strip(clean(raw))
        return c.isNotEmpty() && LOADING.matches(c)
    }

    /** ئایا ئەم دەقە ڕووکارە و پێویست بە خوێندنەوە/وەرگێڕان نییە؟ */
    fun isNoise(raw: String, ui: Boolean): Boolean {
        if (raw.length > MAX_LABEL_LEN) return false
        val c = strip(clean(raw))
        if (c.isEmpty()) return true                                   // تەنها ئیمۆجی/هێما
        if (LOADING.matches(c)) return true                            // Loading… / بارکردن… / جاري التحميل
        if (isTime(c) || COUNT.any { it.matches(c) }) return true
        // هێڵی سەرپۆست: "AI content · hoshmand444 · 2h" — ئەگەر بەشێکی کات/بەروارە
        val parts = clean(raw).split('·', '•', '|').map { strip(it) }.filter { it.isNotEmpty() }
        if (parts.size >= 2 && c.length <= 90 && parts.any { isTime(it) }) return true
        if (!ui) return false
        if (c in UI_WORDS) return true
        if (DAYWORD_ONLY.matches(c)) return true
        if (UI_PATTERNS.any { it.matches(c) }) return true
        // هێڵی سەرپۆست بێ کاتی ژمارەدار: هەموو بەشەکان ڕووکارن (نموونە "Sponsored · Public")
        if (parts.size >= 2 && parts.all { it in UI_WORDS || UI_PATTERNS.any { p -> p.matches(it) } }) return true
        return false
    }

    /** ناسنامەی view (viewIdResourceName) ی ڕووکار: time/date/badge/tab/toolbar… (تەنها بۆ دەقی کورت) */
    fun isNoiseId(id: String?, textLen: Int): Boolean {
        if (id.isNullOrEmpty() || textLen > 40) return false
        return ID_NOISE.containsMatchIn(id.substringAfterLast('/').lowercase())
    }
}
