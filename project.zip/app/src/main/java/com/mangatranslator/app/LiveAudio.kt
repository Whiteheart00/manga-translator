package com.mangatranslator.app

import android.media.AudioAttributes

/**
 * پەخشکردنی دەنگی وەرگێڕانی زیندوو: دەنگی کوردی (Piper) و ئینگلیزی بە چ جۆرە دەنگێک (usage) دەپەخشرێن.
 * بنەڕەت MEDIA ـە (وەک پێشوو). لە کاتی وەرگێڕانی زیندوو دەگۆڕدرێت بۆ ASSISTANT/ALARM، چونکە
 * گرتنی دەنگی مۆبایل (AudioPlaybackCapture) دەنگی MEDIA دەگرێت و دەنگی وەرگێڕانەکەی خۆشی دەگرتەوە.
 */
object LiveAudio {
    @Volatile var outUsage: Int = AudioAttributes.USAGE_MEDIA
}
