package com.mangatranslator.app

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/**
 * ئایکۆنی خوێندنەوە بە شێوەی کاپسوڵ: بلندگۆ لە چەپ + تیر لە ڕاست.
 * - دەستلێدان = خوێندنەوە بە دەنگ
 * - دەستلێدان لەسەر تیرەکە = خۆی دەشارێتەوە بۆ لێوار (تەنها تیرەکە دەمێنێتەوە)؛ دووبارە دەستلێدان دەیهێنێتەوە
 * کاتێک دەنگ دەخوێنرێتەوە شەپۆلەکان دەجوڵێن؛ کاتێک بێدەنگە، خۆی دەلەرێنێتەوە تا سەرنج ڕابکێشێت.
 */
class SpeakFab(ctx: Context, private val c1: Int, private val c2: Int) : View(ctx) {

    private var phase = 0f
    private var speaking = false
    private var collapsed = false
    private var downX = 0f
    private val d = resources.displayMetrics.density
    private val violet = 0xFF7C4DFF.toInt()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val path = Path()
    private val pill = RectF()
    private val oval = RectF()

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    private val listener: (Boolean) -> Unit = { s -> speaking = s; invalidate() }

    private val wiggleRunner = object : Runnable {
        override fun run() {
            if (!speaking && !collapsed) wiggle()
            postDelayed(this, 5500)
        }
    }

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "خوێندنەوە بە دەنگ"
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    private fun wiggle() {
        val rot = ObjectAnimator.ofFloat(this, View.ROTATION, 0f, -7f, 6f, -4f, 2f, 0f).setDuration(750)
        val sx = ObjectAnimator.ofFloat(this, View.SCALE_X, 1f, 1.14f, 1f).setDuration(750)
        val sy = ObjectAnimator.ofFloat(this, View.SCALE_Y, 1f, 1.14f, 1f).setDuration(750)
        AnimatorSet().apply { playTogether(rot, sx, sy); start() }
    }

    private fun setCollapsed(v: Boolean) {
        collapsed = v
        // کاتێک کۆدەبێتەوە، تەنها بەشی تیرەکە دەمێنێتەوە
        val target = if (v) -(width * 0.70f) else 0f
        animate().translationX(target).setDuration(260).start()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; return true }
            MotionEvent.ACTION_UP -> {
                if (collapsed) setCollapsed(false)
                else if (downX > width * 0.70f) setCollapsed(true)
                else performClick()
                return true
            }
        }
        return true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
        Narrator.addListener(listener)
        speaking = Narrator.speaking
        postDelayed(wiggleRunner, 2500)
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        Narrator.removeListener(listener)
        removeCallbacks(wiggleRunner)
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val pad = 10f * d
        val h = height - pad * 2
        val l = pad
        val r = width - pad
        val t = pad
        val b = pad + h
        val rad = h / 2f
        pill.set(l, t, r, b)
        val cy = (t + b) / 2f

        // درەوشانەوەی دەوروبەر (glow)
        val pulse = 0.5f + 0.5f * sin(phase * 6.2832f)
        val glowA = if (speaking) 0.75f + 0.25f * pulse else 0.45f + 0.25f * pulse
        fill.shader = LinearGradient(l, 0f, r, 0f, c1, violet, Shader.TileMode.CLAMP)
        fill.setShadowLayer((10f + 6f * pulse) * d, 0f, 3f * d, (c1 and 0x00FFFFFF) or ((glowA * 255).toInt() shl 24))
        cv.drawRoundRect(pill, rad, rad, fill)
        fill.clearShadowLayer()
        fill.shader = null

        // خەتی دەرەوەی سپی
        line.shader = null
        line.strokeWidth = 1.6f * d
        line.color = 0x99FFFFFF.toInt()
        cv.drawRoundRect(pill, rad, rad, line)

        // بازنەی ڕووناکی پشت بلندگۆ
        val sx = l + rad + 1f * d
        val s = rad / 14f
        fill.color = 0x38FFFFFF
        cv.drawCircle(sx, cy, rad - 5f * d, fill)

        // بلندگۆ
        path.reset()
        path.addRoundRect(RectF(sx - 8f * s, cy - 3.2f * s, sx - 4.6f * s, cy + 3.2f * s), 0.8f * s, 0.8f * s, Path.Direction.CW)
        path.moveTo(sx - 4.6f * s, cy - 3.2f * s)
        path.lineTo(sx - 0.2f * s, cy - 7f * s)
        path.lineTo(sx - 0.2f * s, cy + 7f * s)
        path.lineTo(sx - 4.6f * s, cy + 3.2f * s)
        path.close()
        cv.drawPath(path, glyph)

        // شەپۆلەکانی دەنگ
        line.strokeWidth = 1.9f * s
        for (i in 0..1) {
            val rr = (4.6f + i * 3.6f) * s
            val a = if (speaking) {
                (0.30f + 0.70f * (0.5f + 0.5f * sin((phase * 2f - i * 0.4f) * 6.2832f))).coerceIn(0f, 1f)
            } else 1f
            line.color = ((0xFF * a).toInt() shl 24) or 0x00FFFFFF
            oval.set(sx + 1.2f * s - rr, cy - rr, sx + 1.2f * s + rr, cy + rr)
            cv.drawArc(oval, -46f, 92f, false, line)
        }

        // تیری بچووک (کردنەوە/شاردنەوە)
        val ax = r - rad * 0.78f
        val aw = 3.4f * s
        line.strokeWidth = 2.1f * s
        line.color = 0xFFFFFFFF.toInt()
        path.reset()
        if (collapsed) {      // ›
            path.moveTo(ax - aw * 0.5f, cy - aw * 1.3f)
            path.lineTo(ax + aw * 0.7f, cy)
            path.lineTo(ax - aw * 0.5f, cy + aw * 1.3f)
        } else {              // ‹
            path.moveTo(ax + aw * 0.5f, cy - aw * 1.3f)
            path.lineTo(ax - aw * 0.7f, cy)
            path.lineTo(ax + aw * 0.5f, cy + aw * 1.3f)
        }
        cv.drawPath(path, line)

        // ئەستێرەی بچووکی لەرزۆک
        if (!collapsed) {
            val sxx = r - 3f * d
            val syy = t + 1f * d
            val sz = (1.6f + 1.4f * pulse) * d
            fill.color = 0xFFFFE08A.toInt()
            path.reset()
            path.moveTo(sxx, syy - sz * 1.6f)
            path.quadTo(sxx, syy, sxx + sz * 1.6f, syy)
            path.quadTo(sxx, syy, sxx, syy + sz * 1.6f)
            path.quadTo(sxx, syy, sxx - sz * 1.6f, syy)
            path.quadTo(sxx, syy, sxx, syy - sz * 1.6f)
            path.close()
            cv.drawPath(path, fill)
        }
    }
}
