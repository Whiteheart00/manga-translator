package com.mangatranslator.app

import android.content.Context

/**
 * فەرهەنگی وشە ناڕوونەکان (assets/ferhenga-nerun.txt).
 * وەک «ئاماژەی ڕێنمایی» بۆ Gemini بەکاردێت، نەک وەک فەرهەنگی جێگیری جێگرتنەوە:
 * تەنها ئەو وشانەی لە دەقی ئێستای شاشەدا هەن دەنێردرێن (پرۆمپت بچووک دەمێنێتەوە = خێراتر)،
 * و Gemini بەپێی ڕستەی تەواو ماناکە هەڵدەبژێرێت.
 * بەش ١ (وشە ئینگلیزییە فرەماناکان) + بەش ٤ (چەمکە بێ وەرگێڕانی ڕاستەوخۆکان) بەکاردێن.
 */
object AmbiguityGlossary {

    private class Entry(val key: String, val meanings: String, val concept: Boolean)

    @Volatile
    private var entries: List<Entry>? = null

    /** وشە زۆر باوەکان کە ئاماژەکەیان تەنها دەنگەدەنگ دروست دەکات */
    private val STOP = setOf(
        "can", "may", "just", "even", "well", "fine", "last", "long", "hard", "close",
        "live", "left", "right", "mine", "second", "fall", "case", "check", "kind",
        "mean", "present", "state", "order", "change", "match", "face", "head", "light"
    )

    private val WORD = Regex("[a-z][a-z']*")

    private fun load(ctx: Context): List<Entry> {
        entries?.let { return it }
        synchronized(this) {
            entries?.let { return it }
            val out = ArrayList<Entry>()
            try {
                ctx.applicationContext.assets.open("ferhenga-nerun.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                    for (line in lines) {
                        val l = line.trim()
                        if (l.isEmpty() || l.startsWith("#")) continue
                        val p = l.split("|").map { it.trim() }
                        if (p.size < 3) continue
                        val n = p[0].toIntOrNull() ?: continue
                        val concept = n in 215..264
                        if (!(n in 1..148 || concept)) continue
                        val key = p[1].lowercase()
                        if (key.isEmpty() || key in STOP) continue
                        if (key.any { it.code > 0x24F }) continue
                        out.add(Entry(key, p[2], concept))
                    }
                }
            } catch (_: Throwable) {
            }
            entries = out
            return out
        }
    }

    /**
     * ئاماژەکانی ئەو وشانەی لە [texts] دا هەن (کۆمەڵێک دێڕ) یان "" ئەگەر هیچ نەبوو.
     * چەمکەکان (accountability...) یەکەمن، پاشان وشە درێژترەکان.
     */
    fun hintsFor(ctx: Context, texts: List<String>, max: Int = 10, maxChars: Int = 900): String {
        val all = load(ctx)
        if (all.isEmpty()) return ""
        val joined = texts.joinToString(" ").lowercase()
        if (joined.none { it in 'a'..'z' }) return ""
        val words = HashSet<String>()
        for (m in WORD.findAll(joined)) {
            val w = m.value
            words.add(w)
            if (w.length > 3 && w.endsWith("s")) words.add(w.dropLast(1))
            if (w.length > 5 && w.endsWith("ing")) words.add(w.dropLast(3))
        }
        val hits = all.filter { e ->
            if (e.key.contains(' ') || e.key.contains('-')) joined.contains(e.key) else e.key in words
        }.sortedWith(compareByDescending<Entry> { it.concept }.thenByDescending { it.key.length })
        if (hits.isEmpty()) return ""
        val sb = StringBuilder()
        for (e in hits.take(max)) {
            val line = "- ${e.key}: ${e.meanings}\n"
            if (sb.length + line.length > maxChars) break
            sb.append(line)
        }
        return sb.toString().trimEnd()
    }
}
