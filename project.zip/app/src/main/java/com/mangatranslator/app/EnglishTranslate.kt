package com.mangatranslator.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * وەرگێڕانی دەقی کوردیی سۆرانی ← ئینگلیزیی ڕەوان (بۆ ناردنی نامە بۆ کەسێک).
 * سەرەتا Gemini (باشتر)؛ ئەگەر کلیل نەبوو یان شکستی هێنا، Google Translate ی بێ کلیل.
 * لە thread ی پاشبنەما بانگ بکرێت. null = نەکرا.
 */
object EnglishTranslate {

    private const val PROMPT =
        "Translate the following Central Kurdish (Sorani) text into natural, fluent English, the way a person would " +
            "write it in a chat message to someone. Keep names, numbers and Latin-script words as they are. " +
            "Do not explain, comment or add anything. Return ONLY the English translation.\n\nText:\n"

    fun fromKurdish(text: String, keysRaw: String): String? {
        val src = text.trim()
        if (src.isEmpty()) return null
        if (keysRaw.isNotBlank()) {
            try {
                val out = GeminiKeys.withKeys(keysRaw) { key ->
                    GeminiModels.call(false) { m, think -> post(body(src, m, think), key, m) }
                }.trim().trim('"', '`').trim()
                if (out.isNotEmpty()) return out
            } catch (_: Throwable) {
            }
        }
        return try {
            free(src).takeIf { it.isNotBlank() }
        } catch (_: Throwable) {
            null
        }
    }

    private fun body(src: String, model: String, think: Boolean): String {
        val gen = JSONObject().put("temperature", 0.2).put("maxOutputTokens", 1024)
        if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
        return JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", PROMPT + src)))
                )
            )
            .put("generationConfig", gen)
            .toString()
    }

    private fun post(body: String, key: String, model: String): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8_000
            c.readTimeout = 25_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try {
                    JSONObject(resp).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    resp
                }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            return try {
                val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").optJSONArray("parts")
                if (parts == null || parts.length() == 0) "" else parts.getJSONObject(0).optString("text", "")
            } catch (_: Exception) {
                throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
            }
        } finally {
            c.disconnect()
        }
    }

    /** Google Translate ی بێ کلیل: ckb ← en */
    private fun free(text: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        val c = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=ckb&tl=en&dt=t&q=$q")
            .openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5_000
            c.readTimeout = 10_000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val res = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val parts = JSONArray(res).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val seg = parts.optJSONArray(i) ?: continue
                if (!seg.isNull(0)) sb.append(seg.getString(0))
            }
            return sb.toString().trim()
        } finally {
            c.disconnect()
        }
    }
}
