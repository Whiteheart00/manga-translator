package com.mangatranslator.app

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.animation.LinearInterpolator
import kotlin.math.min

/**
 * پاشبنەمای شووشەیی بۆ ناونیشانەکان: بە بڕێکی زۆر کەم ڕەنگی شین-مۆری هەیە (تەنها تۆزێک ڕەنگ)،
 * پاشبنەما لە ناویەوە دیارە، لێوی شووشەیی سپی، ڕووناکیی سەرەوە و درەوشانەوەیەک کە ماوە ماوە بەسەریدا تێدەپەڕێت.
 */
class GlassPillDrawable(private val density: Float) : Drawable() {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)

    private val box = RectF()
    private val glossBox = RectF()
    private val matrix = Matrix()
    private var sheenShader: Shader? = null

    private var radius = 0f
    private var glossRadius = 0f
    private var bandLen = 0f
    private var sweepSpan = 0f
    private var left = 0f

    /** -1 = ئێستا درەوشانەوە نییە، 0..1 = شوێنی درەوشانەوەکە */
    private var sweep = -1f

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = CYCLE_MS
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val t = it.animatedValue as Float
            val n = if (t < SWEEP_PART) t / SWEEP_PART else -1f
            if (n != sweep) { sweep = n; invalidateSelf() }
        }
    }

    private fun argb(a: Float, r: Int, g: Int, b: Int) =
        ((a * 255).toInt().coerceIn(0, 255) shl 24) or (r shl 16) or (g shl 8) or b

    private fun white(a: Float) = argb(a, 255, 255, 255)

    override fun onBoundsChange(b: android.graphics.Rect) {
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        val l = b.left.toFloat(); val t = b.top.toFloat()
        left = l
        radius = min(h / 2f, 22f * density)
        glossRadius = radius

        // شووشەی بە تۆزێک ڕەنگی شین-مۆر (٪١٠ تا ٪١٦)؛ لێوی خوارەوە کەمێک ڕووناکترە
        val col = GlassStyle.colored
        fill.shader = if (col)
            LinearGradient(l, t, l + w, t + h * .6f,
                intArrayOf(argb(.26f, 66, 133, 244), argb(.18f, 155, 114, 203), argb(.26f, 217, 101, 112)),
                floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, t, 0f, t + h,
                intArrayOf(argb(.17f, 143, 162, 255), argb(.08f, 125, 140, 240), argb(.14f, 170, 180, 255)),
                floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)

        // ڕووناکیی سەرەوە (نیوەی سەرەوەی شووشە)
        val gi = 1.6f * density
        glossBox.set(l + gi, t + gi, l + w - gi, t + h * .52f)
        gloss.shader = LinearGradient(0f, glossBox.top, 0f, glossBox.bottom,
            white(.34f), white(0f), Shader.TileMode.CLAMP)

        outline.strokeWidth = 1f * density
        outline.color = 0x38000000

        rim.strokeWidth = 1.4f * density
        rim.shader = LinearGradient(l, t, l + w, t + h,
            if (col) intArrayOf(white(.95f), argb(.60f, 155, 114, 203), argb(.50f, 217, 101, 112), white(.70f))
            else intArrayOf(white(.95f), white(.25f), white(.14f), white(.70f)),
            floatArrayOf(0f, .35f, .65f, 1f), Shader.TileMode.CLAMP)

        // باندی درەوشانەوە (لێژ، لە چەپەوە بۆ ڕاست)
        bandLen = h * 1.8f
        sheenShader = LinearGradient(0f, t, bandLen, t + h * .9f,
            intArrayOf(white(0f), white(0f), white(.42f), white(0f), white(0f)),
            floatArrayOf(0f, .36f, .50f, .64f, 1f), Shader.TileMode.CLAMP)
        sheen.shader = sheenShader
        sweepSpan = w + bandLen
    }

    override fun draw(c: Canvas) {
        if (radius <= 0f) return
        val b = bounds
        val l = b.left.toFloat(); val t = b.top.toFloat()
        val r = b.right.toFloat(); val bt = b.bottom.toFloat()

        box.set(l, t, r, bt)
        c.drawRoundRect(box, radius, radius, fill)
        c.drawRoundRect(glossBox, glossRadius, glossRadius, gloss)

        val o = outline.strokeWidth / 2f
        box.set(l + o, t + o, r - o, bt - o)
        c.drawRoundRect(box, radius, radius, outline)

        val ri = outline.strokeWidth + rim.strokeWidth / 2f
        box.set(l + ri, t + ri, r - ri, bt - ri)
        c.drawRoundRect(box, radius - ri, radius - ri, rim)

        val sw = sweep
        if (sw >= 0f) {
            matrix.setTranslate(left - bandLen + sw * sweepSpan, 0f)
            sheenShader?.setLocalMatrix(matrix)
            sheen.shader = sheenShader
            box.set(l + ri, t + ri, r - ri, bt - ri)
            c.drawRoundRect(box, radius - ri, radius - ri, sheen)
        }
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        if (visible) {
            if (!anim.isStarted) {
                anim.start()
                anim.currentPlayTime = (Math.random() * CYCLE_MS).toLong()
            }
        } else {
            anim.cancel()
            sweep = -1f
        }
        return changed
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT

    companion object {
        private const val CYCLE_MS = 5200L
        private const val SWEEP_PART = 0.30f
    }
}
