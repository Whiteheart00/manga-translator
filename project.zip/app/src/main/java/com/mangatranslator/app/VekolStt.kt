package com.mangatranslator.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.text.Normalizer

/**
 * قسەکردن بە کوردی (سۆرانی) ← نووسین، بەتەواوی ئۆفلاین.
 * مۆدێل: RevgeAI/vekol-stt-ckb-base (Whisper-base ی fine-tune کراو، ONNX).
 * مۆڵەت: CC-BY-NC 4.0 (تەنها بۆ بەکارهێنانی نا-بازرگانی).
 *
 * کۆدی Kotlin ـی ئەم فایلە لەسەر vekol_stt.py ی هەمان پڕۆژە دروستکراوە.
 * فایلەکانی مۆدێل (نزیکەی ٢٩١ مێگابایت) لە APK دا نین؛ یەکجار دادەبەزێن بۆ filesDir.
 */
object VekolStt {

    // یەکەم: Release ی خۆت (خێراتر و جێگیرتر)؛ دووەم: Hugging Face وەک پاشەکشە
    private val BASE_URLS = listOf(
        "https://github.com/Whiteheart00/manga-translator/releases/download/v1.0.1/" to "",
        "https://huggingface.co/RevgeAI/vekol-stt-ckb-base/resolve/main/" to "?download=true"
    )

    private class Spec(val name: String, val size: Long)

    private val FILES = listOf(
        Spec("vocab.json", 1_036_584L),
        Spec("encoder_model.onnx", 82_433_773L),
        Spec("decoder_model_merged.onnx", 208_376_584L)
    )

    val TOTAL_BYTES: Long = FILES.sumOf { it.size }

    // Whisper (فرە-زمان) تۆکنە تایبەتەکان
    private const val SOT = 50258L
    private const val FA = 50300L          // وەک «لەنگەری پیت»ی فارسی بۆ سۆرانی
    private const val TRN = 50359L
    private const val NOTS = 50363L
    private const val EOT = 50257
    private const val TEXT_TOKENS = 50257  // تۆکنی سەروو ئەمە دەق نین

    private const val N_FFT = 400
    private const val HOP = 160
    private const val N_SAMPLES = 480_000  // ٣٠ چرکە لە 16kHz
    private const val N_MELS = 80
    private const val N_FREQ = N_FFT / 2 + 1   // 201
    private const val N_FRAMES = 3000

    private const val LAYERS = 6
    private const val HEADS = 8
    private const val HEAD_DIM = 64
    private const val MAX_NEW_TOKENS = 440

    // ---------- شوێنی فایلەکان ----------

    fun modelDir(ctx: Context): File = File(ctx.filesDir, "vekol-base")

    private fun complete(ctx: Context, s: Spec): Boolean {
        val f = File(modelDir(ctx), s.name)
        return f.exists() && f.length() == s.size
    }

    fun isReady(ctx: Context): Boolean = FILES.all { complete(ctx, it) }

    /** ژمارەی بایتی دابەزێندراو تا ئێستا (بۆ پیشاندانی پێشکەوتن). */
    fun downloadedBytes(ctx: Context): Long =
        FILES.sumOf { s ->
            val f = File(modelDir(ctx), s.name)
            val p = File(modelDir(ctx), s.name + ".part")
            when {
                f.exists() && f.length() == s.size -> s.size
                p.exists() -> p.length().coerceAtMost(s.size)
                else -> 0L
            }
        }

    /** فایلەکان بسڕەوە (بۆ ئازادکردنی شوێن). */
    @Synchronized
    fun deleteModel(ctx: Context) {
        release()
        modelDir(ctx).deleteRecursively()
    }

    // ---------- دابەزاندن (لە thread ی پاشبنەما بانگ بکرێت) ----------

    /**
     * فایلە کەمەکان دادەبەزێنێت. ئەگەر پچڕا، جاری داهاتوو لەو شوێنەوە بەردەوام دەبێت.
     * onProgress(بایتی دابەزێندراو، کۆی بایت، ناوی فایل)
     */
    fun download(ctx: Context, onProgress: (Long, Long, String) -> Unit) {
        val dir = modelDir(ctx)
        if (!dir.exists() && !dir.mkdirs()) throw IOException("نەتوانرا فۆڵدەر دروست بکرێت")
        var doneBefore = 0L
        for (s in FILES) {
            val dst = File(dir, s.name)
            if (complete(ctx, s)) {
                doneBefore += s.size
                onProgress(doneBefore, TOTAL_BYTES, s.name)
                continue
            }
            fetch(s, dst) { cur -> onProgress(doneBefore + cur, TOTAL_BYTES, s.name) }
            doneBefore += s.size
        }
    }

    private fun fetch(s: Spec, dst: File, onBytes: (Long) -> Unit) {
        var last: Throwable? = null
        for ((base, suffix) in BASE_URLS) {
            try {
                fetchFrom(base + s.name + suffix, s, dst, onBytes)
                return
            } catch (t: Throwable) {
                last = t
                File(dst.parentFile, s.name + ".part").let { if (it.exists() && it.length() > s.size) it.delete() }
            }
        }
        throw last ?: IOException("دابەزاندن سەرنەکەوت")
    }

    private fun fetchFrom(url: String, s: Spec, dst: File, onBytes: (Long) -> Unit) {
        val part = File(dst.parentFile, s.name + ".part")
        var have = if (part.exists()) part.length() else 0L
        if (have > s.size) {
            part.delete(); have = 0L
        }
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 20_000
            c.readTimeout = 60_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "MangaTranslator/1.0")
            if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
            val code = c.responseCode
            if (code != 200 && code != 206) throw IOException("HTTP $code")
            val append = code == 206 && have > 0
            if (!append) have = 0L
            onBytes(have)
            FileOutputStream(part, append).use { out ->
                c.inputStream.use { inp ->
                    val buf = ByteArray(64 * 1024)
                    var total = have
                    var lastReport = 0L
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                        if (total - lastReport > 256 * 1024) {
                            lastReport = total
                            onBytes(total)
                        }
                    }
                    onBytes(total)
                }
            }
        } finally {
            c.disconnect()
        }
        if (part.length() != s.size) {
            throw IOException("${s.name}: قەبارە ڕاست نییە (${part.length()} / ${s.size}). دووبارە هەوڵبدەرەوە")
        }
        if (dst.exists()) dst.delete()
        if (!part.renameTo(dst)) throw IOException("${s.name}: نەتوانرا ناوەکەی بگۆڕدرێت")
    }

    // ---------- بارکردنی مۆدێل ----------

    private var env: OrtEnvironment? = null
    private var enc: OrtSession? = null
    private var dec: OrtSession? = null
    private var id2tok: Array<String?>? = null
    private var melFilters: FloatArray? = null
    private var cosT: FloatArray? = null
    private var sinT: FloatArray? = null
    private var window: FloatArray? = null

    private val byteDecoder: Map<Char, Int> by lazy {
        val bs = ArrayList<Int>()
        for (i in 33..126) bs.add(i)
        for (i in 161..172) bs.add(i)
        for (i in 174..255) bs.add(i)
        val cs = ArrayList<Int>(bs)
        var n = 0
        for (b in 0 until 256) {
            if (b !in bs) {
                bs.add(b); cs.add(256 + n); n++
            }
        }
        val m = HashMap<Char, Int>()
        for (i in bs.indices) m[cs[i].toChar()] = bs[i]
        m
    }

    @Synchronized
    private fun load(ctx: Context) {
        if (enc != null && dec != null) return
        if (!isReady(ctx)) throw IOException("مۆدێلی کوردی دانەبەزێندراوە")
        val dir = modelDir(ctx)

        val e = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            if (DeviceProfile.low) {
                // ڕامی کەم: arena و memory-pattern ی ONNX دەیان MB ڕام دەگرن
                try { setCPUArenaAllocator(false) } catch (_: Throwable) {}
                try { setMemoryPatternOptimization(false) } catch (_: Throwable) {}
            }
        }
        val encS = e.createSession(File(dir, "encoder_model.onnx").absolutePath, opts)
        val decS = try {
            e.createSession(File(dir, "decoder_model_merged.onnx").absolutePath, opts)
        } catch (t: Throwable) {
            encS.close()
            throw t
        }

        // وشەنامە
        val vocab = JSONObject(File(dir, "vocab.json").readText(Charsets.UTF_8))
        val arr = arrayOfNulls<String>(TEXT_TOKENS)
        val keys = vocab.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val id = vocab.getInt(k)
            if (id in 0 until TEXT_TOKENS) arr[id] = k
        }

        // فلتەری mel (80 x 201، float32 little-endian) لە assets
        val raw = ctx.assets.open("mel_filters.bin").use { it.readBytes() }
        val fb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        val mf = FloatArray(N_MELS * N_FREQ)
        if (fb.remaining() < mf.size) throw IOException("mel_filters.bin کورتە")
        fb.get(mf)

        // خشتەی twiddle بۆ FFT: W^j = exp(-2*pi*i*j/N)  (cos و sin)
        val ct = FloatArray(N_FFT) { Math.cos(2.0 * Math.PI * it / N_FFT).toFloat() }
        val st = FloatArray(N_FFT) { Math.sin(2.0 * Math.PI * it / N_FFT).toFloat() }
        val w = FloatArray(N_FFT) { (0.5 - 0.5 * Math.cos(2.0 * Math.PI * it / N_FFT)).toFloat() }

        env = e; enc = encS; dec = decS
        id2tok = arr; melFilters = mf; cosT = ct; sinT = st; window = w
    }

    /**
     * مۆدێلەکان پێش وەرگرتنی دەنگ بار دەکات (لە thread ی پاشبنەما)؛ هەر کە دوگمەی مایک دادەگیرێت بانگ دەکرێت
     * تا لە کاتی قسەکردنی بەکارهێنەردا بارکردنەکە تەواو بێت. transcribe هەمان قفڵ بەکاردەهێنێت و چاوەڕێی دەکات.
     */
    fun preload(ctx: Context) {
        if (enc != null && dec != null) return
        if (!isReady(ctx)) return
        val app = ctx.applicationContext
        Thread {
            try { load(app) } catch (t: Throwable) { android.util.Log.w("VekolStt", "preload failed", t) }
        }.start()
    }

    /** مۆدێلەکان لە ڕام دەردەهێنێت (نزیکەی ٣٠٠ مێگابایت). */
    @Synchronized
    fun release() {
        try { enc?.close() } catch (_: Throwable) {}
        try { dec?.close() } catch (_: Throwable) {}
        enc = null; dec = null
        id2tok = null; melFilters = null; cosT = null; sinT = null; window = null
    }

    // ---------- API ی سەرەکی ----------

    /**
     * pcm: PCM16 mono 16kHz (هەمان دەرچووی Dictation.stop()).
     * لە thread ی پاشبنەما بانگ بکرێت. بەتاڵ = هیچ قسەیەک نەبوو.
     */
    @Synchronized
    fun transcribe(ctx: Context, pcm: ByteArray): String {
        if (pcm.size < 16_000) return ""   // کەمتر لە نیو چرکە
        val tStart = android.os.SystemClock.elapsedRealtime()
        load(ctx)
        val tLoaded = android.os.SystemClock.elapsedRealtime()

        val n = pcm.size / 2
        val bb = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        val audio = FloatArray(n) { bb.getShort(it * 2) / 32768f }

        // بەرزکردنەوەی دەنگی کەم (وەک Dictation.normalize)
        var peak = 1e-4f
        for (v in audio) { val a = Math.abs(v); if (a > peak) peak = a }
        val gain = (0.61f / peak).coerceIn(1f, 8f)
        if (gain > 1.05f) for (i in audio.indices) audio[i] = (audio[i] * gain).coerceIn(-1f, 1f)

        val parts = ArrayList<String>()
        var start = 0
        while (start < n) {
            val end = minOf(n, start + N_SAMPLES)
            if (end - start >= 8_000) {           // پارچەی کورتتر لە نیو چرکە فڕێ دەدرێت
                val mel = logMel(audio, start, end - start)
                val t = decodeChunk(mel)
                if (t.isNotBlank()) parts.add(t)
            }
            start = end
        }
        android.util.Log.d("VekolStt", "load=${tLoaded - tStart}ms, transcribe=${android.os.SystemClock.elapsedRealtime() - tLoaded}ms")
        return parts.joinToString(" ").trim()
    }

    // ---------- FFT ی تێکەڵ (radix 2 و 5) ----------

    private val tmpR = FloatArray(8)
    private val tmpI = FloatArray(8)

    /**
     * FFT ی ڕیکورسیڤ بۆ n = 2^a * 5^b. ct/st خشتەی twiddle ی N_FFT ن (cos و sin ی 2*pi*j/N).
     * W_N^j = cos - i*sin. دەرچوو لە out[outOff, outOff+n] دەنووسرێت.
     */
    private fun fftRec(
        inR: FloatArray, inI: FloatArray, inOff: Int, inStride: Int,
        outR: FloatArray, outI: FloatArray, outOff: Int, n: Int,
        ct: FloatArray, st: FloatArray
    ) {
        if (n == 1) { outR[outOff] = inR[inOff]; outI[outOff] = inI[inOff]; return }
        val p = if (n % 2 == 0) 2 else if (n % 5 == 0) 5 else n
        val m = n / p
        for (r in 0 until p) {
            fftRec(inR, inI, inOff + r * inStride, inStride * p, outR, outI, outOff + r * m, m, ct, st)
        }
        val step = N_FFT / n            // W_n^j = W_N^(j*step)
        val pStep = N_FFT / p           // W_p^j = W_N^(j*pStep)
        for (k in 0 until m) {
            for (r in 0 until p) {
                val idx = (r * k * step) % N_FFT
                val wr = ct[idx]; val wi = -st[idx]
                val yr = outR[outOff + r * m + k]; val yi = outI[outOff + r * m + k]
                tmpR[r] = yr * wr - yi * wi
                tmpI[r] = yr * wi + yi * wr
            }
            for (q in 0 until p) {
                var sr = 0f; var si = 0f
                for (r in 0 until p) {
                    val idx = ((r * q) % p) * pStep
                    val wr = ct[idx]; val wi = -st[idx]
                    sr += tmpR[r] * wr - tmpI[r] * wi
                    si += tmpR[r] * wi + tmpI[r] * wr
                }
                outR[outOff + k + m * q] = sr
                outI[outOff + k + m * q] = si
            }
        }
    }

    // ---------- log-mel (هاوشێوەی Whisper) ----------

    private fun logMel(audio: FloatArray, off: Int, len: Int): FloatArray {
        val ct = cosT!!; val st = sinT!!; val w = window!!; val mf = melFilters!!

        // ٣٠ چرکە، بە سفر پڕکراوەتەوە
        val padded = FloatArray(N_SAMPLES)
        System.arraycopy(audio, off, padded, 0, minOf(len, N_SAMPLES))

        // reflect-pad بە 200 لە هەر لایەک
        val half = N_FFT / 2
        val ext = FloatArray(N_SAMPLES + N_FFT)
        System.arraycopy(padded, 0, ext, half, N_SAMPLES)
        for (i in 1..half) {
            ext[half - i] = padded[i]
            ext[half + N_SAMPLES - 1 + i] = padded[N_SAMPLES - 1 - i]
        }
        var lastNz = -1
        for (i in ext.indices.reversed()) if (ext[i] != 0f) { lastNz = i; break }

        // spectrum توان [freq][frame] بە FFT ی تێکەڵ (400 = 2^4 * 5^2)؛ زۆر خێراترە لە DFT ی ئاسایی
        val power = FloatArray(N_FREQ * N_FRAMES)
        val xr = FloatArray(N_FFT)
        val xi = FloatArray(N_FFT)          // هەمیشە سفر (دەنگ ڕاستەقینەیە)
        val orr = FloatArray(N_FFT)
        val oii = FloatArray(N_FFT)
        for (t in 0 until N_FRAMES) {
            val s0 = t * HOP
            if (s0 > lastNz) break               // فرەیمەکانی دوای دەنگ هەمووی سفرن
            for (i in 0 until N_FFT) xr[i] = ext[s0 + i] * w[i]
            fftRec(xr, xi, 0, 1, orr, oii, 0, N_FFT, ct, st)
            for (k in 0 until N_FREQ) {
                power[k * N_FRAMES + t] = orr[k] * orr[k] + oii[k] * oii[k]
            }
        }

        // mel = filters @ power (فلتەرەکان زۆریان سفرە، بۆیە تەنها نا-سفرەکان)
        val mel = FloatArray(N_MELS * N_FRAMES)
        for (m in 0 until N_MELS) {
            val mo = m * N_FRAMES
            for (k in 0 until N_FREQ) {
                val f = mf[m * N_FREQ + k]
                if (f == 0f) continue
                val po = k * N_FRAMES
                for (t in 0 until N_FRAMES) mel[mo + t] += f * power[po + t]
            }
        }

        // log10، دابەزاندنی ئاست بۆ (max - 8)، ڕێکخستن
        var mx = -1e30f
        for (i in mel.indices) {
            val v = Math.log10(Math.max(mel[i].toDouble(), 1e-10)).toFloat()
            mel[i] = v
            if (v > mx) mx = v
        }
        val floor = mx - 8f
        for (i in mel.indices) {
            val v = if (mel[i] < floor) floor else mel[i]
            mel[i] = (v + 4f) / 4f
        }
        return mel
    }

    // ---------- یارمەتیدەرەکانی tensor ----------

    private fun fbuf(a: FloatArray): FloatBuffer {
        val fb = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(a); fb.rewind()
        return fb
    }

    private fun lbuf(a: LongArray): LongBuffer {
        val lb = ByteBuffer.allocateDirect(a.size * 8).order(ByteOrder.nativeOrder()).asLongBuffer()
        lb.put(a); lb.rewind()
        return lb
    }

    private fun OrtSession.Result.tensor(name: String): OnnxTensor =
        get(name).get() as OnnxTensor

    /** past ـی بەتاڵ بۆ یەکەم هەنگاو؛ ئەگەر tensor ی بەتاڵ سەرنەکەوت، سفرێکی 1-درێژ. */
    private fun emptyPast(e: OrtEnvironment): OnnxTensor =
        try {
            OnnxTensor.createTensor(e, fbuf(FloatArray(0)), longArrayOf(1, HEADS.toLong(), 0, HEAD_DIM.toLong()))
        } catch (_: Throwable) {
            OnnxTensor.createTensor(
                e, fbuf(FloatArray(HEADS * HEAD_DIM)),
                longArrayOf(1, HEADS.toLong(), 1, HEAD_DIM.toLong())
            )
        }

    private fun argmaxLast(res: OrtSession.Result): Int {
        val lt = res.get(0) as OnnxTensor
        val shape = (lt.info as TensorInfo).shape
        val seq = shape[1].toInt()
        val v = shape[2].toInt()
        val fb = lt.floatBuffer
        val off = (seq - 1) * v
        var best = 0
        var bv = -Float.MAX_VALUE
        for (i in 0 until v) {
            val x = fb.get(off + i)
            if (x > bv) { bv = x; best = i }
        }
        return best
    }

    // ---------- decoder (greedy، لەگەڵ KV cache) ----------

    private fun decodeChunk(mel: FloatArray): String {
        val e = env!!; val encS = enc!!; val decS = dec!!

        val melT = OnnxTensor.createTensor(e, fbuf(mel), longArrayOf(1, N_MELS.toLong(), N_FRAMES.toLong()))
        val encRes = try {
            encS.run(mapOf("input_features" to melT))
        } finally {
            melT.close()
        }

        var first: OrtSession.Result? = null
        var cur: OrtSession.Result? = null
        val gen = ArrayList<Int>()
        try {
            val hidden = encRes.get(0) as OnnxTensor

            // هەنگاوی یەکەم: [SOT, fa, transcribe, notimestamps]
            run {
                val ids = OnnxTensor.createTensor(e, lbuf(longArrayOf(SOT, FA, TRN, NOTS)), longArrayOf(1, 4))
                val cp = OnnxTensor.createTensor(e, lbuf(longArrayOf(0, 1, 2, 3)), longArrayOf(4))
                val ucb = OnnxTensor.createTensor(e, booleanArrayOf(false))
                val empty = emptyPast(e)
                try {
                    val feed = HashMap<String, OnnxTensor>()
                    feed["input_ids"] = ids
                    feed["encoder_hidden_states"] = hidden
                    feed["cache_position"] = cp
                    feed["use_cache_branch"] = ucb
                    for (l in 0 until LAYERS) {
                        feed["past_key_values.$l.decoder.key"] = empty
                        feed["past_key_values.$l.decoder.value"] = empty
                        feed["past_key_values.$l.encoder.key"] = empty
                        feed["past_key_values.$l.encoder.value"] = empty
                    }
                    cur = decS.run(feed)
                    first = cur
                } finally {
                    ids.close(); cp.close(); ucb.close(); empty.close()
                }
            }

            var nxt = argmaxLast(cur!!)
            gen.add(nxt)
            var pos = 4
            var steps = 0
            while (nxt != EOT && steps < MAX_NEW_TOKENS) {
                val idT = OnnxTensor.createTensor(e, lbuf(longArrayOf(nxt.toLong())), longArrayOf(1, 1))
                val cpT = OnnxTensor.createTensor(e, lbuf(longArrayOf(pos.toLong())), longArrayOf(1))
                val ucbT = OnnxTensor.createTensor(e, booleanArrayOf(true))
                val next = try {
                    val f = HashMap<String, OnnxTensor>()
                    f["input_ids"] = idT
                    f["encoder_hidden_states"] = hidden
                    f["cache_position"] = cpT
                    f["use_cache_branch"] = ucbT
                    val c = cur!!
                    val fst = first!!
                    for (l in 0 until LAYERS) {
                        f["past_key_values.$l.decoder.key"] = c.tensor("present.$l.decoder.key")
                        f["past_key_values.$l.decoder.value"] = c.tensor("present.$l.decoder.value")
                        f["past_key_values.$l.encoder.key"] = fst.tensor("present.$l.encoder.key")
                        f["past_key_values.$l.encoder.value"] = fst.tensor("present.$l.encoder.value")
                    }
                    decS.run(f)
                } finally {
                    idT.close(); cpT.close(); ucbT.close()
                }
                if (cur !== first) cur!!.close()
                cur = next
                nxt = argmaxLast(next)
                gen.add(nxt)
                pos++
                steps++

                // پاراستن لە دووبارەبوونەوەی بێ کۆتایی
                if (gen.size >= 16) {
                    val last = gen[gen.size - 1]
                    var same = true
                    for (j in 2..16) if (gen[gen.size - j] != last) { same = false; break }
                    if (same) break
                }
            }
        } finally {
            if (cur != null && cur !== first) try { cur!!.close() } catch (_: Throwable) {}
            try { first?.close() } catch (_: Throwable) {}
            try { encRes.close() } catch (_: Throwable) {}
        }
        return tokensToText(gen)
    }

    // ---------- تۆکن ← دەق ----------

    private fun tokensToText(ids: List<Int>): String {
        val vocab = id2tok!!
        val sb = StringBuilder()
        for (id in ids) if (id in 0 until TEXT_TOKENS) vocab[id]?.let { sb.append(it) }
        val bd = byteDecoder
        val bytes = java.io.ByteArrayOutputStream()
        for (ch in sb) bd[ch]?.let { bytes.write(it) }
        return normalizeSorani(String(bytes.toByteArray(), Charsets.UTF_8))
    }

    private val STRIP = Regex("[\u200c\u200d\u0640\u064b-\u0652]")
    private val SPACES = Regex("\\s+")

    private fun normalizeSorani(raw: String): String {
        var t = Normalizer.normalize(raw, Normalizer.Form.NFC)
        val sb = StringBuilder(t.length)
        for (c in t) {
            sb.append(
                when (c) {
                    '\u0643' -> '\u06A9'                       // ك → ک
                    '\u064A', '\u0649' -> '\u06CC'             // ي ى → ی
                    '\u0629' -> '\u06D5'                       // ة → ە
                    '\u06BE' -> '\u0647'                       // ھ → ه
                    '\u0624' -> '\u0648'                       // ؤ → و
                    '\u0623', '\u0625', '\u0622', '\u0671' -> '\u0627'   // أ إ آ ٱ → ا
                    in '\u0660'..'\u0669' -> '0' + (c - '\u0660')        // ٠-٩
                    in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')        // ۰-۹
                    else -> c
                }
            )
        }
        t = STRIP.replace(sb.toString(), "")
        return SoraniClean.tidy(SPACES.replace(t, " ").trim())
    }
}
