package com.mangatranslator.app

import android.graphics.Bitmap
import kotlin.math.abs

/**
 * ئاشکراکردنی گۆڕانی شاشە بە "ئیمزای" وێنەیەکی ٣٢×٣٢ی خۆڵەمێشی.
 * distance() ناوەندی جیاوازی ڕووناکییە (٠ تا ٢٥٥).
 */
object ChangeDetector {

    private const val N = 32

    fun signature(src: Bitmap): IntArray {
        val small = Bitmap.createScaledBitmap(src, N, N, true)
        val px = IntArray(N * N)
        small.getPixels(px, 0, N, 0, 0, N, N)
        if (small !== src) small.recycle()
        return IntArray(N * N) { i ->
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            (r * 299 + g * 587 + b * 114) / 1000
        }
    }

    fun distance(a: IntArray, b: IntArray): Float {
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toFloat() / a.size
    }
}
