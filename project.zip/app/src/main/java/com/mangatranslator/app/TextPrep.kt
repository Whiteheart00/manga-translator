package com.mangatranslator.app

/**
 * ئامادەکردنی دەقی OCR پێش وەرگێڕان، و چاکسازی دەقی سۆرانی دوای وەرگێڕان.
 */
object TextPrep {

    /**
     * مانگا زۆربەی کات بە پیتی گەورەیە ("WHAT ARE YOU DOING?!") و مۆدێلی وەرگێڕان بەو شێوەیە خراپ دەبێت،
     * بۆیە ئەگەر دەقەکە زۆربەی گەورەیە، دەیکەین بە شێوەی ئاسایی (پیتی یەکەمی هەر ڕستەیەک گەورە).
     */
    fun prepare(raw: String): String {
        val t = raw.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        val letters = t.count { it.isLetter() }
        if (letters < 3) return t
        val upper = t.count { it.isUpperCase() }
        return if (upper.toFloat() / letters >= 0.7f) sentenceCase(t) else t
    }

    private fun sentenceCase(s: String): String {
        val lower = s.lowercase()
        val sb = StringBuilder(lower.length)
        var capNext = true
        for (ch in lower) {
            if (capNext && ch.isLetter()) {
                sb.append(ch.uppercaseChar())
                capNext = false
            } else {
                sb.append(ch)
                if (ch == '.' || ch == '!' || ch == '?' || ch == '…') {
                    capNext = true
                } else if (ch.isLetterOrDigit()) {
                    capNext = false
                }
            }
        }
        return sb.toString().replace(Regex("\\bi\\b"), "I")
    }

    /** یەکخستنی پیتە عەرەبییەکان بۆ شێوەی کوردی: ي/ى → ی ، ك → ک */
    fun fixSorani(s: String): String =
        s.replace('ي', 'ی')
            .replace('ى', 'ی')
            .replace('ك', 'ک')
            .trim()
}
