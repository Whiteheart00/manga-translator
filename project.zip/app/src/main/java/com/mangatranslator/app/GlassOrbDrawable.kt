package com.mangatranslator.app

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * بازنەی «شووشەی تەواو ڕوون»: هیچ ڕەنگێکی پڕ نییە و پاشبنەما لە ناویەوە دیارە.
 * تەنها لێوی شووشەیی، هێڵی ڕووناکی، دڵۆپی بریسکە و درەوشانەوەیەکی نەرم کە ماوە ماوە بەسەریدا تێدەپەڕێت.
 * `tint` تەنها بۆ نیشانەی بچووکی دۆخی چالاک (`active`) بەکاردێت، نەک بۆ ڕەنگکردنی خودی شووشەکە.
 */
class GlassOrbDrawable(
    private val tint: Int,
    private val density: Float,
    private val active: Boolean = false
) : Drawable() {

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val caustic = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val innerRim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val spot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sparkle = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFFFFFFF.toInt() }

    private val upper = Path()
    private val lower = Path()
    private val star = Path()
    private val oval = RectF()
    private val sheenMatrix = Matrix()
    private var sheenShader: Shader? = null

    private var cx = 0f
    private var cy = 0f
    private var sr = 0f
    private var sSize = 0f

    /** -1 = ئێستا درەوشانەوە نییە، 0..1 = شوێنی درەوشانەوەکە لە کاتی تێپەڕین */
    private var sweep = -1f

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = CYCLE_MS
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val t = it.animatedValue as Float
            val n = if (t < SWEEP_PART) t / SWEEP_PART else -1f
            if (n != sweep) { sweep = n; invalidateSelf() }
        }
    }

    private fun a(c: Int, alpha: Float) = (c and 0x00FFFFFF) or ((alpha * 255).toInt().coerceIn(0, 255) shl 24)
    private fun white(alpha: Float) = a(0xFFFFFF, alpha)

    override fun onBoundsChange(b: android.graphics.Rect) {
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        cx = b.exactCenterX(); cy = b.exactCenterY()
        val full = minOf(w, h) / 2f
        sr = full * 0.86f
        sSize = sr * 2f
        val l = cx - sr; val t = cy - sr; val s = sSize
        val act = if (active) 1f else 0f
        val col = GlassStyle.colored

        // درەوشانەوەی سپیی نەرم لە دەرەوە
        glow.shader = RadialGradient(cx, cy, full,
            if (col) intArrayOf(a(tint, 0f), a(tint, .22f + .25f * act), a(tint, 0f))
            else intArrayOf(white(0f), white(.14f + .22f * act), white(0f)),
            floatArrayOf(0f, 0.82f, 1f), Shader.TileMode.CLAMP)

        // جەستەی شووشە: ناوەڕاست تەواو ڕوون، لێوەکان کەمێک سپی (ئەستووریی شووشە)
        body.shader = RadialGradient(cx - sr * .12f, cy - sr * .15f, sr,
            if (col) intArrayOf(a(tint, .10f), a(tint, .20f), a(tint, .48f + .10f * act))
            else intArrayOf(white(.00f), white(.03f), white(.20f + .08f * act)),
            floatArrayOf(0f, .62f, 1f), Shader.TileMode.CLAMP)

        // ڕووناکیی پێچاوپێچی خوارەوە (caustic)
        caustic.shader = RadialGradient(cx + sr * .32f, cy + sr * .60f, sr * .72f,
            if (col) intArrayOf(a(tint, .45f), a(tint, 0f)) else intArrayOf(white(.26f), white(0f)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)

        outline.strokeWidth = 1f * density
        outline.color = 0x40000000

        rim.strokeWidth = 1.6f * density
        rim.shader = LinearGradient(l, t, l + s, t + s,
            if (col) intArrayOf(white(.98f), a(tint, .70f), a(tint, .55f), white(.78f))
            else intArrayOf(white(.98f), white(.22f), white(.12f), white(.72f)),
            floatArrayOf(0f, .38f, .62f, 1f), Shader.TileMode.CLAMP)

        innerRim.strokeWidth = 0.8f * density
        innerRim.color = if (col) a(tint, .35f) else white(.20f)

        shine.strokeWidth = 1.5f * density
        upper.reset()
        upper.moveTo(l + s * .20f, t + s * .13f)
        upper.cubicTo(l + s * .35f, t + s * .025f, l + s * .70f, t + s * .035f, l + s * .84f, t + s * .18f)
        lower.reset()
        lower.moveTo(l + s * .13f, t + s * .68f)
        lower.cubicTo(l + s * .24f, t + s * .91f, l + s * .56f, t + s * .98f, l + s * .75f, t + s * .88f)

        oval.set(l + s * .34f, t + s * .21f, l + s * .62f, t + s * .31f)
        spot.shader = LinearGradient(oval.left, oval.top, oval.right, oval.bottom,
            white(.85f), white(.05f), Shader.TileMode.CLAMP)

        // باندی درەوشانەوە (لەسەر هێڵی لێژ دەجووڵێت)
        sheenShader = LinearGradient(cx - sr, cy - sr, cx + sr, cy + sr,
            intArrayOf(white(0f), white(0f), white(.55f), white(0f), white(0f)),
            floatArrayOf(0f, .40f, .50f, .60f, 1f), Shader.TileMode.CLAMP)
        sheen.shader = sheenShader

        sparkle.color = white(.95f)
        dot.color = tint
        dotRing.strokeWidth = 1f * density
    }

    private fun drawSparkle(c: Canvas, x: Float, y: Float, r: Float) {
        star.reset()
        star.moveTo(x, y - r)
        star.quadTo(x, y, x + r, y)
        star.quadTo(x, y, x, y + r)
        star.quadTo(x, y, x - r, y)
        star.quadTo(x, y, x, y - r)
        star.close()
        c.drawPath(star, sparkle)
    }

    override fun draw(c: Canvas) {
        if (sr <= 0f) return
        val full = minOf(bounds.width(), bounds.height()) / 2f
        c.drawCircle(cx, cy, full, glow)
        c.drawCircle(cx, cy, sr, body)
        c.drawCircle(cx, cy, sr, caustic)

        // لێوەکان: هێڵی تاریکی باریک (بۆ پاشبنەمای ڕووناک) + لێوی شووشەیی سپی
        c.drawCircle(cx, cy, sr + outline.strokeWidth / 2f, outline)
        c.drawCircle(cx, cy, sr - rim.strokeWidth / 2f, rim)
        c.drawCircle(cx, cy, sr * 0.88f, innerRim)

        // هێڵەکانی ڕووناکی و دڵۆپی بریسکە
        shine.color = white(.92f); c.drawPath(upper, shine)
        shine.color = white(.40f); c.drawPath(lower, shine)
        c.drawOval(oval, spot)

        // درەوشانەوەی تێپەڕ
        val sw = sweep
        if (sw >= 0f) {
            val off = (sw * 2f - 1f) * sr * 1.2f
            sheenMatrix.setTranslate(off, off)
            sheenShader?.setLocalMatrix(sheenMatrix)
            sheen.shader = sheenShader
            c.drawCircle(cx, cy, sr - rim.strokeWidth, sheen)
        }

        // ئەستێرەی بچووکی بریسکەدار (لە کاتی درەوشانەوە گەورەتر دەبێت)
        val grow = if (sw >= 0f) 1f + 0.7f * sin(PI.toFloat() * sw) else 1f
        drawSparkle(c, cx + sr * .52f, cy - sr * .52f, sSize * .06f * grow)

        // نیشانەی چالاکی: خاڵێکی بچووک (تەنها ئەمە ڕەنگی هەیە)
        if (active) {
            val dr = sr * .15f
            val dx = cx + sr * .62f
            val dy = cy + sr * .62f
            c.drawCircle(dx, dy, dr, dot)
            c.drawCircle(dx, dy, dr, dotRing)
        }
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        if (visible) {
            if (!anim.isStarted) {
                anim.start()
                // هەر بابلەیەک لە کاتێکی جیاوازدا دەدرەوشێتەوە
                anim.currentPlayTime = (Math.random() * CYCLE_MS).toLong()
            }
        } else {
            anim.cancel()
            sweep = -1f
        }
        return changed
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT

    companion object {
        private const val CYCLE_MS = 4200L
        private const val SWEEP_PART = 0.24f
    }
}
