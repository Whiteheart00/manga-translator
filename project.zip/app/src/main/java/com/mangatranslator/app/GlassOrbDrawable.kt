package com.mangatranslator.app

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable

/**
 * بازنەی «Liquid Glass» بۆ بابلە شەمەندەفەرەکان (گوازراوەتەوە لە LiquidGlassMenu.kt ی Compose):
 * درەوشانەوەی ڕەنگ لە دەرەوە، شێلی شووشەیی بە لێوی گەش و هێڵی ڕووناکی، و ئۆربی ڕەنگاوڕەنگی ناوەوە.
 * `tint` ڕەنگی ئۆربەکەیە؛ بۆ گۆڕینی دۆخ تەنها drawableی نوێ دابنێ.
 */
class GlassOrbDrawable(private val tint: Int, private val density: Float) : Drawable() {

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shell = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val upper = Path()
    private val lower = Path()
    private val oval = RectF()
    private var cx = 0f
    private var cy = 0f
    private var sr = 0f
    private var ir = 0f

    private fun a(c: Int, alpha: Float) = (c and 0x00FFFFFF) or ((alpha * 255).toInt().coerceIn(0, 255) shl 24)
    private fun white(alpha: Float) = a(0xFFFFFF, alpha)

    override fun onBoundsChange(b: android.graphics.Rect) {
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        cx = b.exactCenterX(); cy = b.exactCenterY()
        val R = minOf(w, h) / 2f
        sr = R * 0.86f
        ir = sr * 0.64f
        val l = cx - sr; val t = cy - sr; val s = sr * 2f

        glow.shader = RadialGradient(cx, cy, R, intArrayOf(a(tint, .0f), a(tint, .42f), a(tint, 0f)),
            floatArrayOf(0f, 0.80f, 1f), Shader.TileMode.CLAMP)
        shell.shader = LinearGradient(l, t, l + s, t + s,
            intArrayOf(0x667EBAE9, 0x222B4A70, white(.06f)), floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
        rim.strokeWidth = 1.7f * density
        rim.shader = LinearGradient(l + s * .08f, t + s * .08f, l + s * .94f, t + s * .96f,
            intArrayOf(white(.95f), white(.16f), a(tint, .42f), white(.68f)), null, Shader.TileMode.CLAMP)
        shine.strokeWidth = 1.3f * density
        upper.reset()
        upper.moveTo(l + s * .20f, t + s * .13f)
        upper.cubicTo(l + s * .35f, t + s * .025f, l + s * .70f, t + s * .035f, l + s * .84f, t + s * .18f)
        lower.reset()
        lower.moveTo(l + s * .13f, t + s * .68f)
        lower.cubicTo(l + s * .24f, t + s * .91f, l + s * .56f, t + s * .98f, l + s * .75f, t + s * .88f)

        val dark = android.graphics.Color.rgb(
            (android.graphics.Color.red(tint) * .58f).toInt(),
            (android.graphics.Color.green(tint) * .62f).toInt(),
            (android.graphics.Color.blue(tint) * .82f).toInt()
        )
        inner.shader = LinearGradient(cx - sr * .45f, cy - sr * .55f, cx + sr * .55f, cy + sr * .72f,
            intArrayOf(white(.98f), tint, dark, 0xFF182B55.toInt()), floatArrayOf(0f, .38f, .78f, 1f), Shader.TileMode.CLAMP)
        oval.set(l + s * .36f, t + s * .27f, l + s * .61f, t + s * .37f)
        spot.shader = LinearGradient(oval.left, oval.top, oval.right, oval.bottom,
            white(.80f), white(.04f), Shader.TileMode.CLAMP)
    }

    override fun draw(c: Canvas) {
        if (sr <= 0f) return
        c.drawCircle(cx, cy, minOf(bounds.width(), bounds.height()) / 2f, glow)
        c.drawCircle(cx, cy, sr, shell)
        c.drawCircle(cx, cy, sr - rim.strokeWidth / 2f, rim)
        shine.color = white(.88f); c.drawPath(upper, shine)
        shine.color = white(.32f); c.drawPath(lower, shine)
        c.drawCircle(cx, cy, ir, inner)
        c.drawOval(oval, spot)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
