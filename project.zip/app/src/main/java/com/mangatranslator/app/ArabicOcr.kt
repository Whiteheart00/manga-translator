package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * OCR ی عەرەبی بە Tesseract (ara). ML Kit پشتیوانی لە عەرەبی ناکات، بۆیە ئەمە بەکاردێت.
 * فایلی زمانەکە (~١-٢MB) یەکەم جار خۆکارانە دادەبەزێت و دواتر ئۆفلاین کار دەکات.
 * هەموو بانگەکان دەبێت لە thread ی پاشبنەما بن.
 */
object ArabicOcr {
    private const val TAG = "ArabicOcr"
    private val URLS = listOf(
        "https://github.com/tesseract-ocr/tessdata_fast/raw/main/ara.traineddata",
        "https://github.com/tesseract-ocr/tessdata/raw/main/ara.traineddata"
    )
    private const val MIN_CONF = 40
    private val lock = Any()
    private var api: TessBaseAPI? = null

    private fun dataFile(ctx: Context) = File(ctx.filesDir, "tess/tessdata/ara.traineddata")

    fun isInstalled(ctx: Context): Boolean = dataFile(ctx).let { it.exists() && it.length() > 100_000 }

    /** null = سەرکەوتوو، دەنا پەیامی هەڵە */
    fun download(ctx: Context): String? {
        val f = dataFile(ctx)
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, "ara.tmp")
        val errs = ArrayList<String>()
        for (u in URLS) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", "MangaTranslator/1.0")
                if (c.responseCode !in 200..299) { errs.add("HTTP ${c.responseCode}"); c.disconnect(); continue }
                c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                c.disconnect()
                if (tmp.length() < 100_000) { tmp.delete(); errs.add("فایلەکە بچووکە"); continue }
                if (f.exists()) f.delete()
                if (tmp.renameTo(f)) return null
                errs.add("نەتوانرا ناوەکەی بگۆڕدرێت")
            } catch (t: Throwable) {
                tmp.delete()
                errs.add(t.message ?: t.javaClass.simpleName)
            }
        }
        return "داگرتنی OCR ی عەرەبی سەرنەکەوت (" + errs.distinct().joinToString("، ") + ")"
    }

    private fun engine(ctx: Context): TessBaseAPI? {
        api?.let { return it }
        return try {
            TessBaseAPI().also {
                if (!it.init(File(ctx.filesDir, "tess").absolutePath, "ara")) { it.recycle(); return null }
                it.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
                api = it
            }
        } catch (t: Throwable) {
            Log.e(TAG, "init failed", t); null
        }
    }

    /** بلۆکە عەرەبییەکان لەسەر وێنەکە. ئەگەر فایلی زمان نەبوو، هەوڵی داگرتن دەدات. */
    fun recognize(ctx: Context, bmp: Bitmap, onNotice: (String) -> Unit): List<TextBox> {
        if (!isInstalled(ctx)) {
            onNotice("OCR ی عەرەبی دادەبەزێت (یەکجار)…")
            val err = download(ctx)
            if (err != null) { onNotice(err); return emptyList() }
        }
        return try {
            synchronized(lock) {
                val t = engine(ctx) ?: return emptyList()
                t.setImage(bmp)
                t.getUTF8Text() // دەبێتە هۆی ناسینەوە
                val out = ArrayList<TextBox>()
                val it = t.resultIterator
                if (it != null) {
                    val lvl = TessBaseAPI.PageIteratorLevel.RIL_PARA
                    it.begin()
                    do {
                        val txt = (it.getUTF8Text(lvl) ?: "").replace(Regex("\\s+"), " ").trim()
                        val conf = it.confidence(lvl)
                        val r = it.getBoundingRect(lvl)
                        val arabic = txt.count { ch -> ch.code in 0x0600..0x06FF }
                        if (r != null && txt.length >= 2 && conf >= MIN_CONF && arabic >= 2) out.add(TextBox(r, txt))
                    } while (it.next(lvl))
                    it.delete()
                }
                t.clear()
                out
            }
        } catch (t: Throwable) {
            Log.e(TAG, "recognize failed", t)
            emptyList()
        }
    }

    fun release() {
        synchronized(lock) { try { api?.recycle() } catch (_: Throwable) {}; api = null }
    }
}
