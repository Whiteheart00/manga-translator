package com.mangatranslator.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * خوێنەرەوەی ڕێنمایی: بە دەنگی کوردیی ئۆفلاینی خودی ئەپەکە (Piper / Berfin) دەخوێنێتەوە.
 * - needsVoice: ئەگەر بەکارهێنەر "نەخوێندەوار" بێت، هەموو شتێک خۆکارانە دەخوێنرێتەوە
 * - speak: هەمیشە دەخوێنێتەوە (بۆ ئایکۆنی دووبارەکردنەوە)
 */
object Narrator {
    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val gen = AtomicInteger(0)
    @Volatile private var piper: PiperTts? = null
    private val listeners = CopyOnWriteArrayList<(Boolean) -> Unit>()

    @Volatile var speaking = false
        private set

    fun addListener(l: (Boolean) -> Unit) { listeners.add(l) }
    fun removeListener(l: (Boolean) -> Unit) { listeners.remove(l) }

    fun isReady(ctx: Context) = PiperTts.isInstalled(ctx.applicationContext)

    fun needsVoice(ctx: Context) = TranslatorSettings(ctx.applicationContext).literacy == 2

    private fun setSpeaking(v: Boolean) {
        speaking = v
        ui.post { for (l in listeners) l(v) }
    }

    /** مۆدێلەکە پێشوەختە بار دەکات تا یەکەم خوێندنەوە درەنگ نەکەوێت. */
    fun warmUp(ctx: Context) {
        val app = ctx.applicationContext
        if (!PiperTts.isInstalled(app)) return
        exec.execute {
            try {
                val p = piper ?: PiperTts(app).also { piper = it }
                p.warmUp()
            } catch (_: Throwable) {
            }
        }
    }

    fun stop() {
        gen.incrementAndGet()
        piper?.stop()
        setSpeaking(false)
    }

    /** تەنها ئەگەر بەکارهێنەر نەخوێندەوار بێت دەخوێنێتەوە. */
    fun autoSpeak(ctx: Context, text: String, onDone: ((Boolean) -> Unit)? = null) {
        if (needsVoice(ctx)) speak(ctx, text, onDone)
    }

    fun speak(ctx: Context, text: String, onDone: ((Boolean) -> Unit)? = null) {
        speakAll(ctx, listOf(text), onDone)
    }

    /** onDone(true) = بە سەرکەوتوویی تەواو بوو؛ onDone(false) = دەنگ نییە یان هەڵە. */
    fun speakAll(ctx: Context, texts: List<String>, onDone: ((Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        val my = gen.incrementAndGet()
        piper?.stop()
        if (!PiperTts.isInstalled(app)) {
            ui.post { onDone?.invoke(false) }
            return
        }
        // خێرایی بۆ ڕێنمایی لە ١x زیاتر نابێت، تا نەخوێندەوار بەباشی تێی بگات
        val speed = TranslatorSettings(app).speechSpeed.coerceAtMost(1f)
        exec.execute {
            if (gen.get() != my) return@execute
            val p = piper ?: PiperTts(app).also { piper = it }
            setSpeaking(true)
            val err = try {
                p.speakBlocking(texts, speed) { gen.get() == my }
            } catch (t: Throwable) {
                t.message ?: "error"
            }
            if (gen.get() == my) {
                setSpeaking(false)
                ui.post { onDone?.invoke(err == null) }
            }
        }
    }
}
