package com.mangatranslator.app

/**
 * پاککردنەوەی دەقی سۆرانی دوای مۆدێلی دەنگ←نووسین (Vekol).
 * ئەوەی ڕێسایی ڕاست دەکرێتەوە: نووسینی لکاو («کتێب ەکە» ← «کتێبەکە»)، بۆشایی خاڵبەندی،
 * خاڵبەندیی ئینگلیزی ← کوردی، و دووبارەبوونەوەی هەمان وشە (هەڵەی خۆگەڕاندنی Whisper).
 * وشەی هەڵە (وەک «عەز» بۆ «حەز») ڕێسایی ڕاست ناکرێتەوە — ئەوە بۆ KurdishTextFix (Gemini)ـە.
 */
object SoraniClean {
    private val CLITIC = Regex("^(ەکە|ەکان|ەکەم|ەکەت|ەکەی|ەکەمان|ەکەتان|ەکەیان|ەکانم|ەکانت|ەکانی|ەکانمان|ەکانتان|ەکانیان)$")
    private const val PUNCT = "،؛؟!.:"
    private val PUNCT_CHARS = PUNCT.toCharArray()

    private val REPEAT = Regex("(?<!\\S)(\\S+?)(?:[ ،]+\\1(?!\\S)){2,}")
    private val SPACE_BEFORE = Regex("\\s+([،؛؟!.:])")
    private val SPACE_AFTER = Regex("([،؛؟!:])(?=[^\\s،؛؟!.:])")
    private val MULTI_END = Regex("([.!؟])[.!؟]+")

    fun tidy(raw: String): String {
        var t = raw.replace('?', '؟').replace(',', '،').replace(';', '؛').trim()
        if (t.isEmpty()) return t
        t = REPEAT.replace(t, "$1")

        val out = ArrayList<String>()
        for (w in t.split(' ')) {
            if (w.isEmpty()) continue
            val core = w.trimEnd(*PUNCT_CHARS)
            if (out.isNotEmpty() && core.isNotEmpty() && CLITIC.matches(core) && out.last().last() !in PUNCT) {
                out[out.size - 1] = out.last() + w
            } else {
                out.add(w)
            }
        }
        t = out.joinToString(" ")
        t = SPACE_BEFORE.replace(t, "$1")
        t = SPACE_AFTER.replace(t, "$1 ")
        t = MULTI_END.replace(t, "$1")
        return t.trim()
    }
}
