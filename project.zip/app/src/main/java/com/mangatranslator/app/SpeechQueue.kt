package com.mangatranslator.app

/**
 * ڕیزی دەنگی ژێرنووسی زیندوو: FIFO ی ڕاستەقینە (فەنکشنی پاک، بێ Android، تاقیکراو).
 *
 * یاسا: **هیچ ڕستەیەک ناسڕدرێتەوە، ناپەڕێنرێت و نابڕدرێت.** هەموو ڕستەیەک بە ڕیزی دەرکەوتنی دەخوێنرێتەوە.
 * کاتێک چەند ڕستە لە ڕیزدا چاوەڕێن، لە یەک خوێندنەوەدا (بە هەمان ڕیز، تا [maxChars] پیت) پێکەوە دەنێردرێن بۆ
 * ئەوەی نێوانیان بێدەنگی و داواکاری TTS کەم بێت؛ و کەمێک خێراتر دەخوێنرێنەوە ([Batch.boost]، تا [maxBoost])
 * بۆ ئەوەی ڕیزەکە کۆ نەبێتەوە. هیچ کاتژمێرێکی «کۆن بوو» و هیچ سنوورێک بۆ ژمارەی ڕستەکان نییە.
 */
class SpeechQueue(
    private val maxChars: Int = 300,
    private val maxBoost: Float = 1.3f
) {
    class Batch(val text: String, val boost: Float, val count: Int)

    private val q = ArrayDeque<String>()

    fun isEmpty() = q.isEmpty()
    fun size() = q.size
    fun clear() = q.clear()

    /** تەنها یەک ڕستە ماوە و ئەویش کورتە (≤٢ وشە) */
    fun onlyShort(): Boolean = q.size == 1 && SpeechMerge.isShort(q.first())

    fun add(text: String) {
        val t = text.trim()
        if (t.isNotEmpty()) q.addLast(t)
    }

    /** یەکەم ڕستەی چاوەڕێ (+ ئەوانەی دوای ئەو کە لە [maxChars] دا جێ دەبنەوە)؛ null ئەگەر ڕیز بەتاڵ بێت. */
    fun take(): Batch? {
        if (q.isEmpty()) return null
        val pending = q.size
        val parts = arrayListOf(q.removeFirst())
        var len = parts[0].length
        while (q.isNotEmpty() && len + 1 + q.first().length <= maxChars) {
            val n = q.removeFirst()
            parts.add(n)
            len += n.length + 1
        }
        val text = if (parts.size == 1) parts[0] else parts.joinToString(" ") { endPunct(it) }
        val boost = (1f + 0.06f * (pending - 1)).coerceIn(1f, maxBoost)
        return Batch(text, boost, parts.size)
    }

    private fun endPunct(s: String): String =
        if (s.last() in ".!?؟،,…:;") s else "$s،"
}
