package com.mangatranslator.app

/** Preserve existing tones; the reference recipe is applied in PCM, not again at playback. */
internal object PiperVoiceProfile {
    data class Preset(val id: Int, val label: String, val pitch: Float,
                      val cutoffHz: Float, val targetRms: Float,
                      val edge: Int = 0, val soft: Int = 0)
    private val presets = listOf(
        Preset(0, "دەنگی ڕەسەن", 1f, 7000f, 0.1f),
        Preset(1, "پیاوانەی نەرم", 1f, 5600f, 0.095f),
        Preset(2, "تۆنی ژنانەی نەرم (گۆڕینی دەنگ)", 1.22f, 6000f, 0.095f),
        Preset(3, "نموونەی ئافرەت — ٢١٥ Hz", 1f, 7000f, 0.1f)
    )
    val labels: List<String> = presets.map { it.label }
    fun get(id: Int): Preset = presets.getOrElse(id) { presets[0] }
    fun customized(settings: TranslatorSettings): Preset {
        val base = get(settings.piperVoiceProfile)
        return base.copy(
            pitch = settings.piperPitch,
            cutoffHz = settings.piperCutoffHz.toFloat(),
            targetRms = 0.1f * settings.piperTargetRms / 100f,
            edge = settings.piperEdge,
            soft = settings.piperSoft
        )
    }
    /** Preserve the original helper API used by the existing unit tests/tools. */
    fun cacheKey(speed: Float, lowLatency: Boolean, preset: Preset, text: String) =
        "voice-pcm-v4|${(speed * 100).toInt()}|${if (lowLatency) 1 else 0}|tone=${preset.id}|p=${preset.pitch}|c=${preset.cutoffHz}|r=${preset.targetRms}|g=${preset.edge}|s=${preset.soft}|$text"

    fun cacheKey(speed: Float, lowLatency: Boolean, preset: Preset, text: String, settings: TranslatorSettings) =
        "voice-pcm-v4|${(speed * 100).toInt()}|${if (lowLatency) 1 else 0}|tone=${preset.id}|p=${(settings.piperPitch * 100).toInt()}|c=${settings.piperCutoffHz}|r=${settings.piperTargetRms}|n=${settings.piperNoiseScale}|l=${settings.piperLengthScale}|w=${settings.piperNoiseW}|e=${settings.piperEndPauseMs}|g=${settings.piperEdge}|s=${settings.piperSoft}|$text"
}
