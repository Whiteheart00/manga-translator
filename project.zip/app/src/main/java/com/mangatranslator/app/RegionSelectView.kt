package com.mangatranslator.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * شاشەی تەواو، کەمێک تاریک: بەکارهێنەر بە پەنجە ڕووبەرێک دەکێشێت.
 * کاتێک پەنجە هەڵدەگیرێت، onSelected بانگ دەکرێت. دوگمەی ✕ = پاشگەزبوونەوە.
 */
@SuppressLint("ViewConstructor")
class RegionSelectView(
    context: Context,
    private val onSelected: (RectF) -> Unit,
    private val onCancel: () -> Unit
) : View(context) {

    private val d = resources.displayMetrics.density
    private val dim = Paint().apply { color = Color.argb(110, 0, 0, 0) }
    private val clear = Paint().apply {
        color = Color.TRANSPARENT
        xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
    }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFB300")
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * d
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 16f * d
        textAlign = Paint.Align.CENTER
    }
    private val btnBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#C62828") }

    private var sx = 0f
    private var sy = 0f
    private var cx = 0f
    private var cy = 0f
    private var drawing = false
    private var cancelRect = RectF()

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val bw = 150f * d
        val bh = 44f * d
        cancelRect = RectF(w / 2f - bw / 2, 40f * d, w / 2f + bw / 2, 40f * d + bh)
    }

    private fun sel() = RectF(minOf(sx, cx), minOf(sy, cy), maxOf(sx, cx), maxOf(sy, cy))

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        if (drawing) {
            val r = sel()
            canvas.drawRect(r, clear)
            canvas.drawRect(r, border)
        } else {
            canvas.drawText("ڕووبەرەکە بکێشە (بە پەنجە)", width / 2f, height / 2f, txt)
        }
        canvas.drawRoundRect(cancelRect, 12f * d, 12f * d, btnBg)
        canvas.drawText("✕ پاشگەزبوونەوە", cancelRect.centerX(), cancelRect.centerY() + 6f * d, txt)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                if (cancelRect.contains(e.x, e.y)) {
                    onCancel()
                    return true
                }
                sx = e.x; sy = e.y; cx = e.x; cy = e.y
                drawing = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                cx = e.x; cy = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (!drawing) return true
                drawing = false
                cx = e.x; cy = e.y
                val r = sel()
                if (r.width() >= 40f * d && r.height() >= 30f * d) onSelected(r)
                else invalidate()   // زۆر بچووکە: دووبارە بکێشە
            }
            MotionEvent.ACTION_CANCEL -> {
                drawing = false
                invalidate()
            }
        }
        return true
    }
}
