package com.mangatranslator.app

import android.content.Context

/**
 * فەرهەنگی شاراوەی وشەی سۆرانی بۆ باشترکردنی نووسینی ئۆفلاین (Vekol).
 * لیستەکە لە assets/kurdish_vocab.txt ـە و لە هیچ شوێنێکی ڕووکاردا نیشان نادرێت (نە لە خانەی «ناوەکانم»، نە لە ژمارەی «وشەی فێربوو»)،
 * و ناچێتە ناو داواکارییەکانی Gemini.
 *
 * چۆن کار دەکات: دوای ئەوەی Vekol دەقەکەی نووسی، هەر وشەیەک کە لە فەرهەنگەکەدا نییە و تەنها بە پیتە لێکچووەکان
 * (ە/ه، ی/ێ، و/ۆ، ر/ڕ، ل/ڵ، ف/ڤ...) لە وشەیەکی فەرهەنگەکە جیایە، دەگۆڕدرێت بەو وشەیە.
 * ئاسایشی: وشەی کورتتر لە ٥ پیت دەست لێ نادرێت؛ ئەگەر دوو وشەی فەرهەنگ دەگونجێن (نادڵنیایی) هیچ ناگۆڕدرێت؛
 * پاشگرە باوەکان (ەکە، ەکان، ان، ی، م، ت...) دەکرێنە لاوە و دووبارە دادەنرێنەوە.
 * لە thread ی پاشبنەما بانگ بکرێت (یەکەم جار ~٢٠KB دەخوێنێتەوە).
 */
object KurdishVocab {

    private const val MIN_LEN = 5
    private val CHUNK_SPLIT = Regex("[،,;؛\\n\\r]+")

    /** هەر دەستەیەک = پیتە لێکچووەکان (ئەو پیتەی یەکەم نوێنەرەکەیە). */
    private val CLASSES = arrayOf(
        "\u0647\u06D5\u062D",
        "\u06CC\u06CE",
        "\u0648\u06C6",
        "\u0631\u0695",
        "\u0644\u06B5",
        "\u0641\u06A4",
        "\u0626\u0639",
        "\u062E\u063A\u0642",
        "\u062A\u0637",
        "\u0633\u0635\u062B",
        "\u0632\u0638\u0636\u0630"
    )

    /** پاشگرەکان، درێژترین یەکەم (بە شێوەی ڕێکخراو). */
    private val SUFFIXES = arrayOf(
        "\u06D5\u06A9\u0627\u0646\u06CC\u0627\u0646",
        "\u06D5\u06A9\u0627\u0646\u062A\u0627\u0646",
        "\u06D5\u06A9\u0627\u0646\u0645\u0627\u0646",
        "\u06D5\u06A9\u06D5\u0645\u0627\u0646",
        "\u06D5\u06A9\u06D5\u06CC\u0627\u0646",
        "\u06D5\u06A9\u06D5\u062A\u0627\u0646",
        "\u06D5\u06A9\u0627\u0646\u0645",
        "\u06D5\u06A9\u0627\u0646\u062A",
        "\u06D5\u06A9\u0627\u0646\u06CC",
        "\u06D5\u06A9\u0627\u0646",
        "\u06D5\u06A9\u06D5\u0645",
        "\u06CC\u06D5\u0648\u06D5",
        "\u06D5\u06A9\u06D5\u06CC",
        "\u06D5\u06A9\u06D5\u062A",
        "\u062A\u0627\u0646",
        "\u06CC\u0627\u0646",
        "\u0645\u0627\u0646",
        "\u06D5\u06A9\u06D5",
        "\u06D5\u0648\u06D5",
        "\u06CE\u06A9\u06CC",
        "\u06CC\u06D5\u06A9",
        "\u06CE\u06A9",
        "\u06CC\u0634",
        "\u06D5\u06CC",
        "\u0627\u0646",
        "\u062F\u0627",
        "\u06CC\u0646",
        "\u06D5\u06A9",
        "\u0634",
        "\u06D5",
        "\u06CC",
        "\u0645",
        "\u06CE",
        "\u062A",
        ""
    )

    private val REP: Map<Char, Char> by lazy {
        val m = HashMap<Char, Char>()
        for (c in CLASSES) for (ch in c) m[ch] = c[0]
        m
    }

    @Volatile private var words: HashSet<String>? = null
    @Volatile private var bySkel: HashMap<String, ArrayList<String>>? = null

    private fun skel(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) sb.append(REP[c] ?: c)
        return sb.toString()
    }

    @Synchronized
    private fun load(ctx: Context) {
        if (words != null) return
        val set = HashSet<String>(4096)
        val map = HashMap<String, ArrayList<String>>()
        fun add(w: String) {
            if (w.length < 2 || !set.add(w)) return
            if (w.length >= MIN_LEN) map.getOrPut(skel(w)) { ArrayList() }.add(w)
        }
        ctx.assets.open("kurdish_vocab.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) add(line.trim())
        }
        // لیستی زیادە (دەکرێت بە ڕێکخستنی نەکراوی، بە کۆما/دێڕ/ناونیشان جیا کرابێتەوە): assets/kurdish_vocab_extra.txt
        // هەر وشەیەک پاک دەکرێتەوە: نۆرماڵ، لاتینی/ژمارە/هێمای ناڕێک فڕێ دەدرێن، دووبارە نامێنێت.
        // ڕستەی چەند وشەیی (سەرۆکی پەرلەمان) وەک خۆی و وەک وشە جیاکانیش زیاد دەکرێت.
        try {
            ctx.assets.open("kurdish_vocab_extra.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    for (chunk in CHUNK_SPLIT.split(line)) {
                        val c = KurdishEntities.norm(chunk).trim()
                        if (c.isEmpty() || c.endsWith(":")) continue
                        for (w in c.split(' ')) {
                            val t = w.trim().trim('.', '،', ',', ':', '؛', '؟', '!')
                            if (t.length >= 2 && t.all { ch -> ch in '\u0621'..'\u06FF' && ch !in '\u0660'..'\u0669' && ch !in '\u06F0'..'\u06F9' }) add(t)
                        }
                    }
                }
            }
        } catch (_: Throwable) { /* فایلی زیادە ئارەزوومەندانەیە */ }
        bySkel = map
        words = set
    }

    /**
     * دەقی ئۆفلاین چاک دەکات. [original] = دەقی خاوی Vekol؛ ئەگەر [text] لەسەر ئەو بنەمایە چاکرابێت (وشە فێربووەکان)،
     * ئەو وشانەی گۆڕدراون دەست لێ نادرێن. هەر هەڵەیەک ← دەقی ڕەسەن دەگەڕێتەوە.
     */
    fun fix(ctx: Context, text: String, original: String = text): String {
        if (text.isBlank()) return text
        return try {
            load(ctx)
            val ws = words ?: return text
            val idx = bySkel ?: return text
            val parts = text.split(' ')
            val orig = original.split(' ')
            val same = parts.size == orig.size
            var changed = false
            val out = ArrayList<String>(parts.size)
            for ((i, w) in parts.withIndex()) {
                if (same && w != orig[i]) { out.add(w); continue }
                val r = fixWord(w, ws, idx)
                if (r != w) changed = true
                out.add(r)
            }
            if (changed) out.joinToString(" ") else text
        } catch (_: Throwable) {
            text
        }
    }

    private fun fixWord(w: String, ws: HashSet<String>, idx: HashMap<String, ArrayList<String>>): String {
        var a = 0
        var b = w.length
        while (a < b && !w[a].isLetter()) a++
        while (b > a && !w[b - 1].isLetter()) b--
        if (b - a < MIN_LEN) return w
        val core = KurdishEntities.norm(w.substring(a, b))
        for (c in core) if (c < '\u0621' || c > '\u06FF') return w     // لاتینی، ژمارە... دەست لێ نادرێت
        if (core.length < MIN_LEN || core in ws) return w
        // وشەی دروستی پاشگرداری وەک «ئەندازیارەکە»: دەمێنێتەوە
        for (suf in SUFFIXES) {
            if (core.length - suf.length < MIN_LEN || !core.endsWith(suf)) continue
            if (core.substring(0, core.length - suf.length) in ws) return w
        }
        for (suf in SUFFIXES) {
            if (core.length - suf.length < MIN_LEN || !core.endsWith(suf)) continue
            val fixed = nearest(core.substring(0, core.length - suf.length), idx) ?: continue
            return w.substring(0, a) + fixed + suf + w.substring(b)
        }
        return w
    }

    /** تەنها یەک وشەی فەرهەنگ کە بە ١ (یان ٢ بۆ وشەی درێژ) پیتی لێکچوو جیاوازە؛ ئەگەرنا null. */
    private fun nearest(stem: String, idx: HashMap<String, ArrayList<String>>): String? {
        val cands = idx[skel(stem)] ?: return null
        val limit = if (stem.length >= 7) 2 else 1
        var best: String? = null
        for (c in cands) {
            if (c.length != stem.length) continue
            var d = 0
            for (i in stem.indices) if (stem[i] != c[i]) d++
            if (d in 1..limit) {
                if (best != null && best != c) return null     // نادڵنیا: دوو وشە دەگونجێن
                best = c
            }
        }
        return best
    }
}
