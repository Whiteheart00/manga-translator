package com.mangatranslator.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.text.Normalizer
import java.util.zip.ZipInputStream

/**
 * دەنگی کوردیی نیورالی ئۆفلاین (Piper / VITS بە ONNX، ڕاستەوخۆ بە onnxruntime).
 * مۆدێلەکە (model.onnx + model.onnx.json) پیتی کوردیی سۆرانی ڕاستەوخۆ دەخوێنێتەوە، بێ espeak.
 * مۆدێلەکە لە ڕێکخستنی دەنگ ← «هێنانی مۆدێل» دەهێنرێت و دەکرێتە filesDir/piper_kurdish/.
 */
class PiperTts(private val ctx: Context) {

    @Volatile private var env: OrtEnvironment? = null
    @Volatile private var session: OrtSession? = null
    @Volatile private var idMap: Map<String, Long> = emptyMap()
    @Volatile private var sampleRate = 22050
    @Volatile private var noiseScale = 0.667f
    @Volatile private var lengthScale = 1.0f
    @Volatile private var noiseW = 0.8f
    @Volatile private var hasSid = false
    @Volatile private var track: AudioTrack? = null
    @Volatile private var cancelled = false

    @Volatile var speaking = false
        private set

    /** پەیام دەگەڕێنێتەوە ئەگەر مۆدێل نەدۆزرایەوە یان بار نەبوو. */
    @Synchronized
    private fun ensureLoaded(): String? {
        if (session != null) return null
        val dir = modelDir(ctx)
        val onnx = File(dir, MODEL)
        val cfg = File(dir, CONFIG)
        if (!onnx.exists() || !cfg.exists()) {
            return "مۆدێلی کوردیی نیورالی نەهێنراوە. لە ڕێکخستنی دەنگ دوگمەی «هێنانی مۆدێل» دابگرە و فایلی zip ی مۆدێلەکە هەڵبژێرە"
        }
        return try {
            val j = JSONObject(cfg.readText())
            val m = j.getJSONObject("phoneme_id_map")
            val map = HashMap<String, Long>()
            for (k in m.keys()) map[k] = m.getJSONArray(k).getLong(0)
            idMap = map
            sampleRate = j.optJSONObject("audio")?.optInt("sample_rate", 22050) ?: 22050
            j.optJSONObject("inference")?.let {
                noiseScale = it.optDouble("noise_scale", 0.667).toFloat()
                lengthScale = it.optDouble("length_scale", 1.0).toFloat()
                noiseW = it.optDouble("noise_w", 0.8).toFloat()
            }
            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
            val s = e.createSession(onnx.absolutePath, opts)
            hasSid = s.inputNames.contains("sid")
            env = e
            session = s
            null
        } catch (e: Throwable) {
            Log.e(TAG, "load failed", e)
            "بارکردنی مۆدێلی کوردی سەرنەکەوت: ${e.message}"
        }
    }

    /** دەقی سۆرانی ← ID ـی پیتەکان (وەک Piper: ^ پیت _ پیت _ ... $). */
    private fun toIds(text: String): LongArray? {
        val t = Normalizer.normalize(
            text.replace('ك', 'ک').replace('ي', 'ی').replace('ى', 'ی').replace('ة', 'ە')
                .replace("\u200c", "").replace("\u200d", "").replace("ـ", ""),
            Normalizer.Form.NFD
        )
        val bos = idMap["^"] ?: 1L
        val eos = idMap["$"] ?: 2L
        val pad = idMap["_"] ?: 0L
        val ids = ArrayList<Long>(t.length * 2 + 2)
        ids.add(bos)
        var any = false
        for (ch in t) {
            val id = idMap[ch.toString()] ?: continue
            if (ch == '^' || ch == '$' || ch == '_') continue
            ids.add(id); ids.add(pad)
            if (ch != ' ' && ch != '.' && ch != '!' && ch != '-' && ch != ':') any = true
        }
        ids.add(eos)
        return if (any) ids.toLongArray() else null
    }

    private fun synth(ids: LongArray, speed: Float): FloatArray {
        val e = env ?: throw IllegalStateException("env")
        val s = session ?: throw IllegalStateException("session")
        val n = ids.size.toLong()
        val inputs = HashMap<String, OnnxTensor>()
        try {
            inputs["input"] = OnnxTensor.createTensor(e, LongBuffer.wrap(ids), longArrayOf(1, n))
            inputs["input_lengths"] = OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(n)), longArrayOf(1))
            inputs["scales"] = OnnxTensor.createTensor(
                e, FloatBuffer.wrap(floatArrayOf(noiseScale, lengthScale / speed.coerceIn(0.5f, 2f), noiseW)), longArrayOf(3)
            )
            if (hasSid) inputs["sid"] = OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(0)), longArrayOf(1))
            s.run(inputs).use { res ->
                val fb = (res[0] as OnnxTensor).floatBuffer
                val out = FloatArray(fb.remaining())
                fb.get(out)
                return out
            }
        } finally {
            inputs.values.forEach { try { it.close() } catch (_: Exception) {} }
        }
    }

    /** بە ڕیز دەخوێنێتەوە؛ لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو. */
    fun speakBlocking(texts: List<String>, speed: Float, isCurrent: () -> Boolean): String? {
        ensureLoaded()?.let { return it }
        cancelled = false
        speaking = true
        try {
            for (t in texts) {
                for (sentence in splitSentences(t)) {
                    if (cancelled || !isCurrent()) return null
                    val ids = toIds(sentence) ?: continue
                    val samples = try {
                        synth(ids, speed)
                    } catch (e: Throwable) {
                        Log.e(TAG, "synth failed", e)
                        return "Piper: ${e.message}"
                    }
                    if (samples.isEmpty()) continue
                    play(samples, sampleRate, isCurrent)
                }
            }
        } finally {
            speaking = false
        }
        return null
    }

    private fun splitSentences(s: String): List<String> =
        s.split(Regex("(?<=[.!?؟\\n])\\s*")).map { it.trim() }.filter { it.length >= 2 }

    private fun play(samples: FloatArray, rate: Int, isCurrent: () -> Boolean) {
        val pcm = ShortArray(samples.size) { i ->
            (samples[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val at = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, pcm.size * 2))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = at
        try {
            at.write(pcm, 0, pcm.size)
            at.play()
            val totalMs = pcm.size * 1000L / rate
            val start = System.currentTimeMillis()
            while (!cancelled && isCurrent() && System.currentTimeMillis() - start < totalMs + 150) {
                Thread.sleep(40)
            }
        } finally {
            try { at.stop() } catch (_: Exception) {}
            at.release()
            if (track === at) track = null
        }
    }

    fun stop() {
        cancelled = true
        speaking = false
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
    }

    fun shutdown() {
        stop()
        try { session?.close() } catch (_: Throwable) {}
        session = null
    }

    companion object {
        private const val TAG = "PiperTts"
        private const val MODEL = "model.onnx"
        private const val CONFIG = "model.onnx.json"

        fun modelDir(ctx: Context) = File(ctx.filesDir, "piper_kurdish")

        fun isInstalled(ctx: Context) =
            File(modelDir(ctx), MODEL).exists() && File(modelDir(ctx), CONFIG).exists()

        private fun displayName(ctx: Context, uri: Uri): String =
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0) else null
                }
            } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()

        /**
         * فایلە هەڵبژێردراوەکان دەهێنێت: zip (کە model.onnx و model.onnx.json ی تێدایە) یان .onnx / .json.
         * لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو، ئەگینا پەیامی هەڵە.
         */
        fun importModel(ctx: Context, uris: List<Uri>): String? {
            val dir = modelDir(ctx)
            dir.mkdirs()
            try {
                for (uri in uris) {
                    val name = displayName(ctx, uri).lowercase()
                    val input = ctx.contentResolver.openInputStream(uri) ?: return "فایلەکە نەکرایەوە"
                    input.use { ins ->
                        when {
                            name.endsWith(".zip") -> {
                                ZipInputStream(ins.buffered()).use { zin ->
                                    while (true) {
                                        val e = zin.nextEntry ?: break
                                        if (e.isDirectory) continue
                                        val base = e.name.substringAfterLast('/').lowercase()
                                        val target = when {
                                            base.endsWith(".onnx.json") -> CONFIG
                                            base.endsWith(".onnx") -> MODEL
                                            else -> null
                                        } ?: continue
                                        File(dir, target + ".tmp").outputStream().use { zin.copyTo(it) }
                                        File(dir, target).delete()
                                        File(dir, target + ".tmp").renameTo(File(dir, target))
                                    }
                                }
                            }
                            name.endsWith(".onnx.json") || name.endsWith(".json") ->
                                File(dir, CONFIG).outputStream().use { ins.copyTo(it) }
                            name.endsWith(".onnx") ->
                                File(dir, MODEL).outputStream().use { ins.copyTo(it) }
                            else -> return "جۆری فایل نەناسراوە ($name). zip یان .onnx یان .json هەڵبژێرە"
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "import failed", e)
                return "هێنان سەرنەکەوت: ${e.message}"
            }
            return if (isInstalled(ctx)) null
            else "model.onnx یان model.onnx.json لە فایلەکاندا نەبوو"
        }
    }
}
