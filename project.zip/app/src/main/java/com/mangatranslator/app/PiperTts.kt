package com.mangatranslator.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.text.Normalizer
import java.util.concurrent.BlockingQueue
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.ZipInputStream

/** پەیامێک بۆ ڕیزی خوێندنەوە: text == null واتە کۆتایی. */
class SpeechMsg(val text: String?)

/**
 * دەنگی کوردیی نیورالی ئۆفلاین (Piper / VITS بە ONNX، ڕاستەوخۆ بە onnxruntime).
 * مۆدێلەکە (model.onnx + model.onnx.json) پیتی کوردیی سۆرانی ڕاستەوخۆ دەخوێنێتەوە، بێ espeak.
 * مۆدێلەکە لە ڕێکخستنی دەنگ ← «هێنانی مۆدێل» دەهێنرێت و دەکرێتە filesDir/piper_kurdish/.
 */
class PiperTts(private val ctx: Context) {

    @Volatile private var env: OrtEnvironment? = null
    @Volatile private var session: OrtSession? = null
    @Volatile private var idMap: Map<String, Long> = emptyMap()
    @Volatile private var sampleRate = 22050
    // ڕێکخستنی ڕوونی دەنگ (بێ گۆڕینی مۆدێلەکە): noise کەمتر = دەنگی جێگیرتر، length زیاتر = کەمێک هێواشتر.
    // ئەگەر دەنگەکە زۆر «ڕۆبۆت» بوو TUNE_NOISE بەرەو 0.667 بەرز بکەرەوە.
    private val TUNE_NOISE = 0.4f
    private val TUNE_NOISE_W = 0.55f
    private val TUNE_LENGTH = 1.08f
    private val TARGET_RMS = 0.1f
    @Volatile private var noiseScale = TUNE_NOISE
    @Volatile private var lengthScale = 1.0f * TUNE_LENGTH
    @Volatile private var noiseW = TUNE_NOISE_W
    @Volatile private var hasSid = false
    @Volatile private var track: AudioTrack? = null
    @Volatile private var cancelled = false

    @Volatile var speaking = false
        private set

    /** پەیام دەگەڕێنێتەوە ئەگەر مۆدێل نەدۆزرایەوە یان بار نەبوو. */
    @Synchronized
    private fun ensureLoaded(): String? {
        if (session != null) return null
        val dir = modelDir(ctx)
        val onnx = File(dir, MODEL)
        val cfg = File(dir, CONFIG)
        if (!onnx.exists() || !cfg.exists()) {
            return "مۆدێلی کوردیی نیورالی نەهێنراوە. لە ڕێکخستنی دەنگ دوگمەی «هێنانی مۆدێل» دابگرە و فایلی zip ی مۆدێلەکە هەڵبژێرە"
        }
        return try {
            val j = JSONObject(cfg.readText())
            val m = j.getJSONObject("phoneme_id_map")
            val map = HashMap<String, Long>()
            for (k in m.keys()) map[k] = m.getJSONArray(k).getLong(0)
            idMap = map
            sampleRate = j.optJSONObject("audio")?.optInt("sample_rate", 22050) ?: 22050
            j.optJSONObject("inference")?.let {
                noiseScale = TUNE_NOISE
                lengthScale = it.optDouble("length_scale", 1.0).toFloat() * TUNE_LENGTH
                noiseW = TUNE_NOISE_W
            }
            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
            val s = e.createSession(onnx.absolutePath, opts)
            hasSid = s.inputNames.contains("sid")
            env = e
            session = s
            null
        } catch (e: Throwable) {
            Log.e(TAG, "load failed", e)
            "بارکردنی مۆدێلی کوردی سەرنەکەوت: ${e.message}"
        }
    }

    /** دەقی سۆرانی ← ID ـی پیتەکان (وەک Piper: ^ پیت _ پیت _ ... $). */
    private fun toIds(text: String): LongArray? {
        val t = Normalizer.normalize(
            text.replace('ك', 'ک').replace('ي', 'ی').replace('ى', 'ی').replace('ة', 'ە')
                .replace("\u200c", "").replace("\u200d", "").replace("ـ", ""),
            Normalizer.Form.NFD
        )
        val bos = idMap["^"] ?: 1L
        val eos = idMap["$"] ?: 2L
        val pad = idMap["_"] ?: 0L
        val ids = ArrayList<Long>(t.length * 2 + 2)
        ids.add(bos)
        var any = false
        for (ch in t) {
            val id = idMap[ch.toString()] ?: continue
            if (ch == '^' || ch == '$' || ch == '_') continue
            ids.add(id); ids.add(pad)
            if (ch != ' ' && ch != '.' && ch != '!' && ch != '-' && ch != ':') any = true
        }
        ids.add(eos)
        return if (any) ids.toLongArray() else null
    }

    /** بێدەنگیی سەر و کۆتا دەبڕێت، fade ی کورت دەدات و ئاستی دەنگ یەکسان دەکات؛ endPauseMs = وەستانی دوای ڕستە. */
    private fun polish(x: FloatArray, rate: Int, endPauseMs: Int): FloatArray {
        var peak = 0f
        for (v in x) { val a = Math.abs(v); if (a > peak) peak = a }
        if (peak < 1e-4f) return x
        val th = peak * 0.01f
        var st = 0
        while (st < x.size - 1 && Math.abs(x[st]) < th) st++
        var en = x.size - 1
        while (en > st && Math.abs(x[en]) < th) en--
        val a = maxOf(0, st - (rate * 0.04).toInt())
        val b = minOf(x.size, en + (rate * 0.06).toInt())
        if (b <= a) return x
        val pad = rate * endPauseMs / 1000
        val y = FloatArray(b - a + pad)
        System.arraycopy(x, a, y, 0, b - a)
        val len = b - a
        denoise(y, len, rate)   // DC و خشەی زیر (hiss) کەم دەکاتەوە
        val fade = minOf((rate * 0.015).toInt(), len / 2)
        for (i in 0 until fade) {
            val g = i / fade.toFloat()
            y[i] *= g
            y[len - 1 - i] *= g
        }
        var sum = 0.0
        var pk = 0f
        for (i in 0 until len) { val v = y[i]; sum += v.toDouble() * v; val q = Math.abs(v); if (q > pk) pk = q }
        val rms = Math.sqrt(sum / len).toFloat()
        if (rms < 1e-5f || pk < 1e-5f) return y
        val g = minOf(TARGET_RMS / rms, 0.9f / pk, 2.5f)   // 4x خشەی بێدەنگی بەرز دەکردەوە
        for (i in 0 until len) y[i] *= g
        return y
    }

    /**
     * DC-blocker + دوو فلتەری نەرمی low-pass (~٧kHz): خشە و گزگزەی زیری VITS کەم دەکاتەوە بێ ئەوەی دەنگەکە کپ بکات.
     * تەنها بەشی [0, len) دەگۆڕێت (وەستانی کۆتایی دەست لێنادرێت).
     */
    private fun denoise(y: FloatArray, len: Int, rate: Int) {
        val r = 0.995f
        var px = 0f
        var py = 0f
        for (i in 0 until len) {
            val x = y[i]
            val o = x - px + r * py
            px = x
            py = o
            y[i] = o
        }
        val fc = minOf(7000f, rate * 0.45f)
        val a = (1.0 - Math.exp(-2.0 * Math.PI * fc / rate)).toFloat()
        var s1 = 0f
        var s2 = 0f
        for (i in 0 until len) {
            s1 += a * (y[i] - s1)
            s2 += a * (s1 - s2)
            y[i] = s2
        }
    }

    private fun synth(ids: LongArray, speed: Float): FloatArray {
        val e = env ?: throw IllegalStateException("env")
        val s = session ?: throw IllegalStateException("session")
        val n = ids.size.toLong()
        val inputs = HashMap<String, OnnxTensor>()
        try {
            inputs["input"] = OnnxTensor.createTensor(e, LongBuffer.wrap(ids), longArrayOf(1, n))
            inputs["input_lengths"] = OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(n)), longArrayOf(1))
            inputs["scales"] = OnnxTensor.createTensor(
                e, FloatBuffer.wrap(floatArrayOf(noiseScale, lengthScale / speed.coerceIn(0.5f, 2f), noiseW)), longArrayOf(3)
            )
            if (hasSid) inputs["sid"] = OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(0)), longArrayOf(1))
            s.run(inputs).use { res ->
                val fb = (res[0] as OnnxTensor).floatBuffer
                val out = FloatArray(fb.remaining())
                fb.get(out)
                return out
            }
        } finally {
            inputs.values.forEach { try { it.close() } catch (_: Exception) {} }
        }
    }

    /** مۆدێلەکە بار دەکات و یەک ڕستەی کورت دروست دەکات، تا یەکەم خوێندنەوە چاوەڕێی بارکردن نەکات. */
    fun warmUp() {
        try {
            if (ensureLoaded() == null) {
                toIds("سڵاو.")?.let { synth(it, 1f) }
            }
        } catch (_: Throwable) {
        }
    }

    /** بە ڕیز دەخوێنێتەوە؛ لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو. */
    fun speakBlocking(texts: List<String>, speed: Float, isCurrent: () -> Boolean): String? {
        val q = LinkedBlockingQueue<SpeechMsg>()
        for (t in texts) q.add(SpeechMsg(t))
        q.add(SpeechMsg(null))
        return speakStream(q, speed, isCurrent)
    }

    /**
     * دەقەکان لە `source` وەردەگرێت تا کۆتایی (SpeechMsg(null)). دروستکردنی دەنگ (thread ی خۆی) و پەخشکردن
     * پێکەوە کار دەکەن: لە کاتی خوێندنەوەی ڕستەیەک، ڕستەی دواتر دروست دەکرێت، و بە یەک AudioTrack دەپەخشرێت بێ وچان.
     * لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو.
     */
    fun speakStream(source: BlockingQueue<SpeechMsg>, speed: Float, isCurrent: () -> Boolean): String? {
        ensureLoaded()?.let { return it }
        cancelled = false
        speaking = true
        val pcmQ = LinkedBlockingQueue<FloatArray>(3)
        val endMark = FloatArray(0)
        val err = AtomicReference<String?>(null)
        val producer = Thread({
            try {
                loop@ while (!cancelled && isCurrent()) {
                    val m = source.poll(150, TimeUnit.MILLISECONDS) ?: continue
                    val t = m.text ?: break
                    for (sentence in chunks(KurdishSpeechPrep.prepare(t))) {
                        if (cancelled || !isCurrent()) break@loop
                        val ids = toIds(sentence) ?: continue
                        val endsSentence = sentence.trimEnd().lastOrNull()?.let { it == '.' || it == '!' || it == '؟' } == true
                        val samples = polish(synth(ids, speed), sampleRate, if (endsSentence) 120 else 30)
                        if (samples.isEmpty()) continue
                        while (!pcmQ.offer(samples, 200, TimeUnit.MILLISECONDS)) {
                            if (cancelled || !isCurrent()) break@loop
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "synth failed", e)
                err.set("Piper: ${e.message}")
            } finally {
                pcmQ.offer(endMark, 1, TimeUnit.SECONDS)
            }
        }, "piper-synth")
        producer.start()

        var at: AudioTrack? = null
        var written = 0L
        try {
            while (!cancelled && isCurrent()) {
                val samples = pcmQ.poll(200, TimeUnit.MILLISECONDS)
                if (samples == null) {
                    // دروستکردنی ڕستەی دواتر درێژەی کێشا: ئەوەی هەیە بیپەخشێنە
                    at?.let { if (written > 0 && it.playState != AudioTrack.PLAYSTATE_PLAYING) it.play() }
                    continue
                }
                if (samples === endMark) break
                val pcm = ShortArray(samples.size) { i -> (samples[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
                var t = at
                if (t == null) {
                    t = newTrack(sampleRate)
                    at = t
                    track = t
                }
                var off = 0
                while (off < pcm.size && !cancelled && isCurrent()) {
                    val n = t.write(pcm, off, minOf(pcm.size - off, 2048), AudioTrack.WRITE_NON_BLOCKING)
                    if (n < 0) break
                    if (n == 0) {
                        if (t.playState != AudioTrack.PLAYSTATE_PLAYING) t.play()   // بەفەر پڕ بوو
                        Thread.sleep(8)
                    } else off += n
                }
                written += off
                // دەست بە پەخش دەکات دوای ٠٫٣ چرکە دەنگ لە بەفەر (underrun = گزگزە)
                if (t.playState != AudioTrack.PLAYSTATE_PLAYING && written >= sampleRate * 3L / 10) t.play()
            }
            // ڕستەی کۆتایی هەتا کۆتایی دەپەخشرێت
            val t = at
            if (t != null && !cancelled && isCurrent()) {
                if (t.playState != AudioTrack.PLAYSTATE_PLAYING) t.play()
                val deadline = System.currentTimeMillis() + written * 1000L / sampleRate + 1500
                while (!cancelled && isCurrent() && t.playbackHeadPosition < written && System.currentTimeMillis() < deadline) {
                    Thread.sleep(30)
                }
            }
        } finally {
            producer.interrupt()
            at?.let {
                // وەستاندن: دەنگی ماوە لە بەفەر فڕێ دەدرێت، نەک هەتا کۆتایی بپەخشرێت
                if (cancelled || !isCurrent()) {
                    try { it.pause(); it.flush() } catch (_: Exception) {}
                }
                try { it.stop() } catch (_: Exception) {}
                it.release()
            }
            if (track === at) track = null
            speaking = false
        }
        return err.get()
    }

    private fun newTrack(rate: Int): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, rate * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    private fun splitSentences(s: String): List<String> =
        s.split(Regex("(?<=[.!?؟\\n])\\s*")).map { it.trim() }.filter { it.length >= 2 }

    /** ڕستەی درێژ دەکرێتە پارچەی کورت (لە فاریزە/بۆشایی)، بۆ ئەوەی دەنگی یەکەم پارچە زوو ئامادە بێت. */
    private fun chunks(s: String): List<String> {
        val out = ArrayList<String>()
        for (sent in splitSentences(s)) {
            if (sent.length <= MAX_CHUNK) {
                out.add(sent)
                continue
            }
            val cur = StringBuilder()
            for (w in sent.split(' ')) {
                if (w.isEmpty()) continue
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(w)
                val endsComma = w.endsWith("،") || w.endsWith(",") || w.endsWith("؛")
                if (cur.length >= MAX_CHUNK || (endsComma && cur.length >= 35)) {
                    out.add(cur.toString())
                    cur.setLength(0)
                }
            }
            if (cur.isNotEmpty()) {
                if (cur.length < 8 && out.isNotEmpty()) out[out.size - 1] = out.last() + " " + cur else out.add(cur.toString())
            }
        }
        return out.filter { it.length >= 2 }
    }

    fun stop() {
        cancelled = true
        speaking = false
    }

    fun shutdown() {
        stop()
        try { session?.close() } catch (_: Throwable) {}
        session = null
    }

    companion object {
        private const val TAG = "PiperTts"
        private const val MODEL = "model.onnx"
        private const val CONFIG = "model.onnx.json"
        private const val MAX_CHUNK = 80

        fun modelDir(ctx: Context) = File(ctx.filesDir, "piper_kurdish")

        fun isInstalled(ctx: Context) =
            File(modelDir(ctx), MODEL).exists() && File(modelDir(ctx), CONFIG).exists()

        const val VOICE_URL = "https://github.com/Whiteheart00/manga-translator/releases/download/v1.0.1/kurdish_onnx_model.zip"

        /** دەنگی کوردی دادەبەزێنێت و دەیکاتەوە. null = باشە. لەسەر thread ی کار بانگ بکرێت. */
        fun download(ctx: Context, url: String = VOICE_URL, progress: (Int) -> Unit): String? {
            val dir = modelDir(ctx)
            dir.mkdirs()
            val z = File(ctx.cacheDir, "ku_voice.zip")
            return try {
                var u = url
                var c: java.net.HttpURLConnection
                var hops = 0
                while (true) {
                    c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 15_000
                    c.readTimeout = 60_000
                    c.instanceFollowRedirects = false
                    val code = c.responseCode
                    if (code in 300..399 && hops++ < 6) {
                        u = java.net.URL(java.net.URL(u), c.getHeaderField("Location") ?: return "داگرتن سەرنەکەوت: redirect").toString()
                        c.disconnect()
                        continue
                    }
                    if (code !in 200..299) { c.disconnect(); return "داگرتن سەرنەکەوت: HTTP $code" }
                    break
                }
                val total = c.contentLengthLong
                var got = 0L
                var last = -1
                c.inputStream.use { ins ->
                    z.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            got += n
                            if (total > 0) {
                                val p = (got * 100 / total).toInt()
                                if (p != last) { last = p; progress(p) }
                            }
                        }
                    }
                }
                c.disconnect()
                ZipInputStream(z.inputStream().buffered()).use { zin ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        if (e.isDirectory) continue
                        val base = e.name.substringAfterLast('/').lowercase()
                        val target = when {
                            base.endsWith(".onnx.json") -> CONFIG
                            base.endsWith(".onnx") -> MODEL
                            else -> null
                        } ?: continue
                        val tmp = File(dir, "$target.tmp")
                        tmp.outputStream().use { zin.copyTo(it) }
                        File(dir, target).delete()
                        tmp.renameTo(File(dir, target))
                    }
                }
                if (isInstalled(ctx)) null else "model.onnx یان model.onnx.json لە zip دا نەبوو"
            } catch (e: Throwable) {
                Log.e(TAG, "download failed", e)
                "داگرتن سەرنەکەوت: ${e.message}"
            } finally {
                z.delete()
            }
        }

        private fun displayName(ctx: Context, uri: Uri): String =
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0) else null
                }
            } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()

        /**
         * فایلە هەڵبژێردراوەکان دەهێنێت: zip (کە model.onnx و model.onnx.json ی تێدایە) یان .onnx / .json.
         * لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو، ئەگینا پەیامی هەڵە.
         */
        fun importModel(ctx: Context, uris: List<Uri>): String? {
            val dir = modelDir(ctx)
            dir.mkdirs()
            try {
                for (uri in uris) {
                    val name = displayName(ctx, uri).lowercase()
                    val input = ctx.contentResolver.openInputStream(uri) ?: return "فایلەکە نەکرایەوە"
                    input.use { ins ->
                        when {
                            name.endsWith(".zip") -> {
                                ZipInputStream(ins.buffered()).use { zin ->
                                    while (true) {
                                        val e = zin.nextEntry ?: break
                                        if (e.isDirectory) continue
                                        val base = e.name.substringAfterLast('/').lowercase()
                                        val target = when {
                                            base.endsWith(".onnx.json") -> CONFIG
                                            base.endsWith(".onnx") -> MODEL
                                            else -> null
                                        } ?: continue
                                        File(dir, target + ".tmp").outputStream().use { zin.copyTo(it) }
                                        File(dir, target).delete()
                                        File(dir, target + ".tmp").renameTo(File(dir, target))
                                    }
                                }
                            }
                            name.endsWith(".onnx.json") || name.endsWith(".json") ->
                                File(dir, CONFIG).outputStream().use { ins.copyTo(it) }
                            name.endsWith(".onnx") ->
                                File(dir, MODEL).outputStream().use { ins.copyTo(it) }
                            else -> return "جۆری فایل نەناسراوە ($name). zip یان .onnx یان .json هەڵبژێرە"
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "import failed", e)
                return "هێنان سەرنەکەوت: ${e.message}"
            }
            return if (isInstalled(ctx)) null
            else "model.onnx یان model.onnx.json لە فایلەکاندا نەبوو"
        }
    }
}
