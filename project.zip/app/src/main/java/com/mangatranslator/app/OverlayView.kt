package com.mangatranslator.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View

/**
 * ئەو View ـەی لەسەر هەموو شاشە دەکێشرێت (touch-through).
 * هەر بابلێک دەپۆشێت بە ڕەشی تەواو و دەقی سۆرانی (ڕاستەوچەپ) تێدا دەنووسێت،
 * بە قەبارەی فۆنتێک کە لە بابلەکە بێت.
 */
class OverlayView(context: Context) : View(context) {

    private var boxes: List<TextBox> = emptyList()
    private var frameW = 1
    private var frameH = 1

    private val density = resources.displayMetrics.density
    private val layoutCache = HashMap<String, Pair<StaticLayout, Float>>()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
    }

    fun setBoxes(list: List<TextBox>, fw: Int, fh: Int) {
        boxes = list
        frameW = fw.coerceAtLeast(1)
        frameH = fh.coerceAtLeast(1)
        invalidate()
    }

    fun hasBoxes(): Boolean = boxes.isNotEmpty()

    /**
     * دەقە وەرگێڕدراوەکان بە ڕیزبەندی خوێندنەوە (سەرەوە بۆ خوارەوە، پاشان چەپ بۆ ڕاست).
     * بابلەکانی «…» (هێشتا وەرنەگێڕدراون) و «؟» (سەرنەکەوتوو) نایەن.
     */
    fun spokenTexts(): List<String> {
        val rows = 12
        return boxes
            .filter { it.text != "…" && it.text != "؟" && it.text.isNotBlank() }
            .sortedWith(compareBy({ it.rect.top * rows / frameH }, { it.rect.left }))
            .map { it.text }
    }

    fun clear() {
        if (boxes.isNotEmpty()) {
            boxes = emptyList()
            invalidate()
        }
    }

    private val st = TranslatorSettings(context)

    override fun onDraw(canvas: Canvas) {
        if (boxes.isEmpty()) return
        val bg = st.overlayBg and 0x00FFFFFF
        bgPaint.color = bg or (st.overlayBgAlpha shl 24)
        borderPaint.color = bg or (minOf(255, st.overlayBgAlpha + 40) shl 24)
        textPaint.color = st.overlayFg
        val sx = width.toFloat() / frameW
        val sy = height.toFloat() / frameH
        val grow = 3f * density

        val auto = st.overlayAuto
        for (b in boxes) {
            if (b.native) continue   // کوردی خۆی: وەک خۆی دەمێنێتەوە، دەنگ بۆ دەخوێنرێتەوە
            if (auto && b.bg != 0) {
                // وەک Google: باگراوندی ڕەسەنی بابلەکە + دەقی ڕەش یان سپی بەپێی ڕووناکی
                val c = b.bg or (0xFF shl 24)
                bgPaint.color = c
                borderPaint.color = c
                val lum = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                textPaint.color = if (lum < 140f) Color.WHITE else Color.rgb(20, 20, 20)
            } else {
                bgPaint.color = bg or (st.overlayBgAlpha shl 24)
                borderPaint.color = bg or (minOf(255, st.overlayBgAlpha + 40) shl 24)
                textPaint.color = st.overlayFg
            }
            val r = RectF(
                b.rect.left * sx - grow,
                b.rect.top * sy - grow,
                b.rect.right * sx + grow,
                b.rect.bottom * sy + grow
            )
            canvas.drawRoundRect(r, 8f * density, 8f * density, bgPaint)
            canvas.drawRoundRect(r, 8f * density, 8f * density, borderPaint)
            drawFitted(canvas, b.text, r)
        }
    }

    /** دەق دەنووسێت (ڕاستەوچەپ) و فۆنت بچووک دەکاتەوە تا لە ناو r بێت. */
    private fun drawFitted(canvas: Canvas, text: String, r: RectF) {
        val pad = 4f * density
        val availW = (r.width() - 2 * pad).toInt().coerceAtLeast(10)
        val availH = r.height() - 2 * pad

        // دۆزینەوەی قەبارەی فۆنت گران دەبێت (چەندین StaticLayout)؛ ئەنجامەکە هەڵدەگیرێت تا هەر کێشانێک دووبارە نەکرێتەوە
        val key = "$availW|${availH.toInt()}|$text"
        var hit = layoutCache[key]
        if (hit == null) {
            var size = 20f * density
            val minSize = 8f * density
            val step = if (DeviceProfile.low) 2f * density else 1f * density
            var built: StaticLayout
            while (true) {
                textPaint.textSize = size
                built = StaticLayout.Builder
                    .obtain(text, 0, text.length, textPaint, availW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
                if (built.height <= availH || size <= minSize) break
                size -= step
            }
            if (layoutCache.size > 48) layoutCache.clear()
            hit = built to size
            layoutCache[key] = hit
        }
        val layout = hit.first
        textPaint.textSize = hit.second

        val dy = ((availH - layout.height) / 2f).coerceAtLeast(0f)
        canvas.save()
        canvas.translate(r.left + pad, r.top + pad + dy)
        layout.draw(canvas)
        canvas.restore()
    }
}
