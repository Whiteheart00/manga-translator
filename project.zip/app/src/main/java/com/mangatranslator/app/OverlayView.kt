package com.mangatranslator.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View

/**
 * ئەو View ـەی لەسەر هەموو شاشە دەکێشرێت (touch-through).
 * هەر بابلێک دەپۆشێت بە ڕەشی تەواو و دەقی سۆرانی (ڕاستەوچەپ) تێدا دەنووسێت،
 * بە قەبارەی فۆنتێک کە لە بابلەکە بێت.
 */
class OverlayView(context: Context) : View(context) {

    private var boxes: List<TextBox> = emptyList()
    private var frameW = 1
    private var frameH = 1

    private val density = resources.displayMetrics.density

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
    }

    fun setBoxes(list: List<TextBox>, fw: Int, fh: Int) {
        boxes = list
        frameW = fw.coerceAtLeast(1)
        frameH = fh.coerceAtLeast(1)
        invalidate()
    }

    fun hasBoxes(): Boolean = boxes.isNotEmpty()

    /**
     * دەقە وەرگێڕدراوەکان بە ڕیزبەندی خوێندنەوە (سەرەوە بۆ خوارەوە، پاشان چەپ بۆ ڕاست).
     * بابلەکانی «…» (هێشتا وەرنەگێڕدراون) و «؟» (سەرنەکەوتوو) نایەن.
     */
    fun spokenTexts(): List<String> {
        val rows = 12
        return boxes
            .filter { it.text != "…" && it.text != "؟" && it.text.isNotBlank() }
            .sortedWith(compareBy({ it.rect.top * rows / frameH }, { it.rect.left }))
            .map { it.text }
    }

    fun clear() {
        if (boxes.isNotEmpty()) {
            boxes = emptyList()
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (boxes.isEmpty()) return
        val sx = width.toFloat() / frameW
        val sy = height.toFloat() / frameH
        val grow = 3f * density

        for (b in boxes) {
            val r = RectF(
                b.rect.left * sx - grow,
                b.rect.top * sy - grow,
                b.rect.right * sx + grow,
                b.rect.bottom * sy + grow
            )
            canvas.drawRoundRect(r, 8f * density, 8f * density, bgPaint)
            canvas.drawRoundRect(r, 8f * density, 8f * density, borderPaint)
            drawFitted(canvas, b.text, r)
        }
    }

    /** دەق دەنووسێت (ڕاستەوچەپ) و فۆنت بچووک دەکاتەوە تا لە ناو r بێت. */
    private fun drawFitted(canvas: Canvas, text: String, r: RectF) {
        val pad = 4f * density
        val availW = (r.width() - 2 * pad).toInt().coerceAtLeast(10)
        val availH = r.height() - 2 * pad

        var size = 20f * density
        val minSize = 8f * density
        var layout: StaticLayout
        while (true) {
            textPaint.textSize = size
            layout = StaticLayout.Builder
                .obtain(text, 0, text.length, textPaint, availW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .build()
            if (layout.height <= availH || size <= minSize) break
            size -= 1f * density
        }

        val dy = ((availH - layout.height) / 2f).coerceAtLeast(0f)
        canvas.save()
        canvas.translate(r.left + pad, r.top + pad + dy)
        layout.draw(canvas)
        canvas.restore()
    }
}
