package com.mangatranslator.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import org.json.JSONObject
import org.vosk.Recognizer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/**
 * وەرگێڕانی دەنگی زیندوو، لە دوو ئاڕاستەدا (لە پڕۆژەی «وەرگێڕی دەنگی کوردی»ـەوە هێنراوە):
 *
 *  dir = 0  ئینگلیزی ← کوردی : گوێگرتنی ئینگلیزی ئۆفلاین (Vosk) → وەرگێڕانی دەق (Google) → دەنگی کوردیی ئۆفلاین (Piper)
 *  dir = 1  کوردی ← ئینگلیزی : Gemini دەنگە کوردییەکە دەبیسترێت و دەیکات بە ئینگلیزی (یان مۆدێلی ئۆفلاینی Vekol + Google)
 *                              → دەنگی ئینگلیزیی ناو مۆبایل
 *
 * سەرچاوەی دەنگ: دەنگی مۆبایل (AudioPlaybackCapture بە MediaProjection؛ بۆ یاری/ڤیدیۆ) یان مایک.
 * ڕستە بە ڕستە کار دەکات: گوێگرتن هەرگیز چاوەڕێی وەرگێڕان ناکات و ڕیزبەندی ڕستەکان دەپارێزرێت.
 */
class LiveTranslator(
    context: Context,
    private val projection: MediaProjection?,
    private val dir: Int,
    private val phoneAudio: Boolean,
    private val muteOriginal: Boolean,
    private val onStatus: (msg: String, error: Boolean) -> Unit,
    private val onLine: (src: String, out: String) -> Unit,
    private val onEnded: () -> Unit
) {
    private val ctx: Context = context.applicationContext
    private val settings = TranslatorSettings(ctx)

    private class Seg(val c: ArrayList<ShortArray>)

    @Volatile var alive = false
        private set
    @Volatile private var ready = false
    private val stopped = AtomicBoolean(false)

    private var rec: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null

    // ناسینەوەی دەست پێکردن/کۆتایی ڕستە (بە قفڵ پارێزراوە)
    private val lock = Any()
    private var seg: Seg? = null
    private var live = false
    private var silence = 0
    private var hot = 0
    private val pre = ArrayList<ShortArray>()

    // دەنگی ئەسڵی: فیلتەری 250-3500Hz + ئاستی دەنگی ئارام کە لەگەڵ مۆسیقا/نۆیز دەگۆڕێت
    private var hpX = 0.0
    private var hpY = 0.0
    private var lpY = 0.0
    private var floor = 0.0

    // Vosk لە thread ی خۆی کار دەکات، بۆیە گوێگرتن هەرگیز چاوەڕێی شتێکی تر ناکات
    private val stt: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile private var recog: Recognizer? = null   // تەنها لە thread ی stt دەستی لێ دەدرێت

    // وەرگێڕان (ئینتەرنێت) لە thread ـەکانی خۆی؛ order ڕیزبەندی ڕستەکان دەپارێزێت
    private val net: ExecutorService = Executors.newFixedThreadPool(3)
    private val order: ExecutorService = Executors.newSingleThreadExecutor()

    // دەنگی کوردی (Piper) و ئینگلیزی
    private val ttsQ = LinkedBlockingQueue<SpeechMsg>()
    @Volatile private var piper: PiperTts? = null
    private var etts: TextToSpeech? = null
    @Volatile private var ettsOk = false

    private val tagRe = Regex("[<\\[][^>\\]]*[>\\]]")
    private val wordRe = Regex("[A-Za-z\\u00C0-\\u024F']{2,}")
    private val sentEnd = Regex("[.?!…]+[\"')\\]]*\\s+(?=\\S)")
    private val abbreviations = setOf("mr", "mrs", "ms", "dr", "st", "vs", "jr", "sr", "mt", "no")

    // ---------------------------------------------------------------- دەستپێکردن / وەستان

    /** null = دەستی پێکرد، دەنا پەیامی هەڵە. لەسەر main thread بانگ بکە. */
    fun start(): String? {
        if (alive) return null
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return "ڕێگەپێدانی مایک نەدراوە. ئەپەکە بکەرەوە و ڕێگەپێدانی مایک بدە"
        }
        if (dir == 0) {
            if (!LiveStt.isInstalled(ctx.filesDir)) return "مۆدێلی گوێگرتنی ئینگلیزی نەهێنراوە"
            if (!PiperTts.isInstalled(ctx)) return "دەنگی کوردی نەهێنراوە؛ لە ڕێکخستنی دەنگ دایبەزێنە"
        } else {
            if (settings.geminiTtsKey.isBlank() && !VekolStt.isReady(ctx)) {
                return "بۆ کوردی ← ئینگلیزی کلیلی Gemini (لە ڕێکخستنی دەنگ) یان مۆدێلی ئۆفلاینی نووسینی کوردی پێویستە"
            }
        }
        if (phoneAudio && (projection == null || Build.VERSION.SDK_INT < 29)) {
            return "گرتنی دەنگی مۆبایل پێویستی بە دۆخی «گرتنی شاشە»یە (نەک Accessibility) و Android 10+. مایک هەڵبژێرە"
        }

        alive = true
        // دەنگی وەرگێڕدراو نابێت بگیرێتەوە (AudioPlaybackCapture تەنها MEDIA/GAME/UNKNOWN دەگرێت)
        LiveAudio.outUsage = AudioAttributes.USAGE_ASSISTANT
        if (phoneAudio && muteOriginal) OrigMute.apply(ctx)

        val ok = try {
            if (phoneAudio) (Build.VERSION.SDK_INT >= 29 && startPhoneCapture()) else startMicCapture()
        } catch (e: Throwable) {
            false
        }
        if (!ok) {
            alive = false
            LiveAudio.outUsage = AudioAttributes.USAGE_MEDIA
            OrigMute.restore(ctx)
            return if (phoneAudio) "ناتوانرێت دەنگی مۆبایل بگیرێت (ڕەنگە ئەو ئەپە ڕێگە نادات)" else "مایکرۆفۆن نەکرایەوە"
        }
        if (dir == 0) {
            startStt()
            startKuSpeech()
        } else {
            initEnTts()
            ready = true
            onStatus("✅ گوێم لێیە (کوردی ← ئینگلیزی)", false)
        }
        return null
    }

    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        alive = false
        ready = false
        OrigMute.restore(ctx)   // بەرزییەکان دەگەڕێنێتەوە و جۆری پەخشکردن دەکاتەوە MEDIA
        try { rec?.stop() } catch (_: Throwable) {}
        try { rec?.release() } catch (_: Throwable) {}
        rec = null
        try { aec?.release() } catch (_: Throwable) {}
        aec = null
        ttsQ.clear()
        ttsQ.offer(SpeechMsg(null))
        try { piper?.stop() } catch (_: Throwable) {}
        try { etts?.stop(); etts?.shutdown() } catch (_: Throwable) {}
        etts = null
        ettsOk = false
        try {
            stt.execute { try { recog?.close() } catch (_: Throwable) {}; recog = null }
        } catch (_: RejectedExecutionException) {
        }
        stt.shutdown()
        net.shutdownNow()
        order.shutdownNow()
        synchronized(lock) {
            seg = null; live = false
            pre.clear(); silence = 0; hot = 0
        }
        onEnded()
    }

    private fun fail(msg: String) {
        if (alive) onStatus("❌ $msg", true)
        stop()
    }

    private fun runOn(ex: ExecutorService, r: () -> Unit) {
        try { ex.execute { r() } } catch (_: RejectedExecutionException) {}
    }

    // ---------------------------------------------------------------- گرتنی دەنگ

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.Q)
    @SuppressLint("MissingPermission")
    private fun makeRecord(proj: MediaProjection, rate: Int, mask: Int): AudioRecord? {
        return try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(mask)
                .build()
            val bpf = 2 * (if (mask == AudioFormat.CHANNEL_IN_STEREO) 2 else 1)
            val minB = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minB, rate * bpf * 2))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (r.state == AudioRecord.STATE_INITIALIZED) r else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.Q)
    private fun startPhoneCapture(): Boolean {
        val proj = projection ?: return false
        var stereo = false
        var r = makeRecord(proj, 16000, AudioFormat.CHANNEL_IN_MONO)
        if (r == null) {
            r = makeRecord(proj, 48000, AudioFormat.CHANNEL_IN_STEREO)
            stereo = true
        }
        if (r == null) return false
        val rr: AudioRecord = r
        val st = stereo
        rec = rr
        Thread({ captureLoop(rr, st) }, "live-capture").start()
        return true
    }

    @SuppressLint("MissingPermission")
    private fun startMicCapture(): Boolean {
        val rate = 16000
        val minB = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.UNPROCESSED,
            MediaRecorder.AudioSource.MIC
        )
        for (s in sources) {
            try {
                val r = AudioRecord(s, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minB, rate * 4))
                if (r.state == AudioRecord.STATE_INITIALIZED) {
                    rec = r
                    // دەنگی وەرگێڕدراوی خودی مۆبایل لە مایکەوە لادەبرێت (ئەگەر ئامێرەکە پشتیوانی بکات)
                    try {
                        if (AcousticEchoCanceler.isAvailable()) {
                            aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
                        }
                    } catch (_: Exception) {
                    }
                    Thread({ captureLoop(r, false) }, "live-capture").start()
                    return true
                }
                r.release()
            } catch (_: Exception) {
            }
        }
        return false
    }

    private fun captureLoop(r: AudioRecord, stereo: Boolean) {
        // گوێگرتن نابێت لەلایەن دروستکردنی دەنگی کوردییەوە لە کار بخرێت
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (_: Exception) {}
        try {
            r.startRecording()
            val frame = if (stereo) 3840 else 640   // ٤٠ms
            val buf = ShortArray(frame)
            while (alive) {
                var got = 0
                while (got < frame && alive) {
                    val n = r.read(buf, got, frame - got)
                    if (n < 0) {
                        if (alive) fail("هەڵەی تۆمارکردن: $n")
                        return
                    }
                    if (n == 0) Thread.sleep(5) else got += n
                }
                if (!alive) return
                val out: ShortArray
                if (stereo) {
                    out = ShortArray(640)
                    for (i in 0 until 640) {
                        var sum = 0
                        val b = i * 6
                        for (k in 0 until 6) sum += buf[b + k].toInt()
                        out[i] = (sum / 6).toShort()
                    }
                } else {
                    out = buf.copyOf()
                }
                onChunk(out)
            }
        } catch (e: Exception) {
            if (alive) fail("تۆمارکردن: " + (e.message ?: "").take(100))
        }
    }

    // ---------------------------------------------------------------- دیاریکردنی ڕستە

    private fun voiceRms(c: ShortArray): Double {
        val aHp = 0.9087   // ~250 Hz @16k
        val aLp = 0.5787   // ~3500 Hz @16k
        var e = 0.0
        for (v in c) {
            val x = v / 32768.0
            hpY = aHp * (hpY + x - hpX)
            hpX = x
            lpY += aLp * (hpY - lpY)
            e += lpY * lpY
        }
        return sqrt(e / c.size)
    }

    private fun endSeg() {
        val sg = seg ?: return
        seg = null
        silence = 0
        if (live) {
            live = false
            if (dir == 1) kuSegment(sg.c) else sttEnd()
        }
    }

    private fun onChunk(c: ShortArray) {
        if (!ready) return
        val vr = voiceRms(c)
        val above = vr > maxOf(THR * 0.6, floor * 1.35)
        // ئاستی ئارام لەگەڵ مۆسیقا/نۆیز دەگۆڕێت، بەڵام بە قسە بەرز ناکرێتەوە
        if (!above) floor += (vr - floor) * (if (vr < floor) 0.15 else 0.03)
        else floor += (vr - floor) * 0.002
        val endMs = if (dir == 1) 700 else 600
        synchronized(lock) {
            val s = seg
            if (s == null) {
                pre.add(c)
                if (pre.size > 13) pre.removeAt(0)   // ~٠.٥ چرکە پێش یەکەم وشە، تا سەرەتای وشە نەبڕدرێت
                hot = if (above) hot + 1 else 0
                if (hot >= 1) {
                    seg = Seg(ArrayList(pre))
                    if (dir == 0) seg?.let { sttBegin(it.c) }
                    pre.clear()
                    hot = 0
                    silence = 0
                    live = true
                }
            } else {
                s.c.add(c)
                if (dir == 0) sttFeed(c)
                silence = if (above) 0 else silence + 40
                val longCut = s.c.size * 40 >= 7000
                if (silence >= endMs || longCut) {
                    // کاتێک قسەی درێژ دەبڕدرێت، پارچەی دواتر بە کەمێک دووبارەبوونەوە دەست پێدەکات تا وشە نەبڕدرێت
                    val tail: ArrayList<ShortArray> = if (longCut) ArrayList(s.c.takeLast(8)) else ArrayList()
                    endSeg()
                    pre.addAll(tail)
                }
            }
        }
    }

    // ---------------------------------------------------------------- ئینگلیزی ← کوردی (Vosk ئۆفلاین)

    private fun pcmBytes(c: ShortArray): ByteArray {
        val bb = ByteBuffer.allocate(c.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in c) bb.putShort(v)
        return bb.array()
    }

    private fun pcmOf(chunks: List<ShortArray>): ByteArray {
        var n = 0
        for (c in chunks) n += c.size
        val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (c in chunks) for (v in c) bb.putShort(v)
        return bb.array()
    }

    private fun jsonText(s: String, key: String): String =
        try { JSONObject(s).optString(key, "").trim() } catch (_: Exception) { "" }

    /** لەسەر thread ی stt */
    private fun feedOne(c: ShortArray) {
        val r = recog ?: return
        val b = pcmBytes(c)
        if (r.acceptWaveForm(b, b.size)) {
            // Vosk وچانێکی ناو قسەی دۆزییەوە: ئەو بەشە دەقێکی تەواوە
            val t = jsonText(r.result, "text")
            if (t.isNotBlank()) emitFinal(t)
        } else {
            val p = jsonText(r.partialResult, "partial")
            if (p.isNotBlank()) onStatus("🔤 " + p.takeLast(80), false)
        }
    }

    private fun sttBegin(first: List<ShortArray>) {
        val copy = ArrayList(first)
        runOn(stt) {
            try {
                if (!alive) return@runOn
                try { recog?.close() } catch (_: Throwable) {}
                recog = Recognizer(LiveStt.load(ctx.filesDir), 16000f)
                for (c in copy) feedOne(c)
            } catch (e: Throwable) {
                if (alive) onStatus("❌ گوێگرتن: " + (e.message ?: e.toString()).take(120), true)
            }
        }
    }

    private fun sttFeed(c: ShortArray) {
        runOn(stt) {
            try {
                if (alive) feedOne(c)
            } catch (_: Throwable) {
            }
        }
    }

    private fun sttEnd() {
        runOn(stt) {
            try {
                val r = recog ?: return@runOn
                recog = null
                val t = jsonText(r.finalResult, "text")
                try { r.close() } catch (_: Throwable) {}
                if (alive && t.isNotBlank()) emitFinal(t)
            } catch (_: Throwable) {
            }
        }
    }

    private fun startStt() {
        onStatus("🔄 مۆدێلی گوێگرتن دەکرێتەوە...", false)
        runOn(stt) {
            try {
                LiveStt.load(ctx.filesDir)
                if (!alive) return@runOn
                ready = true
                onStatus("✅ گوێم لێیە (ئینگلیزی ← کوردی)", false)
            } catch (e: Throwable) {
                fail((e.message ?: e.toString()).take(150))
            }
        }
    }

    /** دەقێکی ئینگلیزیی تەواو: کورتەکان بە یەک دێڕ، درێژەکان ڕستە بە ڕستە (تا یەکەمیان زووتر بخوێنرێتەوە) */
    private fun emitFinal(raw: String) {
        val str = raw.trim()
        if (str.length <= 120) {
            emit(str)
            return
        }
        var start = 0
        for (m in sentEnd.findAll(str)) {
            val before = str.substring(start, m.range.first).substringAfterLast(' ').lowercase().trim('"', '(', '\'')
            if (before in abbreviations) continue
            val cut = m.range.last + 1
            emit(str.substring(start, cut))
            start = cut
        }
        if (start < str.length) emit(str.substring(start))
    }

    private fun emit(raw: String) {
        val en = tagRe.replace(raw, " ").replace(Regex("\\s+"), " ").trim()
        val words = wordRe.findAll(en).map { it.value }.toList()
        if (words.isEmpty() || words.joinToString("").length < 3) return
        onStatus("🔤 " + en.take(80), false)
        try {
            val f = net.submit(Callable<String?> { GoogleTranslator.translateSpeech(en, "en", "ckb") })
            order.execute {
                try {
                    val ku = f.get() ?: return@execute
                    if (!alive || ku.isBlank()) return@execute
                    onLine(en, ku)
                    ttsQ.offer(SpeechMsg(ku))
                } catch (_: InterruptedException) {
                } catch (e: Exception) {
                    if (alive) onStatus("❌ وەرگێڕان نەکرا: " + (e.cause?.message ?: e.message ?: e.toString()).take(120), true)
                }
            }
        } catch (_: RejectedExecutionException) {
        }
    }

    /** دەنگی کوردی (Piper، ئۆفلاین): یەک پەخشکەر کە ڕستەکان بە ڕیز لە ttsQ وەردەگرێت */
    private fun startKuSpeech() {
        val p = Narrator.sharedPiper(ctx)
        piper = p
        Thread({ try { p.warmUp() } catch (_: Throwable) {} }, "live-warm").start()
        Thread({
            var fails = 0
            while (alive) {
                val err = try {
                    p.speakStream(ttsQ, settings.speechSpeed) { alive }
                } catch (t: Throwable) {
                    t.message ?: "error"
                }
                if (err != null) {
                    fails++
                    if (alive) onStatus("❌ " + err.take(140), true)
                    if (fails >= 3) break
                } else {
                    fails = 0
                }
                // ئەگەر کەسێکی تر (ڕێنمایی دەنگی) پەخشەکەی وەستاند، دووبارە دەستی پێدەکەینەوە
                if (alive) try { Thread.sleep(150) } catch (_: InterruptedException) { break }
            }
        }, "live-speak").start()
    }

    // ---------------------------------------------------------------- کوردی ← ئینگلیزی

    private fun initEnTts() {
        etts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val t = etts
                t?.setLanguage(Locale.US)
                t?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(LiveAudio.outUsage)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                ettsOk = true
            } else {
                onStatus("❌ دەنگی ئینگلیزیی مۆبایل بەردەست نییە", true)
            }
        }
    }

    private fun speakEn(s: String) {
        val t = etts
        if (!ettsOk || t == null) return
        t.setSpeechRate(settings.speechSpeed.coerceIn(0.5f, 2f))
        t.speak(s, TextToSpeech.QUEUE_ADD, Bundle(), "u" + System.nanoTime())
    }

    private fun wavOf(chunks: List<ShortArray>): ByteArray {
        var n = 0
        for (c in chunks) n += c.size
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + n * 2); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(16000); bb.putInt(32000); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(n * 2)
        for (c in chunks) for (v in c) bb.putShort(v)
        return bb.array()
    }

    /** Gemini (ئەگەر کلیل هەبێت) یان مۆدێلی ئۆفلاینی Vekol + Google: دەنگی کوردی ← (کوردی، ئینگلیزی) */
    private fun kuToEn(chunks: List<ShortArray>, keys: String): Pair<String, String>? {
        if (keys.isNotBlank()) {
            try {
                return LiveGemini.kuToEn(wavOf(chunks), keys)
            } catch (e: Exception) {
                if (!VekolStt.isReady(ctx)) throw e
                // Gemini سەرنەکەوت (quota/ئینتەرنێت)؛ مۆدێلی ئۆفلاین تاقی دەکەینەوە
            }
        }
        if (!VekolStt.isReady(ctx)) throw RuntimeException("کلیلی Gemini یان مۆدێلی ئۆفلاینی کوردی پێویستە")
        val ku = VekolStt.transcribe(ctx, pcmOf(chunks)).trim()
        if (ku.length < 2) return null
        val en = GoogleTranslator.translateSpeech(ku, "ckb", "en") ?: return null
        return Pair(ku, en)
    }

    /** یەک ڕستەی کوردی: دەبیسترێت، دەکرێت بە ئینگلیزی و دەخوێنرێتەوە. ڕیزبەندی دەپارێزرێت. */
    private fun kuSegment(chunks: List<ShortArray>) {
        if (chunks.size * 40 < 500) return   // کەمتر لە نیو چرکە
        val copy = ArrayList(chunks)
        val keys = settings.geminiTtsKey
        try {
            val f = net.submit(Callable<Pair<String, String>?> { kuToEn(copy, keys) })
            order.execute {
                try {
                    val r = f.get()
                    if (!alive || r == null) return@execute
                    onLine(r.first, r.second)
                    speakEn(r.second)
                } catch (_: InterruptedException) {
                } catch (e: Exception) {
                    if (alive) onStatus("❌ " + (e.cause?.message ?: e.message ?: e.toString()).take(140), true)
                }
            }
        } catch (_: RejectedExecutionException) {
        }
    }

    companion object {
        private const val THR = 0.008
    }
}
