package com.mangatranslator.app

import android.graphics.Color

/** پاڵێتی ڕەنگ: دوو ڕەنگی پاشبنەما (سەرەوە/خوارەوە) + دوو ڕەنگی تایبەت */
data class Palette(val name: String, val bgTop: Int, val bgBottom: Int, val a1: Int, val a2: Int, val light: Boolean = false)

object Palettes {
    private fun p(n: String, t: String, b: String, a1: String, a2: String, light: Boolean = false) =
        Palette(n, Color.parseColor(t), Color.parseColor(b), Color.parseColor(a1), Color.parseColor(a2), light)

    val all = listOf(
        p("ئاو", "#031C2B", "#0A6A8A", "#00B4D8", "#90E0EF"),
        p("شووشە", "#222848", "#5B70AE", "#8EA6FF", "#DCE5FF"),
        p("شەو", "#0A1128", "#0F2A5C", "#1E90FF", "#29D3FF"),
        p("زمرووت", "#03231B", "#0B7A55", "#14B87A", "#7CFFC4"),
        p("بنەوشە", "#190A3A", "#5E2CA5", "#9B5CFF", "#E0A8FF"),
        p("خۆرئاوا", "#2A0E2E", "#B8481C", "#FF7A45", "#FFD166"),
        p("گوڵ", "#2A0922", "#92306D", "#FF4FA3", "#FFB3DA"),
        p("زێڕ", "#1B1304", "#6B4E0E", "#F5B301", "#FFE08A"),
        p("سپی", "#FFFFFF", "#DCE8F7", "#2563EB", "#0284C7", light = true),
        p("ڕەش", "#000000", "#0B0B10", "#3A3A44", "#8E8EA0")
    )

    fun get(i: Int) = all[i.coerceIn(0, all.lastIndex)]
}
