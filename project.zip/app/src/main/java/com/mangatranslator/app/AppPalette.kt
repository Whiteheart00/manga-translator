package com.mangatranslator.app

import android.graphics.Color

/** پاڵێتی ڕەنگ: دوو ڕەنگی پاشبنەما (سەرەوە/خوارەوە) + دوو ڕەنگی تایبەت */
data class Palette(val name: String, val bgTop: Int, val bgBottom: Int, val a1: Int, val a2: Int, val light: Boolean = false)

object Palettes {
    private fun p(n: String, t: String, b: String, a1: String, a2: String, light: Boolean = false) =
        Palette(n, Color.parseColor(t), Color.parseColor(b), Color.parseColor(a1), Color.parseColor(a2), light)

    val all = listOf(
        p("ئاو", "#031C2B", "#0A6A8A", "#00B4D8", "#90E0EF"),
        p("شووشە", "#222848", "#5B70AE", "#8EA6FF", "#DCE5FF"),
        p("شەو", "#0A1128", "#0F2A5C", "#1E90FF", "#29D3FF"),
        p("زمرووت", "#03231B", "#0B7A55", "#14B87A", "#7CFFC4"),
        p("بنەوشە", "#190A3A", "#5E2CA5", "#9B5CFF", "#E0A8FF"),
        p("خۆرئاوا", "#2A0E2E", "#B8481C", "#FF7A45", "#FFD166"),
        p("گوڵ", "#2A0922", "#92306D", "#FF4FA3", "#FFB3DA"),
        p("زێڕ", "#1B1304", "#6B4E0E", "#F5B301", "#FFE08A"),
        p("سپی", "#FFFFFF", "#EEF3FC", "#3B6EF5", "#7B5CFA", light = true),
        p("ڕەش", "#000000", "#0B0B10", "#3A3A44", "#8E8EA0"),
        // ---- ڕەنگە مۆدێرنەکان (دوای ئەوانی کۆن، تا ئیندێکسی ڕەنگە هەڵبژێردراوەکان نەگۆڕێن) ----
        p("ئۆرۆرا", "#04141F", "#0E5A5A", "#2DE2A6", "#7CF7FF"),
        p("نیۆن", "#0B0220", "#3A0CA3", "#F72585", "#4CC9F0"),
        p("مۆکا", "#1E140F", "#6F4E37", "#D4A373", "#FAEDCD"),
        p("نەعنا", "#06231F", "#1F7A6B", "#5EEAD4", "#CCFBF1"),
        p("ساکورا", "#2B1020", "#C2185B", "#FF8FB8", "#FFD6E7"),
        p("ئاسمان", "#0B1B3F", "#2563EB", "#60A5FA", "#BFDBFE"),
        p("ئەرخەوان", "#1A0B2E", "#6D28D9", "#A78BFA", "#F0ABFC"),
        p("مەرجان", "#2A0F0F", "#C2410C", "#FB7185", "#FDBA74"),
        p("دارستان", "#07140A", "#166534", "#4ADE80", "#BBF7D0"),
        p("ئێوارە", "#12122A", "#4C3A8E", "#FB923C", "#F9A8D4"),
        p("ئەنتراسایت", "#0F1115", "#1C2030", "#6366F1", "#22D3EE"),
        p("پاستێلی مۆر", "#FFF7FB", "#F3E8FF", "#C084FC", "#F472B6", light = true),
        p("نەعنای ڕوون", "#F0FDF9", "#D9F7EE", "#10B981", "#06B6D4", light = true),
        p("ئاسمانی ڕوون", "#F5FAFF", "#DCEBFF", "#3B82F6", "#8B5CF6", light = true),
        p("هەنگوین", "#FFFBF2", "#FFEBCF", "#F59E0B", "#F43F5E", light = true)
    )

    fun get(i: Int) = all[i.coerceIn(0, all.lastIndex)]
}
