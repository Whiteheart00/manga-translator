package com.mangatranslator.app

/**
 * دەقی سۆرانی ← دەقێک کە مۆدێلی Piper بتوانێت بیخوێنێتەوە.
 * مۆدێلەکە تەنها پیتی کوردیی عەرەبی دەناسێت؛ ژمارە (2026)، بەروار (11/7/2026)، کورتکراوە (GTA) و وشەی
 * ئینگلیزی (RockStar, Player) پێشتر بێدەنگ بوون. ئێرە هەموویان دەگۆڕێت بۆ پیتی کوردی:
 *  - ژمارە ← وشەی کوردی (٢٠٢٦ ← دوو هەزار و بیست و شەش)
 *  - بەروار ← «یازدەی حەوتی دوو هەزار و بیست و شەش»
 *  - کورتکراوە ← ناوی پیتەکان (GTA ← جی تی ئەی)
 *  - وشەی ئینگلیزی ← فەرهەنگی وشە باوەکان، ئەگەر نەبوو ڕێسای نزیکی دەنگ
 * ئەگەر Gemini خۆی دەقی «speech» ی داوە (وەرگێڕانی ڕووبەر)، ئەوە باشترە و ئەم بەشە هیچ نەماوە بۆ گۆڕین.
 */
object KurdishSpeechPrep {

    fun prepare(text: String): String {
        var s = normalizeDigits(text)
        s = s.replace(Regex("(?<=[A-Za-z])(?=\\d)|(?<=\\d)(?=[A-Za-z])"), " ")
        s = dates(s)
        s = s.replace(Regex("(?<=\\d),(?=\\d{3}(?!\\d))"), "")
        s = s.replace(Regex("(\\d+)\\s?%")) { num(it.groupValues[1]) + " لەسەد" }
        s = s.replace(Regex("\\$\\s?(\\d+(?:\\.\\d+)?)")) { num(it.groupValues[1]) + " دۆلار" }
        s = s.replace(Regex("(\\d+)\\.(\\d+)")) {
            num(it.groupValues[1]) + " پۆینت " + it.groupValues[2].map { d -> ones[d - '0'] }.joinToString(" ")
        }
        s = s.replace(Regex("\\d+")) { num(it.value) }
        s = s.replace(Regex("[A-Za-z][A-Za-z'’]*")) { latin(it.value) }
        return cleanPunct(s.replace(Regex("\\s+"), " ").trim())
    }

    /** مۆدێلەکە تەنها ، ؛ ؟ ! . : دەناسێت؛ کۆمای ئینگلیزی، کەوانە، هێما... پێشتر بێدەنگ فڕێ دەدران. */
    private fun cleanPunct(t0: String): String {
        var t = t0.replace("...", ".").replace("…", ".")
            .replace(',', '،').replace('?', '؟').replace(';', '؛')
            .replace('—', '،').replace('–', '،').replace("&", " و ")
        val drop = "()[]{}«»“”„\"'`*#_~/\\|<>=+@^\$•·-"
        val sb = StringBuilder(t.length)
        for (c in t) sb.append(if (drop.indexOf(c) >= 0) ' ' else c)
        t = sb.toString()
            .replace(Regex("([.!؟])[.!؟]+"), "$1")
            .replace(Regex("([،؛])\\s*([،؛])+"), "$1")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex(" ?([،؛.!؟:])"), "$1")
        return t.trim()
    }

    // ───────────────────────── ژمارە ─────────────────────────

    private val ones = arrayOf(
        "سفر", "یەک", "دوو", "سێ", "چوار", "پێنج", "شەش", "حەوت", "هەشت", "نۆ", "دە",
        "یازدە", "دوازدە", "سیازدە", "چواردە", "پازدە", "شازدە", "حەڤدە", "هەژدە", "نۆزدە"
    )
    private val tens = arrayOf("", "", "بیست", "سی", "چل", "پەنجا", "شەست", "حەفتا", "هەشتا", "نەوەد")

    private fun normalizeDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            sb.append(
                when (c) {
                    in '٠'..'٩' -> '0' + (c - '٠')
                    in '۰'..'۹' -> '0' + (c - '۰')
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    private fun num(digits: String): String {
        val d = digits.substringBefore('.')
        if (d.length > 15 || (d.length > 1 && d.startsWith("0"))) return d.map { ones[it - '0'] }.joinToString(" ")
        return num(d.toLong())
    }

    private fun num(n: Long): String {
        return when {
            n < 20 -> ones[n.toInt()]
            n < 100 -> tens[(n / 10).toInt()] + if (n % 10 > 0) " و " + ones[(n % 10).toInt()] else ""
            n < 1000 -> {
                val h = (n / 100).toInt()
                val head = if (h == 1) "سەد" else ones[h] + " سەد"
                head + if (n % 100 > 0) " و " + num(n % 100) else ""
            }
            n < 1_000_000 -> {
                val t = n / 1000
                val head = if (t == 1L) "هەزار" else num(t) + " هەزار"
                head + if (n % 1000 > 0) " و " + num(n % 1000) else ""
            }
            n < 1_000_000_000 -> {
                val t = n / 1_000_000
                num(t) + " ملیۆن" + if (n % 1_000_000 > 0) " و " + num(n % 1_000_000) else ""
            }
            else -> {
                val t = n / 1_000_000_000
                num(t) + " ملیار" + if (n % 1_000_000_000 > 0) " و " + num(n % 1_000_000_000) else ""
            }
        }
    }

    /** 11/7/2026 ، 11.7.2026 ، 11-7-2026 ← «یازدەی حەوتی دوو هەزار و بیست و شەش» (ڕۆژ/مانگ/ساڵ) */
    private fun dates(s: String): String =
        s.replace(Regex("(?<!\\d)(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{4})(?!\\d)")) { m ->
            var d = m.groupValues[1].toInt()
            var mo = m.groupValues[2].toInt()
            if (mo > 12 && d <= 12) { val t = d; d = mo; mo = t }   // مانگ/ڕۆژ
            if (d !in 1..31 || mo !in 1..12) m.value
            else num(d.toLong()) + "ی " + num(mo.toLong()) + "ی " + num(m.groupValues[3].toLong())
        }

    // ───────────────────────── وشەی لاتین ─────────────────────────

    private val letterNames = mapOf(
        'a' to "ئەی", 'b' to "بی", 'c' to "سی", 'd' to "دی", 'e' to "ئی", 'f' to "ئێف", 'g' to "جی",
        'h' to "ئەیچ", 'i' to "ئای", 'j' to "جەی", 'k' to "کەی", 'l' to "ئێل", 'm' to "ئێم", 'n' to "ئێن",
        'o' to "ئۆ", 'p' to "پی", 'q' to "کیو", 'r' to "ئار", 's' to "ئێس", 't' to "تی", 'u' to "یو",
        'v' to "ڤی", 'w' to "دەبڵیو", 'x' to "ئێکس", 'y' to "وای", 'z' to "زێد"
    )

    /** وشە باوەکان (یاری، ئەپ، ناوی کۆمپانیا). کلیل بە پیتی بچووک و بێ ' */
    private val dict = mapOf(
        "rockstar" to "ڕۆکستار", "player" to "پلەیەر", "players" to "پلەیەرەکان", "game" to "گەیم", "games" to "گەیمەکان",
        "gamer" to "گەیمەر", "gaming" to "گەیمینگ", "online" to "ئۆنلاین", "offline" to "ئۆفلاین", "update" to "ئەپدەیت",
        "level" to "لێڤڵ", "video" to "ڤیدیۆ", "youtube" to "یوتیوب", "facebook" to "فەیسبووک", "google" to "گووگڵ",
        "instagram" to "ئینستاگرام", "tiktok" to "تیکتۆک", "telegram" to "تێلێگرام", "whatsapp" to "وەتسئەپ",
        "snapchat" to "سناپچات", "twitter" to "تویتەر", "android" to "ئەندرۆید", "iphone" to "ئایفۆن", "ios" to "ئای ئۆ ئێس",
        "ok" to "ئۆکەی", "okay" to "ئۆکەی", "hello" to "هەلۆ", "hi" to "های", "app" to "ئەپ", "apps" to "ئەپەکان",
        "apple" to "ئەپڵ", "microsoft" to "مایکرۆسۆفت", "windows" to "ویندۆز", "playstation" to "پلەیستەیشن",
        "xbox" to "ئێکس بۆکس", "nintendo" to "نینتەندۆ", "steam" to "ستیم", "epic" to "ئێپیک", "ps" to "پی ئێس",
        "pc" to "پی سی", "vs" to "ڤێرسەس", "internet" to "ئینتەرنێت", "wifi" to "وایفای", "email" to "ئیمەیڵ",
        "website" to "ماڵپەڕ", "link" to "لینک", "live" to "لایڤ", "like" to "لایک", "share" to "شەیر", "post" to "پۆست",
        "story" to "ستۆری", "server" to "سێرڤەر", "mod" to "مۆد", "boss" to "بۆس", "quest" to "کوێست", "team" to "تیم",
        "ai" to "ئەی ئای", "gta" to "جی تی ئەی", "fifa" to "فیفا", "pubg" to "پەبجی", "minecraft" to "ماینکرافت",
        "netflix" to "نێتفلیکس", "amazon" to "ئەمەزۆن", "samsung" to "سامسۆنگ", "huawei" to "هواوی", "nvidia" to "ئێنڤیدیا",
        "release" to "ڕیلیز", "trailer" to "تریلەر", "price" to "پرایس", "pro" to "پرۆ", "plus" to "پڵەس", "max" to "ماکس",
        "mobile" to "مۆبایل", "phone" to "فۆن", "news" to "نیوز", "ps5" to "پی ئێس پێنج", "no" to "نۆ", "yes" to "یێس"
    )

    private fun latin(tok: String): String {
        val low = tok.lowercase().replace("'", "").replace("’", "")
        if (low.isEmpty()) return ""
        dict[low]?.let { return it }
        // کۆ: players → پلەیەرەکان ، بەڵام تەنها ئەگەر فەرهەنگ هەیبێت
        if (low.endsWith("s") && low.length > 3) dict[low.dropLast(1)]?.let { return it + "ەکان" }
        val caps = tok.length in 2..4 && tok == tok.uppercase()
        val noVowel = low.none { it in "aeiou" } && low.length <= 5
        if (caps || noVowel) return low.map { letterNames[it] ?: "" }.filter { it.isNotEmpty() }.joinToString(" ")
        if (low.length == 1) return letterNames[low[0]] ?: ""
        return phonetic(low)
    }

    // ڕێسای نزیکیی دەنگ (ئینگلیزی ← پیتی کوردی)؛ ڕێگای پاشەکەوتە کاتێک وشەکە لە فەرهەنگ نییە
    private val multi = listOf(
        "tion" to "شن", "sion" to "ژن", "ight" to "ایت", "igh" to "ای", "tch" to "چ", "dge" to "ج",
        "sh" to "ش", "ch" to "چ", "th" to "س", "ph" to "ف", "ck" to "ک", "ng" to "نگ", "qu" to "کوو",
        "ee" to "ی", "ea" to "ی", "oo" to "وو", "ou" to "ەو", "ow" to "ەو", "oa" to "ۆ", "ai" to "ەی", "ay" to "ەی",
        "ey" to "ەی", "oi" to "ۆی", "oy" to "ۆی", "au" to "ۆ", "aw" to "ۆ", "ie" to "ی", "wh" to "و", "ew" to "یوو"
    )
    private val single = mapOf(
        'a' to "ە", 'b' to "ب", 'd' to "د", 'e' to "ێ", 'f' to "ف", 'h' to "ه", 'i' to "ی", 'j' to "ج",
        'k' to "ک", 'l' to "ل", 'm' to "م", 'n' to "ن", 'o' to "ۆ", 'p' to "پ", 'q' to "ک", 'r' to "ر",
        's' to "س", 't' to "ت", 'u' to "ۆ", 'v' to "ڤ", 'w' to "و", 'x' to "کس", 'y' to "ی", 'z' to "ز"
    )
    private const val VOWELS = "aeiouy"

    private fun phonetic(w0: String): String {
        var w = w0
        // «e»ی کۆتایی بێدەنگە و دەنگی پێش خۆی درێژ دەکات: game → گەیم ، like → لایک ، home → هۆم
        val magic = w.length >= 4 && w.endsWith("e") && w[w.length - 2] !in VOWELS && w[w.length - 3] in "aiou"
        val longV = mapOf('a' to "ەی", 'i' to "ای", 'o' to "ۆ", 'u' to "یوو")
        val vIdx = if (magic) w.length - 3 else -1
        if (magic) w = w.dropLast(1)
        val out = StringBuilder()
        var i = 0
        while (i < w.length) {
            if (i == vIdx) { out.append(longV[w[i]]); i++; continue }
            if (i == 0 && w.startsWith("kn")) { out.append("ن"); i += 2; continue }
            if (i == 0 && w.startsWith("wr")) { out.append("ڕ"); i += 2; continue }
            val m = multi.firstOrNull { w.startsWith(it.first, i) }
            if (m != null) { out.append(m.second); i += m.first.length; continue }
            val c = w[i]
            val next = w.getOrNull(i + 1)
            out.append(
                when (c) {
                    'c' -> if (next != null && next in "eiy") "س" else "ک"
                    'g' -> if (next != null && next in "iy" && i + 2 < w.length) "ج" else "گ"
                    'y' -> if (i == 0) "ی" else "ی"
                    else -> single[c] ?: ""
                }
            )
            i++
        }
        return out.toString()
    }
}
