package com.mangatranslator.app

/** زمانە پشتیوانیکراوەکانی دەقی سەر شاشە (سەرچاوە). ئامانج هەمیشە سۆرانییە. */
object SourceLangs {
    val codes = listOf("auto", "en", "ar", "ja", "zh", "ko")
    val labels = listOf(
        "🌐 خۆکار (ناسینەوەی زمان)",
        "ئینگلیزی (English)",
        "عەرەبی (العربية)",
        "جاپانی (日本語)",
        "چینی (中文)",
        "کۆری (한국어)"
    )

    /** کۆدی زمان بۆ Google Translate */
    fun apiCode(lang: String): String = when (lang) {
        "zh" -> "zh-CN"
        "en", "ar", "ja", "ko" -> lang
        else -> "auto"
    }
}
