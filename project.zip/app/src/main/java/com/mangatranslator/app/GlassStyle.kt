package com.mangatranslator.app

import android.content.Context

/** شووشەی ڕەنگاوڕەنگ (ڕەنگی Gemini) یان شووشەی تەواو ڕوونی بێ ڕەنگ. لە ڕێکخستنەکان دەگۆڕدرێت. */
object GlassStyle {
    @Volatile var colored: Boolean = true

    fun load(ctx: Context) { colored = TranslatorSettings(ctx).coloredGlass }
}
