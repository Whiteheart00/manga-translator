package com.mangatranslator.app

import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log

/**
 * دڵی "Continuous Mode".
 *
 * بۆ هەر فرەیمێک (لە thread ی گرتنەوە) بانگ دەکرێت:
 *  1. ئەگەر شاشە لە دوایین پەڕەی ڕاگیراو جیاواز بوو  → ئۆڤەرلەی کۆن دەسڕێتەوە و `generation` زیاد دەکات
 *  2. کاتێک شاشە بۆ ٢ فرەیمی یەک لە دوای یەک ڕاوەستا → OCR دەکات
 *  3. دەقە دۆزراوەکان دەدات بە `onBoxes` (وەرگێڕان لە دەرەوە ئەنجام دەدرێت)
 *
 * هەر کاتێک ئۆڤەرلەی شاشە گۆڕدرا، دەبێت `notifyOverlayUpdated()` بانگ بکرێت، بۆ ئەوەی
 * گۆڕانی ئۆڤەرلەی خۆمان وەک "پەڕەی نوێ" نەژمێردرێت.
 *
 * هەموو ئەو Bitmapـانەی وەریدەگرێت خۆی recycle دەکات.
 */
class PageWatcher(
    private val ocr: OcrEngine,
    /** هەر thread بێت: پەڕەی نوێ دۆزرایەوە و ئۆڤەرلەی کۆن دەبێت بسڕدرێتەوە. */
    private val onClear: () -> Unit,
    /** لەسەر main thread: دەقە دۆزراوەکان، قەبارەی فرەیم، و ژمارەی نەوە (generation). */
    private val onBoxes: (List<TextBox>, Int, Int, Int) -> Unit,
    /** پەیامی دۆخ بۆ دۆزینەوەی کێشە (هەر thread): فرەیم گەیشت، پەڕەی نوێ، OCR، ژمارەی دەقەکان */
    private val onStatus: (String) -> Unit = {},
    /** ڕێژەی گۆڕانی شاشە (٠..١) کە پێویستە بۆ ناسینەوەی پەڕەی نوێ */
    private val changeFraction: () -> Float = { 0.5f }
) {
    @Volatile private var firstFrameSeen = false
    /** بە هەر پەڕەیەکی نوێ زیاد دەبێت. کارە درێژەکان بەم دەزانن ئایا هێشتا کاتیان نەچووە. */
    @Volatile
    var generation = 0
        private set

    @Volatile private var baseline: IntArray? = null
    @Volatile private var prev: IntArray? = null
    @Volatile private var pending = false
    @Volatile private var ocrBusy = false
    @Volatile private var ocrStartedAt = 0L
    @Volatile private var overlayChangedAt = 0L
    @Volatile private var needRebaseline = false
    private var stableCount = 0

    fun isCurrent(gen: Int): Boolean = gen == generation

    fun notifyOverlayUpdated() {
        overlayChangedAt = SystemClock.elapsedRealtime()
        needRebaseline = true
    }

    /** دەستی بەکارهێنەر: دەستبەجێ وەرگێڕانی دووبارەی شاشەی ئێستا. */
    fun forceRescan() {
        generation++
        pending = true
        stableCount = 0
        prev = null
        needRebaseline = false
        onClear()
    }

    fun reset() {
        generation++
        baseline = null
        prev = null
        pending = false
        needRebaseline = false
        stableCount = 0
    }

    fun onFrame(bmp: Bitmap) {
        if (!firstFrameSeen) { firstFrameSeen = true; onStatus("فرەیم دێت ✓") }
        if (ocrBusy) {
            // OCR ی گیرخواردوو: دوای ٤٠ چرکە ئازادی بکە
            if (SystemClock.elapsedRealtime() - ocrStartedAt > OCR_TIMEOUT_MS) {
                Log.w(TAG, "OCR timeout, resetting")
                ocrBusy = false
                generation++
            }
            bmp.recycle()
            return
        }

        val sig = ChangeDetector.signature(bmp)
        val now = SystemClock.elapsedRealtime()

        // ئۆڤەرلەی ئێمە تازە گۆڕا: چاوەڕێ بکە تا شاشە ڕابوەستێت، پاشان فرەیمێک دەکەین بە بنەما
        if (now - overlayChangedAt < OVERLAY_SETTLE_MS) {
            bmp.recycle()
            return
        }
        if (needRebaseline) {
            needRebaseline = false
            if (!pending) {
                baseline = sig
                bmp.recycle()
                return
            }
        }

        if (!pending) {
            val base = baseline
            if (base == null || ChangeDetector.changedFraction(sig, base) >= changeFraction()) {
                Log.d(TAG, "page change detected")
                onStatus("پەڕەی نوێ… چاوەڕێ بکە")
                pending = true
                stableCount = 0
                prev = sig
                generation++
                onClear()
            }
            bmp.recycle()
            return
        }

        // چاوەڕێی ڕاوەستانی شاشە
        val p = prev
        if (p != null && ChangeDetector.distance(sig, p) < STABLE_THRESHOLD) {
            stableCount++
        } else {
            stableCount = 0
        }
        prev = sig

        if (stableCount < STABLE_FRAMES) {
            bmp.recycle()
            return
        }

        // شاشە ڕاوەستاوە → OCR
        onStatus("OCR دەستی پێکرد…")
        ocrBusy = true
        ocrStartedAt = SystemClock.elapsedRealtime()
        stableCount = 0
        baseline = sig // شاشە بێ ئۆڤەرلە
        val gen = generation
        val w = bmp.width
        val h = bmp.height
        ocr.recognize(bmp) { boxes ->
            bmp.recycle()
            ocrBusy = false
            if (gen == generation) {
                pending = false
                onStatus(if (boxes.isEmpty()) "هیچ دەقێک نەدۆزرایەوە" else "${boxes.size} دەق دۆزرایەوە، وەرگێڕان…")
                onBoxes(boxes, w, h, gen)
            }
        }
    }

    companion object {
        private const val TAG = "PageWatcher"
        private const val STABLE_THRESHOLD = 4f      // جیاوازی کەمتر لەمە = ڕاوەستاو
        private const val STABLE_FRAMES = 2          // ≈ ٠.٣ چرکە
        // فرەیمی Accessibility ≈٤٠٠ms دواکەوتنی هەیە؛ ئەگەر کورت بێت فرەیمی پێش ئۆڤەرلە وەک "پەڕەی نوێ" دەژمێردرێت
        // و وەرگێڕانەکە دەسڕێتەوە (لووپ)
        private const val OVERLAY_SETTLE_MS = 800L   // دوای گۆڕانی ئۆڤەرلە
        private const val OCR_TIMEOUT_MS = 40000L   // Gemini بینین (عەرەبی) ڕەنگە ١٥-٣٠ چرکە بخایەنێت
    }
}
