package com.mangatranslator.app

import android.graphics.Bitmap
import android.util.Log

/**
 * دڵی "Continuous Mode".
 *
 * بۆ هەر فرەیمێک (لە thread ی گرتنەوە) بانگ دەکرێت:
 *  1. ئەگەر شاشە لە دوایین پەڕەی ڕاگیراو جیاواز بوو  → ئۆڤەرلەی کۆن دەسڕێتەوە و چاوەڕێی ڕاوەستان دەکات
 *  2. کاتێک شاشە بۆ ٢ فرەیمی یەک لە دوای یەک ڕاوەستا → OCR دەکات
 *  3. دەرەنجام نیشان دەدات و ئیمزای نوێ دەبێتە بنەما (بۆ ئەوەی ئۆڤەرلەی خۆمان وەک گۆڕان نەژمێردرێت)
 *
 * هەموو ئەو Bitmapـانەی وەریدەگرێت خۆی recycle دەکات.
 */
class PageWatcher(
    private val ocr: OcrEngine,
    /** هەر thread بێت: بانگ دەکرێت کاتێک پەڕەی نوێ دۆزرایەوە و ئۆڤەرلەی کۆن دەبێت بسڕدرێتەوە. */
    private val onClear: () -> Unit,
    /** لەسەر main thread: دەقە دۆزراوەکان + قەبارەی فرەیم. */
    private val onBoxes: (List<TextBox>, Int, Int) -> Unit
) {
    @Volatile private var baseline: IntArray? = null
    @Volatile private var prev: IntArray? = null
    @Volatile private var pending = false
    @Volatile private var busy = false
    @Volatile private var rebaseline = false
    private var stableCount = 0

    fun reset() {
        baseline = null
        prev = null
        pending = false
        rebaseline = false
        stableCount = 0
    }

    fun onFrame(bmp: Bitmap) {
        if (busy) {
            bmp.recycle()
            return
        }

        val sig = ChangeDetector.signature(bmp)

        // دوای نیشاندانی ئۆڤەرلەی نوێ، یەکەم فرەیم دەکەین بە بنەما
        if (rebaseline) {
            baseline = sig
            prev = sig
            rebaseline = false
            bmp.recycle()
            return
        }

        if (!pending) {
            val base = baseline
            if (base == null || ChangeDetector.distance(sig, base) > CHANGE_THRESHOLD) {
                Log.d(TAG, "page change detected")
                pending = true
                stableCount = 0
                prev = sig
                onClear()
            }
            bmp.recycle()
            return
        }

        // چاوەڕێی ڕاوەستانی شاشە
        val p = prev
        if (p != null && ChangeDetector.distance(sig, p) < STABLE_THRESHOLD) {
            stableCount++
        } else {
            stableCount = 0
        }
        prev = sig

        if (stableCount < STABLE_FRAMES) {
            bmp.recycle()
            return
        }

        // شاشە ڕاوەستاوە → OCR
        busy = true
        stableCount = 0
        val w = bmp.width
        val h = bmp.height
        ocr.recognize(bmp) { boxes ->
            bmp.recycle()
            onBoxes(boxes, w, h)
            pending = false
            rebaseline = true
            busy = false
        }
    }

    companion object {
        private const val TAG = "PageWatcher"
        private const val CHANGE_THRESHOLD = 8f   // جیاوازی بۆ ناسینەوەی پەڕەی نوێ
        private const val STABLE_THRESHOLD = 3f   // جیاوازی کەمتر لەمە = ڕاوەستاو
        private const val STABLE_FRAMES = 2       // ≈ ٠.٥ چرکە
    }
}
