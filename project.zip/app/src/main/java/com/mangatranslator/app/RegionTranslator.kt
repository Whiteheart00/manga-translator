package com.mangatranslator.app

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** یەک پارچە دەق لە ڕووبەرە دیاریکراوەکە. rect بە پیکسێلی وێنەی ڕووبەرەکەیە (crop). */
data class RegionItem(
    val rect: Rect?,
    val original: String,
    val kurdish: String,
    val alreadyKurdish: Boolean
)

/**
 * وەرگێڕانی ڕووبەرێکی دیاریکراو بە Gemini (وێنە → دەق + وەرگێڕان بۆ سۆرانی) لە یەک داواکاریدا.
 * هەموو زمانێک (جاپانی، چینی، عەرەبی، ڕووسی...) پشتیوانی دەکات. ئەگەر دەقەکە خۆی سۆرانی بوو، وەرناگێڕدرێت.
 */
object RegionTranslator {
    private const val MAX_SIDE = 960

    private const val PROMPT =
        "This image is a cropped part of a phone screen (manga, comic, webtoon, game, video, app or web page). " +
            "Find every piece of readable text in it, in ANY language or script (including vertical text). " +
            "Ignore watermarks, page numbers and app buttons. " +
            "Return the text blocks in natural reading order (manga: right-to-left, top-to-bottom; otherwise by the script's direction). " +
            "For each block give: box = [ymin, xmin, ymax, xmax] normalized to 0-1000 around the text; " +
            "lang = BCP-47 code of the source language (use ckb for Central/Sorani Kurdish in Arabic script); " +
            "kurdish = natural, spoken Central Kurdish (Sorani, Arabic script) translation. " +
            "If the text is ALREADY Sorani Kurdish, set lang to ckb and copy it into kurdish unchanged (fix only obvious OCR slips). " +
            "If the text is Sorani Kurdish written in LATIN letters (informal chat romanization, e.g. 'Slaw chony basit insaallah?', 'Khariky chit?', 'Mn yary online dakam', with ch/sh/kh/gh/w/y spellings, dakam, chony, zor, mn, to, nakam...), " +
            "it is NOT a foreign language: set lang to ckb and in kurdish write the SAME sentence transcribed into correct Sorani Arabic script, word for word, without translating or changing the meaning (keep colloquial wording; write Arabic loanwords in Kurdish script, e.g. insaallah = ئینشائەڵڵا; English words like online = ئۆنلاین). " +
            "If it is Kurmanji (Latin Kurdish with ç ş ê î û and Kurmanji grammar) or any other language, translate it to Sorani. " +
            "Keep names consistent as Kurdish-script transliterations. Be brief: output only the JSON. If there is no text, return an empty array."

    private fun schema(): JSONObject {
        val box = JSONObject().put("type", "ARRAY").put("items", JSONObject().put("type", "INTEGER"))
        val str = JSONObject().put("type", "STRING")
        val item = JSONObject()
            .put("type", "OBJECT")
            .put(
                "properties",
                JSONObject().put("box", box).put("lang", str).put("kurdish", str)
            )
            .put("required", JSONArray().put("lang").put("kurdish"))
        return JSONObject().put("type", "ARRAY").put("items", item)
    }

    private fun encode(src: Bitmap): String {
        var b = src
        val m = maxOf(b.width, b.height)
        if (m > MAX_SIDE) {
            val k = MAX_SIDE.toFloat() / m
            b = Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
        }
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 72, out)
        if (b !== src) b.recycle()
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** لە thread ی پاشبنەما بانگ بکرێت. `crop` دەمێنێتەوە (recycle ناکرێت). */
    fun run(crop: Bitmap, keysRaw: String, fast: Boolean = true): List<RegionItem> {
        val b64 = encode(crop)
        fun body(model: String, think: Boolean): String {
            val gen = JSONObject()
                .put("responseMimeType", "application/json")
                .put("responseSchema", schema())
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            return JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray()
                                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
                                .put(JSONObject().put("text", PROMPT))
                        )
                    )
                )
                .put("generationConfig", gen)
                .toString()
        }

        val text = GeminiKeys.withKeys(keysRaw) { key ->
            GeminiModels.call(fast) { m, think -> post(body(m, think), key, m) }
        }
        return parse(text, crop.width, crop.height)
    }

    /**
     * وەک run، بەڵام هەر بلۆکێک کە تەواو بوو یەکسەر onItem بانگ دەکات (بێ چاوەڕێی وەڵامی تەواو)،
     * بۆ ئەوەی خوێندنەوە زوو دەست پێبکات. لە thread ی پاشبنەما بانگ بکرێت.
     */
    fun runStream(crop: Bitmap, keysRaw: String, fast: Boolean, onItem: (RegionItem) -> Unit): Int {
        val b64 = encode(crop)
        val w = crop.width
        val h = crop.height
        var emitted = 0
        fun body(model: String, think: Boolean): String {
            val gen = JSONObject()
                .put("responseMimeType", "application/json")
                .put("responseSchema", schema())
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            return JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray()
                                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
                                .put(JSONObject().put("text", PROMPT))
                        )
                    )
                )
                .put("generationConfig", gen)
                .toString()
        }
        GeminiKeys.withKeys(keysRaw) { key ->
            GeminiModels.call(fast) { m, think ->
                var seen = 0 // ئەگەر دووبارە هەوڵ درایەوە، ئەوانەی پێشتر نێردران پشتگوێ دەخرێن
                streamPost(body(m, think), key, m) { obj ->
                    seen++
                    if (seen > emitted) {
                        toItem(obj, w, h)?.let { onItem(it) }
                        emitted = seen
                    }
                }
                ""
            }
        }
        return emitted
    }

    private fun streamPost(body: String, key: String, model: String, onObj: (JSONObject) -> Unit) {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                val resp = c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val why = try { JSONObject(resp).getJSONObject("error").getString("message") } catch (_: Exception) { resp }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            // دەرهێنانی ئۆبجێکتەکانی ناو ئارەیەکە هەر کە تەواو بوون
            val sb = StringBuilder()
            var depth = 0
            var inStr = false
            var esc = false
            var start = -1
            var pos = 0
            var any = false
            c.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    if (!line.startsWith("data:")) continue
                    val chunk = try {
                        JSONObject(line.substring(5).trim()).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text", "")
                    } catch (_: Exception) { "" }
                    if (chunk.isEmpty()) continue
                    any = true
                    sb.append(chunk)
                    while (pos < sb.length) {
                        val ch = sb[pos]
                        if (inStr) {
                            if (esc) esc = false
                            else if (ch == '\\') esc = true
                            else if (ch == '"') inStr = false
                        } else when (ch) {
                            '"' -> inStr = true
                            '{' -> { if (depth == 0) start = pos; depth++ }
                            '}' -> {
                                depth--
                                if (depth == 0 && start >= 0) {
                                    try { onObj(JSONObject(sb.substring(start, pos + 1))) } catch (e: org.json.JSONException) { }
                                    start = -1
                                }
                            }
                        }
                        pos++
                    }
                }
            }
            if (!any) throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
        } finally {
            c.disconnect()
        }
    }

    private fun toItem(o: JSONObject, w: Int, h: Int): RegionItem? {
        val ku = TextPrep.fixSorani(o.optString("kurdish", ""))
        if (ku.length < 2) return null
        val lang = o.optString("lang", "").lowercase()
        val box = o.optJSONArray("box")
        val rect = if (box != null && box.length() == 4) {
            val y0 = box.optInt(0).coerceIn(0, 1000)
            val x0 = box.optInt(1).coerceIn(0, 1000)
            val y1 = box.optInt(2).coerceIn(0, 1000)
            val x1 = box.optInt(3).coerceIn(0, 1000)
            if (y1 - y0 < 5 || x1 - x0 < 5) null
            else Rect(x0 * w / 1000, y0 * h / 1000, x1 * w / 1000, y1 * h / 1000)
        } else null
        return RegionItem(rect, o.optString("original", ""), ku, lang == "ckb")
    }

    private fun post(body: String, key: String, model: String): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try {
                    JSONObject(resp).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    resp
                }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            return try {
                JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            } catch (_: Exception) {
                throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
            }
        } finally {
            c.disconnect()
        }
    }

    private fun parse(text: String, w: Int, h: Int): List<RegionItem> {
        val arr = try {
            JSONArray(text.trim())
        } catch (_: Exception) {
            throw IOException("وەڵامی Gemini تێنەگەیشتم")
        }
        val out = ArrayList<RegionItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val ku = TextPrep.fixSorani(o.optString("kurdish", ""))
            if (ku.length < 2) continue
            val lang = o.optString("lang", "").lowercase()
            val box = o.optJSONArray("box")
            val rect = if (box != null && box.length() == 4) {
                val y0 = box.optInt(0).coerceIn(0, 1000)
                val x0 = box.optInt(1).coerceIn(0, 1000)
                val y1 = box.optInt(2).coerceIn(0, 1000)
                val x1 = box.optInt(3).coerceIn(0, 1000)
                if (y1 - y0 < 5 || x1 - x0 < 5) null
                else Rect(x0 * w / 1000, y0 * h / 1000, x1 * w / 1000, y1 * h / 1000)
            } else null
            out.add(RegionItem(rect, o.optString("original", ""), ku, lang == "ckb"))
        }
        return out
    }
}
