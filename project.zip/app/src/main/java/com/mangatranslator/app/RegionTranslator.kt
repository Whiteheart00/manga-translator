package com.mangatranslator.app

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** یەک پارچە دەق لە ڕووبەرە دیاریکراوەکە. rect بە پیکسێلی وێنەی ڕووبەرەکەیە (crop). */
data class RegionItem(
    val rect: Rect?,
    val original: String,
    val kurdish: String,
    val alreadyKurdish: Boolean
)

/**
 * وەرگێڕانی ڕووبەرێکی دیاریکراو بە Gemini (وێنە → دەق + وەرگێڕان بۆ سۆرانی) لە یەک داواکاریدا.
 * هەموو زمانێک (جاپانی، چینی، عەرەبی، ڕووسی...) پشتیوانی دەکات. ئەگەر دەقەکە خۆی سۆرانی بوو، وەرناگێڕدرێت.
 */
object RegionTranslator {
    // تێبینی: دۆخی ڕووبەر settings.sourceLang بەکارناهێنێت؛ هەموو زمانێک خۆکارانە دەناسرێتەوە.
    // هەڵبژاردنی زمانی دەق تەنها بۆ وەرگێڕانی خۆکار و شاشەیە (OcrEngine / GoogleTranslator / ArabicGemini).
    private const val MAX_SIDE = 960
    private const val MAX_SIDE_LOW = 800

    private const val PROMPT =
        "This image is a cropped part of a phone screen (manga, comic, webtoon, game, video, app or web page). " +
            "Find every piece of readable text in it, in ANY language or script (including vertical text). " +
            "Ignore watermarks, page numbers and app buttons. " +
            "Return the text blocks in natural reading order (manga: right-to-left, top-to-bottom; otherwise by the script's direction). " +
            "For each block give: box = [ymin, xmin, ymax, xmax] normalized to 0-1000 around the text; " +
            "lang = BCP-47 code of the source language (use ckb for Central/Sorani Kurdish in Arabic script); " +
            "kurdish = natural, spoken Central Kurdish (Sorani, Arabic script) translation. " +
            "If the text is ALREADY Sorani Kurdish, set lang to ckb and copy it into kurdish unchanged (fix only obvious OCR slips). " +
            "If the text is Sorani Kurdish written in LATIN letters (informal chat romanization, e.g. 'Slaw chony basit insaallah?', 'Khariky chit?', 'Mn yary online dakam', with ch/sh/kh/gh/w/y spellings, dakam, chony, zor, mn, to, nakam...), " +
            "it is NOT a foreign language: set lang to ckb and in kurdish write the SAME sentence transcribed into correct Sorani Arabic script, word for word, without translating or changing the meaning (keep colloquial wording; write Arabic loanwords in Kurdish script, e.g. insaallah = ئینشائەڵڵا; English words like online = ئۆنلاین). " +
            "If it is Kurmanji (Latin Kurdish with ç ş ê î û and Kurmanji grammar) or any other language, translate it to Sorani. " +
            "Keep names consistent as Kurdish-script transliterations. Be brief: output only the JSON. If there is no text, return an empty array."

    /** پرۆمپتی کورت بۆ وەرگێڕانی خۆکار (عەرەبی): دەرچوونی کەمتر = خێراتر */
    private const val PROMPT_COMPACT =
        "Phone screenshot (manga, webtoon, video, chat, app or web page). Find every block of readable text (mostly Arabic). " +
            "Ignore watermarks, page numbers, status bar and buttons. Keep reading order (manga: right-to-left, top-to-bottom). " +
            "For each block: box = [ymin, xmin, ymax, xmax] normalized 0-1000, tight around the whole block; " +
            "kurdish = natural spoken Central Kurdish (Sorani, Arabic script) translation of the MEANING (not word by word), same tone, " +
            "names consistent, numbers unchanged. If the text is already Sorani, copy it. Ignore text that is cut off by the image edge. Output only the JSON array; empty array if no text."

    private fun schema(compact: Boolean = false): JSONObject {
        val box = JSONObject().put("type", "ARRAY").put("items", JSONObject().put("type", "INTEGER"))
        val str = JSONObject().put("type", "STRING")
        val props = JSONObject().put("box", box)
        if (!compact) props.put("lang", str)
        props.put("kurdish", str)
        val item = JSONObject()
            .put("type", "OBJECT")
            .put("properties", props)
            .put("required", if (compact) JSONArray().put("box").put("kurdish") else JSONArray().put("lang").put("kurdish"))
        return JSONObject().put("type", "ARRAY").put("items", item)
    }

    private fun encode(src: Bitmap, maxSide: Int = if (DeviceProfile.low) MAX_SIDE_LOW else MAX_SIDE, quality: Int = 72): String {
        var b = src
        val m = maxOf(b.width, b.height)
        if (m > maxSide) {
            val k = maxSide.toFloat() / m
            b = Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
        }
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, quality, out)
        if (b !== src) b.recycle()
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** لە thread ی پاشبنەما بانگ بکرێت. `crop` دەمێنێتەوە (recycle ناکرێت). */
    fun run(crop: Bitmap, keysRaw: String, fast: Boolean = true): List<RegionItem> {
        val b64 = encode(crop)
        fun body(model: String, think: Boolean): String {
            val gen = JSONObject()
                .put("responseMimeType", "application/json")
                .put("responseSchema", schema())
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            return JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray()
                                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
                                .put(JSONObject().put("text", PROMPT))
                        )
                    )
                )
                .put("generationConfig", gen)
                .toString()
        }

        val text = GeminiKeys.withKeys(keysRaw) { key ->
            GeminiModels.call(fast) { m, think -> post(body(m, think), key, m) }
        }
        return parse(text, crop.width, crop.height)
    }

    /**
     * وەک run، بەڵام هەر بلۆکێک کە تەواو بوو یەکسەر onItem بانگ دەکات (بێ چاوەڕێی وەڵامی تەواو)،
     * بۆ ئەوەی خوێندنەوە زوو دەست پێبکات. لە thread ی پاشبنەما بانگ بکرێت.
     */
    fun runStream(crop: Bitmap, keysRaw: String, fast: Boolean, compact: Boolean = false, onItem: (RegionItem) -> Unit): Int {
        // compact (وەرگێڕانی خۆکار): وێنەی گەورەتر بۆ دەقی بچووکی عەرەبی + پرۆمپتی کورت
        val b64 = if (compact) encode(crop, 1280, 80) else encode(crop)
        val w = crop.width
        val h = crop.height
        var emitted = 0
        fun body(model: String, think: Boolean): String {
            val gen = JSONObject()
                .put("responseMimeType", "application/json")
                .put("responseSchema", schema(compact))
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            return JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray()
                                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
                                .put(JSONObject().put("text", if (compact) PROMPT_COMPACT else PROMPT))
                        )
                    )
                )
                .put("generationConfig", gen)
                .toString()
        }
        GeminiKeys.withKeys(keysRaw) { key ->
            GeminiModels.call(fast) { m, think ->
                var seen = 0 // ئەگەر دووبارە هەوڵ درایەوە، ئەوانەی پێشتر نێردران پشتگوێ دەخرێن
                streamPost(body(m, think), key, m) { obj ->
                    seen++
                    if (seen > emitted) {
                        toItem(obj, w, h)?.let { onItem(it) }
                        emitted = seen
                    }
                }
                ""
            }
        }
        return emitted
    }

    private val stripPool = Executors.newCachedThreadPool { r -> Thread(r, "gemini-strip").apply { isDaemon = true } }

    /**
     * خێراکردنی وەرگێڕانی خۆکار: شاشەکە بە ٢-٣ پارچەی ئاسۆیی (بە ٦٪ بەسەریەکدا چوون) دابەش دەکرێت و هەموو پارچەکان
     * بە پارالێل بۆ Gemini دەنێردرێن. کاتی Gemini زۆربەی کاتەکەیە و بەپێی ژمارەی دەقی دەرچوو دەخایەنێت،
     * بۆیە ٣ پارچە ≈ ٣ هێندە خێراتر. هەر پارچەیەک تەنها ئەو بلۆکانە دەدات کە ناوەڕاستیان لە بەشی خۆیەتی (بێ دووبارەبوونەوە).
     * بلۆکەکان هەر کە ئامادە بوون onItem بانگ دەکرێت (لە چەند thread ـێکەوە، onItem دەبێت thread-safe بێت)،
     * و ئەم فەنکشنە تا تەواوبوونی هەموو پارچەکان دەوەستێت (کەواتە bitmap ـەکە تا ئەو کاتە recycle نەکرێت).
     */
    fun runStripsStream(src: Bitmap, keysRaw: String, fast: Boolean, onItem: (RegionItem) -> Unit): Int {
        val w = src.width
        val h = src.height
        val n = when {
            h >= w * 1.6f -> 3
            h >= w * 1.1f -> 2
            else -> 1
        }
        if (n == 1) return runStream(src, keysRaw, fast, compact = true, onItem = onItem)

        val ov = (h * 0.06f).toInt()
        val emitted = AtomicInteger(0)
        val failed = AtomicInteger(0)
        val lastErr = AtomicReference<Throwable?>(null)
        val latch = CountDownLatch(n)
        for (i in 0 until n) {
            val ownTop = h * i / n
            val ownBot = h * (i + 1) / n
            val top = (ownTop - ov).coerceAtLeast(0)
            val bot = (ownBot + ov).coerceAtMost(h)
            stripPool.execute {
                try {
                    val strip = Bitmap.createBitmap(src, 0, top, w, bot - top)
                    try {
                        runStream(strip, keysRaw, fast, compact = true) { item ->
                            val r = item.rect
                            if (r != null) {
                                val cy = top + (r.top + r.bottom) / 2
                                if (cy >= ownTop && cy < ownBot) {
                                    onItem(item.copy(rect = Rect(r.left, r.top + top, r.right, r.bottom + top)))
                                    emitted.incrementAndGet()
                                }
                            }
                        }
                    } finally {
                        if (strip !== src) strip.recycle()
                    }
                } catch (t: Throwable) {
                    lastErr.set(t)
                    failed.incrementAndGet()
                } finally {
                    latch.countDown()
                }
            }
        }
        latch.await()
        // هەموو پارچەکان شکستیان هێنا و هیچ دەقێک نەهات ← هەڵە بدەرەوە بۆ ئەوەی Tesseract وەک یەدەگ بەکاربێت
        if (failed.get() > 0 && emitted.get() == 0) throw (lastErr.get() ?: IOException("Gemini failed"))
        return emitted.get()
    }

    /** پەیوەندی (DNS + TLS) بۆ Gemini پێشوەختە دەکاتەوە و لە pool ی keep-alive ی دەهێڵێتەوە. لە thread ی پاشبنەما. */
    fun preconnect() {
        try {
            val c = URL("https://generativelanguage.googleapis.com/").openConnection() as HttpURLConnection
            c.connectTimeout = 4_000
            c.readTimeout = 4_000
            c.requestMethod = "HEAD"
            c.responseCode
            try { c.inputStream.close() } catch (_: Exception) { c.errorStream?.close() }
        } catch (_: Throwable) {
        }
    }

    private fun streamPost(body: String, key: String, model: String, onObj: (JSONObject) -> Unit) {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            .openConnection() as HttpURLConnection
        var ok = false
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            val bytes = body.toByteArray(Charsets.UTF_8)
            c.setFixedLengthStreamingMode(bytes.size)
            c.outputStream.use { it.write(bytes) }
            val code = c.responseCode
            if (code !in 200..299) {
                val resp = c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val why = try { JSONObject(resp).getJSONObject("error").getString("message") } catch (_: Exception) { resp }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            // دەرهێنانی ئۆبجێکتەکانی ناو ئارەیەکە هەر کە تەواو بوون
            val sb = StringBuilder()
            var depth = 0
            var inStr = false
            var esc = false
            var start = -1
            var pos = 0
            var any = false
            c.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    if (!line.startsWith("data:")) continue
                    val chunk = try {
                        JSONObject(line.substring(5).trim()).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text", "")
                    } catch (_: Exception) { "" }
                    if (chunk.isEmpty()) continue
                    any = true
                    sb.append(chunk)
                    while (pos < sb.length) {
                        val ch = sb[pos]
                        if (inStr) {
                            if (esc) esc = false
                            else if (ch == '\\') esc = true
                            else if (ch == '"') inStr = false
                        } else when (ch) {
                            '"' -> inStr = true
                            '{' -> { if (depth == 0) start = pos; depth++ }
                            '}' -> {
                                depth--
                                if (depth == 0 && start >= 0) {
                                    try { onObj(JSONObject(sb.substring(start, pos + 1))) } catch (e: org.json.JSONException) { }
                                    start = -1
                                }
                            }
                        }
                        pos++
                    }
                }
            }
            if (!any) throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
            ok = true
        } finally {
            // دوای خوێندنەوەی تەواو disconnect ناکەین تا پەیوەندییەکە بۆ داواکاری دواتر بمێنێتەوە (keep-alive)
            if (!ok) c.disconnect()
        }
    }

    private fun toItem(o: JSONObject, w: Int, h: Int): RegionItem? {
        val ku = TextPrep.fixSorani(o.optString("kurdish", ""))
        if (ku.length < 2) return null
        val lang = o.optString("lang", "").lowercase()
        val box = o.optJSONArray("box")
        val rect = if (box != null && box.length() == 4) {
            val y0 = box.optInt(0).coerceIn(0, 1000)
            val x0 = box.optInt(1).coerceIn(0, 1000)
            val y1 = box.optInt(2).coerceIn(0, 1000)
            val x1 = box.optInt(3).coerceIn(0, 1000)
            if (y1 - y0 < 5 || x1 - x0 < 5) null
            else Rect(x0 * w / 1000, y0 * h / 1000, x1 * w / 1000, y1 * h / 1000)
        } else null
        return RegionItem(rect, o.optString("original", ""), ku, lang == "ckb")
    }

    private fun post(body: String, key: String, model: String): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try {
                    JSONObject(resp).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    resp
                }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            return try {
                JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            } catch (_: Exception) {
                throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
            }
        } finally {
            c.disconnect()
        }
    }

    private fun parse(text: String, w: Int, h: Int): List<RegionItem> {
        val arr = try {
            JSONArray(text.trim())
        } catch (_: Exception) {
            throw IOException("وەڵامی Gemini تێنەگەیشتم")
        }
        val out = ArrayList<RegionItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val ku = TextPrep.fixSorani(o.optString("kurdish", ""))
            if (ku.length < 2) continue
            val lang = o.optString("lang", "").lowercase()
            val box = o.optJSONArray("box")
            val rect = if (box != null && box.length() == 4) {
                val y0 = box.optInt(0).coerceIn(0, 1000)
                val x0 = box.optInt(1).coerceIn(0, 1000)
                val y1 = box.optInt(2).coerceIn(0, 1000)
                val x1 = box.optInt(3).coerceIn(0, 1000)
                if (y1 - y0 < 5 || x1 - x0 < 5) null
                else Rect(x0 * w / 1000, y0 * h / 1000, x1 * w / 1000, y1 * h / 1000)
            } else null
            out.add(RegionItem(rect, o.optString("original", ""), ku, lang == "ckb"))
        }
        return out
    }
}
