package com.mangatranslator.app

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * قسەکردن بە کوردی ← نووسین (سۆرانی، پیتی عەرەبی) بە Gemini.
 * start() مایک دەکاتەوە؛ stop() دەنگەکە دەگەڕێنێتەوە؛ transcribe() دەیکات بە دەق.
 */
class Dictation {
    @Volatile
    private var rec: AudioRecord? = null
    private var thread: Thread? = null
    private val buf = ByteArrayOutputStream()

    @Volatile
    var recording = false
        private set

    /** `onLimit` کاتێک بانگ دەکرێت کە ٦٠ چرکە تەواو بوو (خۆکارانە دەوەستێت). */
    @SuppressLint("MissingPermission")
    fun start(onLimit: () -> Unit): Boolean {
        if (recording) return true
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return false
        val r = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4
            )
        } catch (_: Throwable) {
            return false
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            return false
        }
        buf.reset()
        try {
            r.startRecording()
        } catch (_: Throwable) {
            r.release()
            return false
        }
        rec = r
        recording = true
        thread = Thread {
            val chunk = ByteArray(4096)
            val maxBytes = RATE * 2 * MAX_SECONDS
            var cur = r
            var total = 0
            var peak = 0
            var checked = false
            while (recording) {
                val n = cur.read(chunk, 0, chunk.size)
                if (n > 0) synchronized(buf) { buf.write(chunk, 0, n) }
                if (n < 0) break
                if (n > 0 && !checked) {
                    total += n
                    var i = 0
                    while (i + 1 < n) {
                        val v = Math.abs((chunk[i + 1].toInt() shl 8) or (chunk[i].toInt() and 0xFF))
                        if (v > peak) peak = v
                        i += 2
                    }
                    // یەک چرکە تەواو بێدەنگ = سەرچاوەی VOICE_RECOGNITION لەسەر ئەم مۆبایلە کار ناکات ← MIC تاقی بکەرەوە
                    if (total >= RATE * 2) {
                        checked = true
                        if (peak == 0) {
                            val alt = openRecorder(MediaRecorder.AudioSource.MIC)
                            if (alt != null) {
                                try { cur.stop() } catch (_: Exception) {}
                                cur.release()
                                cur = alt
                                rec = alt
                                synchronized(buf) { buf.reset() }
                            }
                        }
                    }
                }
                if (synchronized(buf) { buf.size() } >= maxBytes) {
                    recording = false
                    onLimit()
                    break
                }
            }
        }.also { it.start() }
        return true
    }

    @SuppressLint("MissingPermission")
    private fun openRecorder(source: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        return try {
            val a = AudioRecord(source, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4)
            if (a.state != AudioRecord.STATE_INITIALIZED) { a.release(); return null }
            a.startRecording()
            a
        } catch (_: Throwable) {
            null
        }
    }

    /** مایک دادەخات و دەنگی گیراو (PCM16 16kHz) دەگەڕێنێتەوە. */
    fun stop(): ByteArray {
        recording = false
        try {
            thread?.join(500)
        } catch (_: Exception) {
        }
        thread = null
        rec?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        rec = null
        return synchronized(buf) { buf.toByteArray() }
    }

    fun cancel() {
        stop()
    }

    companion object {
        private const val RATE = 16000
        private const val MAX_SECONDS = 60

        private const val PROMPT =
            "You are a professional Central Kurdish (Sorani) speech-to-text transcriber. " +
                "The audio is a person speaking Sorani Kurdish (Kurdistan Region of Iraq). The speaker may mix in English words, " +
                "names, brands, game titles or numbers. Transcribe EXACTLY what was said, word for word, in the speaker's own words, in " +
                "Arabic script (use ی ک ە ێ ۆ ڵ ڕ وو correctly; use ی not ي, ک not ك, ە not ه where needed). " +
                "The speaker may be poorly educated and speak colloquially or in a local dialect (Hawleri, Slemani, Garmiyan, Kirkuki...), with contractions, dropped sounds, non-standard grammar and borrowed Arabic/Persian/Turkish/English words. Write the words exactly as the speaker pronounced them: do NOT correct grammar, do NOT replace colloquial or dialect words with formal standard ones, do NOT add or remove words. " +
                "Write English words in the Latin alphabet as spoken (e.g. Player, GTA, RockStar), and numbers as digits. " +
                "When a person's name, place or brand is spoken, write it phonetically exactly as heard in Kurdish script (e.g. ئەحمەد، ڕێبین، دیلان); never replace a name with a similar common word, never translate it, never drop it. "+
                "Common Arabic/Islamic phrases used in Kurdish speech must be written in their standard spelling, e.g. السلام علیکم، وعلیکم السلام، ئینشائەڵڵا، ماشائەڵڵا، سوپاس، الحمدلله، بسم الله، نەخێر؛ never turn them into unrelated Kurdish words. "+
                "Add natural punctuation (، . ؟). Do not translate, summarize, explain or add anything. " +
                "Ignore background noise and music. Return ONLY the transcript text. If there is no clear speech, return an empty string."

        private fun vocabLine(vocab: String) =
            if (vocab.isBlank()) "" else " Reference spelling list of common Sorani words, names, places and brands (use ONLY as a spelling guide): " +
                "if a spoken word clearly sounds like a word in this list, write it with EXACTLY that spelling. " +
                "Never insert a word from the list that was not actually spoken, never force a list word over what the speaker really said, " +
                "and keep writing any other word as heard. List: " + vocab + "."

        private fun namesLine(names: List<String>) =
            if (names.isEmpty()) "" else " The speaker often says these names; whenever a spoken word sounds like one of them, write it with EXACTLY this spelling: " +
                names.joinToString("، ") + "."

        /** دەنگ بەرز دەکاتەوە بۆ ئاستی باش (نۆرماڵکردن) تا مۆدێل باشتر بیبیستێت. */
        private fun normalize(pcm: ByteArray): ByteArray {
            val n = pcm.size / 2
            val bb = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
            var peak = 1
            for (i in 0 until n) { val v = Math.abs(bb.getShort(i * 2).toInt()); if (v > peak) peak = v }
            val g = (20000f / peak).coerceIn(1f, 8f)
            if (g <= 1.05f) return pcm
            val out = ByteBuffer.allocate(pcm.size).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until n) out.putShort((bb.getShort(i * 2) * g).toInt().coerceIn(-32768, 32767).toShort())
            return out.array()
        }

        /** WAV ی نۆرماڵکراو بە base64، بۆ ناردنی دەنگ بۆ Gemini (چاککردنی دەستی). */
        fun wavBase64(pcm: ByteArray): String = Base64.encodeToString(wav(normalize(pcm)), Base64.NO_WRAP)

        private fun wav(pcm: ByteArray): ByteArray {
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
                .putInt(RATE).putInt(RATE * 2).putShort(2).putShort(16)
            h.put("data".toByteArray()).putInt(pcm.size)
            return h.array() + pcm
        }

        /** لە thread ی پاشبنەما بانگ بکرێت. بەتاڵ = هیچ قسەیەک نەبوو. */
        fun transcribe(pcm: ByteArray, keysRaw: String, names: List<String> = emptyList(), vocab: String = ""): String {
            if (pcm.size < RATE * 2 / 2) return ""   // کەمتر لە نیو چرکە
            val b64 = Base64.encodeToString(wav(normalize(pcm)), Base64.NO_WRAP)
            fun body(model: String, think: Boolean, cache: String?): String {
                val gen = JSONObject().put("temperature", 0)
                if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
                val o = JSONObject()
                    .put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put("role", "user").put(
                                "parts",
                                JSONArray()
                                    .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", b64)))
                                    .put(JSONObject().put("text", PROMPT + namesLine(names)))
                            )
                        )
                    )
                    .put("generationConfig", gen)
                if (cache != null) o.put("cachedContent", cache)
                return o.toString()
            }
            return GeminiKeys.withKeys(keysRaw) { key ->
                GeminiModels.call(false) { m, think ->
                    val cn = cacheFor(key, m, vocab)
                    try {
                        post(body(m, think, cn), key, m)
                    } catch (e: ApiException) {
                        // کاشەکە بەسەرچووە یان نەماوە ← یەک جار نوێی بکەرەوە و دووبارە هەوڵ بدە
                        val cacheProblem = cn != null && (e.code == 404 || e.code == 403 ||
                            (e.code == 400 && (e.message ?: "").contains("cache", true)))
                        if (!cacheProblem) throw e
                        caches.remove("$key|$m")
                        post(body(m, think, cacheFor(key, m, vocab)), key, m)
                    }
                }
            }.trim()
        }

        // ───────── کاشی فەرهەنگ (Gemini context caching) ─────────
        // لیستی وشەکان تەنها یەک جار دەنێردرێت و لای Gemini دەپارێزرێت؛ هەر دەنگێک تەنها ناوی کاشەکە دەنێرێت.
        // بۆ هەر (کلیل + مۆدێل) کاشێکی جیا؛ دوای ١٢ کاتژمێر یان دووبارە کردنەوەی ئەپ، یەک جار نوێ دەکرێتەوە.
        private const val CACHE_TTL_SEC = 12 * 3600
        private val caches = java.util.concurrent.ConcurrentHashMap<String, Pair<String, Long>>()
        private val noCache = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

        private fun cacheFor(key: String, model: String, vocab: String): String? {
            if (vocab.isBlank()) return null
            val id = "$key|$model"
            if (id in noCache) return null
            val now = System.currentTimeMillis()
            caches[id]?.let { if (now < it.second) return it.first }
            return try {
                val name = createCache(key, model, vocab)
                caches[id] = name to (now + (CACHE_TTL_SEC - 600) * 1000L)
                name
            } catch (e: ApiException) {
                // ئەم مۆدێلە کاش پشتگیری ناکات یان لیستەکە زۆر کورتە ← بێ لیست بەردەوام بە
                if (e.code == 400 || e.code == 403 || e.code == 404) noCache.add(id)
                null
            } catch (_: Throwable) {
                null
            }
        }

        private fun createCache(key: String, model: String, vocab: String): String {
            val body = JSONObject()
                .put("model", "models/$model")
                .put("ttl", "${CACHE_TTL_SEC}s")
                .put(
                    "contents",
                    JSONArray()
                        .put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", vocabLine(vocab)))))
                        .put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", "OK"))))
                )
                .toString()
            val c = URL("https://generativelanguage.googleapis.com/v1beta/cachedContents")
                .openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.connectTimeout = 15_000
                c.readTimeout = 30_000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw ApiException(code, "cache $code ${resp.take(120)}")
                return JSONObject(resp).getString("name")
            } finally {
                c.disconnect()
            }
        }

        private fun post(body: String, key: String, model: String): String {
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val why = try {
                        JSONObject(resp).getJSONObject("error").getString("message")
                    } catch (_: Exception) {
                        resp
                    }
                    throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
                }
                return try {
                    val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").optJSONArray("parts")
                    if (parts == null || parts.length() == 0) "" else parts.getJSONObject(0).optString("text", "")
                } catch (_: Exception) {
                    throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
                }
            } finally {
                c.disconnect()
            }
        }
    }
}
