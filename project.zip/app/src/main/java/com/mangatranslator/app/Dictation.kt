package com.mangatranslator.app

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * قسەکردن بە کوردی ← نووسین (سۆرانی، پیتی عەرەبی) بە Gemini.
 * start() مایک دەکاتەوە؛ stop() دەنگەکە دەگەڕێنێتەوە؛ transcribe() دەیکات بە دەق.
 */
class Dictation {
    private var rec: AudioRecord? = null
    private var thread: Thread? = null
    private val buf = ByteArrayOutputStream()

    @Volatile
    var recording = false
        private set

    /** `onLimit` کاتێک بانگ دەکرێت کە ٦٠ چرکە تەواو بوو (خۆکارانە دەوەستێت). */
    @SuppressLint("MissingPermission")
    fun start(onLimit: () -> Unit): Boolean {
        if (recording) return true
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return false
        val r = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4
            )
        } catch (_: Throwable) {
            return false
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            return false
        }
        buf.reset()
        try {
            r.startRecording()
        } catch (_: Throwable) {
            r.release()
            return false
        }
        rec = r
        recording = true
        thread = Thread {
            val chunk = ByteArray(4096)
            val maxBytes = RATE * 2 * MAX_SECONDS
            while (recording) {
                val n = r.read(chunk, 0, chunk.size)
                if (n > 0) synchronized(buf) { buf.write(chunk, 0, n) }
                if (n < 0) break
                if (synchronized(buf) { buf.size() } >= maxBytes) {
                    recording = false
                    onLimit()
                    break
                }
            }
        }.also { it.start() }
        return true
    }

    /** مایک دادەخات و دەنگی گیراو (PCM16 16kHz) دەگەڕێنێتەوە. */
    fun stop(): ByteArray {
        recording = false
        try {
            thread?.join(500)
        } catch (_: Exception) {
        }
        thread = null
        rec?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        rec = null
        return synchronized(buf) { buf.toByteArray() }
    }

    fun cancel() {
        stop()
    }

    companion object {
        private const val RATE = 16000
        private const val MAX_SECONDS = 60

        private const val PROMPT =
            "The audio is a person speaking Central Kurdish (Sorani). Write exactly what they said as Sorani Kurdish text " +
                "in Arabic script (use ی ک ە ێ ۆ ڵ ڕ ۊ correctly), with natural punctuation. " +
                "Return ONLY the written text, nothing else. If there is no speech, return an empty string."

        private fun wav(pcm: ByteArray): ByteArray {
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
                .putInt(RATE).putInt(RATE * 2).putShort(2).putShort(16)
            h.put("data".toByteArray()).putInt(pcm.size)
            return h.array() + pcm
        }

        /** لە thread ی پاشبنەما بانگ بکرێت. بەتاڵ = هیچ قسەیەک نەبوو. */
        fun transcribe(pcm: ByteArray, keysRaw: String): String {
            if (pcm.size < RATE * 2 / 2) return ""   // کەمتر لە نیو چرکە
            val b64 = Base64.encodeToString(wav(pcm), Base64.NO_WRAP)
            fun body(model: String, think: Boolean): String {
                val gen = JSONObject()
                if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
                return JSONObject()
                    .put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray()
                                    .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", b64)))
                                    .put(JSONObject().put("text", PROMPT))
                            )
                        )
                    )
                    .put("generationConfig", gen)
                    .toString()
            }
            return GeminiKeys.withKeys(keysRaw) { key ->
                GeminiModels.call { m, think -> post(body(m, think), key, m) }
            }.trim()
        }

        private fun post(body: String, key: String, model: String): String {
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val why = try {
                        JSONObject(resp).getJSONObject("error").getString("message")
                    } catch (_: Exception) {
                        resp
                    }
                    throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
                }
                return try {
                    val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").optJSONArray("parts")
                    if (parts == null || parts.length() == 0) "" else parts.getJSONObject(0).optString("text", "")
                } catch (_: Exception) {
                    throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
                }
            } finally {
                c.disconnect()
            }
        }
    }
}
