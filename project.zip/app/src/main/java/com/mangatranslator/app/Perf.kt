package com.mangatranslator.app

import android.os.SystemClock
import android.util.Log

/**
 * کاتپێوان بۆ دۆزینەوەی ئەوەی کات لە کوێ دەچێت.
 * بینینی ئەنجام: Logcat ← فلتەر بکە بە  tag:Perf
 * نموونە:  [region] +1830ms tesseract done found=false
 * هەر start() ی نوێ کاتەکە لە سفرەوە دەست پێدەکاتەوە.
 */
object Perf {
    private const val TAG = "Perf"
    @Volatile private var t0 = 0L
    @Volatile private var name = ""
    @Volatile private var lastMark = 0L

    fun start(n: String, label: String = "start") {
        t0 = SystemClock.elapsedRealtime()
        lastMark = t0
        name = n
        Log.d(TAG, "[$n] +0ms $label")
    }

    /** +Xms لە start ەوە، (+Yms) لە mark ی پێشووەوە */
    fun mark(label: String) {
        if (t0 == 0L) return
        val now = SystemClock.elapsedRealtime()
        Log.d(TAG, "[$name] +${now - t0}ms (+${now - lastMark}) $label")
        lastMark = now
    }

    /** یەکەم جار کە دەنگ دەست پێدەکات؛ پاشان دووبارە ناکرێتەوە تا start ی نوێ */
    @Volatile private var audioLogged = false
    fun audio(on: Boolean) {
        if (on && !audioLogged) { audioLogged = true; mark("★ دەنگ دەستی پێکرد (کۆی چاوەڕوانی)") }
    }
    fun resetAudio() { audioLogged = false }
}
