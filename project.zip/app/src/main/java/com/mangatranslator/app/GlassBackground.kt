package com.mangatranslator.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator

/** پاشبنەمای ئاو/شووشە: گرادیێنت + تەڕایی ڕەنگ + بلوقی هێواش بەرەو سەرەوە */
class GlassBackground(ctx: Context, private val pal: Palette) : View(ctx) {

    private class Bub(var x: Float, var y: Float, val r: Float, val speed: Float)

    private val d = resources.displayMetrics.density
    private val bubs = ArrayList<Bub>()
    private val rnd = java.util.Random(7)
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blob1 = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blob2 = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#16FFFFFF") }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = Color.parseColor("#4DFFFFFF")
    }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#66FFFFFF") }
    private var anim: ValueAnimator? = null
    private var last = 0L

    private fun a(c: Int, alpha: Int) = (c and 0x00FFFFFF) or (alpha shl 24)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), pal.bgTop, pal.bgBottom, Shader.TileMode.CLAMP)
        blob1.shader = RadialGradient(w * 0.15f, h * 0.18f, w * 0.7f, a(pal.a1, 0x66), a(pal.a1, 0), Shader.TileMode.CLAMP)
        blob2.shader = RadialGradient(w * 0.9f, h * 0.85f, w * 0.8f, a(pal.a2, 0x48), a(pal.a2, 0), Shader.TileMode.CLAMP)
        bubs.clear()
        repeat(14) {
            bubs.add(Bub(rnd.nextFloat() * w, rnd.nextFloat() * h,
                (6 + rnd.nextFloat() * 26) * d, (12 + rnd.nextFloat() * 30) * d))
        }
    }

    override fun onDraw(c: Canvas) {
        c.drawPaint(bg)
        c.drawPaint(blob1)
        c.drawPaint(blob2)
        for (b in bubs) {
            c.drawCircle(b.x, b.y, b.r, fill)
            c.drawCircle(b.x, b.y, b.r, ring)
            c.drawCircle(b.x - b.r * 0.35f, b.y - b.r * 0.35f, b.r * 0.2f, shine)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        last = System.nanoTime()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener {
                val now = System.nanoTime()
                val dt = (now - last) / 1e9f
                last = now
                for (b in bubs) {
                    b.y -= b.speed * dt
                    if (b.y + b.r < 0) { b.y = height + b.r; b.x = rnd.nextFloat() * width }
                }
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }
}
