package com.mangatranslator.app

import android.content.Context
import android.graphics.*
import android.view.View

/** پاشبنەمای ئاو/شووشە: گرادیێنتی نەرم + تەڕایی ڕەنگ (بێ بڵق) */
class GlassBackground(ctx: Context, private val pal: Palette) : View(ctx) {

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blob1 = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blob2 = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun a(c: Int, alpha: Int) = (c and 0x00FFFFFF) or (alpha shl 24)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), pal.bgTop, pal.bgBottom, Shader.TileMode.CLAMP)
        blob1.shader = RadialGradient(w * 0.85f, h * 0.10f, w * 0.75f, a(pal.a1, if (pal.light) 0x2E else 0x66), a(pal.a1, 0), Shader.TileMode.CLAMP)
        blob2.shader = RadialGradient(w * 0.10f, h * 0.80f, w * 0.85f, a(pal.a2, if (pal.light) 0x26 else 0x48), a(pal.a2, 0), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        c.drawPaint(bg)
        c.drawPaint(blob1)
        c.drawPaint(blob2)
    }
}
