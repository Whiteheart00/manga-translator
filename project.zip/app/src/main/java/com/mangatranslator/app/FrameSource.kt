package com.mangatranslator.app

import android.graphics.Bitmap

/** سەرچاوەی فرەیمی شاشە: MediaProjection (ScreenCapturer) یان Accessibility (AccessibilityCapturer). */
interface FrameSource {
    /** لە thread ی گرتنەوە بانگ دەکرێت؛ وەرگر دەبێت bitmap recycle بکات. */
    var frameListener: ((Bitmap) -> Unit)?
    fun start()
    /** دوای `delayMs` فرەیمێک دەدات بە `cb` (لە thread ی گرتنەوە؛ cb دەبێت recycle ی بکات). null = نەگیرا. */
    fun requestFrame(delayMs: Long, cb: (Bitmap?) -> Unit)
    fun release()
    /** داوای فرەیمی دووبارە بکە (بۆ forceRescan کاتێک شاشە نەگۆڕاوە)؛ بنەڕەت: هیچ */
    fun kick() {}
}
