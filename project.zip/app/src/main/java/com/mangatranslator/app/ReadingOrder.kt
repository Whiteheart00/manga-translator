package com.mangatranslator.app

/**
 * ڕیزبەندی خوێندنەوەی بلۆکەکان: سەرەوە بۆ خوارەوە بە ١٢ ڕیز، و لەناو هەر ڕیزێکدا چەپ بۆ ڕاست (یان ڕاست بۆ چەپ ئەگەر [rtl]).
 * فەنکشنێکی پاکە (بێ Android) بۆ ئەوەی بتوانرێت تێستی یەکەی بۆ بکرێت.
 */
object ReadingOrder {
    const val ROWS = 12

    fun <T> sort(items: List<T>, frameH: Int, rtl: Boolean = false, top: (T) -> Int, left: (T) -> Int): List<T> {
        val h = frameH.coerceAtLeast(1)
        return items.sortedWith(
            compareBy<T> { top(it) * ROWS / h }
                .thenBy { if (rtl) -left(it) else left(it) }
        )
    }
}
