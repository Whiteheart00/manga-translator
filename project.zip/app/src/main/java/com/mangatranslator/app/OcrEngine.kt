package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/** یەک ناوچەی دەق (بابلی قسە) لەسەر وێنەی گیراو. rect بە پیکسێلی وێنەکەیە. */
data class TextBox(val rect: Rect, val text: String)

/**
 * OCR ئۆفلاین: ئینگلیزی/لاتین، چینی، جاپانی، کۆری بە Google ML Kit، و عەرەبی بە Tesseract.
 * `lang()` یەکێکە لە SourceLangs.codes. لە دۆخی "auto" هەموو ML Kit ـەکان تاقی دەکرێنەوە و زمانی
 * دۆزراوە بۆ پەڕەکانی دواتر دەهێڵرێتەوە (تا پەڕەیەک بێ دەق بێت).
 * دەرەنجامەکان لەسەر main thread دەگەڕێنەوە.
 */
class OcrEngine(
    private val ctx: Context,
    private val lang: () -> String = { "auto" },
    private val onNotice: (String) -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val japanese by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val korean by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val chinese by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }

    /** زمانی دۆزراوە لە دۆخی auto (بۆ خێرایی پەڕەکانی دواتر) */
    @Volatile private var detected: String? = null

    private fun recognizerFor(code: String): TextRecognizer = when (code) {
        "ja" -> japanese
        "ko" -> korean
        "zh" -> chinese
        else -> latin
    }

    fun recognize(bitmap: Bitmap, onDone: (List<TextBox>) -> Unit) {
        val chosen = lang()
        when (chosen) {
            "ar" -> recognizeArabic(bitmap, onDone)
            "auto" -> {
                val known = detected
                if (known != null) {
                    runOne(known, bitmap) { boxes ->
                        if (boxes.isNotEmpty()) onDone(boxes) else { detected = null; detect(bitmap, onDone) }
                    }
                } else detect(bitmap, onDone)
            }
            else -> runOne(chosen, bitmap, onDone)
        }
    }

    private fun recognizeArabic(bitmap: Bitmap, onDone: (List<TextBox>) -> Unit) {
        // Tesseract لە thread ی پاشبنەما؛ bitmap ـەکە تا کۆتایی ئەم کارە ناسڕدرێتەوە چونکە بانگکەر دوای onDone recycle دەکات
        bg.execute {
            val boxes = ArabicOcr.recognize(ctx, bitmap) { msg -> onNotice(msg) }
            main.post { onDone(boxes) }
        }
    }

    private fun runOne(code: String, bitmap: Bitmap, onDone: (List<TextBox>) -> Unit) {
        recognizerFor(code).process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { onDone(toBoxes(it, code)) }
            .addOnFailureListener { e -> Log.e(TAG, "OCR failed ($code)", e); onDone(emptyList()) }
    }

    /** هەموو ML Kit ـەکان پێکەوە، پاشان بەپێی پیتەکان زمانەکە هەڵدەبژێرین */
    private fun detect(bitmap: Bitmap, onDone: (List<TextBox>) -> Unit) {
        val codes = listOf("en", "ja", "ko", "zh")
        val results = HashMap<String, List<TextBox>>()
        var left = codes.size
        for (c in codes) {
            runOne(c, bitmap) { boxes ->
                results[c] = boxes
                if (--left == 0) {
                    val best = pickLanguage(results)
                    val boxes2 = results[best].orEmpty()
                    // ئەگەر "en" هەڵبژێردرا بەڵام پیتی لاتینی ڕاستەقینە کەمە، لەوانەیە عەرەبی بێت
                    val latinLetters = boxes2.joinToString("") { it.text }.count { ch -> ch in 'A'..'Z' || ch in 'a'..'z' }
                    val looksLikeJunk = best == "en" && latinLetters < 6
                    if (boxes2.isNotEmpty() && !looksLikeJunk) {
                        detected = best
                        onDone(boxes2)
                    } else {
                        // عەرەبی تاقی بکەرەوە (ئەگەر فایلەکە نەبوو، خۆی دایدەبەزێنێت)
                        recognizeArabic(bitmap) { ar -> onDone(if (ar.isNotEmpty()) ar else boxes2) }
                    }
                }
            }
        }
    }

    private fun pickLanguage(r: Map<String, List<TextBox>>): String {
        fun score(code: String, native: (Char) -> Boolean): Int {
            val t = r[code].orEmpty().joinToString("") { it.text }
            val letters = t.count { it.isLetter() }
            val n = t.count(native)
            return if (n >= 2 && n * 10 >= letters * 3) n else 0
        }
        val ko = score("ko") { it.code in 0xAC00..0xD7AF || it.code in 0x1100..0x11FF }
        val ja = score("ja") { it.code in 0x3040..0x30FF }
        val zh = score("zh") { it.code in 0x4E00..0x9FFF }
        val m = maxOf(ko, ja, zh)
        return when {
            m == 0 -> "en"
            ko == m -> "ko"
            ja == m -> "ja"
            else -> "zh"
        }
    }

    private fun toBoxes(result: Text, code: String): List<TextBox> {
        val cjk = code == "ja" || code == "ko" || code == "zh"
        return result.textBlocks.mapNotNull { block ->
            val rect = block.boundingBox ?: return@mapNotNull null
            // لە CJK دا بۆشایی لە نێوان هێڵەکان نییە؛ لە لاتین بۆشایی دەخرێتە نێوان
            val text = if (cjk) block.lines.joinToString("") { it.text }.trim()
            else block.text.replace('\n', ' ').trim()
            val ok = if (cjk) text.any { it.isLetterOrDigit() } else text.length >= 2
            if (ok) TextBox(rect, text) else null
        }.also { Log.d(TAG, "OCR($code) found ${it.size} blocks") }
    }

    fun close() {
        latin.close()
        japanese.close()
        korean.close()
        chinese.close()
        bg.shutdown()
        ArabicOcr.release()
    }

    companion object {
        private const val TAG = "OcrEngine"
    }
}
