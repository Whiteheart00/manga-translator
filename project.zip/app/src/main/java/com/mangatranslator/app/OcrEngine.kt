package com.mangatranslator.app

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** یەک ناوچەی دەق (بابلی قسە) لەسەر وێنەی گیراو. rect بە پیکسێلی وێنەکەیە. */
data class TextBox(val rect: Rect, val text: String)

/**
 * OCR ئۆفلاین بە Google ML Kit (Latin).
 * دەرەنجامەکان لەسەر main thread دەگەڕێنەوە.
 */
class OcrEngine {

    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    fun recognize(bitmap: Bitmap, onDone: (List<TextBox>) -> Unit) {
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val boxes = result.textBlocks.mapNotNull { block ->
                    val rect = block.boundingBox ?: return@mapNotNull null
                    // هەموو هێڵەکانی یەک بلۆک دەکەین بە یەک دەق
                    val text = block.text.replace('\n', ' ').trim()
                    if (text.length < 2) null else TextBox(rect, text)
                }
                Log.d(TAG, "OCR found ${boxes.size} blocks")
                onDone(boxes)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "OCR failed", e)
                onDone(emptyList())
            }
    }

    fun close() {
        recognizer.close()
    }

    companion object {
        private const val TAG = "OcrEngine"
    }
}
