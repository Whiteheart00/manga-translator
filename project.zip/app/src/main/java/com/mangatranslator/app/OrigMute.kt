package com.mangatranslator.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager

/**
 * دەنگی ئەسڵیی مۆبایل (یاری/ڤیدیۆ) دەکوژێنێتەوە کاتێک وەرگێڕانی زیندوو کار دەکات، تا تەنها دەنگی وەرگێڕدراو ببیسترێت.
 *  - دەنگی ئەسڵی لەسەر بەرزیی میدیا (STREAM_MUSIC) ـە ← دەکرێتە ٠ (گرتنی دەنگی ئەپەکە هێشتا دەنگەکە وەردەگرێت)؛
 *  - دەنگی وەرگێڕدراو بە بەرزیی ئەلارم (STREAM_ALARM) دەپەخشرێت کە بەرزییەکی جیاوازە، بۆیە دەبیسترێت؛
 *  - بەرزییە کۆنەکان لە فایلێکدا هەڵدەگیرێن و کاتێک وەرگێڕان دەوەستێت (یان ئەپەکە داخرا/کڕاش بوو) دەگەڕێنرێنەوە،
 *    بۆ ئەوەی مۆبایل هەرگیز بێدەنگ نەمێنێتەوە.
 */
object OrigMute {
    private const val PF = "live_ovol"

    private fun am(c: Context) = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    /** ئایا دەنگی ئەسڵی لەلایەن ئێمەوە کوژێندراوەتەوە (بۆ گەڕاندنەوە دوای کڕاش) */
    fun isActive(c: Context): Boolean = c.getSharedPreferences(PF, Context.MODE_PRIVATE).getInt("m", -1) >= 0

    fun apply(c: Context) {
        try {
            val a = am(c)
            val sp = c.getSharedPreferences(PF, Context.MODE_PRIVATE)
            if (sp.getInt("m", -1) < 0) {
                // بەرزییە ڕاستەقینەکان تەنها یەکجار هەڵدەگیرێن (هەرگیز بە ٠ی کوژاوە ناگۆڕدرێن)
                sp.edit()
                    .putInt("m", a.getStreamVolume(AudioManager.STREAM_MUSIC))
                    .putInt("a", a.getStreamVolume(AudioManager.STREAM_ALARM))
                    .commit()
            }
            val m = sp.getInt("m", 0)
            val mMax = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val aMax = a.getStreamMaxVolume(AudioManager.STREAM_ALARM).coerceAtLeast(1)
            // بەرزیی دەنگی وەرگێڕدراو = بەرزیی میدیای پێشوو (لانیکەم ٦٠٪ تا هەرگیز زۆر هێمن نەبێت)
            val ratio = maxOf(m.toFloat() / mMax, 0.6f)
            a.setStreamVolume(AudioManager.STREAM_ALARM, Math.round(ratio * aMax).coerceIn(1, aMax), 0)
            a.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            LiveAudio.outUsage = AudioAttributes.USAGE_ALARM
        } catch (e: Throwable) {
            LiveAudio.outUsage = AudioAttributes.USAGE_ASSISTANT
        }
    }

    fun restore(c: Context) {
        LiveAudio.outUsage = AudioAttributes.USAGE_MEDIA
        try {
            val sp = c.getSharedPreferences(PF, Context.MODE_PRIVATE)
            val m = sp.getInt("m", -1)
            val al = sp.getInt("a", -1)
            val a = am(c)
            if (m >= 0) a.setStreamVolume(AudioManager.STREAM_MUSIC, m, 0)
            if (al >= 0) a.setStreamVolume(AudioManager.STREAM_ALARM, al, 0)
            sp.edit().clear().commit()
        } catch (_: Throwable) {
        }
    }
}
