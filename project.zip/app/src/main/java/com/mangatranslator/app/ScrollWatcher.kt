package com.mangatranslator.app

import android.graphics.Bitmap
import android.os.SystemClock

/**
 * کاتێک وەرگێڕانی دەستی/ڕووبەر لەسەر شاشەیە، ئەگەر بەکارهێنەر شاشەکەی جووڵاند (scroll، پەڕەی نوێ...)
 * `onScrolled` بانگ دەکات تا وەرگێڕانەکە بسڕدرێتەوە (وەک وەرگێڕانی خۆکار).
 * `notifyOverlayUpdated()` هەر کاتێک ئۆڤەرلەی خۆمان گۆڕا بانگ بکە. onFrame لە thread ی گرتنەوەیە و bmp recycle دەکات.
 */
class ScrollWatcher(private val onScrolled: () -> Unit) {
    @Volatile private var baseline: IntArray? = null
    @Volatile private var changedAt = SystemClock.elapsedRealtime()
    @Volatile private var needRebaseline = true
    @Volatile private var fired = false
    /** تا وەرگێڕانەکە تەواو نەبووە و لەسەر شاشە نەمابێت، چاودێری ناکرێت (بۆ ئەوەی کاتی وەرگێڕان بە هەڵە نەسڕدرێتەوە) */
    @Volatile private var armed = false
    private var hits = 0

    fun arm() {
        armed = true
        changedAt = SystemClock.elapsedRealtime()
        needRebaseline = true
        hits = 0
    }

    fun notifyOverlayUpdated() {
        changedAt = SystemClock.elapsedRealtime()
        needRebaseline = true
    }

    fun onFrame(bmp: Bitmap) {
        val sig = ChangeDetector.signature(bmp)
        bmp.recycle()
        if (fired || !armed) return
        if (SystemClock.elapsedRealtime() - changedAt < SETTLE_MS) return
        val base = baseline
        if (needRebaseline || base == null) {
            baseline = sig
            needRebaseline = false
            return
        }
        // دەبێت چەند فرەیمێکی یەک لە دوای یەک بگۆڕێت، بۆ ئەوەی گۆڕانی کورتی (ئەنیمەیشن، لۆدینگ) نەبێتە هۆی سڕینەوە
        if (ChangeDetector.distance(sig, base) > THRESHOLD) {
            if (++hits >= HITS_NEEDED) {
                fired = true
                onScrolled()
            }
        } else hits = 0
    }

    companion object {
        private const val SETTLE_MS = 450L
        private const val THRESHOLD = 10f
        private const val HITS_NEEDED = 3
    }
}
