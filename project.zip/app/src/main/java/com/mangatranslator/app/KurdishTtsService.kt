package com.mangatranslator.app

import android.media.AudioFormat
import android.speech.tts.SynthesisCallback
import android.speech.tts.SynthesisRequest
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeechService
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale

/**
 * دەنگی کوردیی ئۆفلاین (Piper / Berfin) وەک «دەنگی سیستەم» (Text-to-speech engine) ی ئەندرۆید.
 * کاتێک چالاک بکرێت (ڕێکخستنی دەنگ ← «وەک دەنگی سیستەم»)، لە Settings ← Text-to-speech ← Preferred engine دەردەکەوێت و
 * هەر ئەپێک کە دەنگی سیستەم بەکاردێنێت (TalkBack/Select to Speak، خوێنەرەوەی کتێب، ناڤیگەیشن، ئاگادارکەرەوە…)
 * دەتوانێت بیخوێنێتەوە، بێ ئینتەرنێت. بەپێی هەڵبژاردنی بەکارهێنەر: بنەڕەتی کوژاوەیە (android:enabled="false").
 * مۆدێلەکە (model.onnx) دەبێت لە ئەپەکەدا هێنرابێت (PiperTts.isInstalled).
 */
class KurdishTtsService : TextToSpeechService() {

    private val piper by lazy { PiperTts(applicationContext) }
    @Volatile private var stopRequested = false

    private fun isKurdish(lang: String?) = when (lang?.lowercase(Locale.ROOT)) {
        "ckb", "kur", "ku" -> true
        else -> false
    }

    override fun onIsLanguageAvailable(lang: String?, country: String?, variant: String?): Int {
        if (!isKurdish(lang)) return TextToSpeech.LANG_NOT_SUPPORTED
        return when (country?.uppercase(Locale.ROOT)) {
            "IQ", "IRQ", "IR", "IRN" -> TextToSpeech.LANG_COUNTRY_AVAILABLE
            null, "" -> TextToSpeech.LANG_AVAILABLE
            else -> TextToSpeech.LANG_AVAILABLE
        }
    }

    override fun onGetLanguage(): Array<String> = arrayOf("ckb", "IRQ", "")

    override fun onLoadLanguage(lang: String?, country: String?, variant: String?): Int {
        val r = onIsLanguageAvailable(lang, country, variant)
        if (r == TextToSpeech.LANG_NOT_SUPPORTED) return r
        if (!PiperTts.isInstalled(applicationContext)) return TextToSpeech.LANG_MISSING_DATA
        // مۆدێلەکە بە پاشبنەما بار دەکرێت تا یەکەم خوێندنەوە خاو نەبێت
        Thread { try { piper.warmUp() } catch (_: Throwable) {} }.start()
        return r
    }

    // ---- دەنگەکان (API 21+): یەک دەنگی کوردیی سۆرانی ----
    override fun onGetVoices(): List<Voice> =
        listOf(Voice(VOICE_NAME, Locale("ckb", "IQ"), Voice.QUALITY_VERY_HIGH, Voice.LATENCY_NORMAL, false, emptySet()))

    override fun onIsValidVoiceName(name: String?): Int =
        if (name == VOICE_NAME) TextToSpeech.SUCCESS else TextToSpeech.ERROR

    override fun onLoadVoice(name: String?): Int =
        if (name == VOICE_NAME) TextToSpeech.SUCCESS else TextToSpeech.ERROR

    override fun onGetDefaultVoiceNameFor(lang: String?, country: String?, variant: String?): String =
        if (isKurdish(lang)) VOICE_NAME else ""

    override fun onStop() {
        stopRequested = true
    }

    override fun onSynthesizeText(request: SynthesisRequest, callback: SynthesisCallback) {
        stopRequested = false
        if (!isKurdish(request.language)) {
            callback.error(TextToSpeech.ERROR_INVALID_REQUEST)
            return
        }
        if (!PiperTts.isInstalled(applicationContext)) {
            callback.error(TextToSpeech.ERROR_NOT_INSTALLED_YET)
            return
        }
        val text = request.charSequenceText?.toString().orEmpty()
        if (text.isBlank()) {
            callback.start(22050, AudioFormat.ENCODING_PCM_16BIT, 1)
            callback.done()
            return
        }
        // speechRate: ١٠٠ = ئاسایی؛ خێرایی ڕێکخستنی ئەپەکەش لەگەڵ دەگیرێت
        val speed = (request.speechRate / 100f).coerceIn(0.5f, 2f)

        piper.prepare()?.let {
            Log.w(TAG, "load: $it")
            callback.error(TextToSpeech.ERROR_NOT_INSTALLED_YET)
            return
        }
        callback.start(piper.outputSampleRate, AudioFormat.ENCODING_PCM_16BIT, 1)
        val maxBytes = callback.maxBufferSize.coerceAtLeast(1024)

        val err = piper.synthesizeToPcm(text, speed, { stopRequested }) { pcm ->
            val bytes = ByteArray(pcm.size * 2)
            for (i in pcm.indices) {
                val v = pcm[i].toInt()
                bytes[2 * i] = (v and 0xFF).toByte()
                bytes[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
            }
            var off = 0
            while (off < bytes.size) {
                if (stopRequested) return@synthesizeToPcm false
                val n = minOf(maxBytes, bytes.size - off)
                if (callback.audioAvailable(bytes, off, n) != TextToSpeech.SUCCESS) return@synthesizeToPcm false
                off += n
            }
            true
        }
        if (err != null) { callback.error(); return }
        callback.done()
    }

    override fun onDestroy() {
        stopRequested = true
        try { piper.shutdown() } catch (_: Throwable) {}   // ڕام ئازاد دەکات کاتێک سیستەم ئەم engine ـە دادەخات
        super.onDestroy()
    }

    companion object {
        private const val TAG = "KurdishTtsService"
        const val VOICE_NAME = "ckb-iq-berfin-offline"
    }
}
