package com.mangatranslator.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * وەرگێڕانی ئینگلیزی → سۆرانی تەنها بە Google Translate.
 *  - ئەگەر کلیلی API هەبێت: Google Cloud Translation (فەرمی)
 *  - ئەگەر کلیل نەبێت: ڕێگای بێ کلیلی Google Translate
 * هەموو بانگەکان دەبێت لە thread ی پاشبنەما بن. دەرەنجامەکان لە cache دەمێننەوە.
 */
object GoogleTranslator {

    private const val TAG = "GoogleTranslator"

    private val cache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 500
    }

    /** دەقی بابلێک دەکات بە سۆرانی. null = دەقەکە زۆر کورتە. هەڵە دەگەڕێنێتەوە ئەگەر ئینتەرنێت نەبوو. */
    fun translateBubble(raw: String, key: String): String? {
        val text = TextPrep.prepare(raw)
        if (text.length < 2) return null

        synchronized(cache) { cache[text] }?.let { return it }

        var failure: IOException? = null
        repeat(2) {
            try {
                val out = TextPrep.fixSorani(if (key.isNotBlank()) official(text, key) else free(text))
                if (out.isBlank()) return null
                synchronized(cache) { cache[text] = out }
                return out
            } catch (e: IOException) {
                Log.w(TAG, "attempt failed: ${e.message}")
                failure = e
            }
        }
        throw failure ?: IOException("translate failed")
    }

    private fun official(text: String, key: String): String {
        val body = JSONObject().apply {
            put("q", text)
            put("source", "en")
            put("target", "ckb")
            put("format", "text")
        }
        val res = request(
            "https://translation.googleapis.com/language/translate/v2?key=" + URLEncoder.encode(key, "UTF-8"),
            body.toString()
        )
        return try {
            JSONObject(res).getJSONObject("data").getJSONArray("translations")
                .getJSONObject(0).getString("translatedText").trim()
        } catch (e: Exception) {
            throw IOException("bad response")
        }
    }

    private fun free(text: String): String {
        val res = request(
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ckb&dt=t&q=" +
                URLEncoder.encode(text, "UTF-8"),
            null
        )
        return try {
            val parts = JSONArray(res).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val seg = parts.optJSONArray(i) ?: continue
                if (!seg.isNull(0)) sb.append(seg.getString(0))
            }
            sb.toString().trim()
        } catch (e: Exception) {
            throw IOException("bad response")
        }
    }

    /** body == null → GET، دەنا POST ی JSON */
    private fun request(url: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5_000
            c.readTimeout = 8_000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                Log.e(TAG, "HTTP $code: ${text.take(200)}")
                throw IOException("HTTP $code")
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
