package com.mangatranslator.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * وەرگێڕانی (ئینگلیزی، عەرەبی، جاپانی، چینی، کۆری، یان خۆکار) → سۆرانی تەنها بە Google Translate.
 *  - ئەگەر کلیلی API هەبێت: Google Cloud Translation (فەرمی)
 *  - ئەگەر کلیل نەبێت: ڕێگای بێ کلیلی Google Translate
 * هەموو بانگەکان دەبێت لە thread ی پاشبنەما بن. دەرەنجامەکان لە cache دەمێننەوە.
 */
object GoogleTranslator {

    private const val TAG = "GoogleTranslator"

    private val cache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 500
    }

    /** دەقی بابلێک دەکات بە سۆرانی. null = دەقەکە زۆر کورتە. هەڵە دەگەڕێنێتەوە ئەگەر ئینتەرنێت نەبوو. */
    fun translateBubble(raw: String, lang: String = "auto"): String? {
        val text = TextPrep.prepare(raw)
        if (text.isBlank() || (text.length < 2 && !TextPrep.hasCjk(text))) return null
        val sl = SourceLangs.apiCode(lang)
        val ck = "$sl|$text"

        synchronized(cache) { cache[ck] }?.let { return it }

        var failure: IOException? = null
        repeat(2) {
            try {
                val got: String = free(text, sl)
                val out = TextPrep.fixSorani(got)
                if (out.isBlank()) return null
                synchronized(cache) { cache[ck] = out }
                return out
            } catch (e: IOException) {
                Log.w(TAG, "attempt failed: ${e.message}")
                if (failure == null) failure = e
            }
        }
        throw failure ?: IOException("translate failed")
    }

    /**
     * وەرگێڕانی قسە (وەرگێڕانی دەنگی زیندوو): دەقی ئاسایی لە زمانێکەوە بۆ زمانێکی تر (en ↔ ckb).
     * بێ ئامادەکردنی دەقی OCR. null = دەقەکە زۆر کورتە. هەڵە دەگەڕێنێتەوە ئەگەر ئینتەرنێت نەبوو.
     */
    fun translateSpeech(raw: String, sl: String, tl: String): String? {
        val text = raw.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        if (text.length < 2) return null
        val ck = "$sl>$tl|$text"
        synchronized(cache) { cache[ck] }?.let { return it }
        var failure: IOException? = null
        repeat(2) {
            try {
                val got = free(text, sl, tl)
                val out = if (tl == "ckb") TextPrep.fixSorani(got) else got.trim()
                if (out.isBlank()) return null
                synchronized(cache) { cache[ck] = out }
                return out
            } catch (e: IOException) {
                Log.w(TAG, "speech attempt failed: ${e.message}")
                if (failure == null) failure = e
            }
        }
        throw failure ?: IOException("translate failed")
    }

    /** بێ کلیل: سەرەتا ڕێگای یەکەم، ئەگەر شکستی هێنا ڕێگای دووەم */
    private fun free(text: String, sl: String, tl: String = "ckb"): String {
        val q = URLEncoder.encode(text, "UTF-8")
        try {
            val res = request(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=$q", null
            )
            val parts = JSONArray(res).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val seg = parts.optJSONArray(i) ?: continue
                if (!seg.isNull(0)) sb.append(seg.getString(0))
            }
            if (sb.isNotBlank()) return sb.toString().trim()
        } catch (e: Exception) {
            Log.w(TAG, "gtx failed: ${e.message}")
        }
        try {
            val res = request(
                "https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=$sl&tl=$tl&q=$q", null
            ).trim()
            val out = if (res.startsWith("{")) {
                val ss = JSONObject(res).getJSONArray("sentences")
                val sb = StringBuilder()
                for (i in 0 until ss.length()) sb.append(ss.getJSONObject(i).optString("trans", ""))
                sb.toString().trim()
            } else {
                val first = JSONArray(res).get(0)
                (if (first is JSONArray) first.getString(0) else first.toString()).trim()
            }
            if (out.isNotBlank()) return out
        } catch (e: Exception) {
            Log.w(TAG, "clients5 failed: ${e.message}")
        }
        // ڕێگای سێیەم: لاپەڕەی مۆبایلی Google Translate
        return try {
            val html = request("https://translate.google.com/m?sl=$sl&tl=$tl&q=$q", null)
            val m = Regex("class=\"result-container\">(.*?)</div>", RegexOption.DOT_MATCHES_ALL).find(html)
                ?: throw IOException("no result")
            android.text.Html.fromHtml(m.groupValues[1], android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
        } catch (e: Exception) {
            throw IOException("Google: ${e.message}")
        }
    }

    /** body == null → GET، دەنا POST ی JSON */
    private fun request(url: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5_000
            c.readTimeout = 8_000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                Log.e(TAG, "HTTP $code: ${text.take(200)}")
                val reason = try {
                    JSONObject(text).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    ""
                }
                throw IOException("HTTP $code ${reason.take(120)}".trim())
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
