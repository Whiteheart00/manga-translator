package com.mangatranslator.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

/**
 * وەرگێڕانی (ئینگلیزی، عەرەبی، جاپانی، چینی، کۆری، یان خۆکار) → سۆرانی تەنها بە Google Translate.
 *  - ڕێگای بێ کلیل (translate.googleapis.com / clients5 / مۆبایل)
 *  - هەموو بانگەکان دەبێت لە thread ی پاشبنەما بن
 *  - دەرەنجامەکان لە cache دەمێننەوە
 *  - [نوێ] وەرگێڕانی گرووپی (batch): چەند بابڵ لە یەک داواکاریدا → زۆر خێراتر
 */
object GoogleTranslator {

    private const val TAG = "GoogleTranslator"

    /** جیاکەرەوەیەکی دەگمەن کە Google Translate زۆربەی کات دەیهێڵێتەوە */
    private const val SEP = " ¤ "

    /** ژمارەی بابڵ لە هەر گرووپێک */
    private const val BATCH_SIZE = 6

    /** درێژایی نزیکەی پێش قەدەغەکردنی URL */
    private const val MAX_BATCH_CHARS = 1400

    private val cache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 800
    }

    /** دەقی یەک بابڵ → سۆرانی. null = زۆر کورت. هەڵە دەگەڕێنێتەوە ئەگەر ئینتەرنێت نەبوو. */
    fun translateBubble(raw: String, lang: String = "auto"): String? {
        return translateBubbles(listOf(raw), lang).firstOrNull()
    }

    /**
     * وەرگێڕانی چەند بابڵ لە یەک کاتدا (batch).
     * cache پێشتر پشکنراو؛ گرووپەکان بە پارالێل دەنێردرێن.
     * درێژایی لیستەکە = درێژایی [raws]؛ null بۆ ئەو دەقانەی شایەنی وەرگێڕان نین.
     */
    fun translateBubbles(raws: List<String>, lang: String = "auto"): List<String?> {
        if (raws.isEmpty()) return emptyList()
        val sl = SourceLangs.apiCode(lang)

        data class Item(val index: Int, val prepared: String, val cacheKey: String)

        val result = arrayOfNulls<String>(raws.size)
        val need = ArrayList<Item>(raws.size)

        for ((i, raw) in raws.withIndex()) {
            val text = TextPrep.prepare(raw)
            if (text.isBlank() || (text.length < 2 && !TextPrep.hasCjk(text))) {
                result[i] = null
                continue
            }
            val ck = "$sl|$text"
            val hit = synchronized(cache) { cache[ck] }
            if (hit != null) {
                result[i] = hit
            } else {
                need.add(Item(i, text, ck))
            }
        }

        if (need.isEmpty()) return result.toList()

        // گرووپکردن
        val batches = ArrayList<List<Item>>()
        var cur = ArrayList<Item>()
        var curLen = 0
        for (it in need) {
            val add = it.prepared.length + SEP.length
            if (cur.isNotEmpty() && (cur.size >= BATCH_SIZE || curLen + add > MAX_BATCH_CHARS)) {
                batches.add(cur)
                cur = ArrayList()
                curLen = 0
            }
            cur.add(it)
            curLen += add
        }
        if (cur.isNotEmpty()) batches.add(cur)

        val failures = ConcurrentHashMap<Int, IOException>()

        fun runOneBatch(batch: List<Item>) {
            if (batch.size == 1) {
                val it = batch[0]
                try {
                    val got = free(it.prepared, sl)
                    val out = TextPrep.fixSorani(got)
                    if (out.isNotBlank()) {
                        synchronized(cache) { cache[it.cacheKey] = out }
                        result[it.index] = out
                    }
                } catch (e: IOException) {
                    failures[it.index] = e
                    try {
                        val got = free(it.prepared, sl)
                        val out = TextPrep.fixSorani(got)
                        if (out.isNotBlank()) {
                            synchronized(cache) { cache[it.cacheKey] = out }
                            result[it.index] = out
                            failures.remove(it.index)
                        }
                    } catch (e2: IOException) {
                        failures[it.index] = e2
                    }
                }
                return
            }

            val joined = batch.joinToString(SEP) { it.prepared }
            try {
                val got = free(joined, sl)
                val parts = splitBatchResult(got, batch.size)
                if (parts != null && parts.size == batch.size) {
                    for (i in batch.indices) {
                        val out = TextPrep.fixSorani(parts[i])
                        if (out.isNotBlank()) {
                            synchronized(cache) { cache[batch[i].cacheKey] = out }
                            result[batch[i].index] = out
                        }
                    }
                    return
                }
                Log.w(TAG, "batch split failed (${parts?.size}/${batch.size}), fallback singles")
            } catch (e: IOException) {
                Log.w(TAG, "batch failed: ${e.message}, fallback singles")
            }

            for (it in batch) {
                try {
                    val got = free(it.prepared, sl)
                    val out = TextPrep.fixSorani(got)
                    if (out.isNotBlank()) {
                        synchronized(cache) { cache[it.cacheKey] = out }
                        result[it.index] = out
                    }
                } catch (e: IOException) {
                    failures[it.index] = e
                }
            }
        }

        if (batches.size == 1) {
            runOneBatch(batches[0])
        } else {
            val latch = CountDownLatch(batches.size)
            val pool = Executors.newFixedThreadPool(batches.size.coerceAtMost(4))
            try {
                for (batch in batches) {
                    pool.execute {
                        try {
                            runOneBatch(batch)
                        } finally {
                            latch.countDown()
                        }
                    }
                }
                latch.await()
            } finally {
                pool.shutdownNow()
            }
        }

        val anyOk = result.any { it != null }
        if (!anyOk && failures.isNotEmpty()) {
            throw failures.values.first()
        }
        return result.toList()
    }

    private fun splitBatchResult(raw: String, expected: Int): List<String>? {
        val t = raw.trim()
        if (t.isEmpty()) return null

        if (t.contains("¤")) {
            val parts = t.split(Regex("\\s*¤\\s*")).map { it.trim() }
            if (parts.size == expected) return parts
            if (parts.size > expected) return parts.take(expected)
        }

        val lines = t.split(Regex("\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size == expected) return lines

        if (expected == 1) return listOf(t)
        return null
    }

    private fun free(text: String, sl: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        try {
            val res = request(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=ckb&dt=t&q=$q", null
            )
            val parts = JSONArray(res).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val seg = parts.optJSONArray(i) ?: continue
                if (!seg.isNull(0)) sb.append(seg.getString(0))
            }
            if (sb.isNotBlank()) return sb.toString().trim()
        } catch (e: Exception) {
            Log.w(TAG, "gtx failed: ${e.message}")
        }
        try {
            val res = request(
                "https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=$sl&tl=ckb&q=$q", null
            ).trim()
            val out = if (res.startsWith("{")) {
                val ss = JSONObject(res).getJSONArray("sentences")
                val sb = StringBuilder()
                for (i in 0 until ss.length()) sb.append(ss.getJSONObject(i).optString("trans", ""))
                sb.toString().trim()
            } else {
                val first = JSONArray(res).get(0)
                (if (first is JSONArray) first.getString(0) else first.toString()).trim()
            }
            if (out.isNotBlank()) return out
        } catch (e: Exception) {
            Log.w(TAG, "clients5 failed: ${e.message}")
        }
        return try {
            val html = request("https://translate.google.com/m?sl=$sl&tl=ckb&q=$q", null)
            val m = Regex("class=\"result-container\">(.*?)</div>", RegexOption.DOT_MATCHES_ALL).find(html)
                ?: throw IOException("no result")
            android.text.Html.fromHtml(m.groupValues[1], android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
        } catch (e: Exception) {
            throw IOException("Google: ${e.message}")
        }
    }

    private fun request(url: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 4_000
            c.readTimeout = 7_000
            c.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"
            )
            c.setRequestProperty("Accept", "*/*")
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                Log.e(TAG, "HTTP $code: ${text.take(200)}")
                val reason = try {
                    JSONObject(text).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    ""
                }
                throw IOException("HTTP $code ${reason.take(120)}".trim())
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
