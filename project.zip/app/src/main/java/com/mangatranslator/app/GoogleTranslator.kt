package com.mangatranslator.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

/**
 * وەرگێڕانی (ئینگلیزی، عەرەبی، جاپانی، چینی، کۆری، یان خۆکار) → سۆرانی تەنها بە Google Translate.
 *  - ڕێگای بێ کلیل (translate.googleapis.com / clients5 / مۆبایل)
 *  - هەموو بانگەکان دەبێت لە thread ی پاشبنەما بن
 *  - دەرەنجامەکان لە cache دەمێننەوە
 *  - [نوێ] وەرگێڕانی گرووپی (batch): چەند بابڵ لە یەک داواکاریدا → زۆر خێراتر
 */
object GoogleTranslator {

    private const val TAG = "GoogleTranslator"

    /** جیاکەرەوەیەکی دەگمەن کە Google Translate زۆربەی کات دەیهێڵێتەوە */
    private const val SEP = " ¤ "

    /** ژمارەی بابڵ لە هەر گرووپێک */
    private const val BATCH_SIZE = 6

    /** درێژایی نزیکەی پێش قەدەغەکردنی URL */
    private const val MAX_BATCH_CHARS = 1400

    private val cache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 800
    }

    /** دەقی یەک بابڵ → سۆرانی. null = زۆر کورت. هەڵە دەگەڕێنێتەوە ئەگەر ئینتەرنێت نەبوو. */
    fun translateBubble(raw: String, lang: String = "auto"): String? {
        return translateBubbles(listOf(raw), lang).firstOrNull()
    }

    /**
     * وەرگێڕانی چەند بابڵ لە یەک کاتدا (batch).
     * درێژایی لیستەکە = درێژایی [raws]؛ null بۆ ئەو دەقانەی شایەنی وەرگێڕان نین.
     *
     * دڵنیایی لە ڕێکبوون: دەرچوونی باتش تەنها ئەگەر ژمارەی بەشەکان *بە تەواوی* یەکسان بێت (و هیچیان بەتاڵ نەبن)
     * قبوڵ دەکرێت. ئەگەر نا، باتشەکە دەکرێتە دوو نیوە و دووبارە تاقی دەکرێتەوە، هەتا یەک بابڵ؛ بەم شێوەیە
     * وەرگێڕانی بابڵێک هەرگیز ناچێتە ژێر بابڵێکی تر.
     */
    fun translateBubbles(raws: List<String>, lang: String = "auto"): List<String?> {
        if (raws.isEmpty()) return emptyList()
        val sl = SourceLangs.apiCode(lang)

        class Item(val indices: MutableList<Int>, val prepared: String, val cacheKey: String)

        val result = arrayOfNulls<String>(raws.size)
        val byKey = LinkedHashMap<String, Item>()

        for ((i, raw) in raws.withIndex()) {
            val text = TextPrep.prepare(raw)
            if (text.isBlank() || (text.length < 2 && !TextPrep.hasCjk(text))) continue
            val ck = "$sl|$text"
            val hit = synchronized(cache) { cache[ck] }
            if (hit != null) {
                result[i] = hit
            } else {
                // دەقی هاوشێوە (مانگا زۆر "!" و "..." دووبارە دەکاتەوە) تەنها یەکجار دەنێردرێت
                val ex = byKey[ck]
                if (ex != null) ex.indices.add(i) else byKey[ck] = Item(mutableListOf(i), text, ck)
            }
        }

        val need = ArrayList(byKey.values)
        if (need.isEmpty()) return result.toList()

        val batches = ArrayList<List<Item>>()
        var cur = ArrayList<Item>()
        var curLen = 0
        for (it in need) {
            val add = it.prepared.length + SEP.length
            if (cur.isNotEmpty() && (cur.size >= BATCH_SIZE || curLen + add > MAX_BATCH_CHARS)) {
                batches.add(cur)
                cur = ArrayList()
                curLen = 0
            }
            cur.add(it)
            curLen += add
        }
        if (cur.isNotEmpty()) batches.add(cur)

        val failures = ConcurrentHashMap<Int, IOException>()

        fun store(item: Item, out: String) {
            if (out.isBlank()) return
            synchronized(cache) { cache[item.cacheKey] = out }
            for (i in item.indices) result[i] = out
        }

        fun single(item: Item) {
            for (attempt in 0..1) {
                try {
                    store(item, TextPrep.finish(free(item.prepared, sl)))
                    failures.remove(item.indices.first())
                    return
                } catch (e: IOException) {
                    failures[item.indices.first()] = e
                    if (e is java.net.UnknownHostException || e is java.net.ConnectException) return
                }
            }
        }

        fun runBatch(batch: List<Item>) {
            if (batch.size == 1) { single(batch[0]); return }
            try {
                val got = free(batch.joinToString(SEP) { it.prepared }, sl)
                val parts = splitBatchResult(got, batch.size)
                if (parts != null) {
                    for (i in batch.indices) store(batch[i], TextPrep.finish(parts[i]))
                    return
                }
                Log.w(TAG, "batch count mismatch (${batch.size}) → split in halves")
            } catch (e: IOException) {
                Log.w(TAG, "batch failed: ${e.message}")
                // ئینتەرنێت نییە: دووبارەکردنەوە بێسوودە و تەنها کات دەخوات
                if (e.cause is java.net.UnknownHostException || e.cause is java.net.ConnectException ||
                    e.message?.contains("Unable to resolve host") == true
                ) {
                    for (it in batch) failures[it.indices.first()] = e
                    return
                }
            }
            val mid = batch.size / 2
            runBatch(batch.subList(0, mid))
            runBatch(batch.subList(mid, batch.size))
        }

        if (batches.size == 1) {
            runBatch(batches[0])
        } else {
            val latch = CountDownLatch(batches.size)
            val pool = Executors.newFixedThreadPool(batches.size.coerceAtMost(4))
            try {
                for (batch in batches) {
                    pool.execute {
                        try {
                            runBatch(batch)
                        } finally {
                            latch.countDown()
                        }
                    }
                }
                latch.await()
            } finally {
                pool.shutdownNow()
            }
        }

        val anyOk = result.any { it != null }
        if (!anyOk && failures.isNotEmpty()) {
            throw failures.values.first()
        }
        return result.toList()
    }

    /** تەنها کاتێک بەشەکان دەگەڕێنێتەوە کە ژمارەیان بە تەواوی یەکسان بێت و هیچیان بەتاڵ نەبێت. ڕێکبوونی ناڕوون = null. */
    internal fun splitBatchResult(raw: String, expected: Int): List<String>? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        if (expected == 1) return listOf(t)
        val parts = t.split(Regex("\\s*¤\\s*")).map { it.trim() }
        return if (parts.size == expected && parts.none { it.isEmpty() }) parts else null
    }

    private fun free(text: String, sl: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        try {
            val res = request(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=ckb&dt=t&q=$q", null
            )
            val parts = JSONArray(res).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val seg = parts.optJSONArray(i) ?: continue
                if (!seg.isNull(0)) sb.append(seg.getString(0))
            }
            if (sb.isNotBlank()) return sb.toString().trim()
        } catch (e: Exception) {
            Log.w(TAG, "gtx failed: ${e.message}")
        }
        try {
            val res = request(
                "https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=$sl&tl=ckb&q=$q", null
            ).trim()
            val out = if (res.startsWith("{")) {
                val ss = JSONObject(res).getJSONArray("sentences")
                val sb = StringBuilder()
                for (i in 0 until ss.length()) sb.append(ss.getJSONObject(i).optString("trans", ""))
                sb.toString().trim()
            } else {
                val first = JSONArray(res).get(0)
                (if (first is JSONArray) first.getString(0) else first.toString()).trim()
            }
            if (out.isNotBlank()) return out
        } catch (e: Exception) {
            Log.w(TAG, "clients5 failed: ${e.message}")
        }
        return try {
            val html = request("https://translate.google.com/m?sl=$sl&tl=ckb&q=$q", null)
            val m = Regex("class=\"result-container\">(.*?)</div>", RegexOption.DOT_MATCHES_ALL).find(html)
                ?: throw IOException("no result")
            android.text.Html.fromHtml(m.groupValues[1], android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
        } catch (e: Exception) {
            throw IOException("Google: ${e.message}")
        }
    }

    private fun request(url: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 4_000
            c.readTimeout = 7_000
            c.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"
            )
            c.setRequestProperty("Accept", "*/*")
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                Log.e(TAG, "HTTP $code: ${text.take(200)}")
                val reason = try {
                    JSONObject(text).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    ""
                }
                throw IOException("HTTP $code ${reason.take(120)}".trim())
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
