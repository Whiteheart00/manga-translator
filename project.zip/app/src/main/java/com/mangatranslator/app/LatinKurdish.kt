package com.mangatranslator.app

import android.content.Context
import android.util.Log

/**
 * کوردیی نووسراو بە پیتی لاتینی (وەک چاتی فەیسبووک: "aw mawzw3a kwa 😂 xark esta ferbwwa...")
 * دەگۆڕێت بۆ کوردیی سۆرانی بە پیتی کوردی، پێش ئەوەی بنێردرێت بۆ tts.pawan.krd.
 *
 *  - ئەگەر Gemini چالاک بوو (کلیل هەیە)، وشە بە وشە بە مانا دەگۆڕدرێت («aw» = ئەو، نەک ئاو لە پیتەکانەوە).
 *  - ئەگەر Gemini نەبوو یان شکستی هێنا، ڕێسای سادەی ناوخۆیی بەکار دێت (نزیکە، نەک تەواو ڕاست).
 *  - ژمارەکان وەک پیت: 3 = ع، 7 = ح، 5 = خ، 2 = ئ.
 *  - دەکرێت لە ڕێکخستنەکان بکوژێندرێتەوە (TranslatorSettings.latinKurdish).
 */
object LatinKurdish {
    private const val TAG = "LatinKurdish"

    private val ENGLISH = setOf(
        "the", "and", "is", "are", "you", "to", "of", "in", "it", "that", "this", "for", "with", "was", "have",
        "not", "but", "my", "me", "your", "we", "they", "he", "she", "what", "how", "so", "do", "can", "will"
    )

    /** وشە باوەکانی کوردیی لاتینی؛ ئەگەر هەبوون، دەزانین ئینگلیزی نییە. */
    private val KU_HINTS = setOf(
        "aw", "ba", "la", "ke", "bo", "da", "ez", "nye", "nia", "xo", "esta", "chon", "chi", "kwa", "kwe", "ama",
        "ewa", "ema", "ewan", "min", "tu", "em", "wa", "ya", "le", "lew", "pe", "bas", "baw", "zor", "kam",
        "hamw", "hama", "xosh", "xwsh", "dakat", "dakre", "dakam", "dabe", "nabe", "bash", "xrap", "rast", "drw",
        "brat", "bram", "xoshm", "spas", "slaw", "ba", "hich", "hamu", "chawa", "chonet", "tkaya", "shtek", "shtana"
    )

    /** ووشە باوەکان: وشەی تەواو، ئەگەر لە لیستەکەدا بوو. */
    private val DICT = mapOf(
        "aw" to "ئەو", "ba" to "بە", "la" to "لە", "ke" to "کە", "bo" to "بۆ", "da" to "دا", "ez" to "ئەز",
        "nye" to "نییە", "nia" to "نییە", "xo" to "خۆ", "esta" to "ئێستا", "chon" to "چۆن", "chi" to "چی",
        "kwa" to "کوا", "ama" to "ئەمە", "ewa" to "ئەوە", "ema" to "ئەمە", "ewan" to "ئەوان", "min" to "من",
        "tu" to "تۆ", "em" to "ئەم", "wa" to "وا", "ya" to "یا", "le" to "لێ", "pe" to "پێ", "bas" to "باس",
        "zor" to "زۆر", "kam" to "کەم", "xosh" to "خۆش", "bash" to "باش", "xrap" to "خراپ", "rast" to "ڕاست",
        "brat" to "برات", "bram" to "برام", "spas" to "سوپاس", "slaw" to "سڵاو", "hich" to "هیچ", "hamu" to "هەموو",
        "chawa" to "چاوا", "shtek" to "شتێک", "shtana" to "شتانە", "ferbwwa" to "فێربووە", "bamash" to "بەمەش",
        "bren" to "بڕێن", "dakre" to "دەکرێ", "dakat" to "دەکات", "dakam" to "دەکەم", "dabe" to "دەبێ",
        "nabe" to "نابێ", "w" to "و", "u" to "و", "y" to "ی"
    )

    /** ئایا ئەم دەقە کوردیی لاتینییە و پێویستە بگۆڕدرێت؟ */
    fun needsConversion(settings: TranslatorSettings, text: String): Boolean {
        if (!settings.latinKurdish) return false
        var letters = 0
        var latin = 0
        for (ch in text) {
            if (!ch.isLetter()) continue
            letters++
            if (ch in 'a'..'z' || ch in 'A'..'Z') latin++
        }
        if (letters < 3 || latin * 100 < letters * 70) return false
        val words = text.lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return false
        if (words.any { it in KU_HINTS || (it.length > 2 && it.any { c -> c == '3' || c == '7' }) }) return true
        val eng = words.count { it in ENGLISH }
        return !(words.size >= 4 && eng * 100 >= words.size * 25)
    }

    /** ئیمۆجی و هێما لادەبات، چونکە ماڵپەڕەکە نایخوێنێتەوە. */
    fun clean(text: String): String {
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            val n = Character.charCount(cp)
            val isEmoji = cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF || cp in 0xFE00..0xFE0F || cp == 0x200D || cp in 0x2B00..0x2BFF
            if (!isEmoji) sb.appendCodePoint(cp)
            i += n
        }
        return sb.toString().replace(Regex("[ \\t]+"), " ").trim()
    }

    /** دەقی ئامادە بۆ خوێندنەوە. بلۆک دەکات (thread ی پاشبنەما بانگ بکرێت ئەگەر needsConversion = true). */
    fun convert(ctx: Context, settings: TranslatorSettings, text: String): String {
        val src = clean(text)
        if (!needsConversion(settings, src)) return src
        if (settings.geminiTtsKey.isNotBlank()) {
            try {
                ai(src, settings.geminiTtsKey)?.let { return it }
            } catch (t: Throwable) {
                Log.w(TAG, "gemini convert failed: ${t.message}")
            }
        }
        return rough(src)
    }

    private const val PROMPT =
        "You convert Central Kurdish (Sorani) written in Latin letters (chat spelling, Arabizi style) into proper Sorani Kurdish in Arabic script, " +
            "so that a text-to-speech engine reads it correctly. Read each whole sentence and choose the right Sorani word by meaning and context, " +
            "not letter by letter (for example 'aw' = ئەو, 'esta' = ئێستا, 'ba' = بە, 'la' = لە). " +
            "Digits used as letters: 3 = ع, 7 = ح, 5 = خ, 2 = ئ. Common chat letters: x = خ, q = ق, w = و or وو, y = ی, sh = ش, ch = چ, zh/j = ژ, gh = غ, v = ڤ, " +
            "e can be ە or ێ, a can be ا or ە, i = ی, u = و. Use the correct Sorani letters (ی ک ە ێ ۆ ڵ ڕ). " +
            "Remove emojis. Keep numbers, punctuation and English words/brand names as they are. " +
            "If the text is already in Arabic script, or is entirely English, return it unchanged. " +
            "Do NOT translate, summarize or add anything. Return ONLY the converted text on one line.\n\nText:\n"

    private fun ai(src: String, keysRaw: String): String? {
        val out = GeminiKeys.withKeys(keysRaw) { key ->
            GeminiModels.call(true) { m, think ->
                KurdishTextFix.post(KurdishTextFix.body(src, m, think, PROMPT, 1024), key, m, 4_000, 9_000)
            }
        }.trim().trim('"', '`').replace(Regex("\\s+"), " ").trim()
        if (out.isEmpty()) return null
        if (out.equals(src, ignoreCase = true)) return src      // ئینگلیزی بوو، وەک خۆی
        var letters = 0
        var arabic = 0
        for (c in out) {
            if (!c.isLetter()) continue
            letters++
            if (c.code in 0x0600..0x06FF) arabic++
        }
        if (letters == 0 || arabic * 100 < letters * 50) return null
        val ratio = out.length.toFloat() / src.length
        if (ratio < 0.3f || ratio > 2.5f) return null
        return out
    }

    // ---------- ڕێسای ناوخۆیی (نزیکە) ----------

    private val DIGRAPH = mapOf(
        "sh" to "ش", "ch" to "چ", "kh" to "خ", "gh" to "غ", "zh" to "ژ", "ee" to "ێ", "oo" to "وو", "ww" to "وو",
        "ll" to "ڵ", "rr" to "ڕ", "aa" to "ا"
    )
    private val SINGLE = mapOf(
        'b' to "ب", 'c' to "چ", 'd' to "د", 'f' to "ف", 'g' to "گ", 'h' to "ه", 'j' to "ژ", 'k' to "ک",
        'l' to "ل", 'm' to "م", 'n' to "ن", 'p' to "پ", 'q' to "ق", 'r' to "ر", 's' to "س", 't' to "ت",
        'v' to "ڤ", 'w' to "و", 'x' to "خ", 'y' to "ی", 'z' to "ز", 'i' to "ی", 'u' to "و", 'o' to "ۆ",
        'e' to "ێ", '3' to "ع", '7' to "ح", '5' to "خ", '2' to "ئ"
    )

    private fun roughWord(w: String): String {
        val lw = w.lowercase()
        DICT[lw]?.let { return it }
        val sb = StringBuilder()
        var i = 0
        while (i < lw.length) {
            val two = if (i + 1 < lw.length) lw.substring(i, i + 2) else ""
            val d = DIGRAPH[two]
            if (d != null) { sb.append(d); i += 2; continue }
            val c = lw[i]
            val last = i == lw.length - 1
            if (c == 'a') {
                sb.append(if (i == 0) "ئا" else if (last) "ە" else "ا")
            } else if (i == 0 && (c == 'e' || c == 'i' || c == 'o')) {
                sb.append(if (c == 'e') "ئێ" else if (c == 'i') "ئی" else "ئۆ")
            } else {
                sb.append(SINGLE[c] ?: c.toString())
            }
            i++
        }
        return sb.toString()
    }

    /** گۆڕینی نزیک بەبێ ئینتەرنێت/Gemini. هەر وشەیەکی لاتینی دەگۆڕێت، ئەوانی تر وەک خۆیان. */
    fun rough(text: String): String {
        val sb = StringBuilder()
        val tok = Regex("[A-Za-z0-9]+|[^A-Za-z0-9]+")
        for (m in tok.findAll(text)) {
            val t = m.value
            sb.append(if (t[0].isLetterOrDigit() && t.any { it in 'a'..'z' || it in 'A'..'Z' }) roughWord(t) else t)
        }
        return sb.toString()
    }
}
