package com.mangatranslator.app

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean

/**
 * دابەزاندنی پێداویستییەکان (OCR، دەنگی کوردی، نووسینی ئۆفلاین) لە پاشبنەما تا تەواو دەبن.
 * - ئەگەر بەکارهێنەر لە شاشەی دابەزاندن «دواتر»ی داگرت، هەر کاتێک ئەپەکە دەکرێتەوە دابەزاندن بەردەوام دەبێت.
 * - ئەگەر ئینتەرنێت پچڕا، هەر ١٥ چرکە دووبارە هەوڵ دەدات (نووسینی ئۆفلاین لەو شوێنەوە بەردەوام دەبێت کە وەستابوو).
 */
object Downloads {
    @Volatile private var voicePct = -1
    @Volatile private var sttDone = 0L
    @Volatile private var sttTotal = 0L
    private val running = AtomicBoolean(false)

    fun allReady(ctx: Context): Boolean =
        LocalKurdishOcr.isInstalled(ctx) && TessOcr.allInstalled(ctx) && PiperTts.isInstalled(ctx) && VekolStt.isReady(ctx)

    /** null = هەموو شتێک ئامادەیە؛ ئەگەرنا ڕێژەی پێشکەوتن (0..100). */
    fun percent(ctx: Context): Int? {
        if (allReady(ctx)) return null
        var done = 0f
        if (LocalKurdishOcr.isInstalled(ctx)) done += 4f
        if (TessOcr.allInstalled(ctx)) done += 4f
        if (PiperTts.isInstalled(ctx)) done += 60f
        else if (voicePct > 0) done += 60f * voicePct / 100f
        if (VekolStt.isReady(ctx)) done += 291f
        else if (sttTotal > 0) done += 291f * (sttDone.toFloat() / sttTotal).coerceIn(0f, 1f)
        return (done / 359f * 100f).toInt().coerceIn(0, 99)
    }

    fun ensureAll(ctx: Context) {
        val app = ctx.applicationContext
        if (allReady(app)) return
        if (!running.compareAndSet(false, true)) return
        Thread {
            var tries = 0
            try {
                while (!allReady(app) && tries < 40) {
                    var failed = false
                    if (!LocalKurdishOcr.isInstalled(app)) {
                        try { if (LocalKurdishOcr.download(app) != null) failed = true } catch (_: Throwable) { failed = true }
                    }
                    for (l in TessOcr.FIRST_RUN) {
                        if (!TessOcr.isInstalled(app, l)) {
                            try { if (TessOcr.download(app, l) != null) failed = true } catch (_: Throwable) { failed = true }
                        }
                    }
                    if (!PiperTts.isInstalled(app)) {
                        voicePct = 0
                        try {
                            if (PiperTts.download(app) { p -> voicePct = p } != null) failed = true
                        } catch (_: Throwable) { failed = true }
                        voicePct = -1
                    }
                    if (!VekolStt.isReady(app)) {
                        try {
                            VekolStt.download(app) { d, t, _ -> sttDone = d; sttTotal = t }
                        } catch (_: Throwable) { failed = true }
                    }
                    if (failed) {
                        tries++
                        try { Thread.sleep(15000) } catch (_: InterruptedException) { break }
                    }
                }
            } finally {
                running.set(false)
            }
        }.apply { isDaemon = true }.start()
    }
}
