package com.mangatranslator.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

/**
 * خوێندنەوەی کوردی لە ڕێگەی tts.pawan.krd: WebViewـێکی شاراوە، دەق دەخاتە ناو چوارگۆشەکە و دوگمەی خوێندنەوە دادەگرێت.
 * کاربەر یەک جار لە PawanLoginActivity دەچێتە ژوورەوە و cookieـەکان لە CookieManager دەمێننەوە.
 * هەموو فەرمانەکان لە main thread بانگ بکرێن.
 */
object PawanTts {
    const val URL = "https://tts.pawan.krd/"
    private val ui = Handler(Looper.getMainLooper())

    private var web: WebView? = null
    private var pageReady = false
    private var queued: (() -> Unit)? = null
    private var onState: ((Boolean) -> Unit)? = null
    private var onError: ((String) -> Unit)? = null
    private var gen = 0
    private var timeout: Runnable? = null

    fun hasCookie(): Boolean = !CookieManager.getInstance().getCookie(URL).isNullOrBlank()

    /** تەنها بۆ ئەوەی کاتی بەکارهێنانی یەکەم لەپێشەوە بار بکرێت. */
    fun warmUp(ctx: Context) { ensureWeb(ctx.applicationContext) }

    private class Bridge {
        @JavascriptInterface fun started() = ui.post { onState?.invoke(true) }
        @JavascriptInterface fun ended() = ui.post { finish() }
        @JavascriptInterface fun failed(m: String) = ui.post { fail(m) }
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun ensureWeb(app: Context): WebView {
        web?.let { return it }
        val w = WebView(app)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        CookieManager.getInstance().setAcceptCookie(true)
        w.addJavascriptInterface(Bridge(), "AndroidTts")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) {
                // هەموو دەنگێک کە ماڵپەڕەکە دەیپەخشێنێت بزانین کەی دەست پێدەکات و کەی تەواو دەبێت
                v.evaluateJavascript(HOOK_JS, null)
                pageReady = true
                queued?.also { queued = null }?.invoke()
            }
        }
        w.loadUrl(URL)
        web = w
        return w
    }

    fun speak(ctx: Context, text: String, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (!hasCookie()) {
            onError("سەرەتا لە ڕێکخستنی دەنگ دوگمەی «چوونەژوورەوە بۆ Pawan TTS» بگرە و بچۆ ژوورەوە.")
            return
        }
        this.onState = onState
        this.onError = onError
        val my = ++gen
        val w = ensureWeb(ctx.applicationContext)
        val run = {
            if (gen == my) {
                onState(true)
                w.evaluateJavascript(
                    "window.__pawanSpeak(${JSONObject.quote(t)})", null
                )
                timeout?.let { ui.removeCallbacks(it) }
                timeout = Runnable { if (gen == my) fail("کاتی خوێندنەوە تەواو بوو") }
                ui.postDelayed(timeout!!, 90_000)
            }
        }
        if (pageReady) run() else queued = run
    }

    fun stop() {
        gen++
        queued = null
        timeout?.let { ui.removeCallbacks(it) }
        web?.evaluateJavascript(
            "document.querySelectorAll('audio').forEach(function(a){try{a.pause()}catch(e){}})", null
        )
        onState?.invoke(false)
        onState = null
    }

    private fun finish() {
        timeout?.let { ui.removeCallbacks(it) }
        onState?.invoke(false)
        onState = null
    }

    private fun fail(m: String) {
        timeout?.let { ui.removeCallbacks(it) }
        onState?.invoke(false)
        onState = null
        onError?.invoke(m)
    }

    private const val HOOK_JS = """
(function(){
  if (window.__pawanHooked) return; window.__pawanHooked = true;
  var P = HTMLMediaElement.prototype, origPlay = P.play;
  P.play = function(){
    var a = this;
    if (!a.__h) { a.__h = 1;
      a.addEventListener('ended', function(){ AndroidTts.ended(); });
      a.addEventListener('error', function(){ AndroidTts.failed('دەنگەکە پەخش نەکرا'); });
    }
    AndroidTts.started();
    return origPlay.apply(this, arguments);
  };
  window.__pawanSpeak = function(text){
    document.querySelectorAll('audio').forEach(function(a){ try{ a.pause(); }catch(e){} });
    var t = document.getElementById('text'), b = document.getElementById('speak');
    if (!t || !b) { AndroidTts.failed('پەڕەکە ئامادە نییە، دووبارە هەوڵبدەوە یان بچۆ ژوورەوە'); return; }
    var setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    setter.call(t, text);
    t.dispatchEvent(new Event('input', {bubbles:true}));
    setTimeout(function(){ b.click(); }, 150);
  };
})();
"""
}
