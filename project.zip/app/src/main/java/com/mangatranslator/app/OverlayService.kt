package com.mangatranslator.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast

/**
 * خزمەتگوزاری پێشەوە (foreground service) کە:
 *  - بابلی شەمەندەفەر پیشان دەدات
 *  - بە دەستلێدانی بابلەکە "Continuous Mode" چالاک/ناچالاک دەکات
 *  - لە Continuous Mode: شاشە دەگرێت، گۆڕانی پەڕە دەدۆزێتەوە، OCR دەکات و ئۆڤەرلەی نیشان دەدات
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var overlay: OverlayView? = null
    private var capturer: ScreenCapturer? = null
    private var watcher: PageWatcher? = null
    private val ocr: OcrEngine by lazy { OcrEngine() }
    private var continuousMode = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // دەبێت پێش وەرگرتنی MediaProjection، startForeground بە جۆری mediaProjection بانگ بکرێت
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (capturer == null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection: MediaProjection = mpm.getMediaProjection(resultCode, data)
            capturer = ScreenCapturer(
                context = this,
                projection = projection,
                onFirstFrame = {
                    mainHandler.post { toast("شاشە دەگیرێت ✓") }
                },
                onProjectionStopped = {
                    mainHandler.post { stopSelf() }
                }
            )
        }

        if (bubble == null) showBubble()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopContinuousMode()
        removeBubble()
        capturer?.release()
        capturer = null
        ocr.close()
        super.onDestroy()
    }

    // ---------- Continuous Mode ----------

    private fun toggleContinuousMode() {
        continuousMode = !continuousMode
        if (continuousMode) {
            startContinuousMode()
            bubble?.background = circle(COLOR_ON)
            toast("Continuous Mode: چالاکە")
        } else {
            stopContinuousMode()
            bubble?.background = circle(COLOR_OFF)
            toast("Continuous Mode: ناچالاکە")
        }
    }

    private fun startContinuousMode() {
        addOverlay()

        val w = PageWatcher(
            ocr = ocr,
            onClear = { mainHandler.post { overlay?.clear() } },
            onBoxes = { boxes, fw, fh -> overlay?.setBoxes(boxes, fw, fh) }
        )
        watcher = w

        capturer?.frameListener = { bmp ->
            val current = watcher
            if (current != null) current.onFrame(bmp) else bmp.recycle()
        }
        capturer?.start()
    }

    private fun stopContinuousMode() {
        capturer?.stop()
        capturer?.frameListener = null
        watcher?.reset()
        watcher = null
        removeOverlay()
    }

    // ---------- ئۆڤەرلەی تەواوی شاشە ----------

    private fun addOverlay() {
        if (overlay != null) return

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val view = OverlayView(this)
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        windowManager.addView(view, params)
        overlay = view
        bringBubbleToFront()
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    // ---------- بابلی شەمەندەفەر ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        val size = dp(56)

        val view = TextView(this).apply {
            text = "ک"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = circle(COLOR_OFF)
            alpha = 0.9f
        }

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(220)
        }

        // کێشان (drag) و دەستلێدان (tap)
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        val slop = dp(8)

        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        windowManager.updateViewLayout(v, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleContinuousMode()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, params)
        bubble = view
        bubbleParams = params
    }

    /** بابلەکە دووبارە زیاد دەکرێت بۆ ئەوەی لەسەروو ئۆڤەرلەیەکەوە بێت. */
    private fun bringBubbleToFront() {
        val b = bubble ?: return
        val p = bubbleParams ?: return
        try {
            windowManager.removeView(b)
            windowManager.addView(b, p)
        } catch (_: Exception) {
        }
    }

    private fun removeBubble() {
        bubble?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubble = null
        bubbleParams = null
    }

    // ---------- ئاگادارکردنەوە ----------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "مانگا وەرگێڕ",
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("مانگا وەرگێڕ کار دەکات")
            .setContentText("بابلەکە دابگرە بۆ چالاککردنی وەرگێڕانی بەردەوام")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null, "وەستاندن", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    // ---------- یارمەتیدەرەکان ----------

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(dp(2), Color.WHITE)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        const val ACTION_START = "com.mangatranslator.app.START"
        const val ACTION_STOP = "com.mangatranslator.app.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"

        private const val CHANNEL_ID = "manga_translator"
        private const val NOTIF_ID = 42
        private val COLOR_OFF = Color.parseColor("#78909C")
        private val COLOR_ON = Color.parseColor("#2E7D32")
    }
}
