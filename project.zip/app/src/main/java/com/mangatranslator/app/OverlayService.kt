package com.mangatranslator.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.widget.LinearLayout
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

/**
 * خزمەتگوزاری پێشەوە (foreground service) کە:
 *  - دوو بابلی شەمەندەفەر پیشان دەدات:
 *      ک  = وەرگێڕانی خۆکار (Continuous Mode) چالاک/ناچالاک
 *      وەر = وەرگێڕانی شاشەی ئێستا بە دەستی (درێژ بگرە = شاردنەوەی وەرگێڕان)
 *  - شاشە دەگرێت، OCR دەکات، بە Google دەیکات بە سۆرانی و لەسەر بابلەکان نیشانی دەدات
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    /** TYPE_APPLICATION_OVERLAY (پێویستی بە ڕێگەپێدانی پیشاندان) یان TYPE_ACCESSIBILITY_OVERLAY (بێ ڕێگەپێدان، کاتێک Accessibility چالاکە) */
    private var overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var transBubble: View? = null
    private var transBubbleParams: WindowManager.LayoutParams? = null
    private var speakBubble: View? = null
    private var speakBubbleParams: WindowManager.LayoutParams? = null
    private var regionBubble: View? = null
    private var liveBubble: View? = null
    private var live: LiveSubtitle? = null
    private val liveControl = LivePlaybackControl<LiveSubtitle.Selection>()
    private var regionBubbleParams: WindowManager.LayoutParams? = null
    private var selector: RegionSelectView? = null
    private var langPickerView: View? = null
    private var micBubble: View? = null
    private var micBubbleParams: WindowManager.LayoutParams? = null
    private var resultCard: LinearLayout? = null
    private val dictation = Dictation()
    @Volatile
    private var dictating = false
    private var overlay: OverlayView? = null
    private var capturer: FrameSource? = null
    private var watcher: PageWatcher? = null

    private val ocr: OcrEngine by lazy {
        OcrEngine(applicationContext, { settings.sourceLang }) { msg -> mainHandler.post { toast(msg) } }.also {
            it.geminiKey = { settings.textGeminiKey() }
            it.geminiFast = { settings.fast }
            it.skipLocalOcr = { settings.skipLocalOcr() }
        }
    }
    private val settings: TranslatorSettings by lazy { TranslatorSettings(this) }
    private val tts: SoraniTts by lazy { SoraniTts(this, settings) { PiperTts.takePrepared(applicationContext) } }
    /** چەند بابل پێکەوە وەردەگێڕدرێن */
    private val net = Executors.newFixedThreadPool(6)
    /** هەمان ٦ threadی `net` وەک dispatcherی کۆروتین: بێ threadی نوێ و بێ دواکەوتن */
    private val netD = net.asCoroutineDispatcher()
    /** کارە درێژەکانی وەرگێڕان. Main.immediate: بەشی پێش یەکەم داواکاری تۆڕ هەمان کات (بێ post) دەڕوات. */
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val regionPool = Executors.newCachedThreadPool { r -> Thread(r, "region-task").apply { isDaemon = true } }

    @Volatile
    private var continuousMode = false
    /** هەر وەرگێڕانێکی دەستی ژمارەیەکی نوێ وەردەگرێت؛ کارە کۆنەکان خۆیان دەوەستێنن */
    @Volatile
    private var manualRun = 0

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------- داوای چوونەژوورەوە کاتێک کوکی Pawan بەسەرچوو ----------

    private var loginPrompt: View? = null
    private var lastLoginSpeak = 0L

    /** دوگمەیەک لەسەر شاشە دەردەخات و بە دەنگی ئۆفلاین داوا لە بەکارهێنەر دەکات بچێتە ژوورەوە. main thread. */
    private fun showLoginPrompt() {
        mainHandler.post {
            if (loginPrompt == null) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(18), dp(12), dp(12), dp(12))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(28).toFloat()
                        setColor(0xF27C3AED.toInt())
                    }
                }
                val label = TextView(this).apply {
                    text = "🔑 چوونەژوورەوە بۆ Pawan"
                    setTextColor(Color.WHITE)
                    textSize = 15f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setOnClickListener { openPawanLogin() }
                }
                val close = TextView(this).apply {
                    text = "✕"
                    setTextColor(0xCCFFFFFF.toInt())
                    textSize = 16f
                    setPadding(dp(16), 0, dp(6), 0)
                    setOnClickListener { removeLoginPrompt(); stopTts() }
                }
                row.addView(label, LinearLayout.LayoutParams(-2, -2))
                row.addView(close, LinearLayout.LayoutParams(-2, -2))
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    y = dp(96)
                }
                try {
                    windowManager.addView(row, lp)
                    loginPrompt = row
                } catch (_: Exception) {
                    toast("کۆکی Pawan بەسەرچووە؛ لە ڕێکخستنی دەنگ بچۆ ژوورەوە")
                }
            }
            // هەر ٢٠ چرکە جارێک زیاتر دووبارە ناکرێتەوە
            val now = SystemClock.elapsedRealtime()
            if (now - lastLoginSpeak > 20_000L) {
                lastLoginSpeak = now
                try { tts.speakNotice(LOGIN_SPOKEN) } catch (_: Throwable) {}
            }
        }
    }

    private fun openPawanLogin() {
        stopTts()
        try {
            startActivity(Intent(this, PawanLoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (t: Throwable) {
            Log.e(TAG, "login activity failed", t)
            toast("نەتوانرا پەڕەی چوونەژوورەوە بکرێتەوە؛ لە ڕێکخستنی دەنگ بیکەرەوە")
        }
    }

    private fun removeLoginPrompt() {
        loginPrompt?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        loginPrompt = null
    }

    /** سیستەم ڕامی کەمە: مۆدێلە قورسەکان ئازاد دەکەین (دواتر خۆکارانە دووبارە بار دەبنەوە) */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level < android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level == android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) return
        PiperTts.clearPrepared()
        if (dictating) return
        Thread {
            if (live != null) return@Thread   // ژێرنووسی زیندوو چالاکە: هیچ مۆدێلێک (دەنگ/OCR) ئازاد نەکرێت تا بەکارهێنەر دەیوەستێنێت
            try { TessOcr.release() } catch (_: Throwable) {}
            try { ocr.trimModels() } catch (_: Throwable) {}
            if (!tts.speaking) {
                try { VekolStt.release() } catch (_: Throwable) {}
                try { tts.releaseModels() } catch (_: Throwable) {}
            }
        }.start()
    }

    /** خزمەتگوزاریی Accessibility ـی ئەو کاتەی پەنجەرەکانی پێ کراونەتەوە */
    private var a11yOwner: MangaAccessibilityService? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        DeviceProfile.init(this)
        GeminiModels.init(this)
        PawanTts.onNeedLogin = { showLoginPrompt() }
        PawanTts.onLoginDone = {
            mainHandler.post {
                if (PawanTts.hasCookie() && loginPrompt != null) toast("چوونەژوورەوە تەواو بوو ✓")
                if (PawanTts.hasCookie()) removeLoginPrompt()
            }
        }
        GlassStyle.load(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        Thread { try { tts.warmUp() } catch (_: Throwable) {} }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // دەبێت پێش وەرگرتنی MediaProjection، startForeground بە جۆری mediaProjection بانگ بکرێت
        val notification = buildNotification()
        // دۆخی Accessibility: بێ MediaProjection (Android 11+ و خزمەتگوزارییەکە چالاک بێت)
        val useA11y = intent?.getBooleanExtra(EXTRA_USE_A11Y, false) == true &&
            MangaAccessibilityService.supported() && MangaAccessibilityService.isEnabled(this)
        if (useA11y) {
            // پەنجەرەکان لە ڕێگەی خزمەتگوزاریی Accessibility دەکرێنەوە؛ ڕێگەپێدانی پیشاندان پێویست نییە
            val acc = MangaAccessibilityService.instance
            if (acc != null && (bubble == null || a11yOwner !== acc)) {
                // ئەگەر Accessibility وەستێنرا و دووبارە چالاک کرایەوە، بابلە کۆنەکان مردوون؛ پاکیان دەکەینەوە و نوێ دەیانکەینەوە
                if (bubble != null) removeBubbles()
                (acc.getSystemService(Context.WINDOW_SERVICE) as? WindowManager)?.let {
                    windowManager = it
                    overlayType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    a11yOwner = acc
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            // Android 14: بێ MediaProjection جۆری mediaProjection ڕێگەپێدراو نییە، بۆیە specialUse
            var type = if (useA11y && Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            // دۆخی نوێ مایک پێویستە (قسەکردن بۆ نووسین)
            if (Build.VERSION.SDK_INT >= 30 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            ) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            fgsType = type
            startForeground(NOTIF_ID, notification, type)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (!useA11y && (data == null || resultCode == 0)) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (capturer == null && useA11y && Build.VERSION.SDK_INT >= 30) {
            capturer = AccessibilityCapturer(
                context = this,
                onFirstFrame = { mainHandler.post { toast("شاشە دەگیرێت ✓ (Accessibility)") } },
                onUnavailable = {
                    mainHandler.post { toast("Accessibility ناچالاک بوو؛ ئەپەکە دەوەستێت"); stopSelf() }
                }
            )
        } else if (capturer == null && data != null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection: MediaProjection = mpm.getMediaProjection(resultCode, data)
            capturer = ScreenCapturer(
                context = this,
                projection = projection,
                onFirstFrame = {
                    mainHandler.post { toast("شاشە دەگیرێت ✓") }
                },
                onProjectionStopped = {
                    mainHandler.post { stopSelf() }
                }
            )
        }

        capturer?.start()
        if (bubble == null && regionBubble == null) showBubbles()
        mainHandler.removeCallbacks(uiTick)
        mainHandler.post(uiTick)
        touchModels()
        return START_NOT_STICKY
    }

    /** شاشە سوڕایەوە (فوڵسکرین): ئۆڤەرلەی وەرگێڕان دەبێت بە قەبارەی شاشەی نوێ بێت، دەنا لە لاندسکەیپدا بە قەبارەی پۆرترەیتە */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        mainHandler.post { resizeOverlayToScreen() }
    }

    private fun resizeOverlayToScreen() {
        val v = overlay ?: return
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(m)
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        if (lp.width == m.widthPixels && lp.height == m.heightPixels) return
        lp.width = m.widthPixels
        lp.height = m.heightPixels
        try { windowManager.updateViewLayout(v, lp) } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        stopLive()
        removeLangPicker()
        if (instance === this) instance = null
        mainHandler.removeCallbacks(uiTick)
        mainHandler.removeCallbacks(idleModelRelease)
        scope.cancel()
        PawanTts.onNeedLogin = null
        PawanTts.onLoginDone = null
        removeLoginPrompt()
        removeCancel()
        scrollWatcher = null
        continuousMode = false
        stopContinuousMode()
        removeSelector()
        removeResultCard()
        dictation.cancel()
        removeBubbles()
        capturer?.release()
        capturer = null
        net.shutdownNow()
        Thread { VekolStt.release() }.start()   // مۆدێلی ئۆفلاین لە ڕام دەردەهێنێت
        tts.shutdown()
        try {
            ocr.close()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    // ---------- Continuous Mode ----------

    private fun toggleContinuousMode() {
        if (live != null) stopLive()
        manualRun++
        stopScrollWatch()
        if (!continuousMode) {
            // پێش دەستپێکردن بپرسە: زمانی دەقی وێنەکە کامەیە؟
            askSourceLang { enableContinuousMode() }
        } else {
            continuousMode = false
            stopContinuousMode()
            (dockMain as? GeminiStarView)?.auto = false
            bubble?.background = circle(COLOR_OFF)
            updateCommandUi()
            toast("وەرگێڕانی خۆکار: ناچالاکە")
        }
    }

    private fun enableContinuousMode() {
        continuousMode = true
        startContinuousMode()
        (dockMain as? GeminiStarView)?.auto = true
        if (dockState == DockState.EXPANDED) applyDockState(DockState.COLLAPSED)
        scheduleDock()
        updateCommandUi()
        bubble?.background = circle(COLOR_ON)
        val langLabel = SourceLangs.labels[SourceLangs.codes.indexOf(settings.sourceLang).coerceAtLeast(0)]
            .substringBefore("(").trim()
        toast("وەرگێڕانی خۆکار: چالاکە — $langLabel")
        beginBusy("auto", "وەرگێڕانی خۆکار چالاکە")
        mainHandler.postDelayed({ if (continuousMode) endBusy() }, 2500)
    }

    private fun startContinuousMode() {
        addOverlay()
        if (settings.textGeminiKey().isNotBlank()) net.execute { RegionTranslator.preconnect() }   // TLS پێشوەختە = ٠.٢-٠.٦ چرکە زووتر

        lateinit var w: PageWatcher
        w = PageWatcher(
            ocr = ocr,
            onClear = {
                mainHandler.post {
                    // پەڕەی نوێ: خوێندنەوەی کۆن بوەستێ (تا تێکەڵ نەبێت)
                    if (tts.speaking) stopSpeak()
                    overlay?.clear()
                    w.notifyOverlayUpdated()
                }
            },
            onBoxes = { boxes, fw, fh, gen ->
                translateBoxes(
                    boxes, fw, fh,
                    alive = { continuousMode && w.isCurrent(gen) },
                    onChanged = { w.notifyOverlayUpdated() },
                    // ئەگەر خوێندنەوەی خۆکار چالاک بێت، دوای وەرگێڕان دەخوێنرێتەوە
                    speakWhenDone = settings.autoSpeak
                )
            },
            onPartial = { part, fw, fh, gen ->
                if (continuousMode && w.isCurrent(gen)) {
                    overlay?.setBoxes(ArrayList(part), fw, fh)
                    w.notifyOverlayUpdated()
                }
            },
            changeFraction = { settings.changePercent / 100f },
            textSig = { if (settings.textHashDetect) ScreenText.signature(applicationContext) else 0 }
        )
        watcher = w

        capturer?.frameListener = { bmp ->
            val current = watcher
            if (current != null) current.onFrame(bmp) else bmp.recycle()
        }
    }

    private fun stopContinuousMode() {
        // VirtualDisplay دەمێنێتەوە (بۆ دوگمەی دەستی)؛ تەنها گوێگرەکە لادەبرێت
        capturer?.frameListener = null
        watcher?.reset()
        watcher = null
        removeOverlay()
    }

    // ---------- وەرگێڕانی دەستی ----------

    private fun translateNow() {
        if (capturer == null) return
        if (continuousMode) {
            watcher?.forceRescan()
            capturer?.kick()
            toast("وەرگێڕان...")
            return
        }
        // بپرسە زمانی دەق کامەیە، پاشان وەربگێڕە
        askSourceLang { doTranslateNow() }
    }

    private fun doTranslateNow() {
        val cap = capturer ?: return
        if (live != null) stopLive()
        if (settings.textGeminiKey().isNotBlank()) net.execute { RegionTranslator.preconnect() }
        val run = ++manualRun
        Perf.start("manual"); Perf.resetAudio()
        addOverlay()
        val hadBoxes = overlay?.hasBoxes() == true
        overlay?.clear()
        val langLabel = SourceLangs.labels[SourceLangs.codes.indexOf(settings.sourceLang).coerceAtLeast(0)]
            .substringBefore("(").trim()
        toast("وەرگێڕان ($langLabel)...")
        beginBusy("translate", "وەرگێڕان…")
        updateCommandUi()
        stopScrollWatch()
        startScrollWatch()

        cap.requestFrame(if (hadBoxes) MANUAL_DELAY_MS else DOCK_HIDE_MS) { bmp ->
            mainHandler.post {
                if (run != manualRun) {
                    bmp?.recycle()
                    return@post
                }
                if (bmp == null) {
                    endBusy()
                    toast("شاشە نەگیرا، دووبارە هەوڵبدەرەوە")
                    return@post
                }
                val fw = bmp.width
                val fh = bmp.height
                Perf.mark("فرەیم گیرا ${fw}x$fh")
                ocr.recognize(bmp) { boxes ->
                    bmp.recycle()
                    if (run == manualRun) {
                        if (boxes.isEmpty()) { endBusy(); toast("هیچ دەقێک نەدۆزرایەوە") }
                        else translateBoxes(
                            boxes, fw, fh,
                            alive = { run == manualRun },
                            onChanged = { scrollWatcher?.notifyOverlayUpdated() },
                            speakWhenDone = true
                        )
                    }
                }
            }
        }
    }


    /** پەنجەرەی هەڵبژاردنی زمانی دەقی وێنە — پێش وەرگێڕان دەردەکەوێت */
    private fun askSourceLang(onPicked: () -> Unit) {
        // هەمیشە لە main thread (دوگمەکان هەندێک جار لە threadی تر دێن)
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { askSourceLang(onPicked) }
            return
        }
        // پەنجەرەی کۆن (ئەگەر ماوە) لاببە
        removeLangPicker()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(0xF01A1A2E.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0x55FFFFFF)
            }
            elevation = dp(16).toFloat()
        }
        root.addView(TextView(this).apply {
            text = "زمانی دەقی وێنەکە کامەیە؟"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 0, 0, dp(10))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        val maxH = (resources.displayMetrics.heightPixels * 0.5f).toInt()
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(300).coerceAtMost(maxH)
            )
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val current = settings.sourceLang
        for ((i, code) in SourceLangs.codes.withIndex()) {
            val label = SourceLangs.labels[i]
            val selected = code == current
            val row = TextView(this).apply {
                text = if (selected) "✓  $label" else "    $label"
                setTextColor(if (selected) Color.parseColor("#81C784") else Color.WHITE)
                textSize = 15f
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = GradientDrawable().apply {
                    setColor(if (selected) 0x442E7D32 else 0x33FFFFFF)
                    cornerRadius = dp(10).toFloat()
                }
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    settings.sourceLang = code
                    removeLangPicker()
                    onPicked()
                }
            }
            list.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6) })
        }
        scroll.addView(list)
        root.addView(scroll)
        root.addView(TextView(this).apply {
            text = "پاشگەزبوونەوە"
            setTextColor(0xFFB0BEC5.toInt())
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
            isClickable = true
            setOnClickListener { removeLangPicker() }
        })

        val w = (resources.displayMetrics.widthPixels * 0.9f).toInt().coerceAtMost(dp(380))
        // هەمان شێوازی loginPrompt: FLAG_NOT_FOCUSABLE — لەسەر Service باشتر کار دەکات
        val lp = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            // لەسەر هەموو شتێک (لەوانە پانێل)
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            windowManager.addView(root, lp)
            langPickerView = root
            toast("زمان هەڵبژێرە")
        } catch (t: Throwable) {
            Log.e(TAG, "lang picker failed type=$overlayType", t)
            // هەوڵی دووەم: TYPE_APPLICATION_OVERLAY ئەگەر Accessibility بوو
            if (overlayType != WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) {
                try {
                    lp.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    windowManager.addView(root, lp)
                    langPickerView = root
                    toast("زمان هەڵبژێرە")
                    return
                } catch (t2: Throwable) {
                    Log.e(TAG, "lang picker fallback failed", t2)
                }
            }
            toast("پەنجەرەی زمان دەرنەچوو — بە زمانە پاشەکەوتکراوەکە بەردەوام")
            onPicked()
        }
    }

    private fun removeLangPicker() {
        val v = langPickerView ?: return
        langPickerView = null
        try { windowManager.removeView(v) } catch (_: Throwable) {}
    }

    private fun hideTranslation() {
        removeLangPicker()
        stopScrollWatch()
        stopTts()
        removeResultCard()
        speakBubble?.background = circle(COLOR_SPEAK)
        manualRun++
        endBusy()
        if (continuousMode) {
            overlay?.clear()
            watcher?.notifyOverlayUpdated()
        } else {
            removeOverlay()
        }
        toast("وەرگێڕان شاردرایەوە")
    }

    /**
     * لەسەر main thread بانگ دەکرێت. هەموو بابلەکان دەستبەجێ بە "…" نیشان دەدرێن، پاشان هەموویان
     * پێکەوە (بە پارالێل) دەنێردرێن بۆ Google و هەر کامیان تەواو بوو لەسەر شاشە دەگۆڕدرێت.
     */
    private fun translateBoxes(
        boxes: List<TextBox>,
        fw: Int,
        fh: Int,
        alive: () -> Boolean,
        onChanged: () -> Unit,
        speakWhenDone: Boolean = false,
        forceSpeak: Boolean = false,
        preserveRegionText: Boolean = true
    ) {
        val nativeRegion = if (preserveRegionText) RegionReadPolicy.nativeIndices(boxes.map { it.text }) else emptySet()
        @Suppress("NAME_SHADOWING")
        // کوردیی پێشوو: پیشان بدرێت و بخوێنرێتەوە (وەرنەگێڕدرێتەوە). پێشتر فڕێدەدرا و ناخوێندرایەوە.
        val boxes = boxes.mapIndexedNotNull { index, b ->
            when {
                b.translated -> b
                preserveRegionText && index in nativeRegion -> b.copy(translated = true, native = true)
                OwnOutput.matches(b.text) -> null             // وەرگێڕانی خۆمانە (OCR دووبارە خوێندییەوە) — دووبارە مەیگێڕەوە
                UiNoise.isNoise(b.text, ui = false) -> null   // کات/بەروار/ژمارەی کارلێک — پێویست نییە
                TextFilter.worthTranslating(b.text) -> b
                TextFilter.isLikelySorani(b.text) -> b.copy(translated = true, native = true)
                else -> null
            }
        }
        if (boxes.isEmpty() || !alive()) return
        Perf.mark("translateBoxes: ${boxes.size} بۆکس، کوردی خۆی=${boxes.count { it.native }}، پێویستی بە وەرگێڕان=${boxes.count { !it.translated }}")

        val shown = ArrayList<TextBox>(boxes.map { if (it.translated) it else TextBox(it.rect, "…", bg = it.bg) })
        overlay?.setBoxes(ArrayList(shown), fw, fh)
        onChanged()

        val errorShown = AtomicBoolean(false)
        val srcLang = settings.sourceLang
        val provider = settings.translationProvider
        val cacheLang = if (srcLang == "ar") srcLang else "$srcLang|${provider.id}"
        val canSpeak = speakWhenDone && (forceSpeak || settings.autoSpeak)

        fun rowOf(i: Int) = boxes[i].rect.top * 12 / fh.coerceAtLeast(1)
        // دۆخی تێکەڵ: هەندێک دەق ئامادەیە (کوردی خۆی)، هەندێکی تر هێشتا دەبێت وەربگێڕدرێت.
        // ئامادەکان یەکسەر دەخوێنرێنەوە (چاوەڕێی وەرگێڕانی UI ی ئینگلیزی ناکەین)، وەرگێڕدراوەکان دوای ئەوان.
        val readyIdx = boxes.indices.filter { boxes[it].translated }
        val mixed = canSpeak && readyIdx.isNotEmpty() && boxes.any { !it.translated }
        var mixedEpoch = -1
        if (mixed) {
            val readyTexts = readyIdx
                .sortedWith(compareBy({ rowOf(it) }, { boxes[it].rect.left }))
                .map { boxes[it].text }
                .filter { it != "…" && it != "؟" && it.isNotBlank() && !UiNoise.isLoading(it) }
            if (readyTexts.isNotEmpty()) {
                mixedEpoch = ttsEpoch
                Perf.mark("دۆخی تێکەڵ: ${readyTexts.size} بەشی ئامادە یەکسەر دەخوێنرێتەوە، وەرگێڕان لە پاشبنەما")
                tts.speak(
                    readyTexts,
                    onState = { on ->
                        Perf.audio(on)
                        speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                    },
                    onError = { msg -> toast(msg) }
                )
            }
        }

        // کاتێک هەموو بابلەکان تەواو بوون (هاوبەش بۆ هەردوو ڕێگا)
        fun onAllDone() {
            endBusy()
            Perf.mark("وەرگێڕان تەواو بوو")
            if (!continuousMode) scrollWatcher?.arm()
            if (mixed && mixedEpoch >= 0) {
                // وەرگێڕدراوەکان دوای تەواوبوونی خوێندنەوەی یەکەم؛ ئەگەر بەکارهێنەر وەستاندی یان پەڕەی نوێ هات، نا
                val rest = boxes.indices.filter { !boxes[it].translated }
                    .sortedWith(compareBy({ rowOf(it) }, { boxes[it].rect.left }))
                    .map { shown[it].text }
                    .filter { it != "…" && it != "؟" && it.isNotBlank() && !UiNoise.isLoading(it) }
                if (rest.isEmpty()) return
                scope.launch {
                    // تا ~٢ خولەک چاوەڕێی کۆتایی خوێندنەوەی یەکەم دەکات؛ هەڵوەشێنراوە ئەگەر پەڕەی نوێ هات یان وەستێنرا
                    var tries = 0
                    while (alive() && ttsEpoch == mixedEpoch && tts.speaking && tries < 480) {
                        delay(250)
                        tries++
                    }
                    if (!alive() || ttsEpoch != mixedEpoch) return@launch
                    Perf.mark("خوێندنەوەی وەرگێڕدراوەکان دەست پێدەکات (${rest.size} بەش)")
                    tts.speak(
                        rest,
                        onState = { on -> speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK) },
                        onError = { msg -> toast(msg) }
                    )
                }
                return
            }
            if (canSpeak) {
                val texts = overlay?.spokenTexts().orEmpty()
                if (texts.isNotEmpty()) {
                    Perf.mark("tts.speak() بانگکرا (${texts.size} بەش)")
                    tts.speak(
                        texts,
                        onState = { on ->
                            Perf.audio(on)
                            speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                        },
                        onError = { msg -> toast(msg) }
                    )
                } else if (!continuousMode) {
                    // وەرگێڕان تەواو بوو بەڵام هیچ دەقێکی شیاو نەما (هەمووی ؟ بوو)
                    toast("دەق بۆ خوێندنەوە نەما")
                }
            }
        }

        // گرووپی (batch): چەند بابڵ لە یەک داواکاریدا. هەر گرووپێک لەسەر thread ی تۆڕ بە پارالێل دەڕوات و
        // هەر کە تەواو بوو UI نوێ دەکرێتەوە (یەکەم بابڵەکان زوو دەردەکەون). onAllDone دوای هەموو گرووپەکان.
        suspend fun translateWithGoogle(idx: List<Int>) {
            if (idx.isEmpty()) {
                onAllDone()
                return
            }
            coroutineScope {
                for (chunk in idx.chunked(6)) {
                    launch {
                        if (!alive()) return@launch
                        val texts = chunk.map { boxes[it].text }
                        val translated: List<String?> = withContext(netD) {
                            try {
                                GoogleTranslator.translateBubbles(texts, srcLang)
                            } catch (t: Throwable) {
                                Log.e(TAG, "batch translate failed", t)
                                if (errorShown.compareAndSet(false, true)) {
                                    val why = (t.message ?: t.javaClass.simpleName).take(160)
                                    mainHandler.post { toast("وەرگێڕان سەرنەکەوت:\n$why") }
                                }
                                chunk.map { i ->
                                    try {
                                        GoogleTranslator.translateBubble(boxes[i].text, srcLang)
                                    } catch (_: Throwable) {
                                        null
                                    }
                                }
                            }
                        }
                        if (!alive()) return@launch
                        for ((k, i) in chunk.withIndex()) {
                            val tr = translated.getOrNull(k)
                            if (tr != null) TranslationCache.put(cacheLang, boxes[i].text, tr)
                            shown[i] = TextBox(boxes[i].rect, tr ?: "؟", bg = boxes[i].bg)
                        }
                        overlay?.setBoxes(ArrayList(shown), fw, fh)
                        onChanged()
                    }
                }
            }
            onAllDone()
        }

        // بابلە پێشوەختە وەرگێڕدراوەکان (Gemini بینین) دەستبەجێ دەمێننەوە؛ تەنها ئەوانی تر وەردەگێڕدرێن
        val allPending = boxes.indices.filter { !boxes[it].translated }
        if (allPending.isEmpty()) {
            onAllDone()
            return
        }
        val geminiKey = settings.geminiTtsKey
        val useGemini = if (srcLang == "ar") geminiKey.isNotBlank() else provider != TranslationProvider.GOOGLE
        val pending = ArrayList<Int>()
        if (useGemini) {
            // Gemini: کاشی ContextTranslator بەپێی دراوسێکان کار دەکات (هەمان وشەی فرەمانا لە چوارچێوەی جیاواز ← وەرگێڕانی جیاواز)،
            // بۆیە کاشی سادەی بێ-چوارچێوە لێرە بەکارنایەت
            pending.addAll(allPending)
        } else {
            // کاش: ئەوانەی پێشتر وەرگێڕدراون یەکسەر دەردەکەون، بێ داواکاری تۆڕ
            var hits = 0
            for (i in allPending) {
                val c = TranslationCache.get(cacheLang, boxes[i].text)
                if (c != null) { shown[i] = TextBox(boxes[i].rect, c, bg = boxes[i].bg); hits++ } else pending.add(i)
            }
            if (hits > 0) {
                Perf.mark("کاش: $hits لە ${allPending.size} دەق لە کاش دۆزرایەوە، ${pending.size} ماوە بۆ تۆڕ")
                overlay?.setBoxes(ArrayList(shown), fw, fh)
                onChanged()
            }
            if (pending.isEmpty()) {
                onAllDone()
                return
            }
        }

        // کلیلی Gemini هەبێت: هەموو دەقەکانی شاشە بە یەک داواکاری (هەموو زمانەکان)، بابڵەکان بە stream دەردەکەون.
        // بابڵێک مۆدێل بیپەڕێنێت یان شکست بێت ← تەنها ئەو بابڵە بە Google وەردەگێڕدرێت.
        if (useGemini) {
            val ready = java.util.concurrent.ConcurrentLinkedQueue<Pair<Int, String>>()
            val flushPosted = AtomicBoolean(false)
            fun drain() {
                var any = false
                while (true) {
                    val (k, ku) = ready.poll() ?: break
                    val i = pending[k]
                    shown[i] = TextBox(boxes[i].rect, ku, bg = boxes[i].bg)
                    any = true
                }
                if (any) {
                    overlay?.setBoxes(ArrayList(shown), fw, fh)
                    onChanged()
                }
            }
            scope.launch {
                if (!alive()) return@launch
                Perf.mark("Gemini (چوارچێوە): ${pending.size} بابڵ دەنێردرێت")
                val res: List<String?>? = withContext(netD) {
                    try {
                        val onItem: (Int, String) -> Unit = { k, ku ->
                            ready.add(k to ku)
                            // هەر ٦٠ms یەک نوێکردنەوە (نەک بۆ هەر بابڵێک)، بۆ مۆبایلی خاو
                            if (flushPosted.compareAndSet(false, true)) {
                                mainHandler.postDelayed({ flushPosted.set(false); if (alive()) drain() }, 60)
                            }
                        }
                        if (srcLang == "ar") {
                            ContextTranslator.translate(applicationContext, pending.map { boxes[it].text }, srcLang,
                                geminiKey, settings.fast, onItem = onItem)
                        } else {
                            TextTranslationService.translate(applicationContext, pending.map { boxes[it].text }, srcLang,
                                geminiKey, provider, settings.fast, onItem)
                        }
                    } catch (t: Throwable) {
                        Log.w(TAG, "text translation failed", t)
                        if (srcLang != "ar" && errorShown.compareAndSet(false, true)) {
                            mainHandler.post { if (alive()) toast("وەرگێڕان سەرنەکەوت: ${t.message.orEmpty().take(160)}") }
                        }
                        null
                    }
                }
                drain()
                if (!alive()) return@launch
                if (res == null) {
                    if (srcLang == "ar") translateWithGoogle(pending)
                    else {
                        for (i in pending) if (shown[i].text == "…") shown[i] = TextBox(boxes[i].rect, "؟", bg = boxes[i].bg)
                        overlay?.setBoxes(ArrayList(shown), fw, fh)
                        onChanged()
                        onAllDone()
                    }
                    return@launch
                }
                Perf.mark("Gemini تەواو بوو")
                val missing = ArrayList<Int>()
                var changed = false
                for ((k, i) in pending.withIndex()) {
                    val r = res[k]
                    when {
                        r == null -> missing.add(i)
                        // "" = مۆدێل دەڵێت ئەمە دەق نییە (واترمارک/ژمارەی پەڕە): ناپۆشرێت و ناخوێنرێتەوە
                        r.isBlank() -> { shown[i] = TextBox(boxes[i].rect, "", translated = true, native = true); changed = true }
                        else -> {
                            TranslationCache.put(cacheLang, boxes[i].text, r)
                            if (shown[i].text != r) { shown[i] = TextBox(boxes[i].rect, r, bg = boxes[i].bg); changed = true }
                        }
                    }
                }
                if (changed) {
                    overlay?.setBoxes(ArrayList(shown), fw, fh)
                    onChanged()
                }
                if (missing.isEmpty()) onAllDone()
                else if (srcLang == "ar") translateWithGoogle(missing)
                else {
                    for (i in missing) shown[i] = TextBox(boxes[i].rect, "؟", bg = boxes[i].bg)
                    overlay?.setBoxes(ArrayList(shown), fw, fh)
                    onChanged()
                    onAllDone()
                }
            }
            return
        }

        scope.launch { translateWithGoogle(pending) }
    }

    // ---------- دۆخی ڕووبەر: خۆت ڕووبەرەکە دیاری دەکەیت ----------

    // ---------- ژێرنووسی زیندوو: ڕووبەرێک بەردەوام دەگیرێت ← OCR ← وەرگێڕان ← دەنگ ----------

    private fun toggleLive() {
        if (live != null) { toggleLivePlayback(); return }
        if (capturer == null) { toast("یەکەم گرتنی شاشە چالاک بکە"); return }
        askSourceLang { startRegionSelect(liveMode = true) }
    }

    private fun startLive(r: RectF, w: Int, h: Int) {
        if (capturer == null) return
        stopLive(announce = false)
        manualRun++
        if (continuousMode) toggleContinuousMode()
        stopScrollWatch()
        stopTts()
        if (settings.liveKey().isNotBlank()) net.execute { RegionTranslator.preconnect() }
        net.execute { try { tts.warmUp() } catch (_: Throwable) {} }
        val selection = LiveSubtitle.Selection(LiveGeometry.Box(r.left, r.top, r.right, r.bottom), w, h)
        val token = liveControl.start(selection)
        launchLive(selection, token)
        toast("ژێرنووسی زیندوو چالاکە — ⏸ ڕاگرتنی کاتی، ✕ وەستاندنی تەواو")
    }

    private fun launchLive(selection: LiveSubtitle.Selection, token: Int) {
        val cap = capturer ?: return
        val r = RectF(selection.region.left, selection.region.top, selection.region.right, selection.region.bottom)
        val w = selection.w
        val h = selection.h
        addOverlay()
        overlay?.clear()
        cap.setLiveRefresh(settings.sourceLang != "ar")
        val l = LiveSubtitle(
            this, ocr, tts, settings, mainHandler,
            onCaption = { text ->
                if (liveControl.accepts(token)) {
                    if (text == null) overlay?.clear()
                    else {
                        val g = live?.geom
                        if (g != null && g.w > 1) showLiveCaption(text, g.region, g.w, g.h)
                        else showLiveCaption(text, r, w, h)
                    }
                }
            },
            onError = { msg -> if (liveControl.accepts(token)) toast(msg) }
        )
        l.onGeomChanged = {
            if (liveControl.accepts(token)) {
                overlay?.clear()
                toast("شاشە سوڕایەوە: ڕووبەری ژێرنووس بۆ ئەم ئاراستەیە ڕێکخرا")
            }
        }
        live = l
        l.start(r, w, h, selection.orientations, selection.replayText, selection.sourceNorm, selection.sourceText)
        cap.requestFreshFrame {
            // Attach only after the capturer drops its pre-Pause frame. A rapid
            // second Pause/stop invalidates this callback before attachment.
            liveControl.withCurrent(token) {
                val sc = cap as? ScreenCapturer
                if (sc != null) {
                    sc.rawFrameListener = { bmp, isNew ->
                        if (liveControl.accepts(token)) l.onRawFrame(bmp, isNew)
                    }
                } else {
                    cap.frameListener = { bmp ->
                        if (liveControl.accepts(token)) l.onFrame(bmp) else bmp.recycle()
                    }
                }
            }
        }
        liveBubble?.background = circle(COLOR_LIVE_ON)
        updateCommandUi()
    }

    private fun detachLiveFrames() {
        capturer?.setLiveRefresh(false)
        capturer?.frameListener = null
        (capturer as? ScreenCapturer)?.rawFrameListener = null
    }

    private fun toggleLivePlayback() {
        val l = live ?: return
        when (liveControl.phase) {
            LivePlaybackControl.Phase.RUNNING -> {
                if (!liveControl.pause(l.snapshotSelection())) return
                detachLiveFrames()
                capturer?.setCapturePaused(true)
                l.stop() // closes the old run, its queue and audio immediately
                overlay?.clear()
                liveBubble?.background = circle(COLOR_LIVE)
                updateCommandUi()
                toast("ژێرنووسی زیندوو کاتی ڕاگیرا — ▶ بۆ دەستپێکردنەوە")
            }
            LivePlaybackControl.Phase.PAUSED -> {
                if (capturer == null) { toast("یەکەم گرتنی شاشە چالاک بکە"); return }
                val selection = liveControl.resume() ?: return
                touchModels()
                launchLive(selection, liveControl.generation)
                toast("ژێرنووسی زیندوو بەردەوامە — دوایین ڕستە دەخوێنرێتەوە")
            }
            LivePlaybackControl.Phase.STOPPED -> {}
        }
    }

    private fun stopLive(announce: Boolean = true) {
        val l = live ?: return
        val wasPaused = liveControl.phase == LivePlaybackControl.Phase.PAUSED
        live = null
        liveControl.stop()
        detachLiveFrames()
        if (wasPaused) capturer?.setCapturePaused(false)
        l.stop()
        overlay?.clear()
        liveBubble?.background = circle(COLOR_LIVE)
        updateCommandUi()
        if (announce) toast("ژێرنووسی زیندوو وەستا")
    }

    /**
     * بارێکی ڕەش بە وەرگێڕانەکەوە، لە دەرەوەی ڕووبەری OCR (هەرگیز لەسەری نا — دەنا OCR دەقی کوردی خۆمان دەخوێنێتەوە).
     * یەکەم لای ژێرەوە، ئەگەر شوێن نەبوو لای سەرەوە.
     */
    private fun showLiveCaption(text: String, region: RectF, sw: Int, sh: Int) {
        val gap = dp(6)
        val barH = maxOf(region.height().toInt(), dp(56))
        val below = sh - region.bottom.toInt() - gap
        val above = region.top.toInt() - gap
        val top = when {
            below >= barH -> region.bottom.toInt() + gap
            above >= barH -> region.top.toInt() - gap - barH
            below >= above -> region.bottom.toInt() + gap
            else -> 0
        }
        val hgt = when {
            below >= barH || above >= barH -> barH
            else -> maxOf(below, above).coerceAtLeast(dp(32))
        }
        val width = maxOf(region.width().toInt(), (sw * 0.7f).toInt()).coerceAtMost(sw)
        val cx = region.centerX().toInt()
        val left = (cx - width / 2).coerceIn(0, sw - width)
        val rect = android.graphics.Rect(left, top.coerceIn(0, sh - hgt), left + width, top.coerceIn(0, sh - hgt) + hgt)
        overlay?.setBoxes(listOf(TextBox(rect, text, translated = true, bg = 0xEB121218.toInt())), sw, sh)
    }

    private fun startRegionSelect(liveMode: Boolean = false) {
        if (capturer == null) return
        if (selector != null) return
        if (!liveMode && live != null) stopLive()    // دوو دۆخ پێکەوە ناکرێن
        if (continuousMode) toggleContinuousMode()   // دوو دۆخ پێکەوە ناکرێن
        stopTts()
        speakBubble?.background = circle(COLOR_SPEAK)
        // تا بەکارهێنەر ڕووبەر دەکێشێت، ناسینەوەی کوردی لە پاشبنەما ئامادە دەکرێت
        if (settings.localKurdish) regionPool.execute { LocalKurdishOcr.warmUp(applicationContext) }
        // دەنگی کوردیش پێشوەختە بار دەکرێت (دوای ٢ خولەک بێکاری ڕامەکەی ئازاد دەکرێت) تا «دەست بە خوێندنەوە» خاو نەبێت
        net.execute { try { tts.warmUp() } catch (_: Throwable) {} }

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val view = RegionSelectView(
            this,
            onSelected = { r ->
                removeSelector()
                if (liveMode) startLive(r, metrics.widthPixels, metrics.heightPixels)
                else translateRegion(r, metrics.widthPixels, metrics.heightPixels)
            },
            onCancel = { removeSelector() }
        )
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        windowManager.addView(view, params)
        selector = view
        bringBubbleToFront()
    }

    private fun removeSelector() {
        selector?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        selector = null
    }

    /**
     * ڕووبەرە دیاریکراوەکە دەگیرێت و بە Gemini دەخوێنرێتەوە + دەکرێت بە سۆرانی.
     * دەقی وەرگێڕدراو لەسەر ڕووبەرەکە دەنووسرێت و بە دەنگ دەخوێنرێتەوە.
     * ئەگەر دەقەکە خۆی کوردی بوو: وەرناگێڕدرێت و تەنها دەخوێنرێتەوە.
     */
    /** دوای تەواوبوونی خوێندنەوە، وەرگێڕانی سەر شاشە خۆکارانە دەشاردرێتەوە (ئەگەر ڕووبەرێکی نوێ دیاری نەکرابێت). */
    private fun scheduleHide(run: Int) {
        if (!settings.autoHideOverlay) return
        mainHandler.postDelayed({ if (run == manualRun) overlay?.clear() }, HIDE_DELAY_MS)
    }

    private fun translateRegion(r: RectF, viewW: Int, viewH: Int) {
        val cap = capturer ?: return
        val run = ++manualRun
        Perf.start("region"); Perf.resetAudio()
        addOverlay()
        overlay?.clear()
        toast("ڕووبەر دەخوێنرێتەوە...")
        beginBusy("region", "دەخوێنرێتەوە…")
        updateCommandUi()
        stopScrollWatch()
        startScrollWatch()

        // ڕێگای خێرا: دەقی ڕاستەقینەی ناو ڕووبەر لە Accessibility (بێ گرتنی وێنە، بێ OCR، بێ AI).
        // ئەگەر دەقەکە کوردی بوو: وەک خۆی دەمێنێتەوە (نانووسرێتەوە) و دەستبەجێ دەخوێنرێتەوە.
        val region = Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt())
        net.execute {
            val kurdish = try { regionKurdishBoxes(region, viewW, viewH) } catch (_: Throwable) { null }
            Perf.mark("accessibility: " + (kurdish?.let { "کوردی ${it.size} بلۆک ← ڕێگای خێرا" } ?: "نەدۆزرایەوە ← OCR/Gemini"))
            mainHandler.post {
                if (run != manualRun) return@post
                if (kurdish != null) speakRegionKurdish(kurdish, viewW, viewH)
                else regionCapture(run, r, viewW, viewH)
            }
        }
    }

    /** دەقی کوردیی ناو ڕووبەر لە Accessibility. null = کوردی نییە / نەدۆزرایەوە ← بچۆ سەر OCR/Gemini. */
    private fun regionKurdishBoxes(region: Rect, w: Int, h: Int): List<TextBox>? {
        val all = ScreenText.collect(this, w, h, region = region)
        if (all.isEmpty()) return null
        val area = region.width().toLong() * region.height()
        fun inRegion(b: Rect): Boolean {
            val i = Rect()
            if (!i.setIntersect(b, region)) return false
            val ia = i.width().toLong() * i.height()
            val ba = (b.width().toLong() * b.height()).coerceAtLeast(1)
            // زۆرینەی نۆدەکە لەناو ڕووبەرە، یان ڕووبەرەکە زۆرینەی نۆدێکی نەگەورەیە
            return ia * 2 >= ba || (ia * 10 >= area * 6 && ba <= area * 4)
        }
        val hit = all.filter { inRegion(it.rect) && !UiNoise.isNoise(it.text, ui = false) }
        val native = RegionReadPolicy.nativeIndices(hit.map { it.text })
        val ku = hit.filterIndexed { i, _ -> i in native }
        if (ku.isEmpty()) return null
        // An independent foreign paragraph still takes the translation path;
        // Latin names inside this Sorani selection remain part of its reading.
        if (hit.indices.any { it !in native && TextFilter.worthTranslating(hit[it].text) }) return null
        return ku
            .sortedWith(compareBy({ it.rect.top }, { -it.rect.right }))
            .map { it.copy(translated = true, native = true) }
    }

    private fun speakRegionKurdish(boxes: List<TextBox>, w: Int, h: Int) {
        // native: لەسەر شاشە ناکێشرێت، بەڵام دوگمەی دەنگ بۆ دووبارەکردنەوە هەر دەیخوێنێتەوە
        overlay?.setBoxes(ArrayList(boxes), w, h)
        scrollWatcher?.notifyOverlayUpdated()
        endBusy()
        Perf.mark("tts.speak() بانگکرا (ڕێگای خێرا)")
        tts.speak(
            boxes.map { it.text },
            onState = { on -> Perf.audio(on); mainHandler.post { speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK) } },
            onError = { msg -> mainHandler.post { toastLong(msg) } }
        )
        scrollWatcher?.arm()
    }

    private fun recognizeRegion(crop: Bitmap, englishOnly: Boolean, done: (List<TextBox>) -> Unit) {
        if (englishOnly) ocr.recognizeEnglishOnly(crop, done)
        else ocr.recognize(crop, allowAccessibility = false, done = done)
    }

    /** ڕێگای تەواو: گرتنی وێنەی ڕووبەر ← Tesseract + Gemini */
    private fun regionCapture(run: Int, r: RectF, viewW: Int, viewH: Int) {
        val cap = capturer ?: return
        cap.requestFrame(REGION_DELAY_MS) { bmp ->
            if (bmp == null) {
                mainHandler.post { endBusy(); toast("شاشە نەگیرا، دووبارە هەوڵبدەرەوە") }
                return@requestFrame
            }
            val fw = bmp.width
            val fh = bmp.height
            val kx = fw.toFloat() / viewW
            val ky = fh.toFloat() / viewH
            // ٨dp زیادە: ئەگەر پەنجە لەسەر لێواری دەقەکە بوو پیتەکان نەبڕێن (بڕانی پیت = وەرگێڕانی هەڵە)
            val padPx = (8f * resources.displayMetrics.density).toInt()
            val cr = Rect(
                ((r.left * kx).toInt() - padPx).coerceIn(0, fw - 2),
                ((r.top * ky).toInt() - padPx).coerceIn(0, fh - 2),
                ((r.right * kx).toInt() + padPx).coerceIn(2, fw),
                ((r.bottom * ky).toInt() + padPx).coerceIn(2, fh)
            )
            if (cr.width() < 8 || cr.height() < 8) {
                bmp.recycle()
                mainHandler.post { endBusy(); toast("ڕووبەرەکە زۆر بچووکە") }
                return@requestFrame
            }
            val crop = Bitmap.createBitmap(bmp, cr.left, cr.top, cr.width(), cr.height())
            bmp.recycle()
            Perf.mark("فرەیم گیرا + crop ${cr.width()}x${cr.height()}")

            if (!settings.localKurdish) {
                regionForeignCapture(run, crop, cr, fw, fh)
                return@requestFrame
            }
            // Both recognizers are local and read the same immutable crop.
            // No cloud request or fallback races this native reading stage.
            val native = java.util.concurrent.atomic.AtomicReference<LocalKurdishOcr.NativeRead?>(null)
            val latin = java.util.concurrent.atomic.AtomicReference<List<MixedOcrFilter.Word>>(emptyList())
            val remaining = java.util.concurrent.atomic.AtomicInteger(2)
            fun completeLocal() {
                if (remaining.decrementAndGet() != 0) return
                val read = native.get()
                val merged = if (read == null) "" else if (read.words.isEmpty()) read.text else
                    KurdishVocab.fixOcr(applicationContext, MixedOcrFilter.text(MixedOcrFilter.merge(read.words, latin.get())))
                mainHandler.post {
                    if (run != manualRun) { crop.recycle(); return@post }
                    if (RegionReadPolicy.isSorani(merged)) {
                        crop.recycle()
                        Perf.mark("region: کوردی + ئینگلیزی ناوخۆیی، بێ AI")
                        speakRegionKurdish(listOf(TextBox(Rect(cr), merged, translated = true, native = true)), fw, fh)
                    } else regionForeignCapture(run, crop, cr, fw, fh)
                }
            }
            try {
                ocr.recognizeLatinWords(crop) { words -> latin.set(words); completeLocal() }
            } catch (_: Throwable) { completeLocal() }
            try {
                regionPool.execute {
                    try { native.set(LocalKurdishOcr.detectNative(applicationContext, crop, allowMixedSorani = true)) }
                    finally { completeLocal() }
                }
            } catch (_: java.util.concurrent.RejectedExecutionException) { completeLocal() }
        }
    }

    private fun regionForeignCapture(run: Int, crop: Bitmap, cr: Rect, fw: Int, fh: Int) {
        if (run != manualRun) { crop.recycle(); return }
            // OCR (local Kurdish / ML Kit) first. If it finds nothing and a Gemini key exists,
            // fall back to Gemini vision (ML Kit cannot read Arabic-script Kurdish).
            // Local OCR is only for English + Kurdish. Other languages (ja/ko/zh/hi/ar) use Gemini vision
            // (the path below) when a key exists; without a key they keep the local recognizers.
            val localLangs = settings.sourceLang == "auto" || settings.sourceLang == "en"
            if (settings.sourceLang != "ar" && (localLangs || settings.geminiTtsKey.isBlank())) {
                mainHandler.post {
                    if (run == manualRun) overlay?.setBoxes(listOf(TextBox(cr, "…")), fw, fh)
                }
                val visionKey = settings.geminiTtsKey
                // Keeps screen coordinates by offsetting boxes from the crop.
                val showFound: (List<TextBox>) -> Unit = { found ->
                    mainHandler.post {
                        if (run == manualRun) {
                            if (found.isEmpty()) {
                                overlay?.clear(); endBusy(); toast("هیچ دەقێک نەدۆزرایەوە")
                            } else {
                                val mapped = found.map { box ->
                                    box.copy(rect = Rect(box.rect).apply { offset(cr.left, cr.top) })
                                }
                                translateBoxes(mapped, fw, fh, alive = { run == manualRun },
                                    onChanged = { scrollWatcher?.notifyOverlayUpdated() },
                                    speakWhenDone = true, forceSpeak = true, preserveRegionText = true)
                            }
                        }
                    }
                }
                // Gemini is NOT started up front (it would burn the daily quota on every region).
                // It is asked only when OCR failed; if it fails/quota is out, Tesseract Arabic/Kurdish is used.
                val regionDone: (List<TextBox>) -> Unit = { found ->
                    // ML Kit (Latin) returns nonsense on Kurdish lines, or no box at all for some of them.
                    val garbage = found.any { TextFilter.isGarbageRead(it.text) }
                    if (!garbage && found.isNotEmpty()) {
                        crop.recycle()
                        showFound(found)
                    } else {
                        val clean = found.filter { !TextFilter.isGarbageRead(it.text) }
                        val viaTesseract = {
                            ocr.recognizeArabicOnly(crop) { ar ->
                                crop.recycle()
                                showFound(if (ar.isNotEmpty()) ar else clean)
                            }
                        }
                        if (visionKey.isBlank()) viaTesseract()
                        else net.execute {
                            val viaGemini: List<TextBox> = try {
                                RegionTranslator.run(crop, visionKey, settings.fast).mapNotNull { it ->
                                    if (it.kurdish.trim().length < 2) null
                                    else TextBox(it.rect ?: Rect(0, 0, crop.width, crop.height), it.kurdish.trim(),
                                        translated = true, native = it.alreadyKurdish)
                                }
                            } catch (t: Throwable) {
                                Log.w(TAG, "Gemini region fallback failed (quota?) -> Tesseract", t); emptyList()
                            }
                            if (viaGemini.isNotEmpty()) { crop.recycle(); showFound(viaGemini) }
                            else mainHandler.post { viaTesseract() }
                        }
                    }
                }
                recognizeRegion(crop, localLangs, regionDone)
                return
            }

            mainHandler.post {
                if (run == manualRun) {
                    overlay?.setBoxes(listOf(TextBox(cr, "…")), fw, fh)
                    scrollWatcher?.notifyOverlayUpdated()
                }
            }

            net.execute {
                val boxes = ArrayList<TextBox>()
                var count = 0
                try {
                    val key = settings.geminiTtsKey
                    val localDecided = java.util.concurrent.CountDownLatch(0)
                    val localWon = AtomicBoolean(false)
                    val localFuture: java.util.concurrent.Future<String?>? = null

                    // کۆکردنەوەی دەقەکان؛ لە کۆتاییدا یەک جار speak() — جێگیرتر لە stream
                    val spokenParts = ArrayList<String>()

                    fun speakCollected() {
                        val parts = synchronized(spokenParts) { ArrayList(spokenParts) }
                            .map { it.trim() }
                            .filter { it.isNotEmpty() }
                        if (parts.isEmpty()) return
                        mainHandler.post {
                            if (run != manualRun) return@post
                            // ڕووبەر: دەق لەسەر شاشە دەمێنێتەوە (خۆکار ناشاردرێتەوە)
                            Perf.mark("tts.speak() بانگکرا (${parts.size} بەش)")
                            tts.speak(
                                parts,
                                onState = { on ->
                                    Perf.audio(on)
                                    mainHandler.post {
                                        speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                                        // scheduleHide ناکرێت — بەکارهێنەر دەقەکە دەبینێت و دوگمەی دەنگ دووبارە دەتوانێت
                                    }
                                },
                                onError = { msg ->
                                    mainHandler.post {
                                        toastLong(msg)
                                        // هێشتا دەق لەسەر شاشەیە — دوگمەی دەنگ تاقی بکەرەوە
                                    }
                                }
                            )
                        }
                    }

                    // Gemini لەسەر کۆپیێکی جیا (crop ی ڕەسەن لە کۆتاییدا recycle دەکرێت)
                    val gcrop = if (key.isNotBlank()) crop.copy(Bitmap.Config.ARGB_8888, false) else null
                    val gemFuture = if (gcrop != null) regionPool.submit(java.util.concurrent.Callable<Int> {
                        try {
                            var n = 0
                            RegionTranslator.runStream(gcrop, key, settings.fast) { it0 ->
                                localDecided.await()
                                if (localWon.get() || run != manualRun) return@runStream
                                val ku = it0.kurdish.trim()
                                Perf.mark("gemini بلۆک هات (${ku.length} پیت، کوردی خۆی=${it0.alreadyKurdish})")
                                if (ku.length < 2) return@runStream
                                synchronized(spokenParts) { spokenParts.add(ku) }
                                val rr = it0.rect
                                val rect = if (rr != null) {
                                    Rect(cr.left + rr.left, cr.top + rr.top, cr.left + rr.right, cr.top + rr.bottom)
                                } else cr
                                synchronized(boxes) { boxes.add(TextBox(rect, ku, translated = true, native = it0.alreadyKurdish)) }
                                val snap = synchronized(boxes) { ArrayList(boxes) }
                                mainHandler.post {
                                    if (run == manualRun) {
                                        overlay?.setBoxes(snap, fw, fh)
                                        scrollWatcher?.notifyOverlayUpdated()
                                    }
                                }
                                n++
                            }
                            n
                        } finally {
                            gcrop.recycle()
                        }
                    }) else null

                    // چاوەڕێی OCR ی کوردی؛ ئەگەر دۆزرایەوە Gemini پاشگەز دەکرێتەوە
                    val local = try {
                        localFuture?.get(if (key.isBlank()) LOCAL_WAIT_MS else LOCAL_WAIT_WITH_GEMINI_MS, java.util.concurrent.TimeUnit.MILLISECONDS)
                    } catch (_: java.util.concurrent.TimeoutException) {
                        localFuture?.cancel(true); null
                    } catch (_: Throwable) { null }
                    Perf.mark("tesseract تەواو بوو، دۆزرایەوە=${local != null}")
                    if (local != null) localWon.set(true)
                    localDecided.countDown()

                    if (local != null) {
                        gemFuture?.cancel(true)
                        val ku = local.trim()
                        synchronized(boxes) {
                            boxes.clear()
                            boxes.add(TextBox(cr, ku, translated = true, native = true))
                        }
                        synchronized(spokenParts) {
                            spokenParts.clear()
                            if (ku.length >= 2) spokenParts.add(ku)
                        }
                        val snap = synchronized(boxes) { ArrayList(boxes) }
                        mainHandler.post {
                            if (run == manualRun) {
                                overlay?.setBoxes(snap, fw, fh)
                                scrollWatcher?.notifyOverlayUpdated()
                            }
                        }
                        count = 1
                        speakCollected()
                    } else {
                        if (gemFuture == null) {
                            throw java.io.IOException(
                                "نەتوانرا بە OCR ی کوردی بخوێنرێتەوە. کلیلی Gemini لە «ڕێکخستنی دەنگ» دابنێ یان دەنگی ئۆفلاین چالاک بکە."
                            )
                        }
                        count = try {
                            gemFuture.get()
                        } catch (e: java.util.concurrent.ExecutionException) {
                            throw (e.cause ?: e)
                        }
                        Perf.mark("gemini تەواو بوو ($count بلۆک)")
                        speakCollected()
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "region failed", t)
                    mainHandler.post {
                        if (run == manualRun) {
                            endBusy()
                            overlay?.clear()
                            toastLong("سەرنەکەوت:\n" + (t.message ?: t.javaClass.simpleName).take(160))
                        }
                    }
                    return@execute
                } finally {
                    crop.recycle()
                }

                mainHandler.post {
                    if (run != manualRun) return@post
                    endBusy()
                    val n = synchronized(boxes) { boxes.size }
                    if (count == 0 && n == 0) {
                        overlay?.clear()
                        toast("هیچ دەقێک نەدۆزرایەوە")
                    } else {
                        scrollWatcher?.arm()
                    }
                }
            }
    }

    // ---------- خوێندنەوەی دەنگی ----------

    /** دەستلێدان: دەقە وەرگێڕدراوەکانی شاشە دەخوێنێتەوە. ئەگەر دەیخوێنێتەوە، دەیوەستێنێت. */
    private fun toggleSpeak() {
        if (tts.speaking) {
            stopSpeak()
            return
        }
        val texts = overlay?.spokenTexts().orEmpty()
        if (texts.isEmpty()) {
            toast("سەرەتا شاشە وەربگێڕە (وەر)، پاشان دەنگ")
            return
        }
        ttsEpoch++
        tts.speak(
            texts,
            onState = { on ->
                mainHandler.post {
                    speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                    if (on) beginBusy("speak", "دەخوێنرێتەوە…") else endBusy()
                }
            },
            onError = { msg -> toast(msg) }
        )
    }

    /** هەر وەستانێکی دەنگ ژمارەی epoch زیاد دەکات، بۆ ئەوەی خوێندنەوەی دووەمی چاوەڕوانکراو دوای وەستان دەست پێنەکاتەوە */
    @Volatile private var ttsEpoch = 0
    private fun stopTts() { ttsEpoch++; tts.stop() }

    private fun stopSpeak() {
        endBusy()
        stopTts()
        speakBubble?.background = circle(COLOR_SPEAK)
        toast("خوێندنەوە وەستا")
    }

    // ---------- ئۆڤەرلەی تەواوی شاشە ----------

    private fun addOverlay() {
        if (overlay != null) return

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val view = OverlayView(this)
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        windowManager.addView(view, params)
        overlay = view
        bringBubbleToFront()
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    // ---------- بابلەکانی شەمەندەفەر ----------

    private fun showBubbles() {
        buildDock()
        // هەموو کۆنترۆڵەکان لە یەک پانێلدان (دۆخی کۆن + نوێ پێکەوە)
        bubble = makeItem(GlyphIcon.AUTO, "auto", "وەرگێڕانی خۆکار", COLOR_OFF, onTap = { toggleContinuousMode() })
        transBubble = makeItem(GlyphIcon.TRANSLATE, "translate", "وەرگێڕانی شاشە", COLOR_TRANSLATE,
            onTap = { translateNow() },
            onLong = { hideTranslation() })
        speakBubble = makeItem(GlyphIcon.SPEAK, "speak", "خوێندنەوە بە دەنگ", COLOR_SPEAK,
            onTap = { toggleSpeak() },
            onLong = { stopSpeak() })
        regionBubble = makeItem(GlyphIcon.REGION, "region", "دیاریکردنی ڕووبەر", COLOR_REGION,
            onTap = { startRegionSelect() },
            onLong = { hideTranslation() })
        liveBubble = makeItem(GlyphIcon.REGION, "live", "ژێرنووسی زیندوو (ڤیدیۆ/یاری)", COLOR_LIVE,
            onTap = { toggleLive() })
        micBubble = makeItem(GlyphIcon.MIC, "mic", "قسەکردن بۆ نووسین", COLOR_MIC, onTap = { toggleDictation() })
        addDockWindow()
    }

    // ---------- قسەکردن بە کوردی ← نووسین ----------

    @Volatile
    private var fgsType = 0

    /**
     * Android 14+: ئەگەر خزمەتگوزارییەکە بێ جۆری microphone دەستی پێکردبێت (یان ڕێگەی مایک دواتر درابێت)،
     * AudioRecord دەنگی بێدەنگ دەگەڕێنێتەوە ← «هیچ قسەیەک نەبیسترا». لێرە جۆرەکە نوێ دەکەینەوە.
     */
    private fun ensureMicForeground() {
        if (Build.VERSION.SDK_INT < 30) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val cur = fgsType
        if (cur == 0 || (cur and ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) != 0) return
        try {
            val t = cur or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIF_ID, buildNotification(), t)
            fgsType = t
        } catch (t: Throwable) {
            Log.e(TAG, "mic foreground type failed", t)
        }
    }

    private fun toggleDictation() {
        if (dictating) {
            finishDictation()
            return
        }
        val localStt = (settings.offlineStt || settings.geminiTtsKey.isBlank()) && VekolStt.isReady(this)
        if (!localStt && settings.geminiTtsKey.isBlank()) {
            toast("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ، یان مۆدێلی ئۆفلاین دابەزێنە")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("ڕێگەپێدانی مایک نەدراوە. ئەپەکە بکەرەوە و دووبارە دەستپێبکەرەوە")
            return
        }
        stopTts()
        removeResultCard()
        if (localStt) VekolStt.preload(applicationContext)   // لە کاتی قسەکردنی بەکارهێنەر مۆدێلەکە بار دەبێت
        ensureMicForeground()
        if (!dictation.start { mainHandler.post { if (dictating) finishDictation() } }) {
            toast("مایک نەکرایەوە. ئەپێکی تر مایکی بەکاردەهێنێت؟")
            return
        }
        dictating = true
        micBubble?.background = circle(COLOR_MIC_ON)
        (micBubble as? GlyphIcon)?.kind = GlyphIcon.STOP
        beginBusy("mic", "گوێم لێتە، قسە بکە…")
        updateCommandUi()
        toast("قسە بکە بە کوردی... کۆتایی هات ■ ی سەوز دابگرە (✕ = پاشگەزبوونەوە)")
    }

    @Volatile
    private var dictToken = 0
    @Volatile
    private var lastDictPcm: ByteArray? = null
    @Volatile
    private var lastRawText: String = ""        // دەقی خاوی مۆدێل (بۆ فێربوون لە «چاک بکە»)
    @Volatile
    private var lastRawOffline = false   // دەنگی دوایین قسەکردن، بۆ «چاک بکە» تا Gemini گوێی لێ بگرێت

    private fun finishDictation() {
        ++dictToken
        dictating = false
        micBubble?.background = circle(COLOR_MIC)
        (micBubble as? GlyphIcon)?.kind = GlyphIcon.MIC
        val pcm = dictation.stop()
        lastDictPcm = pcm
        // مایک بێدەنگی گرتووە (ئەپێکی تر مایکی گرتبێت، یان ڕێگەپێدان/جۆری خزمەتگوزاری هەڵە بێت)
        if (pcm.size >= 16_000) {
            var peak = 0
            var i = 0
            while (i + 1 < pcm.size) {
                val v = Math.abs((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF))
                if (v > peak) peak = v
                i += 2
            }
            if (peak < 40) {
                endBusy()
                toastLong("مایک هیچ دەنگێکی نەگرت (تەواو بێدەنگ). ئەپەکە داخە و دووبارە بکەرەوە، و ڕێگەپێدانی مایک بپشکنە")
                return
            }
        }
        val localStt = (settings.offlineStt || settings.geminiTtsKey.isBlank()) && VekolStt.isReady(this)
        toast(if (localStt) "دەنووسرێت (ئۆفلاین)... یەکەمجار کەمێک دەخایەنێت" else "دەنووسرێت...")
        beginBusy("mic", "دەنووسرێت…")
        net.execute {
            var offlineOk = false
            val rawText = try {
                if (localStt) {
                    try {
                        var r = VekolStt.transcribe(applicationContext, pcm)
                        offlineOk = true
                        // مۆدێلی ئۆفلاین بەتاڵی گەڕاندەوە: ئەگەر کلیلی Gemini هەبێت، ئەو هەوڵ دەدات
                        if (r.isBlank() && settings.geminiTtsKey.isNotBlank()) {
                            offlineOk = false
                            r = Dictation.transcribe(pcm, settings.geminiTtsKey, settings.myNameList, KurdishVocab.promptWords(applicationContext))
                        }
                        r
                    } catch (t: Throwable) {
                        Log.e(TAG, "offline stt failed", t)
                        if (settings.geminiTtsKey.isBlank()) throw t
                        offlineOk = false
                        Dictation.transcribe(pcm, settings.geminiTtsKey, settings.myNameList, KurdishVocab.promptWords(applicationContext))
                    }
                } else {
                    Dictation.transcribe(pcm, settings.geminiTtsKey, settings.myNameList, KurdishVocab.promptWords(applicationContext))
                }
            } catch (t: Throwable) {
                Log.e(TAG, "dictation failed", t)
                mainHandler.post { endBusy(); toast("سەرنەکەوت:\n" + (t.message ?: t.javaClass.simpleName).take(160)) }
                return@execute
            }
            // وشە فێربووەکان یەکسەر و بێ ئینتەرنێت لە دەقی ئۆفلاین چاک دەکرێن
            // فەرهەنگی شاراوە (kurdish_vocab) بۆ Gemini دەنێردرێت (Dictation)، نەک بۆ ڕاستکردنەوەی دەقی ئۆفلاین
            val text = if (offlineOk) {
                if (settings.learnFix) KurdishLearn.apply(applicationContext, rawText) else rawText
            } else rawText
            lastRawText = rawText
            lastRawOffline = offlineOk
            mainHandler.post {
                endBusy()
                if (text.isBlank()) toast("هیچ قسەیەک نەبیسترا، دووبارە هەوڵبدەرەوە")
                else showResultCard(text)
            }
        }
    }

    /** کارتی دەرەنجام: دەقی نووسراو + کۆپی + خوێندنەوە + داخستن. خۆکارانە کۆپی دەکرێت. */
    private fun showResultCard(text: String) {
        removeResultCard()
        copyToClipboard(text)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6212121"))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(2), Color.parseColor("#FFB300"))
            }
        }
        // دەقی نووسراو: هەر وشەیەک دابگرە بۆ ئەوەی تەنها ئەو وشەیە بخوێنرێتەوە
        card.addView(TextView(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            textDirection = android.view.View.TEXT_DIRECTION_RTL
            highlightColor = Color.TRANSPARENT
            movementMethod = android.text.method.LinkMovementMethod.getInstance()
            this.text = wordSpans(text)
        })
        // وەرگێڕانی ئینگلیزی (بە دووگمەی EN دەردەکەوێت؛ دابگرە بۆ کۆپیکردنەوە)
        val enView = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.parseColor("#80DEEA"))
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            textDirection = android.view.View.TEXT_DIRECTION_LTR
            gravity = Gravity.START
            setPadding(0, dp(8), 0, 0)
            visibility = View.GONE
        }
        card.addView(enView)
        card.addView(TextView(this).apply {
            this.text = "نووسرا و کۆپی کرا. هەر وشەیەک دابگرە بۆ خوێندنەوەی ئەو وشەیە."
            textSize = 12f
            setTextColor(Color.parseColor("#B0BEC5"))
            setPadding(0, dp(6), 0, dp(8))
        })
        fun btn(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
            this.text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(10).toFloat() }
            setOnClickListener { onClick() }
        }
        val lp = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6); marginStart = dp(6) } }
        fun newRow() = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }

        var fixing = false
        var translating = false
        val fixLabel = "✨ چاک بکە"
        val enLabel = "🇬🇧 ئینگلیزی"
        lateinit var fixBtn: TextView
        lateinit var enBtn: TextView

        // ڕیزی یەکەم: خوێندنەوە + چاککردن بە Gemini
        val row1 = newRow()
        row1.addView(btn("🔊 بیخوێنەوە", COLOR_SPEAK) {
            tts.speak(listOf(text), onState = {}, onError = { m -> toast(m) })
        }, lp())
        fixBtn = btn(fixLabel, Color.parseColor("#6A1B9A")) {
            if (fixing) return@btn
            if (settings.geminiTtsKey.isBlank()) {
                toast("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ")
                return@btn
            }
            fixing = true
            fixBtn.text = "…"
            val src = text
            net.execute {
                val fixed = KurdishTextFix.fixManual(src, settings.geminiTtsKey, lastDictPcm, KurdishEntities.hints(applicationContext, src), settings.myNameList)
                if (fixed != null && settings.learnFix && lastRawOffline && lastRawText.isNotBlank()) KurdishLearn.learn(applicationContext, lastRawText, fixed)
                mainHandler.post {
                    fixing = false
                    if (resultCard !== card) return@post
                    fixBtn.text = fixLabel
                    when {
                        fixed == null -> toast("نەتوانرا چاک بکرێت، دووبارە هەوڵبدەرەوە")
                        fixed == src.trim() -> toast("گۆڕانکاری پێویست نەبوو")
                        else -> {
                            dictToken++   // چاککردنی خۆکاری پاشبنەما دەقە نوێیەکە نەگۆڕێتەوە
                            showResultCard(fixed)   // خۆکارانە کۆپی دەکرێت
                            toast("چاک کرا و کۆپی کرا")
                        }
                    }
                }
            }
        }
        row1.addView(fixBtn, lp())
        card.addView(row1)

        // ڕیزی دووەم: ئینگلیزی + کۆپی + داخستن
        val row2 = newRow().apply { setPadding(0, dp(8), 0, 0) }
        enBtn = btn(enLabel, Color.parseColor("#00838F")) {
            if (translating) return@btn
            translating = true
            enBtn.text = "…"
            val src = text
            net.execute {
                val en = EnglishTranslate.fromKurdish(src, settings.geminiTtsKey, settings.translationProvider)
                mainHandler.post {
                    translating = false
                    if (resultCard !== card) return@post
                    enBtn.text = enLabel
                    if (en.isNullOrBlank()) {
                        toast("وەرگێڕان بۆ ئینگلیزی سەرنەکەوت، ئینتەرنێتەکەت بپشکنە")
                    } else {
                        enView.text = en
                        enView.visibility = View.VISIBLE
                        enView.setOnClickListener { copyToClipboard(en); toast("ئینگلیزییەکە کۆپی کرا") }
                        copyToClipboard(en)   // ئینگلیزییەکە ئێستا لە کلیپبۆردە، لە هەر ئەپێک دایبنێ
                        toast("ئینگلیزییەکە کۆپی کرا")
                    }
                }
            }
        }
        row2.addView(enBtn, lp())
        row2.addView(btn("کۆپی", Color.parseColor("#1565C0")) { copyToClipboard(text); toast("کۆپی کرا") }, lp())
        row2.addView(btn("✕", Color.parseColor("#C62828")) { removeResultCard() }, lp())
        card.addView(row2)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            x = 0
            y = dp(24)
            horizontalMargin = 0.03f
        }
        windowManager.addView(card, params)
        resultCard = card
    }

    /** هەر وشەیەک دەکاتە شوێنی دەستلێدان: دابگرە ← تەنها ئەو وشەیە دەخوێنرێتەوە. */
    private fun wordSpans(text: String): CharSequence {
        val sp = android.text.SpannableString(text)
        val trimChars = charArrayOf('،', '.', '؟', '?', '!', ',', ':', ';', '؛', '"', '“', '”', '«', '»', '(', ')', '…')
        Regex("\\S+").findAll(text).forEach { m ->
            val word = m.value.trim(*trimChars)
            if (word.isEmpty()) return@forEach
            sp.setSpan(object : android.text.style.ClickableSpan() {
                override fun onClick(widget: View) {
                    tts.speak(listOf(word), onState = {}, onError = { e -> toast(e) })
                }

                override fun updateDrawState(ds: android.text.TextPaint) {
                    ds.isUnderlineText = false
                    ds.color = Color.WHITE
                }
            }, m.range.first, m.range.last + 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sp
    }

    private fun removeResultCard() {
        resultCard?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        resultCard = null
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("kurdish", text))
    }

    // ---------- پانێلی شەمەندەفەر (Floating Panel) ----------
    // سێ دۆخ: EXPANDED (هەموو کۆنترۆڵەکان) · COLLAPSED (تەنها بازنەی سەرەکی) · DOCKED (تەنها هێڵێکی باریک لە لێوار)
    // دوای ماوەی دیاریکراو (لە ڕێکخستنی ئەپ) بێ بەکارهێنان، پانێلەکە خۆکارانە دەبێتە هێڵێکی باریک لە لێواری شاشە.
    // هەموو کۆنترۆڵەکان (خۆکار، وەرگێڕان، دەنگ، ڕووبەر، قسە) لە یەک پانێلدان.

    private enum class DockState { EXPANDED, COLLAPSED, DOCKED }

    private var dockRoot: LinearLayout? = null
    private var dockParams: WindowManager.LayoutParams? = null
    private var dockMain: View? = null
    private var dockMainLabel: TextView? = null
    private var dockItems: LinearLayout? = null
    private var dockChevRow: View? = null
    private var dockEditRow: View? = null
    private var dockLine: View? = null
    private var dockState = DockState.COLLAPSED
    private var dockRestoreX = 0
    private val itemRows = HashMap<String, View>()
    private val dockRunnable = Runnable { dockNow() }

    private fun scheduleDock() {
        mainHandler.removeCallbacks(dockRunnable)
        mainHandler.postDelayed(dockRunnable, settings.dockDelaySec * 1000L)
    }

    private fun dockNow() {
        // لە کاتی تۆمارکردن، دیاریکردنی ڕووبەر یان لۆدینگ نەچنە لێوارەوە
        if (selector != null || dictating || loader != null || continuousMode || editItems) { scheduleDock(); return }
        applyDockState(DockState.DOCKED)
    }

    /** ئەستێرەکە بە جووڵەیەکی نەرم (بچووک ← گەورە) دەردەکەوێتەوە */
    private fun popStar() {
        val v = dockMain ?: return
        v.scaleX = 0.4f; v.scaleY = 0.4f; v.rotation = -90f
        v.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(380)
            .setInterpolator(android.view.animation.OvershootInterpolator(2f)).start()
    }

    private fun panelWidth() = dp(228)

    private fun applyDockState(s: DockState) {
        val root = dockRoot ?: return
        val p = dockParams ?: return
        val sw = resources.displayMetrics.widthPixels
        val prev = dockState
        dockState = s
        if (s != DockState.EXPANDED && editItems) setEditMode(false)
        when (s) {
            DockState.DOCKED -> {
                if (prev != DockState.DOCKED) dockRestoreX = p.x
                val left = p.x + p.width / 2 < sw / 2
                dockMain?.visibility = View.GONE
                dockMainLabel?.visibility = View.GONE
                dockItems?.visibility = View.GONE
                dockChevRow?.visibility = View.GONE
                dockEditRow?.visibility = View.GONE
                dockLine?.visibility = View.VISIBLE
                (dockLine?.layoutParams as? LinearLayout.LayoutParams)?.gravity =
                    if (left) Gravity.START else Gravity.END
                dockLine?.requestLayout()
                root.background = null
                root.setPadding(0, 0, 0, 0)
                p.width = dp(28)
                p.x = if (left) 0 else sw - dp(28)
            }
            DockState.COLLAPSED -> {
                if (prev != DockState.COLLAPSED) popStar()
                if (prev == DockState.DOCKED) p.x = dockRestoreX
                dockLine?.visibility = View.GONE
                dockMain?.visibility = View.VISIBLE
                dockMainLabel?.visibility = View.GONE
                dockItems?.visibility = View.GONE
                dockChevRow?.visibility = View.GONE
                dockEditRow?.visibility = View.GONE
                root.background = null
                root.setPadding(0, 0, 0, 0)
                p.width = dp(64)
                p.x = p.x.coerceIn(0, maxOf(0, sw - dp(64)))
            }
            DockState.EXPANDED -> {
                if (prev == DockState.DOCKED) p.x = dockRestoreX
                dockLine?.visibility = View.GONE
                dockMain?.visibility = View.VISIBLE
                dockMainLabel?.visibility = View.VISIBLE
                dockItems?.visibility = View.VISIBLE
                dockChevRow?.visibility = View.VISIBLE
                dockEditRow?.visibility = View.VISIBLE
                // بێ پاشبنەمای گەورە: هەر بازنەیەک و هەر ناونیشانێک شووشەی تایبەت بە خۆی هەیە
                root.background = null
                root.setPadding(dp(8), dp(6), dp(14), dp(6))
                p.width = panelWidth()
                p.x = p.x.coerceIn(0, maxOf(0, sw - panelWidth()))
            }
        }
        try { windowManager.updateViewLayout(root, p) } catch (_: Exception) {}
    }

    /** پاشبنەمای شووشەیی/شلە بۆ ناونیشانەکان (پێوەندی بە پاشبنەمای هیچ پانێلێکەوە نییە) */
    private fun glassPill(tint: Int? = null): android.graphics.drawable.Drawable =
        GlassPillDrawable(resources.displayMetrics.density, tint)

    /** ڕەنگی باگراوندی نووسینی تەنیش دوگمەیەک (بەپێی ڕێکخستنی بەکارهێنەر) */
    private fun labelTint(kind: Int?): Int? = when (settings.labelMode) {
        1 -> if (kind == null) null else settings.iconColor(kind).let { if (it != 0) it else GlyphIcon.defaultColor(kind) }
        2 -> settings.labelColor
        else -> null
    }

    private fun glassLabel(text: String, size: Float, bold: Boolean = false, kind: Int? = null) = TextView(this).apply {
        this.text = text
        textSize = size
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), Color.parseColor("#CC000000"))
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(14), dp(7), dp(14), dp(7))
        background = glassPill(labelTint(kind))
    }

    private fun roundGrad(from: Int, to: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(from, to)
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(2), Color.parseColor("#B3FFFFFF"))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildDock() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        // هێڵی باریک (کاتێک لە لێوار حەشار دراوە)
        val line = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#D9FFFFFF"), Color.parseColor("#59FFFFFF"))
            ).apply {
                cornerRadius = dp(3).toFloat()
                setStroke(dp(1), Color.parseColor("#40000000"))
            }
            visibility = View.GONE
        }
        // دەستلێدان و ڕاکێشان لەسەر هێڵەکە لە ڕێگەی root وە دەگیرێت (لە خوارەوە)، تا ناوچەی دەستلێدان گەورەتر بێت
        root.addView(line, LinearLayout.LayoutParams(dp(6), dp(64)).apply {
            topMargin = dp(18); bottomMargin = dp(18)
        })

        // ڕیزی سەرەوە: بازنەی لۆگۆ + ناو
        val mainRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        // ئەستێرەی Gemini: کاتێک پانێل کەم دەکرێتەوە ئەمە دەمێنێت
        val main = GeminiStarView(this).apply { auto = continuousMode }
        mainRow.addView(main, LinearLayout.LayoutParams(dp(54), dp(54)).apply {
            topMargin = dp(5); bottomMargin = dp(5); marginStart = dp(1)
        })
        val mainLabel = glassLabel("وەڕگێڕی شاشە", 14f, true).apply { visibility = View.GONE }
        // ناوی ئەپەکە لەتەنیشت ئەستێرەکە نیشان نادرێت (تا وەک دوگمە نەبینرێت)؛ mainLabel بۆ هیچ view ێک زیاد ناکرێت
        root.addView(mainRow, LinearLayout.LayoutParams(-1, -2))

        // کۆنترۆڵەکان
        val items = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        root.addView(items, LinearLayout.LayoutParams(-1, -2))

        // دەستکاریکردنی دوگمەکان (شاردنەوە/پیشاندان) لە ناو خودی پانێلەکە
        val editRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            isClickable = true
            setPadding(0, dp(5), 0, dp(5))
            setOnClickListener { setEditMode(!editItems); scheduleDock() }
        }
        val eIcon = TextView(this).apply {
            text = "✎"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = circle(Color.parseColor("#6C7BA8"))
        }
        editRow.addView(eIcon, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(6) })
        val eLabel = glassLabel("دەستکاریکردنی دوگمەکان", 13f, kind = GlyphIcon.CHEVRON)
        editRow.addView(eLabel, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        root.addView(editRow, LinearLayout.LayoutParams(-1, -2))
        editIcon = eIcon
        editLabel = eLabel
        dockEditRow = editRow

        // کەمکردنەوەی پانێل
        val chevRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            isClickable = true
            setPadding(0, dp(5), 0, dp(5))
            setOnClickListener {
                applyDockState(DockState.COLLAPSED)
                scheduleDock()
            }
        }
        chevRow.addView(GlyphIcon(this, GlyphIcon.CHEVRON).apply {
            background = circle(Color.parseColor("#6C7BA8"))
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(6) })
        chevRow.addView(glassLabel("کەمکردنەوەی پانێڵ", 13f, kind = GlyphIcon.CHEVRON), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        root.addView(chevRow, LinearLayout.LayoutParams(-1, -2))

        dockRoot = root
        dockMain = main
        dockMainLabel = mainLabel
        dockItems = items
        dockChevRow = chevRow
        dockLine = line

        val params = WindowManager.LayoutParams(
            dp(64), WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(160)
        }
        dockParams = params

        // کێشان + دەستلێدان لەسەر بازنەی سەرەکی: دەستلێدان = کردنەوە/داخستنی پانێل
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        val slop = dp(8)
        mainRow.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    mainHandler.removeCallbacks(dockRunnable)
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        applyDockState(
                            if (dockState == DockState.EXPANDED) DockState.COLLAPSED else DockState.EXPANDED
                        )
                    }
                    scheduleDock()
                    true
                }
                MotionEvent.ACTION_CANCEL -> { scheduleDock(); true }
                else -> false
            }
        }
    }

    /**
     * کاتێک پانێلەکە بووە هێڵێکی باریک لە لێوار: دەستلێدان یان ڕاکێشانی هێڵەکە بەرەو ناوەڕاستی شاشە
     * پانێلەکە دەهێنێتەوە (لەژێر پەنجەکەتدا دەجووڵێت و کاتێک ڕەهایی دەکەیت دەکرێتەوە).
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun installEdgeDrag() {
        val root = dockRoot ?: return
        val params = dockParams ?: return
        val sw = resources.displayMetrics.widthPixels
        var down = false
        var drag = false
        var lx = 0f
        var ly = 0f
        root.setOnTouchListener { _, e ->
            if (dockState != DockState.DOCKED && !drag) return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    mainHandler.removeCallbacks(dockRunnable)
                    lx = e.rawX; ly = e.rawY
                    down = true; drag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!down) return@setOnTouchListener false
                    if (!drag && (Math.abs(e.rawX - lx) > dp(10) || Math.abs(e.rawY - ly) > dp(10))) {
                        drag = true
                        applyDockState(DockState.COLLAPSED)
                    }
                    if (drag) {
                        params.x = (e.rawX - dp(32)).toInt().coerceIn(0, maxOf(0, sw - dp(64)))
                        params.y = (e.rawY - dp(32)).toInt().coerceAtLeast(0)
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val wasDown = down
                    down = false
                    drag = false
                    if (wasDown) applyDockState(DockState.EXPANDED)
                    scheduleDock()
                    true
                }
                else -> false
            }
        }
    }

    private fun addDockWindow() {
        val root = dockRoot ?: return
        val p = dockParams ?: return
        installEdgeDrag()
        try { windowManager.addView(root, p) } catch (_: Exception) {}
        applyDockState(DockState.EXPANDED)
        scheduleDock()
    }

    // ---------- شاردنەوە/پیشاندانی دوگمەکانی پانێل ----------

    /** دۆخی دەستکاریکردن: هەموو دوگمەکان دەردەکەون و دەستلێدان دەیشارێتەوە یان پیشانی دەدات */
    private var editItems = false
    private var editLabel: TextView? = null
    private var editIcon: TextView? = null

    private fun toggleItemHidden(key: String) {
        settings.setItemHidden(key, !settings.isItemHidden(key))
        refreshItems()
    }

    private fun setEditMode(on: Boolean) {
        editItems = on
        editLabel?.text = if (on) "تەواو ✓ (دوگمەیەک دابگرە بۆ شاردنەوە)" else "دەستکاریکردنی دوگمەکان"
        editIcon?.text = if (on) "✓" else "✎"
        refreshItems()
    }

    /** لە ئەپەکەوە (ڕێکخستن) یان لە پانێلەکەوە بانگ دەکرێت؛ دوگمەکان بەپێی ڕێکخستنەکە نوێ دەکاتەوە */
    fun refreshItems() {
        mainHandler.post {
            for ((key, row) in itemRows) {
                val hidden = settings.isItemHidden(key)
                row.visibility = if (editItems || !hidden) View.VISIBLE else View.GONE
                row.alpha = if (editItems && hidden) 0.35f else 1f
            }
            dockRoot?.let { r -> dockParams?.let { p -> try { windowManager.updateViewLayout(r, p) } catch (_: Exception) {} } }
            if (dockState == DockState.EXPANDED) scheduleDock()
        }
    }

    /** یەک کۆنترۆڵی پانێل: بازنەی ئایکۆنی ڤێکتەر + ناونیشان. دەگەڕێنێتەوە ئایکۆنەکە (بۆ گۆڕینی ڕەنگ/دۆخ). */
    private fun makeItem(
        kind: Int,
        key: String,
        label: String,
        color: Int,
        onTap: () -> Unit,
        onLong: (() -> Unit)? = null
    ): GlyphIcon {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
            isClickable = true
            // لە دۆخی دەستکاریکردن: دەستلێدان = شاردنەوە/پیشاندانی دوگمەکە (فەرمانەکە جێبەجێ ناکرێت)
            setOnClickListener { if (editItems) toggleItemHidden(key) else { onTap(); scheduleDock() } }
            setOnLongClickListener {
                if (editItems) { toggleItemHidden(key); true }
                else if (onLong != null) { onLong(); scheduleDock(); true }
                else false
            }
        }
        val icon = GlyphIcon(this, kind).apply { background = circle(color) }
        // کەوانەیەکی نەرم: هەر ڕیزێک کەمێک لە ڕیزی پێشوو دەگۆڕدرێت
        val arc = intArrayOf(0, 8, 14, 18, 14, 8, 0)
        val shift = arc[(dockItems?.childCount ?: 0) % arc.size]
        row.addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(5 + shift) })
        row.addView(glassLabel(label, 14f, kind = kind), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        dockItems?.addView(row, LinearLayout.LayoutParams(-2, -2))
        itemRows[key] = row
        if (settings.isItemHidden(key)) row.visibility = View.GONE
        return icon
    }

    // ---------- لۆدینگی ستایلی Gemini ----------

    private var loader: GeminiLoader? = null
    private var loaderParams: WindowManager.LayoutParams? = null
    // ---------- ئازادکردنی مۆدێلەکان لە ڕام کاتی بێکاری (کەمکردنەوەی پاتری/ڕام) ----------

    private var lastModelUse = SystemClock.elapsedRealtime()

    /** هەر کاتێک فەرمانێک دەست پێدەکات بانگ دەکرێت؛ تایمەری ٢ خولەکی بێکاری نوێ دەکاتەوە. */
    private fun modelIdleMs() = settings.modelIdleMin * 60_000L

    private fun touchModels() {
        lastModelUse = SystemClock.elapsedRealtime()
        mainHandler.removeCallbacks(idleModelRelease)
        if (settings.modelIdleMin > 0) mainHandler.postDelayed(idleModelRelease, modelIdleMs())
    }

    private val idleModelRelease = object : Runnable {
        override fun run() {
            // ئەگەر هێشتا کار دەکات، دووبارە ٢ خولەک چاوەڕێ بکە
            if (continuousMode || dictating || live != null || commandActive()) { touchModels(); return }
            val idle = SystemClock.elapsedRealtime() - lastModelUse
            if (settings.modelIdleMin <= 0) return   // هەرگیز ئازاد مەکە
            if (idle < modelIdleMs()) { mainHandler.postDelayed(this, modelIdleMs() - idle); return }
            // مۆدێلەکان دواتر خۆکارانە دووبارە بار دەبنەوە کاتێک پێویست بن
            Thread {
                try { VekolStt.release() } catch (_: Throwable) {}
                try { TessOcr.release() } catch (_: Throwable) {}
                try { ocr.trimModels() } catch (_: Throwable) {}
                try { tts.releaseModels() } catch (_: Throwable) {}
            }.start()
        }
    }

    private val busyTimeout = Runnable { endBusy() }

    /** لەسەر main thread بانگ بکە. لۆدینگێکی جوان لەتەنیشت ئەو کۆنترۆڵەوە نیشان دەدات کە چالاک کراوە. */
    private fun beginBusy(key: String, label: String) {
        touchModels()
        mainHandler.removeCallbacks(busyTimeout)
        val existing = loader
        if (existing != null) {
            existing.label = label
            existing.invalidate()
            positionLoader(key)
            try { windowManager.updateViewLayout(existing, loaderParams) } catch (_: Exception) {}
        } else {
            val lv = GeminiLoader(this, label)
            val p = WindowManager.LayoutParams(
                dp(220), dp(54),
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            loader = lv
            loaderParams = p
            positionLoader(key)
            try { windowManager.addView(lv, p) } catch (_: Exception) { loader = null }
        }
        mainHandler.postDelayed(busyTimeout, 45000)
    }

    private fun positionLoader(key: String) {
        val p = loaderParams ?: return
        val dp0 = dockParams ?: return
        val sw = resources.displayMetrics.widthPixels
        val lw = dp(220)
        val lh = dp(54)
        val panelW = if (dockState == DockState.DOCKED) dp(28) else dp0.width
        val onLeft = dp0.x + panelW / 2 < sw / 2
        p.x = (if (onLeft) dp0.x + panelW + dp(6) else dp0.x - lw - dp(6)).coerceIn(0, maxOf(0, sw - lw))
        val anchor: View? = if (dockState == DockState.EXPANDED) itemRows[key] ?: dockMain else dockMain
        var y = dp0.y + dp(10)
        if (anchor != null && anchor.isShown && anchor.height > 0) {
            val loc = IntArray(2)
            anchor.getLocationOnScreen(loc)
            y = loc[1] + anchor.height / 2 - lh / 2
        }
        p.y = y
    }

    private fun endBusy() {
        mainHandler.removeCallbacks(busyTimeout)
        loader?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        loader = null
        loaderParams = null
    }

    /** پانێلەکە دووبارە زیاد دەکرێت بۆ ئەوەی لەسەروو ئۆڤەرلەیەکەوە بێت. */
    private fun bringBubbleToFront() {
        val root = dockRoot ?: return
        val p = dockParams ?: return
        try {
            windowManager.removeView(root)
            windowManager.addView(root, p)
        } catch (_: Exception) {
        }
        val cv = cancelView
        val cp = cancelParams
        if (cv != null && cp != null) {
            try {
                windowManager.removeView(cv)
                windowManager.addView(cv, cp)
            } catch (_: Exception) {
            }
        }
        val sv = stopView
        val sp = stopParams
        if (sv != null && sp != null) {
            try {
                windowManager.removeView(sv)
                windowManager.addView(sv, sp)
            } catch (_: Exception) {
            }
        }
        val lv = loader
        val lp = loaderParams
        if (lv != null && lp != null) {
            try {
                windowManager.removeView(lv)
                windowManager.addView(lv, lp)
            } catch (_: Exception) {
            }
        }
    }

    private fun removeBubbles() {
        mainHandler.removeCallbacks(dockRunnable)
        endBusy()
        dockRoot?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        dockRoot = null
        dockParams = null
        dockMain = null
        dockMainLabel = null
        dockItems = null
        dockChevRow = null
        dockEditRow = null
        editLabel = null
        editIcon = null
        editItems = false
        dockLine = null
        itemRows.clear()
        bubble = null
        transBubble = null
        speakBubble = null
        regionBubble = null
        liveBubble = null
        micBubble = null
    }

    // ---------- ئاگادارکردنەوە ----------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "مانگا وەرگێڕ",
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("مانگا وەرگێڕ کار دەکات")
            .setContentText("وەرگێڕانی خۆکار · وەرگێڕان · دەنگ · ڕووبەر · قسە")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null, "وەستاندن", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    // ---------- دۆخی فەرمان: بابلەکان دەشاردرێنەوە و تەنها ئایکۆنی پاشگەزبوونەوە دەمێنێت ----------

    private var cancelView: View? = null
    private var cancelIsAuto = false
    private var cancelParams: WindowManager.LayoutParams? = null
    private var cmdShown = false
    private var scrollWatcher: ScrollWatcher? = null
    private val uiTick = object : Runnable {
        override fun run() {
            updateCommandUi()
            mainHandler.postDelayed(this, if (DeviceProfile.low) 600L else 300L)
        }
    }

    /** ئایا فەرمانێک کار دەکات یان دەرەنجامی فەرمانێک لەسەر شاشەیە */
    private fun commandActive(): Boolean =
        // ژێرنووسی زیندوو: دوگمەی ✕ ی وەستاندن هەمیشە دیارە (نەک تەنها کاتی دەرکەوتنی ژێرنووس)
        if (live != null) true
        // لە دۆخی خۆکار پانێلەکە (ئەستێرەی مۆر + ناوی ئەپەکە) ناشاردرێتەوە
        else if (continuousMode) selector != null || dictating || tts.speaking
        else selector != null || dictating || loader != null || tts.speaking || overlay?.hasBoxes() == true

    private fun updateCommandUi() {
        val active = commandActive()
        if (!active && scrollWatcher != null && !continuousMode) stopScrollWatch()
        // ئەگەر جۆری دوگمەی پاشگەزبوونەوە گۆڕا (✕ ↔ ئەستێرەی مۆر)، دووبارە دروستی بکەرەوە
        if (active && cmdShown && cancelView != null && cancelIsAuto != continuousMode) removeCancel().also { showCancel() }
        if (active == cmdShown) { syncStop(active); return }
        cmdShown = active
        if (active) {
            mainHandler.removeCallbacks(dockRunnable)
            if (dockState != DockState.COLLAPSED) applyDockState(DockState.COLLAPSED)
            dockRoot?.visibility = View.GONE
            showCancel()
        } else {
            removeCancel()
            dockRoot?.visibility = View.VISIBLE
            scheduleDock()
        }
        syncStop(active)
    }

    /** دوگمەی تەواوکردن (■) تەنها لە کاتی قسەکردن بۆ نووسین */
    private fun syncStop(active: Boolean) {
        if (active && dictating) showStop() else removeStop()
        if (active && live != null) showLiveControl() else removeLiveControl()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showCancel() {
        if (cancelView != null) return
        val dp0 = dockParams ?: return
        val sw = resources.displayMetrics.widthPixels
        val autoStar = continuousMode
        val v: View = if (autoStar) {
            // وەرگێڕانی خۆکار کارایە: ئەستێرەی Gemini ی مۆر + ✓ ؛ دەستلێدان = وەستاندن
            GeminiStarView(this).apply {
                auto = true
                isClickable = true
                setOnClickListener { cancelAll() }
            }
        } else GlyphIcon(this, GlyphIcon.CLOSE).apply {
            background = circle(Color.parseColor("#E5484D"))
            isClickable = true
            setOnClickListener { cancelAll() }
        }
        cancelIsAuto = autoStar
        val size = if (autoStar) dp(58) else dp(46)
        val p = WindowManager.LayoutParams(
            size, size,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (dp0.x + dp(8)).coerceIn(0, maxOf(0, sw - size))
            y = dp0.y + dp(8)
        }
        try {
            windowManager.addView(v, p)
            cancelView = v
            cancelParams = p
        } catch (_: Exception) {}
    }

    private fun removeCancel() {
        removeStop()
        removeLiveControl()
        cancelView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        cancelView = null
        cancelParams = null
    }

    private var liveControlView: GlyphIcon? = null
    private var liveControlParams: WindowManager.LayoutParams? = null

    private fun showLiveControl() {
        val cp = cancelParams ?: return
        val paused = liveControl.phase == LivePlaybackControl.Phase.PAUSED
        val kind = if (paused) GlyphIcon.PLAY else GlyphIcon.PAUSE
        val action = if (paused) "دەستپێکردنەوەی ژێرنووسی زیندوو" else "ڕاگرتنی کاتیی ژێرنووسی زیندوو"
        val metrics = resources.displayMetrics
        val size = dp(46)
        val point = LiveControlLayout.position(metrics.widthPixels, metrics.heightPixels,
            cp.x, cp.y, cp.width, size, dp(8))
        val existing = liveControlView
        if (existing != null) {
            if (existing.kind != kind) {
                existing.kind = kind
                existing.background = circle(if (paused) COLOR_LIVE_ON else COLOR_LIVE)
                existing.contentDescription = action
                existing.tooltipText = action
            }
            liveControlParams?.let { params ->
                if (params.x != point.x || params.y != point.y) {
                    params.x = point.x; params.y = point.y
                    try { windowManager.updateViewLayout(existing, params) } catch (_: Exception) {}
                }
            }
            return
        }
        val view = GlyphIcon(this, kind).apply {
            background = circle(if (paused) COLOR_LIVE_ON else COLOR_LIVE)
            contentDescription = action
            tooltipText = action
            isClickable = true
            setOnClickListener { toggleLivePlayback() }
        }
        val params = WindowManager.LayoutParams(size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = point.x; y = point.y
        }
        try {
            windowManager.addView(view, params)
            liveControlView = view; liveControlParams = params
        } catch (_: Exception) {}
    }

    private fun removeLiveControl() {
        liveControlView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        liveControlView = null; liveControlParams = null
    }

    private var stopView: GlyphIcon? = null
    private var stopParams: WindowManager.LayoutParams? = null

    /** ■ : قسەکردن تەواو بکە و بیکە بە نووسین (✕ تەنها پاشگەزبوونەوەیە) */
    private fun showStop() {
        if (stopView != null) return
        val cp = cancelParams ?: return
        val sw = resources.displayMetrics.widthPixels
        val size = dp(46)
        val v = GlyphIcon(this, GlyphIcon.STOP).apply {
            background = GlassOrbDrawable(Color.parseColor("#1FBF6A"), resources.displayMetrics.density)
            isClickable = true
            setOnClickListener { if (dictating) finishDictation() }
        }
        val p = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // لای ڕاستی ✕ ؛ ئەگەر شوێن نەبوو لای چەپی
            val right = cp.x + size + dp(8)
            x = if (right + size <= sw) right else (cp.x - size - dp(8)).coerceAtLeast(0)
            y = cp.y
        }
        try {
            windowManager.addView(v, p)
            stopView = v
            stopParams = p
        } catch (_: Exception) {}
    }

    private fun removeStop() {
        stopView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        stopView = null
        stopParams = null
    }

    /** پاشگەزبوونەوە لە هەموو فەرمانێک: وەرگێڕان، خوێندنەوە، قسەکردن، ڕووبەر، وەرگێڕانی خۆکار */
    private fun cancelAll() {
        stopLive()                       // پێشتر ژێرنووسی زیندوو نەدەوەستا: تەنها ئۆڤەرلەی لادەچوو و OCR/دەنگ بەردەوام بوو
        if (continuousMode) toggleContinuousMode()
        removeSelector()
        if (dictating) {
            dictating = false
            dictToken++
            try { dictation.cancel() } catch (_: Throwable) {}
            micBubble?.background = circle(COLOR_MIC)
            (micBubble as? GlyphIcon)?.kind = GlyphIcon.MIC
        }
        stopScrollWatch()
        stopTts()
        speakBubble?.background = circle(COLOR_SPEAK)
        removeResultCard()
        manualRun++
        endBusy()
        removeOverlay()
        updateCommandUi()
    }

    // ---------- شاردنەوەی وەرگێڕان بە جوڵاندنی شاشە ----------

    private fun startScrollWatch() {
        if (continuousMode || live != null) return
        val cap = capturer ?: return
        val w = ScrollWatcher(
            onScrolled = { mainHandler.post { scrolledAway() } },
            textSig = { if (settings.textHashDetect) ScreenText.signature(applicationContext) else 0 }
        )
        scrollWatcher = w
        cap.frameListener = { bmp ->
            val cur = scrollWatcher
            if (cur != null) cur.onFrame(bmp) else bmp.recycle()
        }
    }

    private fun stopScrollWatch() {
        if (scrollWatcher == null) return
        scrollWatcher = null
        if (!continuousMode) capturer?.frameListener = null
    }

    private fun scrolledAway() {
        if (live != null) { stopScrollWatch(); return }   // ژێرنووسی زیندوو: دەنگ و نووسین هەرگیز بەهۆی scroll ەوە ناوەستن
        if (scrollWatcher == null) return
        stopScrollWatch()
        stopTts()
        speakBubble?.background = circle(COLOR_SPEAK)
        manualRun++
        endBusy()
        removeOverlay()
        updateCommandUi()
    }

    // ---------- یارمەتیدەرەکان ----------

    /** بازنەی Liquid Glass بە ڕەنگی دیاریکراو (GlassOrbDrawable) */
    private fun circle(color: Int): android.graphics.drawable.Drawable =
        GlassOrbDrawable(
            color, resources.displayMetrics.density,
            active = color == COLOR_ON || color == COLOR_SPEAK_ON || color == COLOR_MIC_ON
        )

    private fun lighten(color: Int): Int {
        val f = 0.30f
        return Color.rgb(
            (Color.red(color) + (255 - Color.red(color)) * f).toInt(),
            (Color.green(color) + (255 - Color.green(color)) * f).toInt(),
            (Color.blue(color) + (255 - Color.blue(color)) * f).toInt()
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun toastLong(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        @Volatile
        var instance: OverlayService? = null

        private const val TAG = "OverlayService"
        const val ACTION_START = "com.mangatranslator.app.START"
        const val ACTION_STOP = "com.mangatranslator.app.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_USE_A11Y = "use_a11y"

        private const val CHANNEL_ID = "manga_translator"
        private const val NOTIF_ID = 42
        private val COLOR_OFF = Color.parseColor("#3B4A6B")
        private val COLOR_ON = Color.parseColor("#1FBF6A")
        private val COLOR_TRANSLATE = Color.parseColor("#1E90FF")
        private val COLOR_REGION = Color.parseColor("#0FB5D6")
        private val COLOR_LIVE = Color.parseColor("#F5A300")
        private val COLOR_LIVE_ON = Color.parseColor("#1FBF6A")
        private val COLOR_MIC = Color.parseColor("#E0307A")
        private val COLOR_MIC_ON = Color.parseColor("#FF2D3D")
        private val COLOR_SPEAK = Color.parseColor("#6C4CF0")
        private val COLOR_SPEAK_ON = Color.parseColor("#FF8A1F")
        private const val MANUAL_DELAY_MS = 350L
        private const val REGION_DELAY_MS = 120L
        private const val LOCAL_WAIT_MS = 2500L   // ڕووبەر (بێ Gemini): کاتی زیاتر بۆ OCR ی کوردی
        private const val LOCAL_WAIT_WITH_GEMINI_MS = 1200L   // لەگەڵ Gemini: چاوەڕێی Tesseract کەمتر
        /** بە دەنگی ئۆفلاین دەخوێنرێتەوە کاتێک کۆکی Pawan بەسەرچوو */
        private const val LOGIN_SPOKEN = "کۆکیی پاوان بەسەرچووە. تکایە دوگمەی چوونەژوورەوە لەسەر شاشە دابگرە و بچۆ ژوورەوە."
        private const val DOCK_HIDE_MS = 220L
        private const val HIDE_DELAY_MS = 8000L   // پێشتر ١.٥چ → زۆر زوو دەسڕایەوە
    }
}
