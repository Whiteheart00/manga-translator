package com.mangatranslator.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.widget.LinearLayout
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * خزمەتگوزاری پێشەوە (foreground service) کە:
 *  - دوو بابلی شەمەندەفەر پیشان دەدات:
 *      ک  = وەرگێڕانی خۆکار (Continuous Mode) چالاک/ناچالاک
 *      وەر = وەرگێڕانی شاشەی ئێستا بە دەستی (درێژ بگرە = شاردنەوەی وەرگێڕان)
 *  - شاشە دەگرێت، OCR دەکات، بە Google دەیکات بە سۆرانی و لەسەر بابلەکان نیشانی دەدات
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var transBubble: TextView? = null
    private var transBubbleParams: WindowManager.LayoutParams? = null
    private var speakBubble: TextView? = null
    private var speakBubbleParams: WindowManager.LayoutParams? = null
    private var regionBubble: TextView? = null
    private var regionBubbleParams: WindowManager.LayoutParams? = null
    private var selector: RegionSelectView? = null
    private var micBubble: TextView? = null
    private var micBubbleParams: WindowManager.LayoutParams? = null
    private var resultCard: LinearLayout? = null
    private val dictation = Dictation()
    @Volatile
    private var dictating = false
    private var overlay: OverlayView? = null
    private var capturer: ScreenCapturer? = null
    private var watcher: PageWatcher? = null

    private val ocr: OcrEngine by lazy { OcrEngine() }
    private val settings: TranslatorSettings by lazy { TranslatorSettings(this) }
    private val tts: SoraniTts by lazy { SoraniTts(this, settings) }
    /** چەند بابل پێکەوە وەردەگێڕدرێن */
    private val net = Executors.newFixedThreadPool(6)

    @Volatile
    private var continuousMode = false
    /** هەر وەرگێڕانێکی دەستی ژمارەیەکی نوێ وەردەگرێت؛ کارە کۆنەکان خۆیان دەوەستێنن */
    @Volatile
    private var manualRun = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        Thread { try { tts.warmUp() } catch (_: Throwable) {} }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // دەبێت پێش وەرگرتنی MediaProjection، startForeground بە جۆری mediaProjection بانگ بکرێت
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            // دۆخی نوێ مایک پێویستە (قسەکردن بۆ نووسین)
            if (Build.VERSION.SDK_INT >= 30 && settings.mode == 1 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            ) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(NOTIF_ID, notification, type)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (capturer == null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection: MediaProjection = mpm.getMediaProjection(resultCode, data)
            capturer = ScreenCapturer(
                context = this,
                projection = projection,
                onFirstFrame = {
                    mainHandler.post { toast("شاشە دەگیرێت ✓") }
                },
                onProjectionStopped = {
                    mainHandler.post { stopSelf() }
                }
            )
        }

        capturer?.start()
        if (bubble == null && regionBubble == null) showBubbles()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        continuousMode = false
        stopContinuousMode()
        removeSelector()
        removeResultCard()
        dictation.cancel()
        removeBubbles()
        capturer?.release()
        capturer = null
        net.shutdownNow()
        tts.shutdown()
        try {
            ocr.close()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    // ---------- Continuous Mode ----------

    private fun toggleContinuousMode() {
        manualRun++
        if (!continuousMode) {
            continuousMode = true
            startContinuousMode()
            bubble?.background = circle(COLOR_ON)
            toast("وەرگێڕانی خۆکار: چالاکە")
        } else {
            continuousMode = false
            stopContinuousMode()
            bubble?.background = circle(COLOR_OFF)
            toast("وەرگێڕانی خۆکار: ناچالاکە")
        }
    }

    private fun startContinuousMode() {
        addOverlay()

        lateinit var w: PageWatcher
        w = PageWatcher(
            ocr = ocr,
            onClear = {
                mainHandler.post {
                    overlay?.clear()
                    w.notifyOverlayUpdated()
                }
            },
            onBoxes = { boxes, fw, fh, gen ->
                translateBoxes(
                    boxes, fw, fh,
                    alive = { continuousMode && w.isCurrent(gen) },
                    onChanged = { w.notifyOverlayUpdated() }
                )
            }
        )
        watcher = w

        capturer?.frameListener = { bmp ->
            val current = watcher
            if (current != null) current.onFrame(bmp) else bmp.recycle()
        }
    }

    private fun stopContinuousMode() {
        // VirtualDisplay دەمێنێتەوە (بۆ دوگمەی دەستی)؛ تەنها گوێگرەکە لادەبرێت
        capturer?.frameListener = null
        watcher?.reset()
        watcher = null
        removeOverlay()
    }

    // ---------- وەرگێڕانی دەستی ----------

    private fun translateNow() {
        val cap = capturer ?: return
        if (continuousMode) {
            watcher?.forceRescan()
            toast("وەرگێڕان...")
            return
        }

        val run = ++manualRun
        addOverlay()
        val hadBoxes = overlay?.hasBoxes() == true
        overlay?.clear()
        toast("وەرگێڕان...")

        // ئەگەر وەرگێڕانی کۆن لەسەر شاشە بوو، کەمێک چاوەڕێ دەکەین تا لە وێنەکە نەمێنێت
        cap.requestFrame(if (hadBoxes) MANUAL_DELAY_MS else 0L) { bmp ->
            mainHandler.post {
                if (run != manualRun) {
                    bmp?.recycle()
                    return@post
                }
                if (bmp == null) {
                    toast("شاشە نەگیرا، دووبارە هەوڵبدەرەوە")
                    return@post
                }
                val fw = bmp.width
                val fh = bmp.height
                ocr.recognize(bmp) { boxes ->
                    bmp.recycle()
                    if (run == manualRun) {
                        if (boxes.isEmpty()) toast("هیچ دەقێک نەدۆزرایەوە")
                        else translateBoxes(
                            boxes, fw, fh,
                            alive = { run == manualRun },
                            onChanged = {},
                            speakWhenDone = true
                        )
                    }
                }
            }
        }
    }

    private fun hideTranslation() {
        tts.stop()
        removeResultCard()
        speakBubble?.background = circle(COLOR_SPEAK)
        manualRun++
        if (continuousMode) {
            overlay?.clear()
            watcher?.notifyOverlayUpdated()
        } else {
            removeOverlay()
        }
        toast("وەرگێڕان شاردرایەوە")
    }

    /**
     * لەسەر main thread بانگ دەکرێت. هەموو بابلەکان دەستبەجێ بە "…" نیشان دەدرێن، پاشان هەموویان
     * پێکەوە (بە پارالێل) دەنێردرێن بۆ Google و هەر کامیان تەواو بوو لەسەر شاشە دەگۆڕدرێت.
     */
    private fun translateBoxes(
        boxes: List<TextBox>,
        fw: Int,
        fh: Int,
        alive: () -> Boolean,
        onChanged: () -> Unit,
        speakWhenDone: Boolean = false
    ) {
        if (boxes.isEmpty() || !alive()) return

        val shown = ArrayList<TextBox>(boxes.map { TextBox(it.rect, "…") })
        overlay?.setBoxes(ArrayList(shown), fw, fh)
        onChanged()
        var remaining = boxes.size

        val key = settings.googleKey
        val errorShown = AtomicBoolean(false)
        for ((i, b) in boxes.withIndex()) {
            net.execute {
                if (!alive()) return@execute
                val tr = try {
                    GoogleTranslator.translateBubble(b.text, key)
                } catch (t: Throwable) {
                    Log.e(TAG, "translate failed", t)
                    if (errorShown.compareAndSet(false, true)) {
                        val why = (t.message ?: t.javaClass.simpleName).take(160)
                        mainHandler.post { toast("وەرگێڕان سەرنەکەوت:\n$why") }
                    }
                    null
                }
                mainHandler.post {
                    if (!alive()) return@post
                    shown[i] = TextBox(b.rect, tr ?: "؟")
                    overlay?.setBoxes(ArrayList(shown), fw, fh)
                    onChanged()
                    remaining--
                    if (remaining == 0 && speakWhenDone && settings.autoSpeak) {
                        val texts = overlay?.spokenTexts().orEmpty()
                        if (texts.isNotEmpty()) {
                            tts.speak(
                                texts,
                                onState = { on ->
                                    speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                                },
                                onError = { msg -> toast(msg) }
                            )
                        }
                    }
                }
            }
        }
    }

    // ---------- دۆخی ڕووبەر: خۆت ڕووبەرەکە دیاری دەکەیت ----------

    private fun startRegionSelect() {
        if (capturer == null) return
        if (selector != null) return
        if (continuousMode) toggleContinuousMode()   // دوو دۆخ پێکەوە ناکرێن
        tts.stop()
        speakBubble?.background = circle(COLOR_SPEAK)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val view = RegionSelectView(
            this,
            onSelected = { r ->
                removeSelector()
                translateRegion(r, metrics.widthPixels, metrics.heightPixels)
            },
            onCancel = { removeSelector() }
        )
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        windowManager.addView(view, params)
        selector = view
        bringBubbleToFront()
    }

    private fun removeSelector() {
        selector?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        selector = null
    }

    /**
     * ڕووبەرە دیاریکراوەکە دەگیرێت و بە Gemini دەخوێنرێتەوە + دەکرێت بە سۆرانی.
     * دەقی وەرگێڕدراو لەسەر ڕووبەرەکە دەنووسرێت و بە دەنگ دەخوێنرێتەوە.
     * ئەگەر دەقەکە خۆی کوردی بوو: وەرناگێڕدرێت و تەنها دەخوێنرێتەوە.
     */
    private fun translateRegion(r: RectF, viewW: Int, viewH: Int) {
        val cap = capturer ?: return
        val run = ++manualRun
        addOverlay()
        overlay?.clear()
        toast("ڕووبەر دەخوێنرێتەوە...")

        cap.requestFrame(REGION_DELAY_MS) { bmp ->
            if (bmp == null) {
                mainHandler.post { toast("شاشە نەگیرا، دووبارە هەوڵبدەرەوە") }
                return@requestFrame
            }
            val fw = bmp.width
            val fh = bmp.height
            val kx = fw.toFloat() / viewW
            val ky = fh.toFloat() / viewH
            val cr = Rect(
                (r.left * kx).toInt().coerceIn(0, fw - 2),
                (r.top * ky).toInt().coerceIn(0, fh - 2),
                (r.right * kx).toInt().coerceIn(2, fw),
                (r.bottom * ky).toInt().coerceIn(2, fh)
            )
            if (cr.width() < 8 || cr.height() < 8) {
                bmp.recycle()
                mainHandler.post { toast("ڕووبەرەکە زۆر بچووکە") }
                return@requestFrame
            }
            val crop = Bitmap.createBitmap(bmp, cr.left, cr.top, cr.width(), cr.height())
            bmp.recycle()

            mainHandler.post {
                if (run == manualRun) {
                    overlay?.setBoxes(listOf(TextBox(cr, "…")), fw, fh)
                }
            }

            net.execute {
                val boxes = ArrayList<TextBox>()
                var count = 0
                try {
                    if (settings.geminiTtsKey.isBlank()) throw java.io.IOException("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ")
                    // خوێندنەوە هەر کە یەکەم بلۆک ئامادە بوو دەست پێدەکات
                    tts.beginStream(
                        settings.fast,
                        onState = { on -> mainHandler.post { speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK) } },
                        onError = { msg -> mainHandler.post { toast(msg) } }
                    )
                    count = RegionTranslator.runStream(crop, settings.geminiTtsKey, settings.fast) { it0 ->
                        if (run != manualRun) return@runStream
                        tts.feed(it0.kurdish)
                        if (!it0.alreadyKurdish) {
                            val rr = it0.rect
                            val rect = if (rr != null) {
                                Rect(cr.left + rr.left, cr.top + rr.top, cr.left + rr.right, cr.top + rr.bottom)
                            } else cr
                            synchronized(boxes) { boxes.add(TextBox(rect, it0.kurdish)) }
                            val snap = synchronized(boxes) { ArrayList(boxes) }
                            mainHandler.post { if (run == manualRun) overlay?.setBoxes(snap, fw, fh) }
                        }
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "region failed", t)
                    mainHandler.post {
                        if (run == manualRun) {
                            tts.endStream()
                            overlay?.clear()
                            toast("سەرنەکەوت:\n" + (t.message ?: t.javaClass.simpleName).take(160))
                        }
                    }
                    return@execute
                } finally {
                    crop.recycle()
                }

                mainHandler.post {
                    if (run != manualRun) return@post
                    tts.endStream()
                    if (count == 0) {
                        overlay?.clear()
                        toast("هیچ دەقێک نەدۆزرایەوە")
                    } else if (synchronized(boxes) { boxes.isEmpty() }) overlay?.clear()
                }
            }
        }
    }

    // ---------- خوێندنەوەی دەنگی ----------

    /** دەستلێدان: دەقە وەرگێڕدراوەکانی شاشە دەخوێنێتەوە. ئەگەر دەیخوێنێتەوە، دەیوەستێنێت. */
    private fun toggleSpeak() {
        if (tts.speaking) {
            stopSpeak()
            return
        }
        val texts = overlay?.spokenTexts().orEmpty()
        if (texts.isEmpty()) {
            toast("سەرەتا شاشە وەربگێڕە (وەر)، پاشان دەنگ")
            return
        }
        tts.speak(
            texts,
            onState = { on ->
                speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
            },
            onError = { msg -> toast(msg) }
        )
    }

    private fun stopSpeak() {
        tts.stop()
        speakBubble?.background = circle(COLOR_SPEAK)
        toast("خوێندنەوە وەستا")
    }

    // ---------- ئۆڤەرلەی تەواوی شاشە ----------

    private fun addOverlay() {
        if (overlay != null) return

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val view = OverlayView(this)
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        windowManager.addView(view, params)
        overlay = view
        bringBubbleToFront()
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    // ---------- بابلەکانی شەمەندەفەر ----------

    private fun showBubbles() {
        if (settings.mode == 1) {
            // دۆخی نوێ: ڕووبەر + قسەکردن بۆ نووسین
            val (b4, p4) = makeBubble(
                "ڕ", COLOR_REGION, dp(8), dp(220),
                onTap = { startRegionSelect() },
                onLong = { hideTranslation() }
            )
            regionBubble = b4
            regionBubbleParams = p4
            val (b5, p5) = makeBubble(
                "قسە", COLOR_MIC, dp(8), dp(290),
                onTap = { toggleDictation() }
            )
            micBubble = b5
            micBubbleParams = p5
            return
        }
        // دۆخی کۆن: وەک خۆی
        val (b1, p1) = makeBubble("ک", COLOR_OFF, dp(8), dp(220), onTap = { toggleContinuousMode() })
        bubble = b1
        bubbleParams = p1
        val (b2, p2) = makeBubble(
            "وەر", COLOR_TRANSLATE, dp(8), dp(290),
            onTap = { translateNow() },
            onLong = { hideTranslation() }
        )
        transBubble = b2
        transBubbleParams = p2
        val (b3, p3) = makeBubble(
            "دەنگ", COLOR_SPEAK, dp(8), dp(360),
            onTap = { toggleSpeak() },
            onLong = { stopSpeak() }
        )
        speakBubble = b3
        speakBubbleParams = p3
    }

    // ---------- قسەکردن بە کوردی ← نووسین ----------

    private fun toggleDictation() {
        if (dictating) {
            finishDictation()
            return
        }
        if (settings.geminiTtsKey.isBlank()) {
            toast("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("ڕێگەپێدانی مایک نەدراوە. لە ئەپەکە دۆخی نوێ هەڵبژێرە و دووبارە دەستپێبکەرەوە")
            return
        }
        tts.stop()
        removeResultCard()
        if (!dictation.start { mainHandler.post { if (dictating) finishDictation() } }) {
            toast("مایک نەکرایەوە. ئەپێکی تر مایکی بەکاردەهێنێت؟")
            return
        }
        dictating = true
        micBubble?.background = circle(COLOR_MIC_ON)
        micBubble?.text = "⏹"
        toast("قسە بکە بە کوردی... کۆتایی هات دووبارە دایبگرە")
    }

    private fun finishDictation() {
        dictating = false
        micBubble?.background = circle(COLOR_MIC)
        micBubble?.text = "قسە"
        val pcm = dictation.stop()
        toast("دەنووسرێت...")
        net.execute {
            val text = try {
                Dictation.transcribe(pcm, settings.geminiTtsKey)
            } catch (t: Throwable) {
                Log.e(TAG, "dictation failed", t)
                mainHandler.post { toast("سەرنەکەوت:\n" + (t.message ?: t.javaClass.simpleName).take(160)) }
                return@execute
            }
            mainHandler.post {
                if (text.isBlank()) toast("هیچ قسەیەک نەبیسترا، دووبارە هەوڵبدەرەوە")
                else showResultCard(text)
            }
        }
    }

    /** کارتی دەرەنجام: دەقی نووسراو + کۆپی + خوێندنەوە + داخستن. خۆکارانە کۆپی دەکرێت. */
    private fun showResultCard(text: String) {
        removeResultCard()
        copyToClipboard(text)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6212121"))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(2), Color.parseColor("#FFB300"))
            }
        }
        card.addView(TextView(this).apply {
            this.text = text
            textSize = 20f
            setTextColor(Color.WHITE)
            textDirection = android.view.View.TEXT_DIRECTION_RTL
        })
        card.addView(TextView(this).apply {
            this.text = "نووسرا و کۆپی کرا. لە هەر ئەپێک دایبنێ (Paste)."
            textSize = 12f
            setTextColor(Color.parseColor("#B0BEC5"))
            setPadding(0, dp(6), 0, dp(8))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL }
        fun btn(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
            this.text = label
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(10).toFloat() }
            setOnClickListener { onClick() }
        }
        val lp = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6); marginStart = dp(6) } }
        row.addView(btn("کۆپی", Color.parseColor("#1565C0")) { copyToClipboard(text); toast("کۆپی کرا") }, lp())
        row.addView(btn("🔊 بیخوێنەوە", COLOR_SPEAK) {
            tts.speak(listOf(text), onState = {}, onError = { m -> toast(m) })
        }, lp())
        row.addView(btn("✕", Color.parseColor("#C62828")) { removeResultCard() }, lp())
        card.addView(row)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            x = 0
            y = dp(24)
            horizontalMargin = 0.03f
        }
        windowManager.addView(card, params)
        resultCard = card
    }

    private fun removeResultCard() {
        resultCard?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        resultCard = null
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("kurdish", text))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeBubble(
        label: String,
        color: Int,
        x0: Int,
        y0: Int,
        onTap: () -> Unit,
        onLong: (() -> Unit)? = null
    ): Pair<TextView, WindowManager.LayoutParams> {
        val size = dp(56)

        val view = TextView(this).apply {
            text = label
            textSize = if (label.length > 1) 16f else 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = circle(color)
            alpha = 0.9f
        }

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = x0
            y = y0
        }

        // کێشان (drag)، دەستلێدان (tap) و گرتنی درێژ (long press)
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var longFired = false
        val slop = dp(8)
        val longRunnable = Runnable {
            if (!moved && onLong != null) {
                longFired = true
                onLong()
            }
        }

        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    longFired = false
                    if (onLong != null) mainHandler.postDelayed(longRunnable, 600)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                        moved = true
                        mainHandler.removeCallbacks(longRunnable)
                    }
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        windowManager.updateViewLayout(v, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    mainHandler.removeCallbacks(longRunnable)
                    if (!moved && !longFired) onTap()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longRunnable)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, params)
        return view to params
    }

    /** بابلەکان دووبارە زیاد دەکرێن بۆ ئەوەی لەسەروو ئۆڤەرلەیەکەوە بن. */
    private fun bringBubbleToFront() {
        for ((v, p) in listOf(
            bubble to bubbleParams,
            transBubble to transBubbleParams,
            speakBubble to speakBubbleParams,
            regionBubble to regionBubbleParams,
            micBubble to micBubbleParams
        )) {
            if (v == null || p == null) continue
            try {
                windowManager.removeView(v)
                windowManager.addView(v, p)
            } catch (_: Exception) {
            }
        }
    }

    private fun removeBubbles() {
        for (v in listOf(bubble, transBubble, speakBubble, regionBubble, micBubble)) {
            if (v == null) continue
            try {
                windowManager.removeView(v)
            } catch (_: Exception) {
            }
        }
        bubble = null
        bubbleParams = null
        transBubble = null
        transBubbleParams = null
        speakBubble = null
        speakBubbleParams = null
        regionBubble = null
        regionBubbleParams = null
        micBubble = null
        micBubbleParams = null
    }

    // ---------- ئاگادارکردنەوە ----------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "مانگا وەرگێڕ",
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("مانگا وەرگێڕ کار دەکات")
            .setContentText(
                if (settings.mode == 1) "ڕ = ڕووبەر  |  قسە = قسەکردن بۆ نووسین"
                else "ک = خۆکار  |  وەر = وەرگێڕان  |  دەنگ = خوێندنەوە"
            )
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null, "وەستاندن", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    // ---------- یارمەتیدەرەکان ----------

    private fun circle(color: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(lighten(color), color)
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(2), Color.parseColor("#B3FFFFFF"))
    }

    private fun lighten(color: Int): Int {
        val f = 0.30f
        return Color.rgb(
            (Color.red(color) + (255 - Color.red(color)) * f).toInt(),
            (Color.green(color) + (255 - Color.green(color)) * f).toInt(),
            (Color.blue(color) + (255 - Color.blue(color)) * f).toInt()
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val TAG = "OverlayService"
        const val ACTION_START = "com.mangatranslator.app.START"
        const val ACTION_STOP = "com.mangatranslator.app.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"

        private const val CHANNEL_ID = "manga_translator"
        private const val NOTIF_ID = 42
        private val COLOR_OFF = Color.parseColor("#3B4A6B")
        private val COLOR_ON = Color.parseColor("#1FBF6A")
        private val COLOR_TRANSLATE = Color.parseColor("#1E90FF")
        private val COLOR_REGION = Color.parseColor("#0FB5D6")
        private val COLOR_MIC = Color.parseColor("#E0307A")
        private val COLOR_MIC_ON = Color.parseColor("#FF2D3D")
        private val COLOR_SPEAK = Color.parseColor("#6C4CF0")
        private val COLOR_SPEAK_ON = Color.parseColor("#FF8A1F")
        private const val MANUAL_DELAY_MS = 350L
        private const val REGION_DELAY_MS = 120L
    }
}
