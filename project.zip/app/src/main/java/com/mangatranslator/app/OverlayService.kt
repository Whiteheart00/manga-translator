package com.mangatranslator.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.widget.LinearLayout
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * خزمەتگوزاری پێشەوە (foreground service) کە:
 *  - دوو بابلی شەمەندەفەر پیشان دەدات:
 *      ک  = وەرگێڕانی خۆکار (Continuous Mode) چالاک/ناچالاک
 *      وەر = وەرگێڕانی شاشەی ئێستا بە دەستی (درێژ بگرە = شاردنەوەی وەرگێڕان)
 *  - شاشە دەگرێت، OCR دەکات، بە Google دەیکات بە سۆرانی و لەسەر بابلەکان نیشانی دەدات
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    /** TYPE_APPLICATION_OVERLAY (پێویستی بە ڕێگەپێدانی پیشاندان) یان TYPE_ACCESSIBILITY_OVERLAY (بێ ڕێگەپێدان، کاتێک Accessibility چالاکە) */
    private var overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var transBubble: View? = null
    private var transBubbleParams: WindowManager.LayoutParams? = null
    private var speakBubble: View? = null
    private var speakBubbleParams: WindowManager.LayoutParams? = null
    private var regionBubble: View? = null
    private var regionBubbleParams: WindowManager.LayoutParams? = null
    private var selector: RegionSelectView? = null
    private var micBubble: View? = null
    private var micBubbleParams: WindowManager.LayoutParams? = null
    private var resultCard: LinearLayout? = null
    private val dictation = Dictation()
    @Volatile
    private var dictating = false
    private var overlay: OverlayView? = null
    private var capturer: FrameSource? = null
    private var watcher: PageWatcher? = null

    private val ocr: OcrEngine by lazy {
        OcrEngine(applicationContext, { settings.sourceLang }) { msg -> mainHandler.post { toast(msg) } }.also {
            it.geminiKey = { settings.geminiTtsKey }
            it.geminiFast = { settings.fast }
        }
    }
    private val settings: TranslatorSettings by lazy { TranslatorSettings(this) }
    private val tts: SoraniTts by lazy { SoraniTts(this, settings) }
    /** چەند بابل پێکەوە وەردەگێڕدرێن */
    private val net = Executors.newFixedThreadPool(6)

    @Volatile
    private var continuousMode = false
    /** هەر وەرگێڕانێکی دەستی ژمارەیەکی نوێ وەردەگرێت؛ کارە کۆنەکان خۆیان دەوەستێنن */
    @Volatile
    private var manualRun = 0

    override fun onBind(intent: Intent?): IBinder? = null

    /** خزمەتگوزاریی Accessibility ـی ئەو کاتەی پەنجەرەکانی پێ کراونەتەوە */
    private var a11yOwner: MangaAccessibilityService? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        GlassStyle.load(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        Thread { try { tts.warmUp() } catch (_: Throwable) {} }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // دەبێت پێش وەرگرتنی MediaProjection، startForeground بە جۆری mediaProjection بانگ بکرێت
        val notification = buildNotification()
        // دۆخی Accessibility: بێ MediaProjection (Android 11+ و خزمەتگوزارییەکە چالاک بێت)
        val useA11y = intent?.getBooleanExtra(EXTRA_USE_A11Y, false) == true &&
            MangaAccessibilityService.supported() && MangaAccessibilityService.isEnabled(this)
        if (useA11y) {
            // پەنجەرەکان لە ڕێگەی خزمەتگوزاریی Accessibility دەکرێنەوە؛ ڕێگەپێدانی پیشاندان پێویست نییە
            val acc = MangaAccessibilityService.instance
            if (acc != null && (bubble == null || a11yOwner !== acc)) {
                // ئەگەر Accessibility وەستێنرا و دووبارە چالاک کرایەوە، بابلە کۆنەکان مردوون؛ پاکیان دەکەینەوە و نوێ دەیانکەینەوە
                if (bubble != null) removeBubbles()
                (acc.getSystemService(Context.WINDOW_SERVICE) as? WindowManager)?.let {
                    windowManager = it
                    overlayType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    a11yOwner = acc
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            // Android 14: بێ MediaProjection جۆری mediaProjection ڕێگەپێدراو نییە، بۆیە specialUse
            var type = if (useA11y && Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            // دۆخی نوێ مایک پێویستە (قسەکردن بۆ نووسین)
            if (Build.VERSION.SDK_INT >= 30 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            ) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            fgsType = type
            startForeground(NOTIF_ID, notification, type)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (!useA11y && (data == null || resultCode == 0)) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (capturer == null && useA11y && Build.VERSION.SDK_INT >= 30) {
            capturer = AccessibilityCapturer(
                context = this,
                onFirstFrame = { mainHandler.post { toast("شاشە دەگیرێت ✓ (Accessibility)") } },
                onUnavailable = {
                    mainHandler.post { toast("Accessibility ناچالاک بوو؛ ئەپەکە دەوەستێت"); stopSelf() }
                }
            )
        } else if (capturer == null && data != null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection: MediaProjection = mpm.getMediaProjection(resultCode, data)
            capturer = ScreenCapturer(
                context = this,
                projection = projection,
                onFirstFrame = {
                    mainHandler.post { toast("شاشە دەگیرێت ✓") }
                },
                onProjectionStopped = {
                    mainHandler.post { stopSelf() }
                }
            )
        }

        capturer?.start()
        if (bubble == null && regionBubble == null) showBubbles()
        mainHandler.removeCallbacks(uiTick)
        mainHandler.post(uiTick)
        touchModels()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        mainHandler.removeCallbacks(uiTick)
        mainHandler.removeCallbacks(idleModelRelease)
        removeCancel()
        scrollWatcher = null
        continuousMode = false
        stopContinuousMode()
        removeSelector()
        removeResultCard()
        dictation.cancel()
        removeBubbles()
        capturer?.release()
        capturer = null
        net.shutdownNow()
        Thread { VekolStt.release() }.start()   // مۆدێلی ئۆفلاین لە ڕام دەردەهێنێت
        tts.shutdown()
        try {
            ocr.close()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    // ---------- Continuous Mode ----------

    private fun toggleContinuousMode() {
        manualRun++
        stopScrollWatch()
        if (!continuousMode) {
            continuousMode = true
            startContinuousMode()
            (dockMain as? GeminiStarView)?.auto = true
            if (dockState == DockState.EXPANDED) applyDockState(DockState.COLLAPSED)   // تەنها ئەستێرەی مۆر دەمێنێت
            scheduleDock()
            updateCommandUi()
            bubble?.background = circle(COLOR_ON)
            toast("وەرگێڕانی خۆکار: چالاکە")
            beginBusy("auto", "وەرگێڕانی خۆکار چالاکە")
            mainHandler.postDelayed({ if (continuousMode) endBusy() }, 2500)
        } else {
            continuousMode = false
            stopContinuousMode()
            (dockMain as? GeminiStarView)?.auto = false
            bubble?.background = circle(COLOR_OFF)
            updateCommandUi()
            toast("وەرگێڕانی خۆکار: ناچالاکە")
        }
    }

    private fun startContinuousMode() {
        addOverlay()

        lateinit var w: PageWatcher
        w = PageWatcher(
            ocr = ocr,
            onClear = {
                mainHandler.post {
                    overlay?.clear()
                    w.notifyOverlayUpdated()
                }
            },
            onBoxes = { boxes, fw, fh, gen ->
                translateBoxes(
                    boxes, fw, fh,
                    alive = { continuousMode && w.isCurrent(gen) },
                    onChanged = { w.notifyOverlayUpdated() }
                )
            },
            onPartial = { part, fw, fh, gen ->
                if (continuousMode && w.isCurrent(gen)) {
                    overlay?.setBoxes(ArrayList(part), fw, fh)
                    w.notifyOverlayUpdated()
                }
            },
            changeFraction = { settings.changePercent / 100f }
        )
        watcher = w

        capturer?.frameListener = { bmp ->
            val current = watcher
            if (current != null) current.onFrame(bmp) else bmp.recycle()
        }
    }

    private fun stopContinuousMode() {
        // VirtualDisplay دەمێنێتەوە (بۆ دوگمەی دەستی)؛ تەنها گوێگرەکە لادەبرێت
        capturer?.frameListener = null
        watcher?.reset()
        watcher = null
        removeOverlay()
    }

    // ---------- وەرگێڕانی دەستی ----------

    private fun translateNow() {
        val cap = capturer ?: return
        if (continuousMode) {
            watcher?.forceRescan()
            toast("وەرگێڕان...")
            return
        }

        val run = ++manualRun
        addOverlay()
        val hadBoxes = overlay?.hasBoxes() == true
        overlay?.clear()
        toast("وەرگێڕان...")
        beginBusy("translate", "وەرگێڕان…")
        updateCommandUi()   // بابلەکان دەشاردرێنەوە پێش گرتنی شاشە
        stopScrollWatch()
        startScrollWatch()

        // ئەگەر وەرگێڕانی کۆن لەسەر شاشە بوو، کەمێک چاوەڕێ دەکەین تا لە وێنەکە نەمێنێت
        cap.requestFrame(if (hadBoxes) MANUAL_DELAY_MS else DOCK_HIDE_MS) { bmp ->
            mainHandler.post {
                if (run != manualRun) {
                    bmp?.recycle()
                    return@post
                }
                if (bmp == null) {
                    endBusy()
                    toast("شاشە نەگیرا، دووبارە هەوڵبدەرەوە")
                    return@post
                }
                val fw = bmp.width
                val fh = bmp.height
                ocr.recognize(bmp) { boxes ->
                    bmp.recycle()
                    if (run == manualRun) {
                        if (boxes.isEmpty()) { endBusy(); toast("هیچ دەقێک نەدۆزرایەوە") }
                        else translateBoxes(
                            boxes, fw, fh,
                            alive = { run == manualRun },
                            onChanged = { scrollWatcher?.notifyOverlayUpdated() },
                            speakWhenDone = true
                        )
                    }
                }
            }
        }
    }

    private fun hideTranslation() {
        stopScrollWatch()
        tts.stop()
        removeResultCard()
        speakBubble?.background = circle(COLOR_SPEAK)
        manualRun++
        endBusy()
        if (continuousMode) {
            overlay?.clear()
            watcher?.notifyOverlayUpdated()
        } else {
            removeOverlay()
        }
        toast("وەرگێڕان شاردرایەوە")
    }

    /**
     * لەسەر main thread بانگ دەکرێت. هەموو بابلەکان دەستبەجێ بە "…" نیشان دەدرێن، پاشان هەموویان
     * پێکەوە (بە پارالێل) دەنێردرێن بۆ Google و هەر کامیان تەواو بوو لەسەر شاشە دەگۆڕدرێت.
     */
    private fun translateBoxes(
        boxes: List<TextBox>,
        fw: Int,
        fh: Int,
        alive: () -> Boolean,
        onChanged: () -> Unit,
        speakWhenDone: Boolean = false
    ) {
        @Suppress("NAME_SHADOWING")
        val boxes = boxes.filter { it.translated || TextFilter.worthTranslating(it.text) }   // ژمارە، S M L XL، کوردیی پێشوو نەکرێن
        if (boxes.isEmpty() || !alive()) return

        val shown = ArrayList<TextBox>(boxes.map { if (it.translated) it else TextBox(it.rect, "…", bg = it.bg) })
        overlay?.setBoxes(ArrayList(shown), fw, fh)
        onChanged()

        val errorShown = AtomicBoolean(false)

        // کاتێک هەموو بابلەکان تەواو بوون (هاوبەش بۆ هەردوو ڕێگا)
        fun onAllDone() {
            endBusy()
            if (!continuousMode) scrollWatcher?.arm()
            if (speakWhenDone && settings.autoSpeak) {
                val texts = overlay?.spokenTexts().orEmpty()
                if (texts.isNotEmpty()) {
                    tts.speak(
                        texts,
                        onState = { on ->
                            speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                        },
                        onError = { msg -> toast(msg) }
                    )
                }
            }
        }

        // Google Translate: هەر بابلێک بە جیا، بە پارالێل
        fun translateWithGoogle(idx: List<Int>) {
            var left = idx.size
            for (i in idx) {
                val b = boxes[i]
                net.execute {
                    if (!alive()) return@execute
                    val tr = try {
                        GoogleTranslator.translateBubble(b.text, settings.sourceLang)
                    } catch (t: Throwable) {
                        Log.e(TAG, "translate failed", t)
                        if (errorShown.compareAndSet(false, true)) {
                            val why = (t.message ?: t.javaClass.simpleName).take(160)
                            mainHandler.post { toast("وەرگێڕان سەرنەکەوت:\n$why") }
                        }
                        null
                    }
                    mainHandler.post {
                        if (!alive()) return@post
                        shown[i] = TextBox(b.rect, tr ?: "؟", bg = b.bg)
                        overlay?.setBoxes(ArrayList(shown), fw, fh)
                        onChanged()
                        left--
                        if (left == 0) onAllDone()
                    }
                }
            }
        }

        // عەرەبی + کلیلی Gemini هەبێت: هەموو دەقەکان بە یەک داواکاری بە Gemini، ئەگەر شکستی هێنا Google
        // بابلە پێشوەختە وەرگێڕدراوەکان (Gemini بینین) دەستبەجێ دەمێننەوە؛ تەنها ئەوانی تر وەردەگێڕدرێن
        val pending = boxes.indices.filter { !boxes[it].translated }
        if (pending.isEmpty()) {
            onAllDone()
            return
        }
        val geminiKey = settings.geminiTtsKey
        if (settings.sourceLang == "ar" && geminiKey.isNotBlank()) {
            net.execute {
                if (!alive()) return@execute
                val res = try {
                    ArabicGemini.translate(pending.map { boxes[it].text }, geminiKey, settings.fast)
                } catch (t: Throwable) {
                    Log.w(TAG, "Gemini Arabic failed, falling back to Google", t)
                    null
                }
                if (res == null) {
                    translateWithGoogle(pending)
                    return@execute
                }
                mainHandler.post {
                    if (!alive()) return@post
                    val missing = ArrayList<Int>()
                    for ((k, i) in pending.withIndex()) {
                        if (res[k].isBlank()) missing.add(i) else shown[i] = TextBox(boxes[i].rect, res[k], bg = boxes[i].bg)
                    }
                    overlay?.setBoxes(ArrayList(shown), fw, fh)
                    onChanged()
                    if (missing.isEmpty()) onAllDone() else translateWithGoogle(missing)
                }
            }
            return
        }

        translateWithGoogle(pending)
    }

    // ---------- دۆخی ڕووبەر: خۆت ڕووبەرەکە دیاری دەکەیت ----------

    private fun startRegionSelect() {
        if (capturer == null) return
        if (selector != null) return
        if (continuousMode) toggleContinuousMode()   // دوو دۆخ پێکەوە ناکرێن
        tts.stop()
        speakBubble?.background = circle(COLOR_SPEAK)
        // تا بەکارهێنەر ڕووبەر دەکێشێت، ناسینەوەی کوردی لە پاشبنەما ئامادە دەکرێت
        if (settings.localKurdish) net.execute { LocalKurdishOcr.warmUp(applicationContext) }
        // دەنگی کوردیش پێشوەختە بار دەکرێت (دوای ٢ خولەک بێکاری ڕامەکەی ئازاد دەکرێت) تا «دەست بە خوێندنەوە» خاو نەبێت
        net.execute { try { tts.warmUp() } catch (_: Throwable) {} }

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val view = RegionSelectView(
            this,
            onSelected = { r ->
                removeSelector()
                translateRegion(r, metrics.widthPixels, metrics.heightPixels)
            },
            onCancel = { removeSelector() }
        )
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        windowManager.addView(view, params)
        selector = view
        bringBubbleToFront()
    }

    private fun removeSelector() {
        selector?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        selector = null
    }

    /**
     * ڕووبەرە دیاریکراوەکە دەگیرێت و بە Gemini دەخوێنرێتەوە + دەکرێت بە سۆرانی.
     * دەقی وەرگێڕدراو لەسەر ڕووبەرەکە دەنووسرێت و بە دەنگ دەخوێنرێتەوە.
     * ئەگەر دەقەکە خۆی کوردی بوو: وەرناگێڕدرێت و تەنها دەخوێنرێتەوە.
     */
    /** دوای تەواوبوونی خوێندنەوە، وەرگێڕانی سەر شاشە خۆکارانە دەشاردرێتەوە (ئەگەر ڕووبەرێکی نوێ دیاری نەکرابێت). */
    private fun scheduleHide(run: Int) {
        if (!settings.autoHideOverlay) return
        mainHandler.postDelayed({ if (run == manualRun) overlay?.clear() }, HIDE_DELAY_MS)
    }

    private fun translateRegion(r: RectF, viewW: Int, viewH: Int) {
        val cap = capturer ?: return
        val run = ++manualRun
        addOverlay()
        overlay?.clear()
        toast("ڕووبەر دەخوێنرێتەوە...")
        beginBusy("region", "دەخوێنرێتەوە…")
        updateCommandUi()
        stopScrollWatch()
        startScrollWatch()

        cap.requestFrame(REGION_DELAY_MS) { bmp ->
            if (bmp == null) {
                mainHandler.post { endBusy(); toast("شاشە نەگیرا، دووبارە هەوڵبدەرەوە") }
                return@requestFrame
            }
            val fw = bmp.width
            val fh = bmp.height
            val kx = fw.toFloat() / viewW
            val ky = fh.toFloat() / viewH
            val cr = Rect(
                (r.left * kx).toInt().coerceIn(0, fw - 2),
                (r.top * ky).toInt().coerceIn(0, fh - 2),
                (r.right * kx).toInt().coerceIn(2, fw),
                (r.bottom * ky).toInt().coerceIn(2, fh)
            )
            if (cr.width() < 8 || cr.height() < 8) {
                bmp.recycle()
                mainHandler.post { endBusy(); toast("ڕووبەرەکە زۆر بچووکە") }
                return@requestFrame
            }
            val crop = Bitmap.createBitmap(bmp, cr.left, cr.top, cr.width(), cr.height())
            bmp.recycle()

            mainHandler.post {
                if (run == manualRun) {
                    overlay?.setBoxes(listOf(TextBox(cr, "…")), fw, fh)
                    scrollWatcher?.notifyOverlayUpdated()
                }
            }

            net.execute {
                val boxes = ArrayList<TextBox>()
                var count = 0
                try {
                    // ١. یەکەم: ناسینەوەی خێرای کوردی لەسەر مۆبایل (بێ AI)؛ ئەگەر کوردی بوو یەکسەر دەخوێنرێتەوە
                    val local = if (settings.localKurdish) LocalKurdishOcr.detect(applicationContext, crop) else null
                    if (local != null) {
                        if (run == manualRun) {
                            tts.beginStream(
                                settings.fast,
                                onState = { on ->
                                    mainHandler.post {
                                        speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                                        if (!on) scheduleHide(run)
                                    }
                                },
                                onError = { msg -> mainHandler.post { toast(msg) } }
                            )
                            tts.feed(local)
                        }
                        count = 1
                    } else {
                    if (settings.geminiTtsKey.isBlank()) throw java.io.IOException("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ")
                    // خوێندنەوە هەر کە یەکەم بلۆک ئامادە بوو دەست پێدەکات
                    tts.beginStream(
                        settings.fast,
                        onState = { on ->
                                    mainHandler.post {
                                        speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                                        if (!on) scheduleHide(run)
                                    }
                                },
                        onError = { msg -> mainHandler.post { toast(msg) } }
                    )
                    count = RegionTranslator.runStream(crop, settings.geminiTtsKey, settings.fast) { it0 ->
                        if (run != manualRun) return@runStream
                        tts.feed(it0.kurdish)
                        if (!it0.alreadyKurdish) {
                            val rr = it0.rect
                            val rect = if (rr != null) {
                                Rect(cr.left + rr.left, cr.top + rr.top, cr.left + rr.right, cr.top + rr.bottom)
                            } else cr
                            synchronized(boxes) { boxes.add(TextBox(rect, it0.kurdish)) }
                            val snap = synchronized(boxes) { ArrayList(boxes) }
                            mainHandler.post { if (run == manualRun) { overlay?.setBoxes(snap, fw, fh); scrollWatcher?.notifyOverlayUpdated() } }
                        }
                    }
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "region failed", t)
                    mainHandler.post {
                        if (run == manualRun) {
                            endBusy()
                            tts.endStream()
                            overlay?.clear()
                            toastLong("سەرنەکەوت:\n" + (t.message ?: t.javaClass.simpleName).take(160))
                        }
                    }
                    return@execute
                } finally {
                    crop.recycle()
                }

                mainHandler.post {
                    if (run != manualRun) return@post
                    endBusy()
                    tts.endStream()
                    if (count == 0) {
                        overlay?.clear()
                        toast("هیچ دەقێک نەدۆزرایەوە")
                    } else if (synchronized(boxes) { boxes.isEmpty() }) overlay?.clear()
                    else scrollWatcher?.arm()
                }
            }
        }
    }

    // ---------- خوێندنەوەی دەنگی ----------

    /** دەستلێدان: دەقە وەرگێڕدراوەکانی شاشە دەخوێنێتەوە. ئەگەر دەیخوێنێتەوە، دەیوەستێنێت. */
    private fun toggleSpeak() {
        if (tts.speaking) {
            stopSpeak()
            return
        }
        val texts = overlay?.spokenTexts().orEmpty()
        if (texts.isEmpty()) {
            toast("سەرەتا شاشە وەربگێڕە (وەر)، پاشان دەنگ")
            return
        }
        tts.speak(
            texts,
            onState = { on ->
                mainHandler.post {
                    speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                    if (on) beginBusy("speak", "دەخوێنرێتەوە…") else endBusy()
                }
            },
            onError = { msg -> toast(msg) }
        )
    }

    private fun stopSpeak() {
        endBusy()
        tts.stop()
        speakBubble?.background = circle(COLOR_SPEAK)
        toast("خوێندنەوە وەستا")
    }

    // ---------- ئۆڤەرلەی تەواوی شاشە ----------

    private fun addOverlay() {
        if (overlay != null) return

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val view = OverlayView(this)
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        windowManager.addView(view, params)
        overlay = view
        bringBubbleToFront()
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    // ---------- بابلەکانی شەمەندەفەر ----------

    private fun showBubbles() {
        buildDock()
        // هەموو کۆنترۆڵەکان لە یەک پانێلدان (دۆخی کۆن + نوێ پێکەوە)
        bubble = makeItem(GlyphIcon.AUTO, "auto", "وەرگێڕانی خۆکار", COLOR_OFF, onTap = { toggleContinuousMode() })
        transBubble = makeItem(GlyphIcon.TRANSLATE, "translate", "وەرگێڕانی شاشە", COLOR_TRANSLATE,
            onTap = { translateNow() },
            onLong = { hideTranslation() })
        speakBubble = makeItem(GlyphIcon.SPEAK, "speak", "خوێندنەوە بە دەنگ", COLOR_SPEAK,
            onTap = { toggleSpeak() },
            onLong = { stopSpeak() })
        regionBubble = makeItem(GlyphIcon.REGION, "region", "دیاریکردنی ڕووبەر", COLOR_REGION,
            onTap = { startRegionSelect() },
            onLong = { hideTranslation() })
        micBubble = makeItem(GlyphIcon.MIC, "mic", "قسەکردن بۆ نووسین", COLOR_MIC, onTap = { toggleDictation() })
        addDockWindow()
    }

    // ---------- قسەکردن بە کوردی ← نووسین ----------

    @Volatile
    private var fgsType = 0

    /**
     * Android 14+: ئەگەر خزمەتگوزارییەکە بێ جۆری microphone دەستی پێکردبێت (یان ڕێگەی مایک دواتر درابێت)،
     * AudioRecord دەنگی بێدەنگ دەگەڕێنێتەوە ← «هیچ قسەیەک نەبیسترا». لێرە جۆرەکە نوێ دەکەینەوە.
     */
    private fun ensureMicForeground() {
        if (Build.VERSION.SDK_INT < 30) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val cur = fgsType
        if (cur == 0 || (cur and ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) != 0) return
        try {
            val t = cur or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIF_ID, buildNotification(), t)
            fgsType = t
        } catch (t: Throwable) {
            Log.e(TAG, "mic foreground type failed", t)
        }
    }

    private fun toggleDictation() {
        if (dictating) {
            finishDictation()
            return
        }
        val localStt = (settings.offlineStt || settings.geminiTtsKey.isBlank()) && VekolStt.isReady(this)
        if (!localStt && settings.geminiTtsKey.isBlank()) {
            toast("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ، یان مۆدێلی ئۆفلاین دابەزێنە")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("ڕێگەپێدانی مایک نەدراوە. ئەپەکە بکەرەوە و دووبارە دەستپێبکەرەوە")
            return
        }
        tts.stop()
        removeResultCard()
        ensureMicForeground()
        if (!dictation.start { mainHandler.post { if (dictating) finishDictation() } }) {
            toast("مایک نەکرایەوە. ئەپێکی تر مایکی بەکاردەهێنێت؟")
            return
        }
        dictating = true
        micBubble?.background = circle(COLOR_MIC_ON)
        (micBubble as? GlyphIcon)?.kind = GlyphIcon.STOP
        beginBusy("mic", "گوێم لێتە، قسە بکە…")
        updateCommandUi()
        toast("قسە بکە بە کوردی... کۆتایی هات ■ ی سەوز دابگرە (✕ = پاشگەزبوونەوە)")
    }

    @Volatile
    private var dictToken = 0
    @Volatile
    private var lastDictPcm: ByteArray? = null
    @Volatile
    private var lastRawText: String = ""        // دەقی خاوی مۆدێل (بۆ فێربوون لە «چاک بکە»)
    @Volatile
    private var lastRawOffline = false   // دەنگی دوایین قسەکردن، بۆ «چاک بکە» تا Gemini گوێی لێ بگرێت

    private fun finishDictation() {
        ++dictToken
        dictating = false
        micBubble?.background = circle(COLOR_MIC)
        (micBubble as? GlyphIcon)?.kind = GlyphIcon.MIC
        val pcm = dictation.stop()
        lastDictPcm = pcm
        // مایک بێدەنگی گرتووە (ئەپێکی تر مایکی گرتبێت، یان ڕێگەپێدان/جۆری خزمەتگوزاری هەڵە بێت)
        if (pcm.size >= 16_000) {
            var peak = 0
            var i = 0
            while (i + 1 < pcm.size) {
                val v = Math.abs((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF))
                if (v > peak) peak = v
                i += 2
            }
            if (peak < 40) {
                endBusy()
                toastLong("مایک هیچ دەنگێکی نەگرت (تەواو بێدەنگ). ئەپەکە داخە و دووبارە بکەرەوە، و ڕێگەپێدانی مایک بپشکنە")
                return
            }
        }
        val localStt = (settings.offlineStt || settings.geminiTtsKey.isBlank()) && VekolStt.isReady(this)
        toast(if (localStt) "دەنووسرێت (ئۆفلاین)... یەکەمجار کەمێک دەخایەنێت" else "دەنووسرێت...")
        beginBusy("mic", "دەنووسرێت…")
        net.execute {
            var offlineOk = false
            val rawText = try {
                if (localStt) {
                    try {
                        var r = VekolStt.transcribe(applicationContext, pcm)
                        offlineOk = true
                        // مۆدێلی ئۆفلاین بەتاڵی گەڕاندەوە: ئەگەر کلیلی Gemini هەبێت، ئەو هەوڵ دەدات
                        if (r.isBlank() && settings.geminiTtsKey.isNotBlank()) {
                            offlineOk = false
                            r = Dictation.transcribe(pcm, settings.geminiTtsKey, settings.myNameList)
                        }
                        r
                    } catch (t: Throwable) {
                        Log.e(TAG, "offline stt failed", t)
                        if (settings.geminiTtsKey.isBlank()) throw t
                        offlineOk = false
                        Dictation.transcribe(pcm, settings.geminiTtsKey, settings.myNameList)
                    }
                } else {
                    Dictation.transcribe(pcm, settings.geminiTtsKey, settings.myNameList)
                }
            } catch (t: Throwable) {
                Log.e(TAG, "dictation failed", t)
                mainHandler.post { endBusy(); toast("سەرنەکەوت:\n" + (t.message ?: t.javaClass.simpleName).take(160)) }
                return@execute
            }
            // وشە فێربووەکان یەکسەر و بێ ئینتەرنێت لە دەقی ئۆفلاین چاک دەکرێن
            // دوای ئەوە، وشەی نزیک لە فەرهەنگی شاراوە (kurdish_vocab) ڕاست دەکرێتەوە؛ وشە فێربووەکان دەست لێ نادرێن
            val text = if (offlineOk) {
                val learned = if (settings.learnFix) KurdishLearn.apply(applicationContext, rawText) else rawText
                KurdishVocab.fix(applicationContext, learned, rawText)
            } else rawText
            lastRawText = rawText
            lastRawOffline = offlineOk
            mainHandler.post {
                endBusy()
                if (text.isBlank()) toast("هیچ قسەیەک نەبیسترا، دووبارە هەوڵبدەرەوە")
                else showResultCard(text)
            }
        }
    }

    /** کارتی دەرەنجام: دەقی نووسراو + کۆپی + خوێندنەوە + داخستن. خۆکارانە کۆپی دەکرێت. */
    private fun showResultCard(text: String) {
        removeResultCard()
        copyToClipboard(text)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6212121"))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(2), Color.parseColor("#FFB300"))
            }
        }
        // دەقی نووسراو: هەر وشەیەک دابگرە بۆ ئەوەی تەنها ئەو وشەیە بخوێنرێتەوە
        card.addView(TextView(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            textDirection = android.view.View.TEXT_DIRECTION_RTL
            highlightColor = Color.TRANSPARENT
            movementMethod = android.text.method.LinkMovementMethod.getInstance()
            this.text = wordSpans(text)
        })
        // وەرگێڕانی ئینگلیزی (بە دووگمەی EN دەردەکەوێت؛ دابگرە بۆ کۆپیکردنەوە)
        val enView = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.parseColor("#80DEEA"))
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            textDirection = android.view.View.TEXT_DIRECTION_LTR
            gravity = Gravity.START
            setPadding(0, dp(8), 0, 0)
            visibility = View.GONE
        }
        card.addView(enView)
        card.addView(TextView(this).apply {
            this.text = "نووسرا و کۆپی کرا. هەر وشەیەک دابگرە بۆ خوێندنەوەی ئەو وشەیە."
            textSize = 12f
            setTextColor(Color.parseColor("#B0BEC5"))
            setPadding(0, dp(6), 0, dp(8))
        })
        fun btn(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
            this.text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(10).toFloat() }
            setOnClickListener { onClick() }
        }
        val lp = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6); marginStart = dp(6) } }
        fun newRow() = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }

        var fixing = false
        var translating = false
        val fixLabel = "✨ چاک بکە"
        val enLabel = "🇬🇧 ئینگلیزی"
        lateinit var fixBtn: TextView
        lateinit var enBtn: TextView

        // ڕیزی یەکەم: خوێندنەوە + چاککردن بە Gemini
        val row1 = newRow()
        row1.addView(btn("🔊 بیخوێنەوە", COLOR_SPEAK) {
            tts.speak(listOf(text), onState = {}, onError = { m -> toast(m) })
        }, lp())
        fixBtn = btn(fixLabel, Color.parseColor("#6A1B9A")) {
            if (fixing) return@btn
            if (settings.geminiTtsKey.isBlank()) {
                toast("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ")
                return@btn
            }
            fixing = true
            fixBtn.text = "…"
            val src = text
            net.execute {
                val fixed = KurdishTextFix.fixManual(src, settings.geminiTtsKey, lastDictPcm, KurdishEntities.hints(applicationContext, src), settings.myNameList)
                if (fixed != null && settings.learnFix && lastRawOffline && lastRawText.isNotBlank()) KurdishLearn.learn(applicationContext, lastRawText, fixed)
                mainHandler.post {
                    fixing = false
                    if (resultCard !== card) return@post
                    fixBtn.text = fixLabel
                    when {
                        fixed == null -> toast("نەتوانرا چاک بکرێت، دووبارە هەوڵبدەرەوە")
                        fixed == src.trim() -> toast("گۆڕانکاری پێویست نەبوو")
                        else -> {
                            dictToken++   // چاککردنی خۆکاری پاشبنەما دەقە نوێیەکە نەگۆڕێتەوە
                            showResultCard(fixed)   // خۆکارانە کۆپی دەکرێت
                            toast("چاک کرا و کۆپی کرا")
                        }
                    }
                }
            }
        }
        row1.addView(fixBtn, lp())
        card.addView(row1)

        // ڕیزی دووەم: ئینگلیزی + کۆپی + داخستن
        val row2 = newRow().apply { setPadding(0, dp(8), 0, 0) }
        enBtn = btn(enLabel, Color.parseColor("#00838F")) {
            if (translating) return@btn
            translating = true
            enBtn.text = "…"
            val src = text
            net.execute {
                val en = EnglishTranslate.fromKurdish(src, settings.geminiTtsKey)
                mainHandler.post {
                    translating = false
                    if (resultCard !== card) return@post
                    enBtn.text = enLabel
                    if (en.isNullOrBlank()) {
                        toast("وەرگێڕان بۆ ئینگلیزی سەرنەکەوت، ئینتەرنێتەکەت بپشکنە")
                    } else {
                        enView.text = en
                        enView.visibility = View.VISIBLE
                        enView.setOnClickListener { copyToClipboard(en); toast("ئینگلیزییەکە کۆپی کرا") }
                        copyToClipboard(en)   // ئینگلیزییەکە ئێستا لە کلیپبۆردە، لە هەر ئەپێک دایبنێ
                        toast("ئینگلیزییەکە کۆپی کرا")
                    }
                }
            }
        }
        row2.addView(enBtn, lp())
        row2.addView(btn("کۆپی", Color.parseColor("#1565C0")) { copyToClipboard(text); toast("کۆپی کرا") }, lp())
        row2.addView(btn("✕", Color.parseColor("#C62828")) { removeResultCard() }, lp())
        card.addView(row2)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            x = 0
            y = dp(24)
            horizontalMargin = 0.03f
        }
        windowManager.addView(card, params)
        resultCard = card
    }

    /** هەر وشەیەک دەکاتە شوێنی دەستلێدان: دابگرە ← تەنها ئەو وشەیە دەخوێنرێتەوە. */
    private fun wordSpans(text: String): CharSequence {
        val sp = android.text.SpannableString(text)
        val trimChars = charArrayOf('،', '.', '؟', '?', '!', ',', ':', ';', '؛', '"', '“', '”', '«', '»', '(', ')', '…')
        Regex("\\S+").findAll(text).forEach { m ->
            val word = m.value.trim(*trimChars)
            if (word.isEmpty()) return@forEach
            sp.setSpan(object : android.text.style.ClickableSpan() {
                override fun onClick(widget: View) {
                    tts.speak(listOf(word), onState = {}, onError = { e -> toast(e) })
                }

                override fun updateDrawState(ds: android.text.TextPaint) {
                    ds.isUnderlineText = false
                    ds.color = Color.WHITE
                }
            }, m.range.first, m.range.last + 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sp
    }

    private fun removeResultCard() {
        resultCard?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        resultCard = null
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("kurdish", text))
    }

    // ---------- پانێلی شەمەندەفەر (Floating Panel) ----------
    // سێ دۆخ: EXPANDED (هەموو کۆنترۆڵەکان) · COLLAPSED (تەنها بازنەی سەرەکی) · DOCKED (تەنها هێڵێکی باریک لە لێوار)
    // دوای ماوەی دیاریکراو (لە ڕێکخستنی ئەپ) بێ بەکارهێنان، پانێلەکە خۆکارانە دەبێتە هێڵێکی باریک لە لێواری شاشە.
    // هەموو کۆنترۆڵەکان (خۆکار، وەرگێڕان، دەنگ، ڕووبەر، قسە) لە یەک پانێلدان.

    private enum class DockState { EXPANDED, COLLAPSED, DOCKED }

    private var dockRoot: LinearLayout? = null
    private var dockParams: WindowManager.LayoutParams? = null
    private var dockMain: View? = null
    private var dockMainLabel: TextView? = null
    private var dockItems: LinearLayout? = null
    private var dockChevRow: View? = null
    private var dockLine: View? = null
    private var dockState = DockState.COLLAPSED
    private var dockRestoreX = 0
    private val itemRows = HashMap<String, View>()
    private val dockRunnable = Runnable { dockNow() }

    private fun scheduleDock() {
        mainHandler.removeCallbacks(dockRunnable)
        mainHandler.postDelayed(dockRunnable, settings.dockDelaySec * 1000L)
    }

    private fun dockNow() {
        // لە کاتی تۆمارکردن، دیاریکردنی ڕووبەر یان لۆدینگ نەچنە لێوارەوە
        if (selector != null || dictating || loader != null || continuousMode) { scheduleDock(); return }
        applyDockState(DockState.DOCKED)
    }

    /** ئەستێرەکە بە جووڵەیەکی نەرم (بچووک ← گەورە) دەردەکەوێتەوە */
    private fun popStar() {
        val v = dockMain ?: return
        v.scaleX = 0.4f; v.scaleY = 0.4f; v.rotation = -90f
        v.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(380)
            .setInterpolator(android.view.animation.OvershootInterpolator(2f)).start()
    }

    private fun panelWidth() = dp(228)

    private fun applyDockState(s: DockState) {
        val root = dockRoot ?: return
        val p = dockParams ?: return
        val sw = resources.displayMetrics.widthPixels
        val prev = dockState
        dockState = s
        when (s) {
            DockState.DOCKED -> {
                if (prev != DockState.DOCKED) dockRestoreX = p.x
                val left = p.x + p.width / 2 < sw / 2
                dockMain?.visibility = View.GONE
                dockMainLabel?.visibility = View.GONE
                dockItems?.visibility = View.GONE
                dockChevRow?.visibility = View.GONE
                dockLine?.visibility = View.VISIBLE
                (dockLine?.layoutParams as? LinearLayout.LayoutParams)?.gravity =
                    if (left) Gravity.START else Gravity.END
                dockLine?.requestLayout()
                root.background = null
                root.setPadding(0, 0, 0, 0)
                p.width = dp(28)
                p.x = if (left) 0 else sw - dp(28)
            }
            DockState.COLLAPSED -> {
                if (prev != DockState.COLLAPSED) popStar()
                if (prev == DockState.DOCKED) p.x = dockRestoreX
                dockLine?.visibility = View.GONE
                dockMain?.visibility = View.VISIBLE
                dockMainLabel?.visibility = View.GONE
                dockItems?.visibility = View.GONE
                dockChevRow?.visibility = View.GONE
                root.background = null
                root.setPadding(0, 0, 0, 0)
                p.width = dp(64)
                p.x = p.x.coerceIn(0, maxOf(0, sw - dp(64)))
            }
            DockState.EXPANDED -> {
                if (prev == DockState.DOCKED) p.x = dockRestoreX
                dockLine?.visibility = View.GONE
                dockMain?.visibility = View.VISIBLE
                dockMainLabel?.visibility = View.VISIBLE
                dockItems?.visibility = View.VISIBLE
                dockChevRow?.visibility = View.VISIBLE
                // بێ پاشبنەمای گەورە: هەر بازنەیەک و هەر ناونیشانێک شووشەی تایبەت بە خۆی هەیە
                root.background = null
                root.setPadding(dp(8), dp(6), dp(14), dp(6))
                p.width = panelWidth()
                p.x = p.x.coerceIn(0, maxOf(0, sw - panelWidth()))
            }
        }
        try { windowManager.updateViewLayout(root, p) } catch (_: Exception) {}
    }

    /** پاشبنەمای شووشەیی/شلە بۆ ناونیشانەکان (پێوەندی بە پاشبنەمای هیچ پانێلێکەوە نییە) */
    private fun glassPill(tint: Int? = null): android.graphics.drawable.Drawable =
        GlassPillDrawable(resources.displayMetrics.density, tint)

    /** ڕەنگی باگراوندی نووسینی تەنیش دوگمەیەک (بەپێی ڕێکخستنی بەکارهێنەر) */
    private fun labelTint(kind: Int?): Int? = when (settings.labelMode) {
        1 -> if (kind == null) null else settings.iconColor(kind).let { if (it != 0) it else GlyphIcon.defaultColor(kind) }
        2 -> settings.labelColor
        else -> null
    }

    private fun glassLabel(text: String, size: Float, bold: Boolean = false, kind: Int? = null) = TextView(this).apply {
        this.text = text
        textSize = size
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), Color.parseColor("#CC000000"))
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(14), dp(7), dp(14), dp(7))
        background = glassPill(labelTint(kind))
    }

    private fun roundGrad(from: Int, to: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(from, to)
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(2), Color.parseColor("#B3FFFFFF"))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildDock() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        // هێڵی باریک (کاتێک لە لێوار حەشار دراوە)
        val line = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#D9FFFFFF"), Color.parseColor("#59FFFFFF"))
            ).apply {
                cornerRadius = dp(3).toFloat()
                setStroke(dp(1), Color.parseColor("#40000000"))
            }
            visibility = View.GONE
        }
        // دەستلێدان و ڕاکێشان لەسەر هێڵەکە لە ڕێگەی root وە دەگیرێت (لە خوارەوە)، تا ناوچەی دەستلێدان گەورەتر بێت
        root.addView(line, LinearLayout.LayoutParams(dp(6), dp(64)).apply {
            topMargin = dp(18); bottomMargin = dp(18)
        })

        // ڕیزی سەرەوە: بازنەی لۆگۆ + ناو
        val mainRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        // ئەستێرەی Gemini: کاتێک پانێل کەم دەکرێتەوە ئەمە دەمێنێت
        val main = GeminiStarView(this).apply { auto = continuousMode }
        mainRow.addView(main, LinearLayout.LayoutParams(dp(54), dp(54)).apply {
            topMargin = dp(5); bottomMargin = dp(5); marginStart = dp(1)
        })
        val mainLabel = glassLabel("وەڕگێڕی شاشە", 14f, true).apply { visibility = View.GONE }
        // ناوی ئەپەکە لەتەنیشت ئەستێرەکە نیشان نادرێت (تا وەک دوگمە نەبینرێت)؛ mainLabel بۆ هیچ view ێک زیاد ناکرێت
        root.addView(mainRow, LinearLayout.LayoutParams(-1, -2))

        // کۆنترۆڵەکان
        val items = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        root.addView(items, LinearLayout.LayoutParams(-1, -2))

        // کەمکردنەوەی پانێل
        val chevRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            isClickable = true
            setPadding(0, dp(5), 0, dp(5))
            setOnClickListener {
                applyDockState(DockState.COLLAPSED)
                scheduleDock()
            }
        }
        chevRow.addView(GlyphIcon(this, GlyphIcon.CHEVRON).apply {
            background = circle(Color.parseColor("#6C7BA8"))
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(6) })
        chevRow.addView(glassLabel("کەمکردنەوەی پانێڵ", 13f, kind = GlyphIcon.CHEVRON), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        root.addView(chevRow, LinearLayout.LayoutParams(-1, -2))

        dockRoot = root
        dockMain = main
        dockMainLabel = mainLabel
        dockItems = items
        dockChevRow = chevRow
        dockLine = line

        val params = WindowManager.LayoutParams(
            dp(64), WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(160)
        }
        dockParams = params

        // کێشان + دەستلێدان لەسەر بازنەی سەرەکی: دەستلێدان = کردنەوە/داخستنی پانێل
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        val slop = dp(8)
        mainRow.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    mainHandler.removeCallbacks(dockRunnable)
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        applyDockState(
                            if (dockState == DockState.EXPANDED) DockState.COLLAPSED else DockState.EXPANDED
                        )
                    }
                    scheduleDock()
                    true
                }
                MotionEvent.ACTION_CANCEL -> { scheduleDock(); true }
                else -> false
            }
        }
    }

    /**
     * کاتێک پانێلەکە بووە هێڵێکی باریک لە لێوار: دەستلێدان یان ڕاکێشانی هێڵەکە بەرەو ناوەڕاستی شاشە
     * پانێلەکە دەهێنێتەوە (لەژێر پەنجەکەتدا دەجووڵێت و کاتێک ڕەهایی دەکەیت دەکرێتەوە).
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun installEdgeDrag() {
        val root = dockRoot ?: return
        val params = dockParams ?: return
        val sw = resources.displayMetrics.widthPixels
        var down = false
        var drag = false
        var lx = 0f
        var ly = 0f
        root.setOnTouchListener { _, e ->
            if (dockState != DockState.DOCKED && !drag) return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    mainHandler.removeCallbacks(dockRunnable)
                    lx = e.rawX; ly = e.rawY
                    down = true; drag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!down) return@setOnTouchListener false
                    if (!drag && (Math.abs(e.rawX - lx) > dp(10) || Math.abs(e.rawY - ly) > dp(10))) {
                        drag = true
                        applyDockState(DockState.COLLAPSED)
                    }
                    if (drag) {
                        params.x = (e.rawX - dp(32)).toInt().coerceIn(0, maxOf(0, sw - dp(64)))
                        params.y = (e.rawY - dp(32)).toInt().coerceAtLeast(0)
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val wasDown = down
                    down = false
                    drag = false
                    if (wasDown) applyDockState(DockState.EXPANDED)
                    scheduleDock()
                    true
                }
                else -> false
            }
        }
    }

    private fun addDockWindow() {
        val root = dockRoot ?: return
        val p = dockParams ?: return
        installEdgeDrag()
        try { windowManager.addView(root, p) } catch (_: Exception) {}
        applyDockState(DockState.EXPANDED)
        scheduleDock()
    }

    /** یەک کۆنترۆڵی پانێل: بازنەی ئایکۆنی ڤێکتەر + ناونیشان. دەگەڕێنێتەوە ئایکۆنەکە (بۆ گۆڕینی ڕەنگ/دۆخ). */
    private fun makeItem(
        kind: Int,
        key: String,
        label: String,
        color: Int,
        onTap: () -> Unit,
        onLong: (() -> Unit)? = null
    ): GlyphIcon {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
            isClickable = true
            setOnClickListener { onTap(); scheduleDock() }
            if (onLong != null) setOnLongClickListener { onLong(); scheduleDock(); true }
        }
        val icon = GlyphIcon(this, kind).apply { background = circle(color) }
        // کەوانەیەکی نەرم: هەر ڕیزێک کەمێک لە ڕیزی پێشوو دەگۆڕدرێت
        val arc = intArrayOf(0, 8, 14, 18, 14, 8, 0)
        val shift = arc[(dockItems?.childCount ?: 0) % arc.size]
        row.addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(5 + shift) })
        row.addView(glassLabel(label, 14f, kind = kind), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        dockItems?.addView(row, LinearLayout.LayoutParams(-2, -2))
        itemRows[key] = row
        return icon
    }

    // ---------- لۆدینگی ستایلی Gemini ----------

    private var loader: GeminiLoader? = null
    private var loaderParams: WindowManager.LayoutParams? = null
    // ---------- ئازادکردنی مۆدێلەکان لە ڕام کاتی بێکاری (کەمکردنەوەی پاتری/ڕام) ----------

    private var lastModelUse = SystemClock.elapsedRealtime()

    /** هەر کاتێک فەرمانێک دەست پێدەکات بانگ دەکرێت؛ تایمەری ٢ خولەکی بێکاری نوێ دەکاتەوە. */
    private fun touchModels() {
        lastModelUse = SystemClock.elapsedRealtime()
        mainHandler.removeCallbacks(idleModelRelease)
        mainHandler.postDelayed(idleModelRelease, MODEL_IDLE_MS)
    }

    private val idleModelRelease = object : Runnable {
        override fun run() {
            // ئەگەر هێشتا کار دەکات، دووبارە ٢ خولەک چاوەڕێ بکە
            if (continuousMode || dictating || commandActive()) { touchModels(); return }
            val idle = SystemClock.elapsedRealtime() - lastModelUse
            if (idle < MODEL_IDLE_MS) { mainHandler.postDelayed(this, MODEL_IDLE_MS - idle); return }
            // مۆدێلەکان دواتر خۆکارانە دووبارە بار دەبنەوە کاتێک پێویست بن
            Thread {
                try { VekolStt.release() } catch (_: Throwable) {}
                try { TessOcr.release() } catch (_: Throwable) {}
                try { tts.releaseModels() } catch (_: Throwable) {}
            }.start()
        }
    }

    private val busyTimeout = Runnable { endBusy() }

    /** لەسەر main thread بانگ بکە. لۆدینگێکی جوان لەتەنیشت ئەو کۆنترۆڵەوە نیشان دەدات کە چالاک کراوە. */
    private fun beginBusy(key: String, label: String) {
        touchModels()
        mainHandler.removeCallbacks(busyTimeout)
        val existing = loader
        if (existing != null) {
            existing.label = label
            existing.invalidate()
            positionLoader(key)
            try { windowManager.updateViewLayout(existing, loaderParams) } catch (_: Exception) {}
        } else {
            val lv = GeminiLoader(this, label)
            val p = WindowManager.LayoutParams(
                dp(220), dp(54),
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            loader = lv
            loaderParams = p
            positionLoader(key)
            try { windowManager.addView(lv, p) } catch (_: Exception) { loader = null }
        }
        mainHandler.postDelayed(busyTimeout, 45000)
    }

    private fun positionLoader(key: String) {
        val p = loaderParams ?: return
        val dp0 = dockParams ?: return
        val sw = resources.displayMetrics.widthPixels
        val lw = dp(220)
        val lh = dp(54)
        val panelW = if (dockState == DockState.DOCKED) dp(28) else dp0.width
        val onLeft = dp0.x + panelW / 2 < sw / 2
        p.x = (if (onLeft) dp0.x + panelW + dp(6) else dp0.x - lw - dp(6)).coerceIn(0, maxOf(0, sw - lw))
        val anchor: View? = if (dockState == DockState.EXPANDED) itemRows[key] ?: dockMain else dockMain
        var y = dp0.y + dp(10)
        if (anchor != null && anchor.isShown && anchor.height > 0) {
            val loc = IntArray(2)
            anchor.getLocationOnScreen(loc)
            y = loc[1] + anchor.height / 2 - lh / 2
        }
        p.y = y
    }

    private fun endBusy() {
        mainHandler.removeCallbacks(busyTimeout)
        loader?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        loader = null
        loaderParams = null
    }

    /** پانێلەکە دووبارە زیاد دەکرێت بۆ ئەوەی لەسەروو ئۆڤەرلەیەکەوە بێت. */
    private fun bringBubbleToFront() {
        val root = dockRoot ?: return
        val p = dockParams ?: return
        try {
            windowManager.removeView(root)
            windowManager.addView(root, p)
        } catch (_: Exception) {
        }
        val cv = cancelView
        val cp = cancelParams
        if (cv != null && cp != null) {
            try {
                windowManager.removeView(cv)
                windowManager.addView(cv, cp)
            } catch (_: Exception) {
            }
        }
        val sv = stopView
        val sp = stopParams
        if (sv != null && sp != null) {
            try {
                windowManager.removeView(sv)
                windowManager.addView(sv, sp)
            } catch (_: Exception) {
            }
        }
        val lv = loader
        val lp = loaderParams
        if (lv != null && lp != null) {
            try {
                windowManager.removeView(lv)
                windowManager.addView(lv, lp)
            } catch (_: Exception) {
            }
        }
    }

    private fun removeBubbles() {
        mainHandler.removeCallbacks(dockRunnable)
        endBusy()
        dockRoot?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        dockRoot = null
        dockParams = null
        dockMain = null
        dockMainLabel = null
        dockItems = null
        dockChevRow = null
        dockLine = null
        itemRows.clear()
        bubble = null
        transBubble = null
        speakBubble = null
        regionBubble = null
        micBubble = null
    }

    // ---------- ئاگادارکردنەوە ----------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "مانگا وەرگێڕ",
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("مانگا وەرگێڕ کار دەکات")
            .setContentText("وەرگێڕانی خۆکار · وەرگێڕان · دەنگ · ڕووبەر · قسە")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null, "وەستاندن", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    // ---------- دۆخی فەرمان: بابلەکان دەشاردرێنەوە و تەنها ئایکۆنی پاشگەزبوونەوە دەمێنێت ----------

    private var cancelView: View? = null
    private var cancelIsAuto = false
    private var cancelParams: WindowManager.LayoutParams? = null
    private var cmdShown = false
    private var scrollWatcher: ScrollWatcher? = null
    private val uiTick = object : Runnable {
        override fun run() {
            updateCommandUi()
            mainHandler.postDelayed(this, 300)
        }
    }

    /** ئایا فەرمانێک کار دەکات یان دەرەنجامی فەرمانێک لەسەر شاشەیە */
    private fun commandActive(): Boolean =
        // لە دۆخی خۆکار پانێلەکە (ئەستێرەی مۆر + ناوی ئەپەکە) ناشاردرێتەوە
        if (continuousMode) selector != null || dictating || tts.speaking
        else selector != null || dictating || loader != null || tts.speaking || overlay?.hasBoxes() == true

    private fun updateCommandUi() {
        val active = commandActive()
        if (!active && scrollWatcher != null && !continuousMode) stopScrollWatch()
        // ئەگەر جۆری دوگمەی پاشگەزبوونەوە گۆڕا (✕ ↔ ئەستێرەی مۆر)، دووبارە دروستی بکەرەوە
        if (active && cmdShown && cancelView != null && cancelIsAuto != continuousMode) removeCancel().also { showCancel() }
        if (active == cmdShown) { syncStop(active); return }
        cmdShown = active
        if (active) {
            mainHandler.removeCallbacks(dockRunnable)
            if (dockState != DockState.COLLAPSED) applyDockState(DockState.COLLAPSED)
            dockRoot?.visibility = View.GONE
            showCancel()
        } else {
            removeCancel()
            dockRoot?.visibility = View.VISIBLE
            scheduleDock()
        }
        syncStop(active)
    }

    /** دوگمەی تەواوکردن (■) تەنها لە کاتی قسەکردن بۆ نووسین */
    private fun syncStop(active: Boolean) { if (active && dictating) showStop() else removeStop() }

    @SuppressLint("ClickableViewAccessibility")
    private fun showCancel() {
        if (cancelView != null) return
        val dp0 = dockParams ?: return
        val sw = resources.displayMetrics.widthPixels
        val autoStar = continuousMode
        val v: View = if (autoStar) {
            // وەرگێڕانی خۆکار کارایە: ئەستێرەی Gemini ی مۆر + ✓ ؛ دەستلێدان = وەستاندن
            GeminiStarView(this).apply {
                auto = true
                isClickable = true
                setOnClickListener { cancelAll() }
            }
        } else GlyphIcon(this, GlyphIcon.CLOSE).apply {
            background = circle(Color.parseColor("#E5484D"))
            isClickable = true
            setOnClickListener { cancelAll() }
        }
        cancelIsAuto = autoStar
        val size = if (autoStar) dp(58) else dp(46)
        val p = WindowManager.LayoutParams(
            size, size,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (dp0.x + dp(8)).coerceIn(0, maxOf(0, sw - size))
            y = dp0.y + dp(8)
        }
        try {
            windowManager.addView(v, p)
            cancelView = v
            cancelParams = p
        } catch (_: Exception) {}
    }

    private fun removeCancel() {
        removeStop()
        cancelView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        cancelView = null
        cancelParams = null
    }

    private var stopView: GlyphIcon? = null
    private var stopParams: WindowManager.LayoutParams? = null

    /** ■ : قسەکردن تەواو بکە و بیکە بە نووسین (✕ تەنها پاشگەزبوونەوەیە) */
    private fun showStop() {
        if (stopView != null) return
        val cp = cancelParams ?: return
        val sw = resources.displayMetrics.widthPixels
        val size = dp(46)
        val v = GlyphIcon(this, GlyphIcon.STOP).apply {
            background = GlassOrbDrawable(Color.parseColor("#1FBF6A"), resources.displayMetrics.density)
            isClickable = true
            setOnClickListener { if (dictating) finishDictation() }
        }
        val p = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // لای ڕاستی ✕ ؛ ئەگەر شوێن نەبوو لای چەپی
            val right = cp.x + size + dp(8)
            x = if (right + size <= sw) right else (cp.x - size - dp(8)).coerceAtLeast(0)
            y = cp.y
        }
        try {
            windowManager.addView(v, p)
            stopView = v
            stopParams = p
        } catch (_: Exception) {}
    }

    private fun removeStop() {
        stopView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        stopView = null
        stopParams = null
    }

    /** پاشگەزبوونەوە لە هەموو فەرمانێک: وەرگێڕان، خوێندنەوە، قسەکردن، ڕووبەر، وەرگێڕانی خۆکار */
    private fun cancelAll() {
        if (continuousMode) toggleContinuousMode()
        removeSelector()
        if (dictating) {
            dictating = false
            dictToken++
            try { dictation.cancel() } catch (_: Throwable) {}
            micBubble?.background = circle(COLOR_MIC)
            (micBubble as? GlyphIcon)?.kind = GlyphIcon.MIC
        }
        stopScrollWatch()
        tts.stop()
        speakBubble?.background = circle(COLOR_SPEAK)
        removeResultCard()
        manualRun++
        endBusy()
        removeOverlay()
        updateCommandUi()
    }

    // ---------- شاردنەوەی وەرگێڕان بە جوڵاندنی شاشە ----------

    private fun startScrollWatch() {
        if (continuousMode) return
        val cap = capturer ?: return
        val w = ScrollWatcher { mainHandler.post { scrolledAway() } }
        scrollWatcher = w
        cap.frameListener = { bmp ->
            val cur = scrollWatcher
            if (cur != null) cur.onFrame(bmp) else bmp.recycle()
        }
    }

    private fun stopScrollWatch() {
        if (scrollWatcher == null) return
        scrollWatcher = null
        if (!continuousMode) capturer?.frameListener = null
    }

    private fun scrolledAway() {
        if (scrollWatcher == null) return
        stopScrollWatch()
        tts.stop()
        speakBubble?.background = circle(COLOR_SPEAK)
        manualRun++
        endBusy()
        removeOverlay()
        updateCommandUi()
    }

    // ---------- یارمەتیدەرەکان ----------

    /** بازنەی Liquid Glass بە ڕەنگی دیاریکراو (GlassOrbDrawable) */
    private fun circle(color: Int): android.graphics.drawable.Drawable =
        GlassOrbDrawable(
            color, resources.displayMetrics.density,
            active = color == COLOR_ON || color == COLOR_SPEAK_ON || color == COLOR_MIC_ON
        )

    private fun lighten(color: Int): Int {
        val f = 0.30f
        return Color.rgb(
            (Color.red(color) + (255 - Color.red(color)) * f).toInt(),
            (Color.green(color) + (255 - Color.green(color)) * f).toInt(),
            (Color.blue(color) + (255 - Color.blue(color)) * f).toInt()
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun toastLong(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val MODEL_IDLE_MS = 2 * 60 * 1000L
        @Volatile
        var instance: OverlayService? = null

        private const val TAG = "OverlayService"
        const val ACTION_START = "com.mangatranslator.app.START"
        const val ACTION_STOP = "com.mangatranslator.app.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_USE_A11Y = "use_a11y"

        private const val CHANNEL_ID = "manga_translator"
        private const val NOTIF_ID = 42
        private val COLOR_OFF = Color.parseColor("#3B4A6B")
        private val COLOR_ON = Color.parseColor("#1FBF6A")
        private val COLOR_TRANSLATE = Color.parseColor("#1E90FF")
        private val COLOR_REGION = Color.parseColor("#0FB5D6")
        private val COLOR_MIC = Color.parseColor("#E0307A")
        private val COLOR_MIC_ON = Color.parseColor("#FF2D3D")
        private val COLOR_SPEAK = Color.parseColor("#6C4CF0")
        private val COLOR_SPEAK_ON = Color.parseColor("#FF8A1F")
        private const val MANUAL_DELAY_MS = 350L
        private const val REGION_DELAY_MS = 120L
        private const val DOCK_HIDE_MS = 220L
        private const val HIDE_DELAY_MS = 1500L
    }
}
