package com.mangatranslator.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * خزمەتگوزاری پێشەوە (foreground service) کە:
 *  - دوو بابلی شەمەندەفەر پیشان دەدات:
 *      ک  = وەرگێڕانی خۆکار (Continuous Mode) چالاک/ناچالاک
 *      وەر = وەرگێڕانی شاشەی ئێستا بە دەستی (درێژ بگرە = شاردنەوەی وەرگێڕان)
 *  - شاشە دەگرێت، OCR دەکات، بە Google دەیکات بە سۆرانی و لەسەر بابلەکان نیشانی دەدات
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var transBubble: TextView? = null
    private var transBubbleParams: WindowManager.LayoutParams? = null
    private var speakBubble: TextView? = null
    private var speakBubbleParams: WindowManager.LayoutParams? = null
    private var overlay: OverlayView? = null
    private var capturer: ScreenCapturer? = null
    private var watcher: PageWatcher? = null

    private val ocr: OcrEngine by lazy { OcrEngine() }
    private val settings: TranslatorSettings by lazy { TranslatorSettings(this) }
    private val tts: SoraniTts by lazy { SoraniTts(this, settings) }
    /** چەند بابل پێکەوە وەردەگێڕدرێن */
    private val net = Executors.newFixedThreadPool(6)

    @Volatile
    private var continuousMode = false
    /** هەر وەرگێڕانێکی دەستی ژمارەیەکی نوێ وەردەگرێت؛ کارە کۆنەکان خۆیان دەوەستێنن */
    @Volatile
    private var manualRun = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // دەبێت پێش وەرگرتنی MediaProjection، startForeground بە جۆری mediaProjection بانگ بکرێت
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (capturer == null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection: MediaProjection = mpm.getMediaProjection(resultCode, data)
            capturer = ScreenCapturer(
                context = this,
                projection = projection,
                onFirstFrame = {
                    mainHandler.post { toast("شاشە دەگیرێت ✓") }
                },
                onProjectionStopped = {
                    mainHandler.post { stopSelf() }
                }
            )
        }

        capturer?.start()
        if (bubble == null) showBubbles()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        continuousMode = false
        stopContinuousMode()
        removeBubbles()
        capturer?.release()
        capturer = null
        net.shutdownNow()
        tts.shutdown()
        try {
            ocr.close()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    // ---------- Continuous Mode ----------

    private fun toggleContinuousMode() {
        manualRun++
        if (!continuousMode) {
            continuousMode = true
            startContinuousMode()
            bubble?.background = circle(COLOR_ON)
            toast("وەرگێڕانی خۆکار: چالاکە")
        } else {
            continuousMode = false
            stopContinuousMode()
            bubble?.background = circle(COLOR_OFF)
            toast("وەرگێڕانی خۆکار: ناچالاکە")
        }
    }

    private fun startContinuousMode() {
        addOverlay()

        lateinit var w: PageWatcher
        w = PageWatcher(
            ocr = ocr,
            onClear = {
                mainHandler.post {
                    overlay?.clear()
                    w.notifyOverlayUpdated()
                }
            },
            onBoxes = { boxes, fw, fh, gen ->
                translateBoxes(
                    boxes, fw, fh,
                    alive = { continuousMode && w.isCurrent(gen) },
                    onChanged = { w.notifyOverlayUpdated() }
                )
            }
        )
        watcher = w

        capturer?.frameListener = { bmp ->
            val current = watcher
            if (current != null) current.onFrame(bmp) else bmp.recycle()
        }
    }

    private fun stopContinuousMode() {
        // VirtualDisplay دەمێنێتەوە (بۆ دوگمەی دەستی)؛ تەنها گوێگرەکە لادەبرێت
        capturer?.frameListener = null
        watcher?.reset()
        watcher = null
        removeOverlay()
    }

    // ---------- وەرگێڕانی دەستی ----------

    private fun translateNow() {
        val cap = capturer ?: return
        if (continuousMode) {
            watcher?.forceRescan()
            toast("وەرگێڕان...")
            return
        }

        val run = ++manualRun
        addOverlay()
        val hadBoxes = overlay?.hasBoxes() == true
        overlay?.clear()
        toast("وەرگێڕان...")

        // ئەگەر وەرگێڕانی کۆن لەسەر شاشە بوو، کەمێک چاوەڕێ دەکەین تا لە وێنەکە نەمێنێت
        cap.requestFrame(if (hadBoxes) MANUAL_DELAY_MS else 0L) { bmp ->
            mainHandler.post {
                if (run != manualRun) {
                    bmp?.recycle()
                    return@post
                }
                if (bmp == null) {
                    toast("شاشە نەگیرا، دووبارە هەوڵبدەرەوە")
                    return@post
                }
                val fw = bmp.width
                val fh = bmp.height
                ocr.recognize(bmp) { boxes ->
                    bmp.recycle()
                    if (run == manualRun) {
                        if (boxes.isEmpty()) toast("هیچ دەقێک نەدۆزرایەوە")
                        else translateBoxes(
                            boxes, fw, fh,
                            alive = { run == manualRun },
                            onChanged = {},
                            speakWhenDone = true
                        )
                    }
                }
            }
        }
    }

    private fun hideTranslation() {
        tts.stop()
        speakBubble?.background = circle(COLOR_SPEAK)
        manualRun++
        if (continuousMode) {
            overlay?.clear()
            watcher?.notifyOverlayUpdated()
        } else {
            removeOverlay()
        }
        toast("وەرگێڕان شاردرایەوە")
    }

    /**
     * لەسەر main thread بانگ دەکرێت. هەموو بابلەکان دەستبەجێ بە "…" نیشان دەدرێن، پاشان هەموویان
     * پێکەوە (بە پارالێل) دەنێردرێن بۆ Google و هەر کامیان تەواو بوو لەسەر شاشە دەگۆڕدرێت.
     */
    private fun translateBoxes(
        boxes: List<TextBox>,
        fw: Int,
        fh: Int,
        alive: () -> Boolean,
        onChanged: () -> Unit,
        speakWhenDone: Boolean = false
    ) {
        if (boxes.isEmpty() || !alive()) return

        val shown = ArrayList<TextBox>(boxes.map { TextBox(it.rect, "…") })
        overlay?.setBoxes(ArrayList(shown), fw, fh)
        onChanged()
        var remaining = boxes.size

        val key = settings.googleKey
        val errorShown = AtomicBoolean(false)
        for ((i, b) in boxes.withIndex()) {
            net.execute {
                if (!alive()) return@execute
                val tr = try {
                    GoogleTranslator.translateBubble(b.text, key)
                } catch (t: Throwable) {
                    Log.e(TAG, "translate failed", t)
                    if (errorShown.compareAndSet(false, true)) {
                        val why = (t.message ?: t.javaClass.simpleName).take(160)
                        mainHandler.post { toast("وەرگێڕان سەرنەکەوت:\n$why") }
                    }
                    null
                }
                mainHandler.post {
                    if (!alive()) return@post
                    shown[i] = TextBox(b.rect, tr ?: "؟")
                    overlay?.setBoxes(ArrayList(shown), fw, fh)
                    onChanged()
                    remaining--
                    if (remaining == 0 && speakWhenDone && settings.autoSpeak) {
                        val texts = overlay?.spokenTexts().orEmpty()
                        if (texts.isNotEmpty()) {
                            tts.speak(
                                texts,
                                onState = { on ->
                                    speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
                                },
                                onError = { msg -> toast(msg) }
                            )
                        }
                    }
                }
            }
        }
    }

    // ---------- خوێندنەوەی دەنگی ----------

    /** دەستلێدان: دەقە وەرگێڕدراوەکانی شاشە دەخوێنێتەوە. ئەگەر دەیخوێنێتەوە، دەیوەستێنێت. */
    private fun toggleSpeak() {
        if (tts.speaking) {
            stopSpeak()
            return
        }
        val texts = overlay?.spokenTexts().orEmpty()
        if (texts.isEmpty()) {
            toast("سەرەتا شاشە وەربگێڕە (وەر)، پاشان دەنگ")
            return
        }
        tts.speak(
            texts,
            onState = { on ->
                speakBubble?.background = circle(if (on) COLOR_SPEAK_ON else COLOR_SPEAK)
            },
            onError = { msg -> toast(msg) }
        )
    }

    private fun stopSpeak() {
        tts.stop()
        speakBubble?.background = circle(COLOR_SPEAK)
        toast("خوێندنەوە وەستا")
    }

    // ---------- ئۆڤەرلەی تەواوی شاشە ----------

    private fun addOverlay() {
        if (overlay != null) return

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val view = OverlayView(this)
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        windowManager.addView(view, params)
        overlay = view
        bringBubbleToFront()
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    // ---------- بابلەکانی شەمەندەفەر ----------

    private fun showBubbles() {
        val (b1, p1) = makeBubble("ک", COLOR_OFF, dp(8), dp(220), onTap = { toggleContinuousMode() })
        bubble = b1
        bubbleParams = p1
        val (b2, p2) = makeBubble(
            "وەر", COLOR_TRANSLATE, dp(8), dp(290),
            onTap = { translateNow() },
            onLong = { hideTranslation() }
        )
        transBubble = b2
        transBubbleParams = p2
        val (b3, p3) = makeBubble(
            "دەنگ", COLOR_SPEAK, dp(8), dp(360),
            onTap = { toggleSpeak() },
            onLong = { stopSpeak() }
        )
        speakBubble = b3
        speakBubbleParams = p3
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeBubble(
        label: String,
        color: Int,
        x0: Int,
        y0: Int,
        onTap: () -> Unit,
        onLong: (() -> Unit)? = null
    ): Pair<TextView, WindowManager.LayoutParams> {
        val size = dp(56)

        val view = TextView(this).apply {
            text = label
            textSize = if (label.length > 1) 16f else 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = circle(color)
            alpha = 0.9f
        }

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = x0
            y = y0
        }

        // کێشان (drag)، دەستلێدان (tap) و گرتنی درێژ (long press)
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var longFired = false
        val slop = dp(8)
        val longRunnable = Runnable {
            if (!moved && onLong != null) {
                longFired = true
                onLong()
            }
        }

        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    longFired = false
                    if (onLong != null) mainHandler.postDelayed(longRunnable, 600)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                        moved = true
                        mainHandler.removeCallbacks(longRunnable)
                    }
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        windowManager.updateViewLayout(v, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    mainHandler.removeCallbacks(longRunnable)
                    if (!moved && !longFired) onTap()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longRunnable)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, params)
        return view to params
    }

    /** بابلەکان دووبارە زیاد دەکرێن بۆ ئەوەی لەسەروو ئۆڤەرلەیەکەوە بن. */
    private fun bringBubbleToFront() {
        for ((v, p) in listOf(
            bubble to bubbleParams,
            transBubble to transBubbleParams,
            speakBubble to speakBubbleParams
        )) {
            if (v == null || p == null) continue
            try {
                windowManager.removeView(v)
                windowManager.addView(v, p)
            } catch (_: Exception) {
            }
        }
    }

    private fun removeBubbles() {
        for (v in listOf(bubble, transBubble, speakBubble)) {
            if (v == null) continue
            try {
                windowManager.removeView(v)
            } catch (_: Exception) {
            }
        }
        bubble = null
        bubbleParams = null
        transBubble = null
        transBubbleParams = null
        speakBubble = null
        speakBubbleParams = null
    }

    // ---------- ئاگادارکردنەوە ----------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "مانگا وەرگێڕ",
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("مانگا وەرگێڕ کار دەکات")
            .setContentText("ک = خۆکار  |  وەر = وەرگێڕان  |  دەنگ = خوێندنەوە")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null, "وەستاندن", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    // ---------- یارمەتیدەرەکان ----------

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(dp(2), Color.WHITE)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val TAG = "OverlayService"
        const val ACTION_START = "com.mangatranslator.app.START"
        const val ACTION_STOP = "com.mangatranslator.app.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"

        private const val CHANNEL_ID = "manga_translator"
        private const val NOTIF_ID = 42
        private val COLOR_OFF = Color.parseColor("#78909C")
        private val COLOR_ON = Color.parseColor("#2E7D32")
        private val COLOR_TRANSLATE = Color.parseColor("#1565C0")
        private val COLOR_SPEAK = Color.parseColor("#6A1B9A")
        private val COLOR_SPEAK_ON = Color.parseColor("#E65100")
        private const val MANUAL_DELAY_MS = 350L
    }
}
