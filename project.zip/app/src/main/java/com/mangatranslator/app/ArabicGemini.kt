package com.mangatranslator.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * وەرگێڕانی دەقی عەرەبی ← سۆرانی بە Gemini (زۆر باشتر لە Google Translate بۆ عەرەبی).
 * هەموو دەقە دۆزراوەکانی شاشە لە یەک داواکاریدا دەنێردرێن، بۆ ئەوەی Gemini ناوەڕۆکی هەموو پەڕەکە ببینێت
 * (ناوەکان و واتا یەکدەگرنەوە) و خێراتریش بێت.
 * لە thread ی پاشبنەما بانگ بکرێت. هەڵە دەگەڕێنێتەوە ئەگەر شکستی هێنا (بانگکەر دەتوانێت Google بەکاربهێنێت).
 */
object ArabicGemini {

    private const val PROMPT =
        "You translate Arabic text that was read from a phone screen by OCR (manga, webtoon, game, chat, video subtitles, app or web page) " +
            "into natural, fluent, SPOKEN Central Kurdish (Sorani, Arabic script). " +
            "The input is a JSON array of strings; each string is one separate text block, in screen order, so use the other blocks as context. " +
            "The Arabic may be Modern Standard Arabic or any dialect (Egyptian, Gulf, Levantine, Iraqi, Maghrebi...), and may have small OCR mistakes or missing diacritics: infer the intended meaning. " +
            "Translate the MEANING, not word by word; keep the tone (casual, angry, formal, funny). " +
            "Use correct Sorani letters (ی ک ە ێ ۆ ڵ ڕ ڤ), never Persian/Arabic ي ك ى. " +
            "Keep names consistent as Kurdish-script transliterations. Keep numbers, emoji and Latin-script words as they are. " +
            "If a block is already Sorani Kurdish, copy it unchanged. " +
            "Return ONLY a JSON array of strings with EXACTLY the same number of items, in the same order. " +
            "Never merge, split, skip or add items; if a block is meaningless noise, return it as an empty string.\n\nInput:\n"

    private val cache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 500
    }

    /** دەگەڕێتەوە لیستێک بە درێژیی هاوشێوەی `texts`. بەتاڵ = ئەو دەقە وەرنەگێڕدرا. */
    fun translate(texts: List<String>, keysRaw: String, fast: Boolean): List<String> {
        if (texts.isEmpty()) return emptyList()
        if (keysRaw.isBlank()) throw IOException("no Gemini key")
        val clean = texts.map { it.replace('\n', ' ').replace(Regex("\\s+"), " ").trim() }

        val result = arrayOfNulls<String>(clean.size)
        val todo = ArrayList<Int>()
        synchronized(cache) {
            for ((i, t) in clean.withIndex()) {
                val hit = cache[t]
                if (hit != null) result[i] = hit else todo.add(i)
            }
        }
        if (todo.isNotEmpty()) {
            val src = todo.map { clean[it] }
            val got = GeminiKeys.withKeys(keysRaw) { key ->
                GeminiModels.call(fast) { m, think -> post(body(src, m, think), key, m) }
            }
            val arr = parse(got, src.size)
            synchronized(cache) {
                for ((k, i) in todo.withIndex()) {
                    val out = TextPrep.fixSorani(arr[k])
                    result[i] = out
                    if (out.isNotBlank()) cache[clean[i]] = out
                }
            }
        }
        return result.map { it ?: "" }
    }

    private fun parse(raw: String, expected: Int): List<String> {
        val t = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = try {
            JSONArray(t)
        } catch (_: Exception) {
            throw IOException("Gemini JSON هەڵەیە")
        }
        if (a.length() != expected) throw IOException("Gemini ژمارەی دەقەکانی گۆڕی (${a.length()}/$expected)")
        return List(expected) { a.optString(it, "") }
    }

    private fun body(src: List<String>, model: String, think: Boolean): String {
        val gen = JSONObject()
            .put("temperature", 0.3)
            .put("maxOutputTokens", 4096)
            .put("responseMimeType", "application/json")
            .put(
                "responseSchema",
                JSONObject().put("type", "ARRAY").put("items", JSONObject().put("type", "STRING"))
            )
        if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
        val input = JSONArray().also { a -> src.forEach { a.put(it) } }.toString()
        return JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", PROMPT + input)))
                )
            )
            .put("generationConfig", gen)
            .toString()
    }

    private fun post(body: String, key: String, model: String): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8_000
            c.readTimeout = 25_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try {
                    JSONObject(resp).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    resp
                }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            return try {
                val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").optJSONArray("parts")
                val sb = StringBuilder()
                if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
                sb.toString()
            } catch (_: Exception) {
                throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
            }
        } finally {
            c.disconnect()
        }
    }
}
