package com.mangatranslator.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.util.Log

/**
 * وەرگێڕانی ئۆفلاین ئینگلیزی → سۆرانی بە NLLB-200 (distilled 600M).
 *
 * decoder بێ KV-cache کار دەکات (هەموو هەنگاوێک هەموو پێشگرەکە دووبارە دەژمێرێت): ئاسانترە و کاردەکات،
 * بەڵام هێواشترە لە وەشانی cache دار. لە داهاتوودا دەتوانین بیگۆڕین.
 *
 * هەموو بانگەکان دەبێت لە یەک thread ی پاشبنەما بن.
 */
class Translator(private val store: ModelStore) {

    private var env: OrtEnvironment? = null
    private var encoder: OrtSession? = null
    private var decoder: OrtSession? = null
    private var tok: NllbTokenizer? = null

    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean =
            size > 300
    }

    val isLoaded: Boolean get() = decoder != null

    @Synchronized
    fun translate(raw: String): String? {
        val text = TextPrep.prepare(raw)
        if (text.length < 2) return null
        cache[text]?.let { return it }

        ensureLoaded()
        val out = TextPrep.fixSorani(generate(text))
        if (out.isBlank()) return null
        cache[text] = out
        return out
    }

    @Synchronized
    fun close() {
        try {
            encoder?.close()
            decoder?.close()
        } catch (_: Exception) {
        }
        encoder = null
        decoder = null
        tok = null
    }

    private fun ensureLoaded() {
        if (decoder != null && encoder != null && tok != null) return
        Log.d(TAG, "loading model...")
        val e = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 6))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val t = NllbTokenizer(store.tokenizerFile)
        val enc = e.createSession(store.encoderFile.absolutePath, opts)
        val dec = e.createSession(store.decoderFile.absolutePath, opts)
        Log.d(TAG, "encoder inputs=${enc.inputNames} outputs=${enc.outputNames}")
        Log.d(TAG, "decoder inputs=${dec.inputNames} outputs=${dec.outputNames}")
        env = e
        tok = t
        encoder = enc
        decoder = dec
        Log.d(TAG, "model loaded")
    }

    private fun generate(text: String): String {
        val e = env!!
        val t = tok!!
        val enc = encoder!!
        val dec = decoder!!

        val srcIds = t.encode(text, SRC_LANG)
        val tgtLangId = t.langId(TGT_LANG)
        val n = srcIds.size

        val idsTensor = OnnxTensor.createTensor(e, arrayOf(srcIds))
        val maskTensor = OnnxTensor.createTensor(e, arrayOf(LongArray(n) { 1L }))
        try {
            val encInputs = HashMap<String, OnnxTensor>()
            encInputs["input_ids"] = idsTensor
            if ("attention_mask" in enc.inputNames) encInputs["attention_mask"] = maskTensor

            enc.run(encInputs).use { encOut ->
                val hidden = encOut.get(0) as OnnxTensor
                val decNames = dec.inputNames

                // decoder دەست پێ دەکات بە [</s>, نیشانەی زمانی ئامانج]
                val generated = ArrayList<Int>()
                generated.add(NllbTokenizer.EOS)
                generated.add(tgtLangId)

                val maxNew = minOf(MAX_NEW_TOKENS, n * 2 + 16)
                // ڕێگری لە دووبارەبوونەوەی سێ-تۆکن (no-repeat-trigram)
                val seen = HashMap<Long, HashSet<Int>>()

                for (step in 0 until maxNew) {
                    val prefix = LongArray(generated.size) { generated[it].toLong() }
                    val inTensor = OnnxTensor.createTensor(e, arrayOf(prefix))
                    val next: Int = try {
                        val inputs = HashMap<String, OnnxTensor>()
                        inputs["input_ids"] = inTensor
                        inputs["encoder_hidden_states"] = hidden
                        if ("encoder_attention_mask" in decNames) {
                            inputs["encoder_attention_mask"] = maskTensor
                        }
                        dec.run(inputs, setOf("logits")).use { out ->
                            val logits = out.get(0) as OnnxTensor
                            val shape = logits.info.shape
                            val seq = shape[1].toInt()
                            val vocab = shape[2].toInt()
                            val fb = logits.floatBuffer

                            val a = generated[generated.size - 2]
                            val b = generated[generated.size - 1]
                            val banned = seen[key(a, b)]
                            pickBest(fb, (seq - 1) * vocab, minOf(vocab, t.vocabSize), banned)
                        }
                    } finally {
                        inTensor.close()
                    }

                    if (next == NllbTokenizer.EOS || next < 0) break

                    val a = generated[generated.size - 2]
                    val b = generated[generated.size - 1]
                    seen.getOrPut(key(a, b)) { HashSet() }.add(next)
                    generated.add(next)
                }

                return t.decode(generated.subList(2, generated.size))
            }
        } finally {
            idsTensor.close()
            maskTensor.close()
        }
    }

    private fun key(a: Int, b: Int): Long = (a.toLong() shl 32) or (b.toLong() and 0xFFFFFFFFL)

    /** argmax ی گشتی، بێ تۆکنە تایبەتەکان (٠،١،٣) و ئەوانەی قەدەغەن. */
    private fun pickBest(
        fb: java.nio.FloatBuffer,
        base: Int,
        limit: Int,
        banned: Set<Int>?
    ): Int {
        var best = -1
        var bestV = Float.NEGATIVE_INFINITY
        for (i in 0 until limit) {
            if (i == 0 || i == 1 || i == 3) continue
            val v = fb.get(base + i)
            if (v > bestV) {
                if (banned != null && banned.contains(i)) continue
                bestV = v
                best = i
            }
        }
        return best
    }

    companion object {
        private const val TAG = "Translator"
        private const val SRC_LANG = "eng_Latn"
        private const val TGT_LANG = "ckb_Arab" // کوردیی ناوەندی (سۆرانی)، پیتی عەرەبی
        private const val MAX_NEW_TOKENS = 128
    }
}
