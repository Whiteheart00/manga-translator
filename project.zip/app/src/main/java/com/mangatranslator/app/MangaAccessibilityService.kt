package com.mangatranslator.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * خزمەتگوزاریی Accessibility: دوای چالاککردنی (یەکجار) ئەپەکە دەتوانێت شاشە بگرێت بێ ئەوەی هەر جارێک
 * پەنجەرەی «ڕێگەپێدانی گرتنی شاشە» (MediaProjection) دەربکەوێت. پێویستی بە Android 11+ هەیە.
 * هیچ دەقێک یان زانیاریێک لە ئەپەکانی تر ناخوێنێتەوە (canRetrieveWindowContent = false)؛ تەنها وێنەی شاشە.
 */
class MangaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // پانێلی بابلەکان خۆکارانە دەرکەوێت؛ هیچ گرتنێکی شاشە نییە تا فەرمانێک بەکار بهێنرێت
        if (TranslatorSettings(this).a11yAutoStart) {
            try {
                androidx.core.content.ContextCompat.startForegroundService(
                    this,
                    Intent(this, OverlayService::class.java).apply {
                        action = OverlayService.ACTION_START
                        putExtra(OverlayService.EXTRA_USE_A11Y, true)
                    }
                )
            } catch (_: Throwable) {}
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** کاتێک Accessibility لە ڕێکخستنەکان کوژێنرایەوە، ئۆڤەرلەی ئەپەکەش دەوەستێت (تا دۆخی کۆن نەمێنێتەوە) */
    private fun stopOverlayIfOurs() {
        val svc = OverlayService.instance ?: return
        try { svc.stopSelf() } catch (_: Throwable) {}
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) { instance = null; stopOverlayIfOurs() }
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) { instance = null; stopOverlayIfOurs() }
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: MangaAccessibilityService? = null

        /** ئایا لەسەر ئەم ئەندرۆیدە دەکرێت (11+) */
        fun supported(): Boolean = android.os.Build.VERSION.SDK_INT >= 30

        /** ئایا بەکارهێنەر چالاکی کردووە */
        fun isEnabled(ctx: Context): Boolean {
            if (instance != null) return true
            val flat = try {
                Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            } catch (_: Throwable) { null } ?: return false
            val me = ComponentName(ctx, MangaAccessibilityService::class.java).flattenToString()
            return flat.split(':').any { it.equals(me, ignoreCase = true) }
        }
    }
}
