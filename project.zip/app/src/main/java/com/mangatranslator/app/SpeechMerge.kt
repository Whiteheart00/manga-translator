package com.mangatranslator.app

/**
 * ڕستەی زۆر کورت (١-٢ وشە) لەلایەن دەنگی ئۆفلاین (Piper / TTS ی سیستەم) بێدەنگ دەبێت یان نابیسترێت.
 * بۆیە ڕستەی کورت دەلکێنرێت بە ڕستەی دواتر (یان ئەگەر دوایین بوو، بە ڕستەی پێشوو) و وەک یەک خوێندنەوە دەخوێنرێتەوە.
 */
object SpeechMerge {

    /** ڕستە بە کەمتر لەم ژمارە وشەیە «کورت»ە و دەلکێنرێت */
    const val MIN_WORDS = 3

    fun words(s: String): Int = s.trim().split(Regex("\\s+")).count { w -> w.any { it.isLetterOrDigit() } }

    fun isShort(s: String): Boolean = words(s) < MIN_WORDS

    private const val END = ".!?؟،,…:;"

    private fun join(a: String, b: String): String =
        if (a.isNotEmpty() && a.last() in END) "$a $b" else "$a، $b"

    fun merge(texts: List<String>): List<String> {
        val out = ArrayList<String>(texts.size)
        var buf: String? = null
        for (raw in texts) {
            val t = raw.trim()
            if (t.isEmpty()) continue
            val cur = if (buf == null) t else join(buf, t)
            if (isShort(cur)) {
                buf = cur
            } else {
                out.add(cur)
                buf = null
            }
        }
        val rest = buf
        if (rest != null) {
            if (out.isNotEmpty()) out[out.size - 1] = join(out.last(), rest) else out.add(rest)
        }
        return out
    }
}

/**
 * دەرچوونەکانی خۆمان (ئەو وەرگێڕانانەی لەسەر شاشە نیشان دراون) بیر دەکاتەوە، بۆ ئەوەی ئەگەر OCR/Accessibility
 * دووبارە هەمان دەق بخوێنێتەوە، دووبارە وەرنەگێڕدرێتەوە (لووپ).
 */
object OwnOutput {
    private const val MAX = 200
    private val exact = HashSet<String>()
    private val recent = ArrayDeque<String>()

    private fun norm(s: String): String =
        s.lowercase()
            .replace('ي', 'ی').replace('ى', 'ی').replace('ك', 'ک')
            .filter { it.isLetterOrDigit() }

    @Synchronized
    fun note(text: String) {
        if (!exact.add(text)) return
        val n = norm(text)
        if (n.length < 6) return
        recent.addLast(n)
        if (recent.size > MAX) {
            recent.removeFirst()
            if (exact.size > MAX * 3) exact.clear()
        }
    }

    @Synchronized
    fun matches(text: String): Boolean {
        val n = norm(text)
        if (n.length < 6) return false
        for (r in recent) {
            if (r == n) return true
            val lo = minOf(r.length, n.length)
            val hi = maxOf(r.length, n.length)
            if (lo >= 8 && lo * 10 >= hi * 7 && (r.contains(n) || n.contains(r))) return true
        }
        return false
    }

    @Synchronized
    fun clear() { exact.clear(); recent.clear() }
}
