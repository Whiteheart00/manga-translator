package com.mangatranslator.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** یەک هەنگاوی ڕێنمایی: چوارگۆشەی چالاک + نووسین + دەقی دەنگ (بێ ژمارە، بۆ Piper). */
class CoachStep(val target: () -> View?, val text: String, val speech: String)

/**
 * ڕێنمایی جوان (coach marks): شاشە تاریک دەبێت، ئەو بەشە ڕووناک دەکرێتەوە، و کارتێک ڕوونکردنەوە دەدات.
 * کاتێک voice = true بێت، هەر هەنگاوێک یەکسەر بە دەنگی ئۆفلاین دەخوێنرێتەوە و دوای تەواوبوون خۆی دەچێتە دواتر.
 */
class CoachOverlay(
    ctx: Context,
    private val pal: Palette,
    private val steps: List<CoachStep>,
    private val scroll: ScrollView?,
    private val voice: Boolean,
    private val onClosed: () -> Unit
) : FrameLayout(ctx) {

    private fun dp(v: Int): Float = v * resources.displayMetrics.density

    private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xD0000000.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(3); color = Color.WHITE
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(10)
        color = (pal.a2 and 0x00FFFFFF) or 0x55000000
    }
    private val dimPath = Path()
    private val hole = RectF()
    private var hasHole = false
    private var holeAnim: ValueAnimator? = null
    private var idx = -1
    private var tok = 0

    private val msg = TextView(ctx).apply {
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF8AB4FF.toInt())
        gravity = Gravity.START
        setLineSpacing(0f, 1.3f)
    }
    private val counter = TextView(ctx).apply {
        textSize = 13f
        setTextColor(0xFF7C879B.toInt())
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }
    private val skipTv = TextView(ctx).apply {
        text = "تێپەڕاندن"
        textSize = 13f
        setTextColor(0xFF9DB2D6.toInt())
        setPadding(dp(12).toInt(), dp(8).toInt(), dp(12).toInt(), dp(8).toInt())
        setOnClickListener { finish() }
    }
    private val nextBtn = TextView(ctx).apply {
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(0xFF8AB4FF.toInt())
        setPadding(dp(26).toInt(), dp(14).toInt(), dp(26).toInt(), dp(14).toInt())
        background = GradientDrawable().apply {
            cornerRadius = dp(16); setColor(0xFF161C28.toInt())
        }
        setOnClickListener { go(idx + 1) }
    }
    private val card = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(22).toInt(), dp(22).toInt(), dp(22).toInt(), dp(18).toInt())
        background = GradientDrawable().apply {
            cornerRadius = dp(28); setColor(0xF2090B10.toInt()); setStroke(dp(1).toInt(), 0xFF2B3140.toInt())
        }
        alpha = 0f
    }

    init {
        isClickable = true
        setWillNotDraw(false)
        layoutDirection = View.LAYOUT_DIRECTION_RTL

        card.addView(msg, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18).toInt() })
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(counter)
        row.addView(skipTv)
        row.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(nextBtn)
        card.addView(row, LinearLayout.LayoutParams(-1, -2))
        addView(card, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.TOP
            leftMargin = dp(20).toInt(); rightMargin = dp(20).toInt()
        })
    }

    fun start() = go(0)

    /** ئایکۆنی دووبارەکردنەوە: هەنگاوی ئێستا دووبارە دەخوێنێتەوە. */
    fun replay() {
        if (idx in steps.indices) speakStep(idx, voice)
    }

    fun finish() {
        tok++
        holeAnim?.cancel()
        Narrator.stop()
        (parent as? ViewGroup)?.removeView(this)
        onClosed()
    }

    private fun go(i: Int) {
        if (i >= steps.size) { finish(); return }
        idx = i
        val my = ++tok
        Narrator.stop()
        val st = steps[i]
        msg.text = st.text
        counter.text = "${i + 1} / ${steps.size}"
        nextBtn.text = if (i == steps.size - 1) "تەواو" else "دواتر"
        card.animate().alpha(0f).setDuration(120).start()

        val t = st.target()
        var wait = 90L
        val sc = scroll
        if (t != null && sc != null && isInside(t, sc) && sc.childCount > 0) {
            val y = topInScroll(t, sc)
            val maxScroll = maxOf(0, sc.getChildAt(0).height - sc.height)
            val desired = (y - (sc.height - t.height) / 3).coerceIn(0, maxScroll)
            if (Math.abs(desired - sc.scrollY) > 4) {
                sc.smoothScrollTo(0, desired)
                wait = 480L
            }
        }
        postDelayed({
            if (my != tok) return@postDelayed
            val r = if (t != null && t.isShown) targetRect(t) else null
            animateHole(r)
            placeCard(r)
            card.animate().alpha(1f).setDuration(220).start()
            if (voice) speakStep(i, true)
        }, wait)
    }

    private fun speakStep(i: Int, advance: Boolean) {
        val my = ++tok
        Narrator.speak(context, steps[i].speech) { ok ->
            if (my == tok && advance) {
                postDelayed({ if (my == tok) go(i + 1) }, if (ok) 1300L else 5000L)
            }
        }
    }

    private fun isInside(t: View, sc: ScrollView): Boolean {
        var p = t.parent
        while (p != null) {
            if (p === sc) return true
            p = p.parent
        }
        return false
    }

    private fun topInScroll(t: View, sc: ScrollView): Int {
        val content = sc.getChildAt(0)
        var y = 0
        var v: View = t
        while (v !== content) {
            y += v.top
            v = v.parent as? View ?: break
        }
        return y
    }

    private fun targetRect(t: View): RectF {
        val a = IntArray(2)
        val b = IntArray(2)
        t.getLocationInWindow(a)
        getLocationInWindow(b)
        val pad = dp(6)
        val l = (a[0] - b[0]).toFloat()
        val tp = (a[1] - b[1]).toFloat()
        return RectF(l - pad, tp - pad, l + t.width + pad, tp + t.height + pad)
    }

    private fun animateHole(to: RectF?) {
        holeAnim?.cancel()
        if (to == null) { hasHole = false; invalidate(); return }
        val from = if (hasHole) RectF(hole) else RectF(to.centerX(), to.centerY(), to.centerX(), to.centerY())
        hasHole = true
        holeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 320
            addUpdateListener {
                val f = it.animatedValue as Float
                hole.set(
                    from.left + (to.left - from.left) * f,
                    from.top + (to.top - from.top) * f,
                    from.right + (to.right - from.right) * f,
                    from.bottom + (to.bottom - from.bottom) * f
                )
                invalidate()
            }
            start()
        }
    }

    private fun placeCard(target: RectF?) {
        card.measure(
            View.MeasureSpec.makeMeasureSpec(width - dp(40).toInt(), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = card.measuredHeight.toFloat()
        val bottomLimit = height - dp(104)
        val y = if (target == null) (height - h) / 2f else {
            var yy = target.bottom + dp(18)
            if (yy + h > bottomLimit) yy = target.top - h - dp(18)
            yy
        }
        card.translationY = y.coerceIn(dp(28), maxOf(dp(28), bottomLimit - h))
    }

    override fun dispatchDraw(canvas: Canvas) {
        dimPath.reset()
        dimPath.fillType = Path.FillType.EVEN_ODD
        dimPath.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
        if (hasHole && hole.width() > 1f) {
            val rad = minOf(dp(18), minOf(hole.width(), hole.height()) / 2f)
            dimPath.addRoundRect(hole, rad, rad, Path.Direction.CW)
            canvas.drawPath(dimPath, dim)
            canvas.drawRoundRect(hole, rad, rad, glow)
            canvas.drawRoundRect(hole, rad, rad, ring)
        } else {
            canvas.drawPath(dimPath, dim)
        }
        super.dispatchDraw(canvas)
    }
}
