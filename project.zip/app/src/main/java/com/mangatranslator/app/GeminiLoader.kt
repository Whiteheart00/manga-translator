package com.mangatranslator.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/**
 * لۆدینگی ستایلی Gemini: کاپسوڵێکی تاریکی شووشەیی بە لێوارێکی ڕەنگاوڕەنگی گەڕاو (شین ← مۆر ← پەمەیی)،
 * ئەستێرەی چوار-پەڕی لەرزۆک، و دەقێک کە درەوشانەوەیەکی تێدا دەڕوات.
 */
class GeminiLoader(ctx: Context, var label: String) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val blue = 0xFF4285F4.toInt()
    private val purple = 0xFF9B72CB.toInt()
    private val pink = 0xFFD96570.toInt()

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEE12162A.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.2f * d }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f * d }
    private val star = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 14f * d
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val path = Path()
    private val mat = Matrix()
    private var phase = 0f

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 6f * d
        rect.set(m, m, w - m, h - m)
        val r = rect.height() / 2f

        // لێواری گەڕاو
        val sweep = SweepGradient(w / 2f, h / 2f, intArrayOf(blue, purple, pink, purple, blue), null)
        mat.setRotate(phase * 360f, w / 2f, h / 2f)
        sweep.setLocalMatrix(mat)

        glow.shader = sweep
        glow.alpha = 70
        c.drawRoundRect(rect, r, r, glow)
        c.drawRoundRect(rect, r, r, bg)
        border.shader = sweep
        c.drawRoundRect(rect, r, r, border)

        // ئەستێرەی چوار-پەڕی
        val pulse = 0.5f + 0.5f * sin(phase * 6.2832f)
        val sx = rect.left + r + 2f * d
        val sy = h / 2f
        val sz = (7f + 2.5f * pulse) * d
        star.shader = LinearGradient(sx - sz, sy - sz, sx + sz, sy + sz, intArrayOf(blue, purple, pink), null, Shader.TileMode.CLAMP)
        path.reset()
        path.moveTo(sx, sy - sz)
        path.quadTo(sx, sy, sx + sz, sy)
        path.quadTo(sx, sy, sx, sy + sz)
        path.quadTo(sx, sy, sx - sz, sy)
        path.quadTo(sx, sy, sx, sy - sz)
        path.close()
        c.save()
        c.rotate(phase * 90f, sx, sy)
        c.drawPath(path, star)
        c.restore()

        // دەق + درەوشانەوە
        val tx = (sx + sz + rect.right) / 2f + 2f * d
        val tw = text.measureText(label)
        val bandX = (tx - tw / 2f) + (tw + 80f * d) * phase - 40f * d
        text.shader = LinearGradient(
            bandX - 40f * d, 0f, bandX + 40f * d, 0f,
            intArrayOf(0x99FFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0x99FFFFFF.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawText(label, tx, h / 2f + text.textSize / 3f, text)
    }
}
