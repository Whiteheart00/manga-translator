package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * ناسینەوەی خێرای کوردیی سۆرانی لەسەر خودی مۆبایل (بێ AI و بێ ئینتەرنێت) بە Tesseract (ckb).
 * ئەگەر دەقەکە بە ڕوونی کوردی بوو، دەقەکە دەگەڕێنێتەوە و ئەپەکە یەکسەر دەیخوێنێتەوە.
 * ئەگەر کوردی نەبوو یان دڵنیا نەبوو، null دەگەڕێنێتەوە و ئەپەکە دەچێتە سەر Gemini.
 */
object LocalKurdishOcr {
    private const val TAG = "LocalKurdishOcr"
    // یەکەم: ڕیپۆی خۆت (هەمان Release ی دەنگی کوردی)؛ دووەم: سەرچاوەی فەرمیی Tesseract
    private val URLS = listOf(
        "https://github.com/Whiteheart00/manga-translator/releases/download/Translator/ckb.traineddata",
        "https://github.com/tesseract-ocr/tessdata_fast/raw/main/ckb.traineddata"
    )
    private const val MIN_CONF = 55
    private val lock = Any()
    private var api: TessBaseAPI? = null

    private fun dataFile(ctx: Context) = File(ctx.filesDir, "tess/tessdata/ckb.traineddata")

    fun isInstalled(ctx: Context) = dataFile(ctx).let { it.exists() && it.length() > 100_000 }

    /** یەکجار داگرتنی فایلی زمانی کوردی (~٣MB). null = سەرکەوتوو. */
    fun download(ctx: Context): String? {
        val f = dataFile(ctx)
        val tmp = File(f.parentFile, "ckb.tmp")
        f.parentFile?.mkdirs()
        var lastErr = "داگرتنی OCR ی کوردی سەرنەکەوت"
        for (u in URLS) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                if (c.responseCode !in 200..299) { lastErr = "$lastErr: HTTP ${c.responseCode}"; c.disconnect(); continue }
                c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                c.disconnect()
                if (tmp.length() < 100_000) { tmp.delete(); continue }
                tmp.renameTo(f)
                return null
            } catch (t: Throwable) {
                tmp.delete()
                lastErr = "داگرتنی OCR ی کوردی سەرنەکەوت: " + (t.message ?: t.javaClass.simpleName)
            }
        }
        return lastErr
    }

    private fun engine(ctx: Context): TessBaseAPI? {
        api?.let { return it }
        return try {
            TessBaseAPI().also {
                if (!it.init(File(ctx.filesDir, "tess").absolutePath, "ckb")) { it.recycle(); return null }
                it.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
                api = it
            }
        } catch (t: Throwable) {
            Log.e(TAG, "init failed", t); null
        }
    }

    /** دەقی کوردی دەگەڕێنێتەوە ئەگەر دڵنیا بوو؛ ئەگەرنا null. لە thread ی پاشبنەما بانگ بکرێت. */
    fun detect(ctx: Context, crop: Bitmap): String? {
        if (!isInstalled(ctx)) return null
        return try {
            synchronized(lock) {
                val t = engine(ctx) ?: return null
                var bmp = crop
                val m = maxOf(crop.width, crop.height)
                if (m < 900) {
                    val k = minOf(2f, 1800f / m)
                    bmp = Bitmap.createScaledBitmap(crop, (crop.width * k).toInt(), (crop.height * k).toInt(), true)
                }
                t.setImage(bmp)
                val text = (t.getUTF8Text() ?: "").replace(Regex("\\s+"), " ").trim()
                val conf = t.meanConfidence()
                t.clear()
                if (bmp !== crop) bmp.recycle()
                Log.d(TAG, "conf=$conf text=$text")
                if (conf >= MIN_CONF && looksKurdish(text)) text else null
            }
        } catch (t: Throwable) {
            Log.e(TAG, "detect failed", t); null
        }
    }

    /** پیتی عەرەبی زۆرینە بێت + پیتی تایبەتی سۆرانی (ە ێ ۆ ڕ ڵ ڤ) هەبن. */
    private fun looksKurdish(s: String): Boolean {
        var letters = 0; var arabic = 0; var special = 0
        for (ch in s) {
            if (!ch.isLetter()) continue
            letters++
            if (ch.code in 0x0600..0x06FF) arabic++
            if (ch == 'ە' || ch == 'ێ' || ch == 'ۆ' || ch == 'ڕ' || ch == 'ڵ' || ch == 'ڤ') special++
        }
        return letters >= 4 && arabic * 100 >= letters * 85 && special >= 2
    }
}
