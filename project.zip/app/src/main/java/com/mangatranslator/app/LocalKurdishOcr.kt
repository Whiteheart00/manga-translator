package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * ناسینەوەی خێرای کوردیی سۆرانی لەسەر خودی مۆبایل (بێ AI و بێ ئینتەرنێت) بە Tesseract (ckb).
 * ئەگەر دەقەکە بە ڕوونی کوردی بوو، دەقەکە دەگەڕێنێتەوە و ئەپەکە یەکسەر دەیخوێنێتەوە.
 * ئەگەر کوردی نەبوو یان دڵنیا نەبوو، null دەگەڕێنێتەوە و ئەپەکە دەچێتە سەر Gemini.
 */
object LocalKurdishOcr {
    private const val TAG = "LocalKurdishOcr"
    private val URLS = listOf(
        "https://github.com/Whiteheart00/manga-translator/releases/download/v1.0.1/ckb.traineddata",
        "https://github.com/tesseract-ocr/tessdata_fast/raw/main/ckb.traineddata",
        "https://github.com/tesseract-ocr/tessdata/raw/main/ckb.traineddata",
        "https://github.com/tesseract-ocr/tessdata_best/raw/main/ckb.traineddata"
    )
    /** کەمتر = خێراتر؛ ٥٠ پێشتر بوو */
    private const val MIN_CONF = 35
    /** تێپەڕی دووەم تەنها ئەگەر متمانە لەمە کەمتر بێت (پێشتر ٨٠ بوو → زۆر خاو) */
    private const val SECOND_PASS_BELOW = 58
    private const val MAX_SIDE = 960
    private const val PREPARE_PAD = 12
    private val lock = Any()
    private var api: TessBaseAPI? = null

    private fun dataFile(ctx: Context) = File(ctx.filesDir, "tess/tessdata/ckb.traineddata")

    /** Version of the bundled fine-tuned model; changing it replaces cached device weights. */
    private const val BUNDLED_VERSION = "ckb-approved69-step1800-4a662f08d5ee"

    fun isInstalled(ctx: Context): Boolean {
        val f = dataFile(ctx)
        val marker = File(f.parentFile, "ckb.version")
        val hasAsset = try { ctx.assets.open("ckb.traineddata").use { true } } catch (_: Throwable) { false }
        val current = try { marker.readText().trim() } catch (_: Throwable) { "" }
        if (f.exists() && f.length() > 100_000 && (!hasAsset || current == BUNDLED_VERSION)) return true
        return try {
            f.parentFile?.mkdirs()
            release()   // مۆدێلی کۆن (دابەزێنراو) بە فایلی ناو ئەپ دەگۆڕدرێت
            ctx.assets.open("ckb.traineddata").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val ok = f.length() > 100_000
            if (ok) marker.writeText(BUNDLED_VERSION)
            ok
        } catch (_: Throwable) {
            f.exists() && f.length() > 100_000   // assets نییە: فایلی دابەزێنراو ئەگەر هەبێت
        }
    }

    fun download(ctx: Context): String? {
        // Install the bundled trained model before considering legacy download URLs.
        if (isInstalled(ctx)) return null
        val f = dataFile(ctx)
        val tmp = File(f.parentFile, "ckb.tmp")
        f.parentFile?.mkdirs()
        val errs = ArrayList<String>()
        for (u in URLS) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", "MangaTranslator/1.0")
                if (c.responseCode !in 200..299) {
                    errs.add("HTTP ${c.responseCode}"); c.disconnect(); continue
                }
                c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                c.disconnect()
                if (tmp.length() < 100_000) {
                    errs.add("file too small"); tmp.delete(); continue
                }
                if (f.exists()) f.delete()
                if (!tmp.renameTo(f)) {
                    tmp.copyTo(f, overwrite = true); tmp.delete()
                }
                release()
                return null
            } catch (t: Throwable) {
                errs.add(t.message ?: t.javaClass.simpleName)
                tmp.delete()
            }
        }
        return "داگرتنی OCR ی کوردی سەرنەکەوت (" + errs.distinct().joinToString("، ") + ")"
    }

    fun release() {
        synchronized(lock) {
            try { api?.recycle() } catch (_: Throwable) {}
            api = null
        }
    }

    fun warmUp(ctx: Context) {
        if (!isInstalled(ctx)) return
        try {
            synchronized(lock) { engine(ctx) }
        } catch (_: Throwable) {
        }
    }

    private fun engine(ctx: Context): TessBaseAPI? {
        api?.let { return it }
        return try {
            TessBaseAPI().also {
                if (!it.init(File(ctx.filesDir, "tess").absolutePath, "ckb")) {
                    it.recycle(); return null
                }
                // ڕووبەری دیاریکراو = یەک بلۆکی دەق → خێراتر و وردتر لە PSM_AUTO
                it.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK)
                it.setVariable("user_defined_dpi", "220")
                it.setVariable("preserve_interword_spaces", "1")
                // کەمکردنەوەی کاری ناوخۆیی Tesseract
                it.setVariable("tessedit_do_invert", "0")
                it.setVariable("load_system_dawg", "0")
                it.setVariable("load_freq_dawg", "0")
                api = it
            }
        } catch (t: Throwable) {
            Log.e(TAG, "init failed", t); null
        }
    }

    /**
     * ئامادەکردنی وێنە: گەورەکردنەوەی سنووردار، invert ئەگەر پێویست، کۆنتراست،
     * و بژاردەی Otsu. خێراتر لە وەشانی پێشوو (MAX_SIDE کەمتر، pad کەمتر).
     */
    private fun prepare(src: Bitmap, binarize: Boolean): Bitmap {
        val m = maxOf(src.width, src.height)
        val k = when {
            m < 700 -> minOf(2.0f, 900f / m)
            m > MAX_SIDE -> MAX_SIDE.toFloat() / m
            else -> 1f
        }
        val scaled = if (k != 1f)
            Bitmap.createScaledBitmap(
                src,
                (src.width * k).toInt().coerceAtLeast(1),
                (src.height * k).toInt().coerceAtLeast(1),
                true
            )
        else src
        val w = scaled.width
        val h = scaled.height
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        if (scaled !== src) scaled.recycle()

        val g = IntArray(w * h)
        val hist = IntArray(256)
        var sum = 0L
        for (i in px.indices) {
            val c = px[i]
            val v = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
            g[i] = v; hist[v]++; sum += v
        }
        val n = g.size
        if (sum / n < 110) {
            for (i in g.indices) g[i] = 255 - g[i]
            hist.reverse()
        }

        var lo = 0; var acc = 0
        while (lo < 255 && acc + hist[lo] < n / 100) { acc += hist[lo]; lo++ }
        var hi = 255; acc = 0
        while (hi > 0 && acc + hist[hi] < n / 100) { acc += hist[hi]; hi-- }
        if (hi - lo < 30) { lo = 0; hi = 255 }
        val range = (hi - lo).coerceAtLeast(1)
        val h2 = IntArray(256)
        for (i in g.indices) {
            val v = ((g[i] - lo) * 255 / range).coerceIn(0, 255)
            g[i] = v; h2[v]++
        }
        val th = if (binarize) otsu(h2, n) else -1

        val pad = PREPARE_PAD
        val ow = w + pad * 2
        val oh = h + pad * 2
        val out = IntArray(ow * oh) { -1 }
        for (y in 0 until h) {
            val base = (y + pad) * ow + pad
            for (x in 0 until w) {
                var v = g[y * w + x]
                if (th >= 0) v = if (v > th) 255 else 0
                out[base + x] = (255 shl 24) or (v shl 16) or (v shl 8) or v
            }
        }
        return Bitmap.createBitmap(out, ow, oh, Bitmap.Config.ARGB_8888)
    }

    private fun otsu(hist: IntArray, total: Int): Int {
        var sum = 0L
        for (i in 0..255) sum += i.toLong() * hist[i]
        var sB = 0L; var wB = 0; var best = 0.0; var th = 127
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0) continue
            val wF = total - wB
            if (wF == 0) break
            sB += t.toLong() * hist[t]
            val mB = sB.toDouble() / wB
            val mF = (sum - sB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; th = t }
        }
        return th
    }

    private data class Res(val text: String, val conf: Int, val words: List<MixedOcrFilter.Word>)
    internal data class NativeRead(val text: String, val confidence: Int,
                                               internal val words: List<MixedOcrFilter.Word>)

    private fun recognize(t: TessBaseAPI, bmp: Bitmap, originalW: Int, originalH: Int): Res {
        t.setImage(bmp)
        val whole = (t.getUTF8Text() ?: "").trim()
        val mean = t.meanConfidence()
        val iterator = t.resultIterator
        if (iterator == null) { t.clear(); return Res(whole, mean, emptyList()) }
        val words = ArrayList<MixedOcrFilter.Word>()
        val sx = originalW.toFloat() / (bmp.width - PREPARE_PAD * 2).coerceAtLeast(1)
        val sy = originalH.toFloat() / (bmp.height - PREPARE_PAD * 2).coerceAtLeast(1)
        try {
            val level = TessBaseAPI.PageIteratorLevel.RIL_WORD
            iterator.begin()
            do {
                val rect = iterator.getBoundingRect(level) ?: continue
                words.add(MixedOcrFilter.Word(iterator.getUTF8Text(level).orEmpty(),
                    ((rect.left - PREPARE_PAD) * sx).toInt().coerceIn(0, originalW),
                    ((rect.top - PREPARE_PAD) * sy).toInt().coerceIn(0, originalH),
                    ((rect.right - PREPARE_PAD) * sx).toInt().coerceIn(0, originalW),
                    ((rect.bottom - PREPARE_PAD) * sy).toInt().coerceIn(0, originalH), iterator.confidence(level)))
            } while (iterator.next(level))
        } finally { iterator.delete(); t.clear() }
        val kept = MixedOcrFilter.nativeWords(words)
        return Res(MixedOcrFilter.text(kept), if (kept.isEmpty()) 0 else kept.map { it.confidence }.average().toInt(), kept)
    }

    private fun normalizeLetters(s: String): String =
        s.replace('\u064A', '\u06CC').replace('\u0649', '\u06CC').replace('\u0643', '\u06A9')

    /** پاککردنەوەی هێما و بۆشاییە نادیارەکان کە Tesseract لە ژێرنوسی ڕەنگاوڕەنگ زیاد دەکات. */
    private fun cleanOcrText(s: String): String = KurdishOcrText.clean(s)

    /**
     * دەقی کوردی دەگەڕێنێتەوە ئەگەر دڵنیا بوو؛ ئەگەرنا null.
     * خێراتر: تێپەڕی دووەم کەمتر، وێنەی بچووکتر، PSM_SINGLE_BLOCK.
     */
    fun detect(ctx: Context, crop: Bitmap, allowMixedSorani: Boolean = false): String? =
        detectNative(ctx, crop, allowMixedSorani)?.text

    internal fun detectNative(ctx: Context, crop: Bitmap, allowMixedSorani: Boolean = false): NativeRead? {
        if (!isInstalled(ctx)) return null
        val t0 = android.os.SystemClock.elapsedRealtime()
        return try {
            synchronized(lock) {
                val t = engine(ctx) ?: return null
                val a = prepare(crop, false)
                var best = try {
                    recognize(t, a, crop.width, crop.height)
                } finally {
                    a.recycle()
                }
                if (Thread.currentThread().isInterrupted) return null

                val norm1 = cleanOcrText(best.text)
                if (!roughlyArabicScript(norm1) && !(allowMixedSorani && RegionReadPolicy.isSorani(norm1))) {
                    Log.d(TAG, "skip: not arabic script, took=${android.os.SystemClock.elapsedRealtime() - t0}ms")
                    return null
                }
                // تێپەڕی دووەم تەنها کاتێک متمانە نزمە (پێشتر زۆر زوو دەچووە سەر تێپەڕی ٢)
                if (best.conf < SECOND_PASS_BELOW) {
                    if (Thread.currentThread().isInterrupted) return null
                    val b = prepare(crop, true)
                    val r2 = try {
                        recognize(t, b, crop.width, crop.height)
                    } finally {
                        b.recycle()
                    }
                    if (r2.conf > best.conf) best = r2
                }
                val text = cleanOcrText(best.text)
                Log.d(TAG, "conf=${best.conf} took=${android.os.SystemClock.elapsedRealtime() - t0}ms text=$text")
                if (best.conf >= MIN_CONF && (looksKurdish(text) || allowMixedSorani && RegionReadPolicy.isSorani(text))) {
                    val fixedWords = best.words.mapNotNull { word ->
                        val clean = cleanOcrText(word.text)
                        if (clean.isBlank()) null
                        else word.copy(text = KurdishVocab.fixOcr(ctx, clean))
                    }
                    val fixedText = if (fixedWords.isNotEmpty()) MixedOcrFilter.text(fixedWords)
                        else KurdishVocab.fixOcr(ctx, text)
                    NativeRead(fixedText, best.conf, fixedWords)
                } else null
            }
        } catch (t: Throwable) {
            Log.e(TAG, "detect failed", t); null
        }
    }

    private fun roughlyArabicScript(s: String): Boolean {
        var letters = 0; var arabic = 0
        for (ch in s) {
            if (!ch.isLetter()) continue
            letters++
            if (ch.code in 0x0600..0x06FF) arabic++
        }
        return letters >= 3 && arabic * 100 >= letters * 55
    }

    /**
     * ناسینەوەی کوردی: عەرەبی زۆرینە + لانیکەم یەک پیتی تایبەتی سۆرانی،
     * یان عەرەبی زۆر بەرز (بۆ دەقی کورت کە OCR پیتی ە ی ون کردبێت).
     */
    private fun looksKurdish(s: String): Boolean {
        var letters = 0; var arabic = 0; var special = 0
        for (ch in s) {
            if (!ch.isLetter()) continue
            letters++
            if (ch.code in 0x0600..0x06FF) arabic++
            if (ch == 'ە' || ch == 'ێ' || ch == 'ۆ' || ch == 'ڕ' || ch == 'ڵ' || ch == 'ڤ') special++
        }
        if (letters < 2) return false
        if (arabic * 100 < letters * 70) return false
        // یەک پیتی تایبەت یان زۆرینەی عەرەبی بۆ دەقی کورت
        if (special >= 1) return true
        return letters >= 5 && arabic * 100 >= letters * 88
    }
}
