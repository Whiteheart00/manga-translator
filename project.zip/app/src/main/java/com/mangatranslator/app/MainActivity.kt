package com.mangatranslator.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.app.AlertDialog
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * شاشەی سەرەکی:
 * ١. ڕێگەپێدانی پیشاندان لەسەر ئەپەکانی تر
 * ٢. دەستپێکردن (گرتنی شاشە + بابلی شەمەندەفەر)
 * ٣. وەستاندن
 * ٤. دابەزاندنی مۆدێلی وەرگێڕان (~٩٠٠ MB، تەنها یەکجار)
 */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var modelText: TextView
    private lateinit var store: ModelStore
    private val handler = Handler(Looper.getMainLooper())

    private val poller = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ModelStore(this)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 26f
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap(bottom = dp(8)))

        statusText = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
        }
        root.addView(statusText, matchWrap(bottom = dp(4)))

        modelText = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
        }
        root.addView(modelText, matchWrap(bottom = dp(24)))

        root.addView(
            button("١. ڕێگەپێدانی پیشاندان لەسەر ئەپەکانی تر") { openOverlaySettings() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٢. دەستپێکردن") { startFlow() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٣. وەستاندن") { stopTranslator() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٤. دابەزاندنی مۆدێلی وەرگێڕان (~٩٠٠ MB)") { downloadModel() },
            matchWrap(bottom = dp(12))
        )

        root.addView(
            button("٥. وەرگێڕانی ئۆنلاین (Claude / Google) و +١٨") { showOnlineDialog() },
            matchWrap(bottom = dp(12))
        )

        setContentView(root)
    }

    private fun showOnlineDialog() {
        val st = TranslatorSettings(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(0))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val group = RadioGroup(this)
        val rbOff = RadioButton(this).apply { text = "ئۆفلاین (NLLB، بێ ئینتەرنێت)"; id = 1 }
        val rbClaude = RadioButton(this).apply { text = "Claude (باشترین بۆ سۆرانی)"; id = 2 }
        val rbGoogle = RadioButton(this).apply { text = "Google Translate"; id = 3 }
        group.addView(rbOff); group.addView(rbClaude); group.addView(rbGoogle)
        group.check(when (st.mode) {
            TranslatorSettings.Mode.OFFLINE -> 1
            TranslatorSettings.Mode.CLAUDE -> 2
            TranslatorSettings.Mode.GOOGLE -> 3
        })
        box.addView(group)

        val claudeKey = EditText(this).apply {
            hint = "کلیلی API ی Claude"
            setText(st.claudeKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val googleKey = EditText(this).apply {
            hint = "کلیلی API ی Google Cloud Translation"
            setText(st.googleKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(claudeKey)
        box.addView(googleKey)

        val adult = CheckBox(this).apply {
            text = "پشتڕاستی دەکەمەوە +١٨ ساڵم و مانگای گەورەسالان دەخوێنمەوە"
            isChecked = st.adultConfirmed
        }
        box.addView(adult)

        val note = TextView(this).apply {
            text = "تێبینی: دەقی بابلەکان دەنێردرێت بۆ ئەو خزمەتگوزارییەی هەڵتبژاردووە. " +
                "ئەگەر Claude بابلێک ڕەت بکاتەوە، خۆکارانە Google (ئەگەر کلیلت هەبێت) یان مۆدێلی ئۆفلاین بەکار دێت."
            textSize = 13f
        }
        box.addView(note)

        AlertDialog.Builder(this)
            .setTitle("وەرگێڕانی ئۆنلاین")
            .setView(box)
            .setPositiveButton("هەڵگرتن") { _, _ ->
                st.mode = when (group.checkedRadioButtonId) {
                    2 -> TranslatorSettings.Mode.CLAUDE
                    3 -> TranslatorSettings.Mode.GOOGLE
                    else -> TranslatorSettings.Mode.OFFLINE
                }
                st.claudeKey = claudeKey.text.toString()
                st.googleKey = googleKey.text.toString()
                st.adultConfirmed = adult.isChecked
                toast("هەڵگیرا. ئەگەر خزمەتگوزاری کار دەکات، بیوەستێنە و دووبارە دەستپێبکەرەوە")
            }
            .setNegativeButton("پاشگەزبوونەوە", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        handler.post(poller)
    }

    override fun onPause() {
        handler.removeCallbacks(poller)
        super.onPause()
    }

    private fun updateStatus() {
        statusText.text = if (Settings.canDrawOverlays(this)) {
            "ڕێگەپێدانی پیشاندان: چالاکە ✓"
        } else {
            "ڕێگەپێدانی پیشاندان: هێشتا نەدراوە"
        }

        modelText.text = when {
            store.isReady() -> "مۆدێلی وەرگێڕان: ئامادەیە ✓"
            store.isDownloading() -> "مۆدێلی وەرگێڕان: دادەبەزێت ${store.progressPercent()}٪"
            store.progressPercent() > 0 ->
                "مۆدێلی وەرگێڕان: دابەزاندن وەستاوە (${store.progressPercent()}٪). دوگمەی ٤ دابگرە"
            else -> "مۆدێلی وەرگێڕان: دانەبەزێنراوە"
        }
    }

    private fun downloadModel() {
        when {
            store.isReady() -> toast("مۆدێلەکە پێشتر دابەزێنراوە")
            store.isDownloading() -> toast("دابەزاندن بەردەوامە، لە ئاگادارکردنەوەکان بیبینە")
            else -> {
                store.startDownload()
                toast("دابەزاندن دەستی پێکرد. باشترە بە Wi-Fi بێت")
            }
        }
        updateStatus()
    }

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            toast("سەرەتا ڕێگەپێدانی پیشاندان چالاک بکە")
            openOverlaySettings()
            return
        }

        // Android 13+: ڕێگەپێدانی ئاگادارکردنەوە بۆ نیشاندانی ئاگادارکردنەوەی خزمەتگوزاری
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }

        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            // با ڕێگەپێدان یان بێ ڕێگەپێدان بەردەوام دەبین؛ خزمەتگوزاری هەر کار دەکات
            requestScreenCapture()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val svc = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                    putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(OverlayService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, svc)
                toast("بابلەکە دەرکەوت. دەتوانیت بچیتە سەر ئەپی مانگاکەت")
                moveTaskToBack(true)
            } else {
                toast("ڕێگەپێدانی گرتنی شاشە وەرنەگیرا")
            }
        }
    }

    private fun stopTranslator() {
        stopService(Intent(this, OverlayService::class.java))
        toast("وەستێنرا")
    }

    // ---------- یارمەتیدەرەکان ----------

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setOnClickListener { onClick() }
    }

    private fun matchWrap(bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = bottom }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val REQ_NOTIF = 1001
        private const val REQ_CAPTURE = 1002
    }
}
