package com.mangatranslator.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.app.AlertDialog
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.Spinner
import androidx.core.content.ContextCompat

/**
 * شاشەی سەرەکی:
 * ١. ڕێگەپێدانی پیشاندان لەسەر ئەپەکانی تر
 * ٢. دەستپێکردن (گرتنی شاشە + بابلی شەمەندەفەر)
 * ٣. وەستاندن
 * ٤. کلیلی Google (ئارەزوومەندانە)
 */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private var testTts: SoraniTts? = null
    private val handler = Handler(Looper.getMainLooper())

    private val poller = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 26f
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap(bottom = dp(8)))

        statusText = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
        }
        root.addView(statusText, matchWrap(bottom = dp(24)))

        // ---- هەڵبژاردنی دۆخ: کۆن (وەک خۆی) یان نوێ ----
        val modeSt = TranslatorSettings(this)
        root.addView(TextView(this).apply {
            text = "دۆخی ئەپ (پێش «دەستپێکردن» هەڵیبژێرە):"
            textSize = 15f
        }, matchWrap(bottom = dp(4)))
        val modeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val rbOld = RadioButton(this).apply {
            id = View.generateViewId()
            text = "دۆخی کۆن: ک / وەر / دەنگ (وەک خۆی)"
        }
        val rbNew = RadioButton(this).apply {
            id = View.generateViewId()
            text = "دۆخی نوێ: ڕووبەر (هەموو زمانێک) + قسەکردن بۆ نووسین"
        }
        modeGroup.addView(rbOld)
        modeGroup.addView(rbNew)
        modeGroup.check(if (modeSt.mode == 1) rbNew.id else rbOld.id)
        modeGroup.setOnCheckedChangeListener { _, id ->
            modeSt.mode = if (id == rbNew.id) 1 else 0
            if (isRunning()) toast("بۆ گۆڕینی دۆخ، سەرەتا «وەستاندن» بکە و دووبارە «دەستپێکردن»")
        }
        root.addView(modeGroup, matchWrap(bottom = dp(16)))

        root.addView(
            button("١. ڕێگەپێدانی پیشاندان لەسەر ئەپەکانی تر") { openOverlaySettings() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٢. دەستپێکردن") { startFlow() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٣. وەستاندن") { stopTranslator() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٤. کلیلی Google (ئارەزوومەندانە)") { showKeyDialog() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٥. ڕێکخستنی دەنگ (خوێندنەوە)") { showVoiceDialog() },
            matchWrap(bottom = dp(12))
        )

        root.addView(
            TextView(this).apply {
                text = "دۆخی کۆن، سێ بابل دەردەکەون:\n" +
                    "«ک» = وەرگێڕانی خۆکار (سەوز = چالاک)\n" +
                    "«وەر» = وەرگێڕانی شاشەی ئێستا (درێژ بگرە بۆ شاردنەوە)\n" +
                    "«دەنگ» = خوێندنەوەی وەرگێڕانەکان بە دەنگ (دووبارە دایبگرە یان درێژ بگرە بۆ وەستاندن)\n" +
                    "\nدۆخی نوێ، دوو بابل دەردەکەون:\n" +
                    "«ڕ» = ڕووبەرێک بکێشە؛ هەر زمانێک بێت دەیکات بە کوردی و دەیخوێنێتەوە (ئەگەر کوردی بوو تەنها دەیخوێنێتەوە)\n" +
                    "«قسە» = دایبگرە، بە کوردی قسە بکە، دووبارە دایبگرە؛ دەنووسرێت و کۆپی دەکرێت بۆ ئەوەی لە هەر ئەپێک دایبنێیت\n" +
                    "(کلیلی Gemini پێویستە)"
                textSize = 14f
            },
            matchWrap(bottom = dp(12))
        )

        setContentView(root)
    }

    private fun showKeyDialog() {
        val st = TranslatorSettings(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(0))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val googleKey = EditText(this).apply {
            hint = "کلیلی API ی Google Cloud Translation"
            setText(st.googleKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(googleKey)
        box.addView(TextView(this).apply {
            text = "ئارەزوومەندانەیە. ئەگەر کلیلت نییە، ئەم خانەیە بەتاڵ بهێڵەرەوە. بێ کلیلیش وەرگێڕان بە Google Translate کار دەکات؛ " +
                "ئەگەر کلیلت هەیە، ڕێگای فەرمی بەکار دێت کە جێگیرترە. ئینتەرنێت پێویستە."
            textSize = 13f
        })

        AlertDialog.Builder(this)
            .setTitle("کلیلی Google")
            .setView(box)
            .setPositiveButton("هەڵگرتن") { _, _ ->
                st.googleKey = googleKey.text.toString()
                toast("هەڵگیرا")
            }
            .setNegativeButton("پاشگەزبوونەوە", null)
            .show()
    }


    private fun showVoiceDialog() {
        val st = TranslatorSettings(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(0))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val key = EditText(this).apply {
            hint = "کلیلی Gemini API (دەتوانیت ٢ یان ٣ کلیل بنووسیت، هەر یەکێک لە دێڕێک)"
            setText(st.geminiTtsKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 2
        }
        val voices = listOf("Kore", "Aoede", "Charon", "Puck")
        val voice = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices)
            setSelection(voices.indexOf(st.geminiTtsVoice).coerceAtLeast(0))
        }
        val autoSpeak = CheckBox(this).apply {
            text = "دوای وەرگێڕانی دەستی شاشە، دەقەکە خۆکارانە بە دەنگ بخوێنەوە"
            isChecked = st.autoSpeak
        }
        val fast = CheckBox(this).apply {
            text = "دۆخی خێرا (دۆخی نوێ): مۆدێلی سووکتر، زۆر خێراتر؛ ئەگەر وەرگێڕان باش نەبوو، ڕایبگرە"
            isChecked = st.fast
        }
        val offlineCb = CheckBox(this).apply {
            text = "خوێندنەوەی ئۆفلاین (بێ ئینتەرنێت): کوردی بە دەنگی ناو مۆبایل دەخوێنرێتەوە"
            isChecked = st.offlineTts
        }
        box.addView(offlineCb)
        val offlineVoices = listOf("ئینگلیزی (لاتینیی کوردی)", "عەرەبی", "تورکی (کۆن)", "فارسیی سیستەم (زۆرجار نییە)", "کوردیی نیورالی (Berfin، ONNX) — باشترین")
        val offlineVoice = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, offlineVoices)
            setSelection(st.offlineVoice)
        }
        box.addView(offlineVoice)
        piperStatus = TextView(this).apply { textSize = 12f }
        refreshPiperStatus()
        box.addView(piperStatus)
        box.addView(Button(this).apply {
            text = "هێنانی مۆدێلی کوردی (zip ی مۆدێلەکە)"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                try { startActivityForResult(i, REQ_PIPER_MODEL) } catch (_: Exception) { toast("فایل هەڵبژێر نەکرایەوە") }
            }
        })
        box.addView(TextView(this).apply {
            text = "پێویستی: دەنگی هەڵبژێردراو دابەزێنە (Settings ← Text-to-speech ← Google ← Install voice data). " +
                "دەنگی کوردیی ئۆفلاین لە ئەندرۆید نییە، بۆیە کوردییەکە نزیکە و وردی Gemini ی نییە. کلیلی Gemini لەم دۆخەدا پێویست نییە."
            textSize = 12f
        })
        box.addView(key)
        box.addView(voice)
        box.addView(autoSpeak)
        box.addView(fast)
        box.addView(TextView(this).apply {
            text = "خوێندنەوە بە Gemini TTS ـە و کوردیی ناوەندی/سۆرانی پشتیوانی دەکات. " +
                "Gemini API لە سنووری خۆڕاییی Google بەکاردێت؛ quota و rate limit هەیە. " +
                "ئەم کلیلی Gemini API جیاوازە لە کلیلی Google Translate. ئینتەرنێت پێویستە."
            textSize = 13f
        })

        fun saveAll() {
            st.geminiTtsKey = key.text.toString()
            st.geminiTtsVoice = voice.selectedItem?.toString() ?: TranslatorSettings.DEFAULT_GEMINI_VOICE
            st.autoSpeak = autoSpeak.isChecked
            st.fast = fast.isChecked
            st.offlineTts = offlineCb.isChecked
            st.offlineVoice = offlineVoice.selectedItemPosition
        }

        AlertDialog.Builder(this)
            .setTitle("ڕێکخستنی دەنگ")
            .setView(box)
            .setPositiveButton("هەڵگرتن") { _, _ ->
                saveAll()
                toast("هەڵگیرا")
            }
            .setNeutralButton("تاقیکردنەوە") { _, _ ->
                saveAll()
                val t = testTts ?: SoraniTts(this, st).also { testTts = it }
                t.speak(
                    listOf("سڵاو، ئەمە تاقیکردنەوەی دەنگە."),
                    onState = {},
                    onError = { toast(it) }
                )
            }
            .setNegativeButton("پاشگەزبوونەوە", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        handler.post(poller)
    }

    override fun onPause() {
        handler.removeCallbacks(poller)
        super.onPause()
    }

    override fun onDestroy() {
        testTts?.shutdown()
        testTts = null
        super.onDestroy()
    }

    private fun updateStatus() {
        statusText.text = if (Settings.canDrawOverlays(this)) {
            "ڕێگەپێدانی پیشاندان: چالاکە ✓"
        } else {
            "ڕێگەپێدانی پیشاندان: هێشتا نەدراوە"
        }
    }

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            toast("سەرەتا ڕێگەپێدانی پیشاندان چالاک بکە")
            openOverlaySettings()
            return
        }

        // Android 13+: ڕێگەپێدانی ئاگادارکردنەوە بۆ نیشاندانی ئاگادارکردنەوەی خزمەتگوزاری
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }

        askMicThenCapture()
    }

    /** دۆخی نوێ مایک پێویستە (قسەکردن بۆ نووسین)؛ ئەگەر ڕێگەی نەدا، ڕووبەرەکە هەر کار دەکات. */
    private fun askMicThenCapture() {
        if (TranslatorSettings(this).mode == 1 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        requestScreenCapture()
    }

    @Suppress("DEPRECATION")
    private fun isRunning(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        return am.getRunningServices(100).any { it.service.className == OverlayService::class.java.name }
    }

    private fun requestScreenCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            // با ڕێگەپێدان یان بێ ڕێگەپێدان بەردەوام دەبین؛ خزمەتگوزاری هەر کار دەکات
            askMicThenCapture()
        } else if (requestCode == REQ_MIC) {
            if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
                toast("مایک ڕێگەی پێنەدرا؛ «قسە» کار ناکات، بەڵام «ڕ» کار دەکات")
            }
            requestScreenCapture()
        }
    }

    @Deprecated("Deprecated in Java")
    private var piperStatus: TextView? = null

    private fun refreshPiperStatus() {
        piperStatus?.text = if (PiperTts.isInstalled(this))
            "مۆدێلی کوردیی نیورالی: هێنراوە ✓"
        else
            "مۆدێلی کوردیی نیورالی: هێشتا نەهێنراوە (دوگمەی خوارەوە دابگرە)"
    }

    private fun importPiperModel(data: Intent) {
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
        data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        toast("مۆدێل دەهێنرێت... (چەند چرکەیەک)")
        Thread {
            val err = PiperTts.importModel(applicationContext, uris)
            Handler(Looper.getMainLooper()).post {
                refreshPiperStatus()
                toast(err ?: "مۆدێلی کوردی هێنرا ✓")
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PIPER_MODEL) {
            if (resultCode == Activity.RESULT_OK && data != null) importPiperModel(data)
            return
        }
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val svc = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                    putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(OverlayService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, svc)
                toast("بابلەکان دەرکەوتن. دەتوانیت بچیتە سەر ئەپی مانگاکەت")
                moveTaskToBack(true)
            } else {
                toast("ڕێگەپێدانی گرتنی شاشە وەرنەگیرا")
            }
        }
    }

    private fun stopTranslator() {
        stopService(Intent(this, OverlayService::class.java))
        toast("وەستێنرا")
    }

    // ---------- یارمەتیدەرەکان ----------

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setOnClickListener { onClick() }
    }

    private fun matchWrap(bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = bottom }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val REQ_NOTIF = 1001
        private const val REQ_CAPTURE = 1002
        private const val REQ_MIC = 1003
        private const val REQ_PIPER_MODEL = 1004
    }
}
