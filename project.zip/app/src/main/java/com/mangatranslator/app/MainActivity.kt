package com.mangatranslator.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.app.AlertDialog
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.Spinner
import androidx.core.content.ContextCompat

/**
 * شاشەی سەرەکی:
 * ١. ڕێگەپێدانی پیشاندان لەسەر ئەپەکانی تر
 * ٢. دەستپێکردن (گرتنی شاشە + بابلی شەمەندەفەر)
 * ٣. وەستاندن
 * ٤. کلیلی Google (ئارەزوومەندانە)
 */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private var testTts: SoraniTts? = null
    private val handler = Handler(Looper.getMainLooper())

    private val poller = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 26f
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap(bottom = dp(8)))

        statusText = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
        }
        root.addView(statusText, matchWrap(bottom = dp(24)))

        root.addView(
            button("١. ڕێگەپێدانی پیشاندان لەسەر ئەپەکانی تر") { openOverlaySettings() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٢. دەستپێکردن") { startFlow() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٣. وەستاندن") { stopTranslator() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٤. کلیلی Google (ئارەزوومەندانە)") { showKeyDialog() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("٥. ڕێکخستنی دەنگ (خوێندنەوە)") { showVoiceDialog() },
            matchWrap(bottom = dp(12))
        )

        root.addView(
            TextView(this).apply {
                text = "دوای دەستپێکردن سێ بابل دەردەکەون:\n" +
                    "«ک» = وەرگێڕانی خۆکار (سەوز = چالاک)\n" +
                    "«وەر» = وەرگێڕانی شاشەی ئێستا (درێژ بگرە بۆ شاردنەوە)\n" +
                    "«دەنگ» = خوێندنەوەی وەرگێڕانەکان بە دەنگ (دووبارە دایبگرە یان درێژ بگرە بۆ وەستاندن)"
                textSize = 14f
            },
            matchWrap(bottom = dp(12))
        )

        setContentView(root)
    }

    private fun showKeyDialog() {
        val st = TranslatorSettings(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(0))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val googleKey = EditText(this).apply {
            hint = "کلیلی API ی Google Cloud Translation"
            setText(st.googleKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(googleKey)
        box.addView(TextView(this).apply {
            text = "ئارەزوومەندانەیە. ئەگەر کلیلت نییە، ئەم خانەیە بەتاڵ بهێڵەرەوە. بێ کلیلیش وەرگێڕان بە Google Translate کار دەکات؛ " +
                "ئەگەر کلیلت هەیە، ڕێگای فەرمی بەکار دێت کە جێگیرترە. ئینتەرنێت پێویستە."
            textSize = 13f
        })

        AlertDialog.Builder(this)
            .setTitle("کلیلی Google")
            .setView(box)
            .setPositiveButton("هەڵگرتن") { _, _ ->
                st.googleKey = googleKey.text.toString()
                toast("هەڵگیرا")
            }
            .setNegativeButton("پاشگەزبوونەوە", null)
            .show()
    }


    private fun showVoiceDialog() {
        val st = TranslatorSettings(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(0))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val key = EditText(this).apply {
            hint = "کلیلی Gemini API لە aistudio.google.com"
            setText(st.geminiTtsKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val voices = listOf("Kore", "Aoede", "Charon", "Puck")
        val voice = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices)
            setSelection(voices.indexOf(st.geminiTtsVoice).coerceAtLeast(0))
        }
        val autoSpeak = CheckBox(this).apply {
            text = "دوای وەرگێڕانی دەستی شاشە، دەقەکە خۆکارانە بە دەنگ بخوێنەوە"
            isChecked = st.autoSpeak
        }
        box.addView(key)
        box.addView(voice)
        box.addView(autoSpeak)
        box.addView(TextView(this).apply {
            text = "خوێندنەوە بە Gemini TTS ـە و کوردیی ناوەندی/سۆرانی پشتیوانی دەکات. " +
                "Gemini API لە سنووری خۆڕاییی Google بەکاردێت؛ quota و rate limit هەیە. " +
                "ئەم کلیلی Gemini API جیاوازە لە کلیلی Google Translate. ئینتەرنێت پێویستە."
            textSize = 13f
        })

        fun saveAll() {
            st.geminiTtsKey = key.text.toString()
            st.geminiTtsVoice = voice.selectedItem?.toString() ?: TranslatorSettings.DEFAULT_GEMINI_VOICE
            st.autoSpeak = autoSpeak.isChecked
        }

        AlertDialog.Builder(this)
            .setTitle("ڕێکخستنی دەنگ")
            .setView(box)
            .setPositiveButton("هەڵگرتن") { _, _ ->
                saveAll()
                toast("هەڵگیرا")
            }
            .setNeutralButton("تاقیکردنەوە") { _, _ ->
                saveAll()
                val t = testTts ?: SoraniTts(this, st).also { testTts = it }
                t.speak(
                    listOf("سڵاو، ئەمە تاقیکردنەوەی دەنگە."),
                    onState = {},
                    onError = { toast(it) }
                )
            }
            .setNegativeButton("پاشگەزبوونەوە", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        handler.post(poller)
    }

    override fun onPause() {
        handler.removeCallbacks(poller)
        super.onPause()
    }

    override fun onDestroy() {
        testTts?.shutdown()
        testTts = null
        super.onDestroy()
    }

    private fun updateStatus() {
        statusText.text = if (Settings.canDrawOverlays(this)) {
            "ڕێگەپێدانی پیشاندان: چالاکە ✓"
        } else {
            "ڕێگەپێدانی پیشاندان: هێشتا نەدراوە"
        }
    }

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            toast("سەرەتا ڕێگەپێدانی پیشاندان چالاک بکە")
            openOverlaySettings()
            return
        }

        // Android 13+: ڕێگەپێدانی ئاگادارکردنەوە بۆ نیشاندانی ئاگادارکردنەوەی خزمەتگوزاری
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }

        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            // با ڕێگەپێدان یان بێ ڕێگەپێدان بەردەوام دەبین؛ خزمەتگوزاری هەر کار دەکات
            requestScreenCapture()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val svc = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                    putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(OverlayService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, svc)
                toast("بابلەکە دەرکەوت. دەتوانیت بچیتە سەر ئەپی مانگاکەت")
                moveTaskToBack(true)
            } else {
                toast("ڕێگەپێدانی گرتنی شاشە وەرنەگیرا")
            }
        }
    }

    private fun stopTranslator() {
        stopService(Intent(this, OverlayService::class.java))
        toast("وەستێنرا")
    }

    // ---------- یارمەتیدەرەکان ----------

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setOnClickListener { onClick() }
    }

    private fun matchWrap(bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = bottom }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val REQ_NOTIF = 1001
        private const val REQ_CAPTURE = 1002
    }
}
