package com.mangatranslator.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.app.AlertDialog
import android.text.InputType
import android.widget.Button
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.HorizontalScrollView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.widget.CheckBox
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.Spinner
import androidx.core.content.ContextCompat

/**
 * شاشەی سەرەکی:
 * ١. ڕێگەپێدانی پیشاندان لەسەر ئەپەکانی تر
 * ٢. دەستپێکردن (گرتنی شاشە + بابلی شەمەندەفەر)
 * ٣. وەستاندن
 * ٤. کلیلی Google (ئارەزوومەندانە)
 */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private var testTts: SoraniTts? = null
    private val handler = Handler(Looper.getMainLooper())

    private val poller = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 1000)
        }
    }

    private lateinit var frame: FrameLayout
    private lateinit var scroll: ScrollView
    private lateinit var fab: SpeakFab
    private var coach: CoachOverlay? = null
    private var picker: LiteracyPicker.Handle? = null
    private val tourViews = HashMap<String, View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GlassStyle.load(this)
        val modeSt = TranslatorSettings(this)
        DeviceProfile.init(this)
        GeminiModels.init(this)

        val pad = dp(18)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(34), pad, dp(124))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        /** کارتی شووشەیی بە ئایکۆن و ناونیشان؛ key بۆ ڕێنمایی (چوارگۆشەی چالاک). */
        fun glass(key: String?, icon: String, heading: String): LinearLayout {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(16), dp(18), dp(18))
                background = rounded(c(R.color.card), 26, c(R.color.card_stroke), dp(1))
                elevation = cardElev()
            }
            val head = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            head.addView(TextView(this).apply {
                text = icon
                textSize = 18f
                gravity = Gravity.CENTER
                background = rounded((pal.a1 and 0x00FFFFFF) or 0x1F000000, 14)
            }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(12) })
            head.addView(TextView(this).apply {
                text = heading
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(c(R.color.text_main))
            })
            card.addView(head, matchWrap(bottom = dp(12)))
            if (key != null) tourViews[key] = card
            root.addView(card, matchWrap(bottom = dp(16)))
            return card
        }

        // ---- ئایکۆنی ڕەنگ لە سەرەوە ----
        val topRow = FrameLayout(this)
        val palBtn = TextView(this).apply {
            text = "🎨"
            textSize = 21f
            gravity = Gravity.CENTER
            // بازنەی گرادیێنتی هەمان ڕەنگی ئێستای ئەپ (وەک پێشبینینی ڕەنگەکە)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.a2, pal.a1, pal.bgBottom)).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), Color.parseColor(if (pal.light) "#33000000" else "#99FFFFFF"))
            }
            elevation = dp(5).toFloat()
            setOnClickListener { showThemeDialog() }
        }
        topRow.addView(palBtn, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.LEFT or Gravity.CENTER_VERTICAL))
        tourViews["theme"] = palBtn
        root.addView(topRow, matchWrap(bottom = dp(2)))

        // ---- سەرەوە: لۆگۆ + ناو + دۆخ ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(4), 0, dp(4))
        }
        val logoWrap = FrameLayout(this).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(30).toFloat()
                setColor(if (pal.light) Color.WHITE else Color.parseColor("#1AFFFFFF"))
                setStroke(dp(1), c(R.color.card_stroke))
            }
            elevation = if (pal.light) dp(8).toFloat() else 0f
        }
        logoWrap.addView(ImageView(this).apply {
            setImageResource(R.drawable.app_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(84), dp(84)))
        header.addView(logoWrap, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(12) })
        header.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(c(R.color.text_main))
            gravity = Gravity.CENTER
        }, matchWrap(bottom = dp(4)))
        header.addView(TextView(this).apply {
            text = "وەرگێڕانی ڕاستەوخۆی شاشە بۆ کوردیی سۆرانی"
            textSize = 14f
            setTextColor(c(R.color.text_dim))
            gravity = Gravity.CENTER
        }, matchWrap(bottom = dp(14)))
        statusText = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        header.addView(statusText, LinearLayout.LayoutParams(-2, -2))
        tourViews["header"] = header
        tourViews["status"] = statusText
        root.addView(header, matchWrap(bottom = dp(18)))

        // ---- کارتی سەرەکی: دەستپێکردن / وەستاندن ----
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.a1, pal.a2)).apply {
                cornerRadius = dp(28).toFloat()
            }
            elevation = dp(8).toFloat()
        }
        hero.addView(TextView(this).apply {
            text = "ئامادەیت بۆ وەرگێڕان؟"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }, matchWrap(bottom = dp(4)))
        hero.addView(TextView(this).apply {
            text = "پانێلی دوگمەکان لەسەر هەموو ئەپەکان دەردەکەوێت"
            textSize = 13f
            setTextColor(0xD9FFFFFF.toInt())
        }, matchWrap(bottom = dp(16)))
        val heroRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val b2 = button("▶  دەستپێکردن", rounded(Color.WHITE, 20), pal.a1) { startFlow() }
        val b3 = button("■  وەستاندن", rounded(0x33FFFFFF, 20), Color.WHITE) { stopTranslator() }
        heroRow.addView(b2, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.6f).apply { marginEnd = dp(5) })
        heroRow.addView(b3, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(5) })
        hero.addView(heroRow, matchWrap())
        tourViews["hero"] = hero
        tourViews["b2"] = b2; tourViews["b3"] = b3
        root.addView(hero, matchWrap(bottom = dp(16)))

        // ---- خێرایی دەنگ ----
        val cardSpeed = glass("speed", "⚡", "خێرایی دەنگ")
        val chips = ArrayList<Pair<Float, TextView>>()
        fun paintChips() {
            val cur = modeSt.speechSpeed
            for ((v, tv) in chips) {
                val sel = v == cur
                tv.background = if (sel) gradient(c(R.color.accent_blue), c(R.color.accent_cyan))
                else rounded(c(R.color.card), 16, c(R.color.card_stroke), dp(1))
                tv.setTextColor(if (sel) Color.WHITE else c(R.color.text_main))
            }
        }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in TranslatorSettings.SPEEDS) {
            val label = if (v == 1f) "ئاسایی" else "${v.toString().trimEnd('0').trimEnd('.')}x"
            val tv = TextView(this).apply {
                text = label
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(16), 0, dp(16), 0)
                setOnClickListener { modeSt.speechSpeed = v; paintChips() }
            }
            chips.add(v to tv)
            chipRow.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(42)).apply { marginEnd = dp(8) })
        }
        paintChips()
        cardSpeed.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow)
        }, matchWrap())

        // ---- چوونە لێواری شاشە ----
        val cardDock = glass("dock", "📌", "چوونە لێواری شاشە")
        val steps = TranslatorSettings.DOCK_STEPS
        fun fmt(sec: Int): String =
            if (sec < 60) "$sec چرکە"
            else {
                val m = sec / 60f
                (if (m % 1f == 0f) m.toInt().toString() else m.toString()) + " خولەک"
            }
        val dockLabel = TextView(this).apply {
            textSize = 14f
            setTextColor(c(R.color.text_main))
        }
        val curIdx = steps.indexOfFirst { it >= modeSt.dockDelaySec }.let { if (it < 0) steps.lastIndex else it }
        dockLabel.text = "بابلەکان دوای " + fmt(steps[curIdx]) + " بێ بەکارهێنان دەچنە لێوار"
        val dockBar = SeekBar(this).apply {
            max = steps.lastIndex
            progress = curIdx
            progressTintList = ColorStateList.valueOf(pal.a2)
            thumbTintList = ColorStateList.valueOf(pal.a2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    dockLabel.text = "بابلەکان دوای " + fmt(steps[p]) + " بێ بەکارهێنان دەچنە لێوار"
                    if (fromUser) modeSt.dockDelaySec = steps[p]
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        cardDock.addView(dockLabel, matchWrap(bottom = dp(4)))
        cardDock.addView(dockBar, matchWrap())

        // ---- ڕام و خێرایی ----
        val cardMem = glass(null, "🚀", "ڕام و خێرایی (ئۆفلاین)")
        val idleSteps = TranslatorSettings.IDLE_STEPS
        fun idleText(v: Int) = if (v == 0) "هەرگیز ئازاد مەکە (خێراترین، ڕامی زیاتر)" else "دوای $v خولەک بێکاری ئازاد بکرێت"
        val idleLabel = TextView(this).apply {
            textSize = 14f
            setTextColor(c(R.color.text_main))
        }
        val idleCur = idleSteps.indexOf(modeSt.modelIdleMin).coerceAtLeast(0)
        idleLabel.text = "مۆدێلە ئۆفلاینەکان: " + idleText(idleSteps[idleCur])
        val idleBar = SeekBar(this).apply {
            max = idleSteps.lastIndex
            progress = idleCur
            progressTintList = ColorStateList.valueOf(pal.a2)
            thumbTintList = ColorStateList.valueOf(pal.a2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    idleLabel.text = "مۆدێلە ئۆفلاینەکان: " + idleText(idleSteps[p])
                    if (fromUser) modeSt.modelIdleMin = idleSteps[p]
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        cardMem.addView(idleLabel, matchWrap(bottom = dp(4)))
        cardMem.addView(idleBar, matchWrap())

        // ---- دۆخی ڕامی کەم (مۆبایلی ٤ یان ٦ گیگ) ----
        val lowNames = listOf(
            "خۆکار (بەپێی ڕامی مۆبایل)",
            "هەمیشە چالاک (سووکترین، بۆ مۆبایلی خاو)",
            "هەمیشە ناچالاک (ڕەسەنترین کوالێتی)"
        )
        val lowLabel = TextView(this).apply {
            textSize = 14f
            setTextColor(c(R.color.text_main))
            setPadding(0, dp(10), 0, dp(4))
        }
        fun lowText() {
            val now = if (DeviceProfile.low) "ئێستا: چالاکە" else "ئێستا: ناچالاکە"
            lowLabel.text = "دۆخی ڕامی کەم: " + lowNames[modeSt.lowRamMode] + "\n" + now + " — بۆ گۆڕین دایبگرە"
        }
        lowText()
        lowLabel.setOnClickListener {
            modeSt.lowRamMode = (modeSt.lowRamMode + 1) % 3
            DeviceProfile.refresh(this)
            lowText()
        }
        cardMem.addView(lowLabel, matchWrap(bottom = dp(4)))

        // ---- دوگمەکانی پانێل ----
        val cardItems = glass(null, "🎛", "دوگمەکانی پانێل")
        cardItems.addView(TextView(this).apply {
            text = "ئەوانەی دەتەوێت لە پانێلی floating دەربکەون هەڵیانبژێرە. (لە ناو پانێلەکەش دەتوانیت بە «✎ دەستکاریکردنی دوگمەکان» بیگۆڕیت)"
            textSize = 13f
            setTextColor(c(R.color.text_dim))
        }, matchWrap(bottom = dp(6)))
        for ((key, name) in TranslatorSettings.PANEL_ITEMS) {
            cardItems.addView(CheckBox(this).apply {
                text = name
                setTextColor(c(R.color.text_main))
                isChecked = !modeSt.isItemHidden(key)
                setOnCheckedChangeListener { _, v ->
                    modeSt.setItemHidden(key, !v)
                    OverlayService.instance?.refreshItems()
                }
            }, matchWrap(bottom = dp(2)))
        }

        // ---- نووسینی ئۆفلاین ----
        val cardStt = glass("stt", "✍", "نووسینی ئۆفلاین (Vekol)")
        val sttCb = CheckBox(this).apply {
            text = "قسە ← نووسین بە مۆدێلی ئۆفلاین (بێ ئینتەرنێت). ئەگەر کوژاوە بێت Gemini بەکاردێت، کە بۆ قسەی شێوەزاری باشترە"
            setTextColor(c(R.color.text_main))
            isChecked = modeSt.offlineStt
            setOnCheckedChangeListener { _, v -> modeSt.offlineStt = v }
        }
        val learnStatus = TextView(this).apply {
            textSize = 13f
            setTextColor(c(R.color.text_dim))
        }
        fun refreshLearn() {
            learnStatus.text = "وشەی فێربوو: " + KurdishLearn.learnedCount(this@MainActivity)
        }
        refreshLearn()
        val learnCb = CheckBox(this).apply {
            text = "فێربوون: کاتێک «✨ چاک بکە» دادەگریت، وشە چاککراوەکان فێر ببێت و دوای دووجار خۆی بیانگۆڕێت (بنەڕەت: کوژاوە)"
            setTextColor(c(R.color.text_main))
            isChecked = modeSt.learnFix
            setOnCheckedChangeListener { _, v -> modeSt.learnFix = v }
        }
        val learnClear = button("پاککردنەوەی وشە فێربووەکان", outline(Color.parseColor("#FF5C6C")), Color.parseColor("#FF5C6C")) {
            KurdishLearn.clear(this)
            refreshLearn()
            toast("وشە فێربووەکان سڕانەوە")
        }
        cardStt.addView(sttCb, matchWrap(bottom = dp(4)))
        cardStt.addView(learnCb, matchWrap(bottom = dp(4)))
        cardStt.addView(learnStatus, matchWrap(bottom = dp(4)))
        cardStt.addView(learnClear, matchWrap(bottom = dp(8)))
        cardStt.addView(TextView(this).apply {
            text = "ناوەکانم (هەر ناوێک لە دێڕێک یان بە کۆما). دەنگەکە بۆ ئەم ناوانە ڕێک دەخرێت:"
            textSize = 13f
            setTextColor(c(R.color.text_dim))
        }, matchWrap(bottom = dp(4)))
        cardStt.addView(styledEdit("نموونە: قەهار، ڕێبین، دیلان", modeSt.myNames, true).apply {
            typeface = Typeface.DEFAULT
            textSize = 14f
            minLines = 3
            var cleaning = false
            fun cleanNow(et: EditText, keepLast: Boolean) {
                val cur = et.text?.toString() ?: return
                val (cleaned, removed) = KurdishLearn.cleanNames(cur, keepLast)
                if (!removed) return
                cleaning = true
                et.setText(cleaned)
                et.setSelection(cleaned.length)
                cleaning = false
                modeSt.myNames = cleaned
                toast("تۆمارکراوە")
            }
            setOnFocusChangeListener { v, hasFocus -> if (!hasFocus) cleanNow(v as EditText, false) }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(e: android.text.Editable?) {
                    if (cleaning) return
                    modeSt.myNames = e?.toString() ?: ""
                    cleanNow(this@apply, true)
                }
                override fun beforeTextChanged(t: CharSequence?, i1: Int, i2: Int, i3: Int) {}
                override fun onTextChanged(t: CharSequence?, i1: Int, i2: Int, i3: Int) {}
            })
        }, matchWrap(bottom = dp(8)))

        // ---- ڕێنمایی دەنگی (خوێندەواری) ----
        val cardLit = glass("lit", "🔊", "ڕێنمایی دەنگی")
        cardLit.addView(TextView(this).apply {
            text = "ئەپەکە دەتوانێت هەموو بەشەکان بە دەنگ بۆ نەخوێندەوار بخوێنێتەوە."
            textSize = 13f
            setTextColor(c(R.color.text_dim))
        }, matchWrap(bottom = dp(10)))
        val litChips = ArrayList<Pair<Int, TextView>>()
        fun paintLit() {
            for ((n, tv) in litChips) {
                val sel = modeSt.literacy == n
                tv.background = if (sel) gradient(c(R.color.accent_blue), c(R.color.accent_cyan))
                else rounded(c(R.color.card), 16, c(R.color.card_stroke), dp(1))
                tv.setTextColor(if (sel) Color.WHITE else c(R.color.text_main))
            }
        }
        val litRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((n, label) in listOf(1 to "خوێندەوارم", 2 to "نەخوێندەوارم")) {
            val tv = TextView(this).apply {
                text = "$n   $label"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener {
                    modeSt.literacy = n
                    paintLit()
                    Narrator.stop()
                    if (n == 2) Narrator.speak(this@MainActivity, "باشە. ئەپەکە ئێستا هەموو شتێک بە دەنگ بۆت دەخوێنێتەوە.")
                }
            }
            litChips.add(n to tv)
            litRow.addView(tv, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(8) })
        }
        paintLit()
        cardLit.addView(litRow, matchWrap(bottom = dp(10)))
        cardLit.addView(
            button("▶  دووبارەکردنەوەی ڕێنمایی", outline(c(R.color.accent_cyan)), c(R.color.accent_cyan)) { startTour(true) },
            matchWrap()
        )

        // ---- زمانی دەقی سەر شاشە ----
        root.addView(
            button("🌐 زمانی دەق (خۆکار و شاشە): " + SourceLangs.labels[SourceLangs.codes.indexOf(TranslatorSettings(this).sourceLang).coerceAtLeast(0)],
                rounded(c(R.color.card), 14, c(R.color.card_stroke), dp(1)), c(R.color.text_main)) { showLangDialog() },
            matchWrap(bottom = dp(10))
        )

        // ---- Accessibility: بێ داواکردنی ڕێگەپێدانی گرتنی شاشە ----
        a11yAtBuild = MangaAccessibilityService.isEnabled(this)
        root.addView(
            button("♿ Accessibility: " + (if (MangaAccessibilityService.isEnabled(this)) "چالاکە ✓" else "ناچالاکە"),
                rounded(c(R.color.card), 14, c(R.color.card_stroke), dp(1)), c(R.color.text_main)) { showA11yDialog() },
            matchWrap(bottom = dp(10))
        )

        // ---- ڕەنگی باگراوندی نووسینەکانی تەنیش دوگمەکان ----
        root.addView(
            button("🏷 ڕەنگی نووسینی تەنیش دوگمەکان",
                rounded(c(R.color.card), 14, c(R.color.card_stroke), dp(1)), c(R.color.text_main)) { showLabelColorDialog() },
            matchWrap(bottom = dp(10))
        )

        // ---- ڕەنگی باگراوندی دەقی وەرگێڕدراو ----
        root.addView(
            button("🖍 ڕەنگی باگراوندی نووسین",
                rounded(c(R.color.card), 14, c(R.color.card_stroke), dp(1)), c(R.color.text_main)) { showTextBgDialog() },
            matchWrap(bottom = dp(10))
        )

        // ---- ڕەنگی هێماکانی بابلەکان ----
        root.addView(
            button("🎨 ڕەنگی هێماکان",
                rounded(c(R.color.card), 14, c(R.color.card_stroke), dp(1)), c(R.color.text_main)) { showIconColorDialog() },
            matchWrap(bottom = dp(10))
        )

        // ---- ڕێکخستنەکان ----
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(
            button("🔊 دەنگ", rounded(c(R.color.card), 14, c(R.color.card_stroke), dp(1)), c(R.color.text_main)) { showVoiceDialog() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        tourViews["settings"] = row
        root.addView(row, matchWrap(bottom = dp(20)))

        // ---- یارمەتی ----
        val cardHelp = glass("help", "❓", "چۆن بەکاری بهێنم؟")
        cardHelp.addView(TextView(this).apply {
            text = "دوای «دەستپێکردن»، پانێلێکی شەمەندەفەر دەردەکەوێت (دەتوانیت بیکێشیت):\n" +
                "🔄 وەرگێڕانی خۆکار — سەوز = چالاک\n" +
                "🌐 وەرگێڕانی شاشەی ئێستا (درێژ بگرە بۆ شاردنەوە)\n" +
                "🔊 خوێندنەوەی وەرگێڕانەکان بە دەنگ\n" +
                "▢ ڕووبەرێک بکێشە؛ دەیکات بە کوردی و دەیخوێنێتەوە (کلیلی Gemini پێویستە)\n" +
                "🎙 بە کوردی قسە بکە؛ دەنووسرێت و کۆپی دەکرێت\n" +
                "\nکاتێک هەر دوگمەیەک کار دەکات، لۆدینگێکی ستایلی Gemini لەتەنیشتی دەردەکەوێت. " +
                "دوای ماوەیەک بێ بەکارهێنان، پانێلەکە دەبێتە هێڵێکی باریک لە لێواری شاشە؛ دەستی لێ بدە تا بگەڕێتەوە."
            textSize = 13f
            setLineSpacing(0f, 1.25f)
            setTextColor(c(R.color.text_dim))
        })

        window.statusBarColor = pal.bgTop
        window.navigationBarColor = pal.bgBottom
        if (pal.light) {
            var f = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = f
        }
        scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            setBackgroundColor(Color.TRANSPARENT)
            addView(root)
        }
        frame = FrameLayout(this).apply {
            addView(GlassBackground(this@MainActivity, pal),
                FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(scroll)
        }
        fab = SpeakFab(this, pal.a1, pal.a2).apply { setOnClickListener { onFabTap() } }
        tourViews["fab"] = fab
        frame.addView(fab, FrameLayout.LayoutParams(dp(104), dp(68), Gravity.BOTTOM or Gravity.LEFT).apply {
            leftMargin = dp(10); bottomMargin = dp(14)
        })
        setContentView(frame)

        // دەرکەوتنی نەرمی کارتەکان
        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(24).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 55L).setDuration(380).start()
        }

        Downloads.ensureAll(this)   // هەر پێداویستییەک نەدابەزیبێت، لە پاشبنەما تا تەواو دەبێت دەیدابەزێنێت
        if (modeSt.literacy != 1) Narrator.warmUp(this)

        // یەکەم کردنەوە: پرسیاری خوێندەواری، پاشان ڕێنمایی
        if (modeSt.literacy == 0) {
            picker = LiteracyPicker.show(this, frame, pal) { _ ->
                picker = null
                recreate()
            }
            fab.bringToFront()
        } else if (!modeSt.tourDone) {
            frame.postDelayed({ if (!isFinishing) startTour(modeSt.literacy == 2) }, 1000)
        }
    }

    // ---------------------------------------------------------------- ڕێنمایی دەنگی

    private fun onFabTap() {
        val p = picker
        val c = coach
        when {
            p != null -> p.speakNow()
            c != null -> c.replay()
            else -> startTour(true)
        }
    }

    private fun startTour(voice: Boolean) {
        if (coach != null || picker != null) return
        val ov = CoachOverlay(this, pal, tourSteps(), scroll, voice) {
            coach = null
            TranslatorSettings(this).tourDone = true
        }
        coach = ov
        frame.addView(ov, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        fab.bringToFront()
        ov.start()
    }

    private fun tourSteps(): List<CoachStep> {
        fun s(key: String, text: String, speech: String) = CoachStep({ tourViews[key] }, text, speech)
        val needPerm = !overlayOk()
        return listOfNotNull(
            s("header", "بەخێربێیت! با بەشەکانی ئەپەکەت پیشان بدەم.",
                "بەخێربێیت. با بەشەکانی ئەپەکەت پیشان بدەم."),
            if (needPerm) s("status", "ئەمە ئاگادارکردنەوەی ڕێگەپێدانە. دایبگرە و ڕێگە بدە؛ دوای ڕێگەپێدان خۆی دەشاردرێتەوە.",
                "ئەمە ئاگادارکردنەوەی ڕێگەپێدانە. دایبگرە و ڕێگە بدە. دوای ئەوە خۆی دەشاردرێتەوە.") else null,
            s("theme", "ئەم ئایکۆنە ڕەنگی ئەپەکە دەگۆڕێت.",
                "ئەم ئایکۆنەی سەرەوە ڕەنگی ئەپەکە دەگۆڕێت. دایبگرە و ڕەنگێک هەڵبژێرە."),
            s("b2", "دەستپێکردن: دایبگرە. ئەگەر پێویست بوو، خۆی داوای ڕێگەپێدان دەکات؛ ڕێگە بدە.",
                "ئەمە دوگمەی دەستپێکردنە. دایبگرە. ئەگەر ئەپەکە داوای ڕێگەپێدانی کرد، ڕێگە بدە. پاشان پانێلی دوگمەکان دەردەکەوێت."),
            s("b3", "وەستاندن: هەر کاتێک دەتەوێت دوگمەکان بوەستێنیت.",
                "ئەمە دوگمەی وەستاندنە. هەر کاتێک دەتەوێت بابلەکان بوەستێنیت، ئەمە دابگرە."),
            s("speed", "لێرە خێرایی دەنگ دیاری دەکەیت.",
                "لێرە خێرایی دەنگەکە دیاری دەکەیت. ئەگەر هێواش دەتەوێت، ژمارەی بچووکتر هەڵبژێرە."),
            s("dock", "بە ڕاکێشانی ئەم هێڵە، دیاری دەکەیت بابلەکان دوای چەند چرکە بچنە لێواری شاشە.",
                "بە ڕاکێشانی ئەم هێڵە، دیاری دەکەیت بابلەکان دوای چەند چرکە بچنە لێواری شاشە."),
            s("stt", "لێرە قسەکردن بۆ نووسین، بێ ئینتەرنێت چالاکە.",
                "لێرە قسەکردن بۆ نووسین بێ ئینتەرنێت چالاکە. قسە دەکەیت و ئەپەکە دەینووسێت."),
            s("lit", "لێرە دەتوانیت دووبارە هەڵبژێریت خوێندەواریت یان نا، و ڕێنماییەکە دووبارە بکەیتەوە.",
                "لێرە دەتوانیت دووبارە هەڵبژێریت خوێندەواریت یان نەخوێندەوار. ژمارە یەک بۆ خوێندەوار، ژمارە دوو بۆ نەخوێندەوار."),
            s("settings", "ڕێکخستنی دەنگ لێرەیە.",
                "لێرە ڕێکخستنی دەنگ و کلیلی گووگڵ دەبینیت."),
            s("help", "لێرە ڕوونکردنەوەی دوگمەکانی پانێل هەیە.",
                "لێرە ڕوونکردنەوەی دوگمەکانی پانێلی شەمەندەفەر هەیە: وەرگێڕانی خۆکار، وەرگێڕانی شاشە، دەنگ، ڕووبەر، و قسەکردن بۆ نووسین."),
            s("fab", "ئەم ئایکۆنە هەمیشە لێرەیە. هەر کاتێک دایبگریت، ئەپەکە بۆت دەخوێنێتەوە.",
                "ئەم ئایکۆنە هەمیشە لێرەیە. هەر کاتێک دایبگریت، ئەپەکە هەموو بەشەکان بۆ دەخوێنێتەوە.")
        )
    }

    private fun readBtn(speech: String) = TextView(this).apply {
        text = "🔊  بیخوێنەوە"
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = gradient(c(R.color.accent_blue), c(R.color.accent_cyan))
        setOnClickListener { Narrator.speak(this@MainActivity, speech) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val c = coach
        if (c != null) { c.finish(); return }
        if (picker != null) return
        super.onBackPressed()
    }

    // ---------------------------------------------------------------- پەنجەرەکان بە دیزاینی ئەپەکە

    private fun openDialog(
        icon: String,
        heading: String,
        speech: String?,
        tall: Boolean,
        footer: (android.app.Dialog) -> List<View>,
        fill: (LinearLayout) -> Unit
    ): android.app.Dialog {
        val dlg = android.app.Dialog(this, android.R.style.Theme_Translucent_NoTitleBar)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(16), dp(16), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(pal.bgTop, pal.bgBottom)).apply {
                cornerRadius = dp(26).toFloat()
                setStroke(dp(1), c(R.color.card_stroke))
            }
            isClickable = true
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = icon
            textSize = 18f
            gravity = Gravity.CENTER
            background = rounded((pal.a1 and 0x00FFFFFF) or 0x33000000, 12)
        }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(10) })
        head.addView(TextView(this).apply {
            text = heading
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(c(R.color.text_main))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (speech != null) {
            head.addView(TextView(this).apply {
                text = "🔊"
                textSize = 17f
                gravity = Gravity.CENTER
                background = gradient(c(R.color.accent_blue), c(R.color.accent_cyan))
                setOnClickListener { Narrator.speak(this@MainActivity, speech) }
            }, LinearLayout.LayoutParams(dp(44), dp(38)))
        }
        card.addView(head, matchWrap(bottom = dp(12)))

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fill(body)
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(body)
        }
        // ئەگەر ناوەڕۆکی پەنجەرەکە لە شاشە درێژتر بوو، ScrollView سنووردار دەکرێت تا دوگمەکانی خوارەوە (داخستن...) نەبڕدرێن
        val bodyW = resources.displayMetrics.widthPixels - dp(28 + 32)
        body.measure(
            View.MeasureSpec.makeMeasureSpec(bodyW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxBody = resources.displayMetrics.heightPixels - dp(290)
        card.addView(
            sv,
            if (tall) LinearLayout.LayoutParams(-1, 0, 1f)
            else if (body.measuredHeight > maxBody) LinearLayout.LayoutParams(-1, maxBody)
            else LinearLayout.LayoutParams(-1, -2)
        )

        val foot = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in footer(dlg)) {
            foot.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        card.addView(foot, matchWrap().apply { topMargin = dp(12) })

        val frameRoot = FrameLayout(this).apply {
            setBackgroundColor(0xB3000000.toInt())
            setOnClickListener { dlg.dismiss() }
        }
        val h = if (tall) (resources.displayMetrics.heightPixels * 0.86f).toInt() else FrameLayout.LayoutParams.WRAP_CONTENT
        frameRoot.addView(card, FrameLayout.LayoutParams(-1, h, Gravity.CENTER).apply {
            setMargins(dp(14), dp(14), dp(14), dp(14))
        })
        dlg.setContentView(frameRoot)
        dlg.window?.setLayout(-1, -1)
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dlg.setOnDismissListener { Narrator.stop() }
        dlg.show()
        if (speech != null) Narrator.autoSpeak(this, speech)
        return dlg
    }

    // ---------------------------------------------------------------- ڕەنگە مۆدێرنەکان (هاوبەش بۆ هەموو بەشەکان)

    private fun lighten(col: Int, f: Float): Int {
        val r = (Color.red(col) + (255 - Color.red(col)) * f).toInt()
        val g = (Color.green(col) + (255 - Color.green(col)) * f).toInt()
        val b = (Color.blue(col) + (255 - Color.blue(col)) * f).toInt()
        return Color.rgb(r, g, b)
    }

    private fun isLightColor(col: Int): Boolean =
        (0.299 * Color.red(col) + 0.587 * Color.green(col) + 0.114 * Color.blue(col)) > 170

    /**
     * تۆڕی ڕەنگەکان: بازنەی تەواو (نەک ئەلیپس)، ڕووناکییەکی نەرم لەسەرەوە، و تیکی هەڵبژاردن.
     * withReset = دوگمەی ↺ بۆ گەڕانەوە بۆ ڕەنگی بنەڕەت (onPick(0)).
     */
    private fun swatchGrid(parent: LinearLayout, initial: Int?, withReset: Boolean, onPick: (Int) -> Unit) {
        val cols = 6
        val size = dp(38)
        val cells = ArrayList<Pair<Int, TextView>>()
        var selected: Int? = initial
        fun paint() {
            cells.forEach { (col, v) ->
                val sel = col == selected
                if (col == 0) {
                    v.text = "↺"
                    v.setTextColor(c(R.color.text_main))
                    v.background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(c(R.color.card))
                        setStroke(dp(if (sel) 3 else 1), if (sel) c(R.color.text_main) else c(R.color.card_stroke))
                    }
                } else {
                    v.text = if (sel) "✓" else ""
                    v.setTextColor(if (isLightColor(col)) Color.parseColor("#101828") else Color.WHITE)
                    v.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(lighten(col, 0.28f), col)).apply {
                        shape = GradientDrawable.OVAL
                        setStroke(dp(if (sel) 3 else 1), if (sel) c(R.color.text_main) else Color.parseColor("#55888888"))
                    }
                }
            }
        }
        val items: List<Int> = (if (withReset) listOf(0) else emptyList()) + MODERN_SWATCHES
        items.chunked(cols).forEach { rowColors ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowColors.forEach { col ->
                val cell = FrameLayout(this)
                val sw = TextView(this).apply {
                    gravity = Gravity.CENTER
                    textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD
                    setOnClickListener { selected = col; paint(); onPick(col) }
                }
                cells.add(col to sw)
                cell.addView(sw, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
                r.addView(cell, LinearLayout.LayoutParams(0, dp(46), 1f))
            }
            repeat(cols - rowColors.size) { r.addView(View(this), LinearLayout.LayoutParams(0, dp(46), 1f)) }
            parent.addView(r, matchWrap())
        }
        paint()
    }

    /** ڕەنگی ئازاد: دوو سلایدەر، ڕەنگ (hue) و پڕیی ڕەنگ (پاستێل ← زیندوو) */
    private fun freeColor(parent: LinearLayout, onPick: (Int) -> Unit) {
        var hue = 200f
        var sat = 0.75f
        fun fire() = onPick(Color.HSVToColor(floatArrayOf(hue.coerceAtMost(359f), sat, 1f)))
        fun bar(max: Int, start: Int, colors: IntArray, change: (Int) -> Unit) = SeekBar(this).apply {
            this.max = max
            progress = start
            progressDrawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors).apply {
                cornerRadius = dp(8).toFloat()
            }
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) { change(p); fire() } }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val rainbow = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 0.75f, 1f)) }
        parent.addView(note("ڕەنگ"), matchWrap().apply { topMargin = dp(8) })
        parent.addView(bar(360, 200, rainbow) { hue = it.toFloat() }, LinearLayout.LayoutParams(-1, dp(34)))
        parent.addView(note("پڕیی ڕەنگ (چەپ = پاستێل، ڕاست = زیندوو)"), matchWrap())
        parent.addView(bar(100, 75, intArrayOf(Color.WHITE, Color.parseColor("#FF2D8A"))) { sat = (it / 100f).coerceIn(0.1f, 1f) }, LinearLayout.LayoutParams(-1, dp(34)))
    }

    private fun dlgBtn(label: String, kind: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(13), dp(8), dp(13))
        when (kind) {
            0 -> { background = gradient(c(R.color.accent_blue), c(R.color.accent_cyan)); setTextColor(Color.WHITE) }
            1 -> { background = outline(c(R.color.accent_cyan)); setTextColor(c(R.color.accent_cyan)) }
            else -> {
                background = rounded(c(R.color.card), 16, c(R.color.card_stroke), dp(1))
                setTextColor(c(R.color.text_dim))
            }
        }
        setOnClickListener { onClick() }
    }

    private fun subCard(parent: LinearLayout, heading: String? = null): LinearLayout {
        val sc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(c(R.color.card), 18, c(R.color.card_stroke), dp(1))
        }
        if (heading != null) {
            sc.addView(TextView(this).apply {
                text = heading
                textSize = 13.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(c(R.color.accent_cyan))
            }, matchWrap(bottom = dp(8)))
        }
        parent.addView(sc, matchWrap(bottom = dp(10)))
        return sc
    }

    private fun styledCheck(label: String, checked: Boolean) = CheckBox(this).apply {
        text = label
        textSize = 13.5f
        setTextColor(c(R.color.text_main))
        isChecked = checked
        buttonTintList = ColorStateList.valueOf(pal.a2)
        setLineSpacing(0f, 1.15f)
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(c(R.color.text_dim))
        setLineSpacing(0f, 1.2f)
    }

    private fun styledEdit(hintText: String, value: String, multi: Boolean) = EditText(this).apply {
        hint = hintText
        setText(value)
        textSize = 13f
        setTextColor(c(R.color.text_main))
        setHintTextColor(c(R.color.text_dim))
        background = rounded(Color.parseColor(if (pal.light) "#0F000000" else "#26000000"), 14, c(R.color.card_stroke), dp(1))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        inputType = if (multi)
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        else
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        if (multi) { minLines = 2; typeface = Typeface.MONOSPACE; textSize = 12f }
    }

    private fun addSpinner(parent: LinearLayout, items: List<String>, sel: Int): Spinner {
        val ink = c(R.color.text_main)
        val dropBg = if (pal.light) Color.WHITE else pal.bgBottom
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(ink); v.textSize = 14f
                return v
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent) as TextView
                v.setTextColor(ink); v.textSize = 14f
                v.setBackgroundColor(dropBg)
                v.setPadding(dp(14), dp(12), dp(14), dp(12))
                return v
            }
        }
        val sp = Spinner(this).apply {
            this.adapter = adapter
            setSelection(sel.coerceIn(0, items.lastIndex))
        }
        val wrap = LinearLayout(this).apply {
            setPadding(dp(6), dp(2), dp(6), dp(2))
            background = rounded(Color.parseColor(if (pal.light) "#0F000000" else "#26000000"), 14, c(R.color.card_stroke), dp(1))
            addView(sp, LinearLayout.LayoutParams(-1, -2))
        }
        parent.addView(wrap, matchWrap(bottom = dp(8)))
        return sp
    }

    private fun showThemeDialog() {
        val st = TranslatorSettings(this)
        var dlgRef: android.app.Dialog? = null
        dlgRef = openDialog("🎨", "ڕەنگی ئەپ", "ڕەنگێک هەڵبژێرە کە دڵت پێی خۆشە.", false,
            { d -> listOf(dlgBtn("داخستن", 2) { d.dismiss() }) }
        ) { body ->
            val perRow = 5
            var rowLayout: LinearLayout? = null
            Palettes.all.forEachIndexed { i, p ->
                if (i % perRow == 0) {
                    rowLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    body.addView(rowLayout, matchWrap(bottom = dp(10)))
                }
                val sel = i == st.theme
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setOnClickListener {
                        if (!sel) {
                            st.theme = i
                            dlgRef?.dismiss()
                            recreate()
                        }
                    }
                }
                item.addView(TextView(this).apply {
                    text = if (sel) "✓" else ""
                    setTextColor(if (p.light) Color.parseColor("#101828") else Color.WHITE)
                    textSize = 18f
                    gravity = Gravity.CENTER
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.a2, p.a1, p.bgBottom)).apply {
                        shape = GradientDrawable.OVAL
                        setStroke(dp(if (sel) 3 else 1), if (sel) c(R.color.text_main) else Color.parseColor("#66888888"))
                    }
                }, LinearLayout.LayoutParams(dp(50), dp(50)))
                item.addView(TextView(this).apply {
                    text = p.name
                    textSize = 11f
                    gravity = Gravity.CENTER
                    setTextColor(c(R.color.text_dim))
                    setPadding(0, dp(4), 0, 0)
                }, LinearLayout.LayoutParams(-2, -2))
                rowLayout?.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
    }

    private fun showLabelColorDialog() {
        val st = TranslatorSettings(this)
        val dens = resources.displayMetrics.density
        lateinit var preview: TextView
        val modeBtns = ArrayList<Pair<Int, TextView>>()

        fun previewTint(): Int? = when (st.labelMode) {
            1 -> GlyphIcon.defaultColor(GlyphIcon.AUTO)
            2 -> st.labelColor
            else -> null
        }
        fun refresh() {
            preview.background = GlassPillDrawable(dens, previewTint())
            modeBtns.forEach { (m, b) ->
                b.background = rounded(
                    if (m == st.labelMode) c(R.color.text_main) and 0x00FFFFFF or 0x33000000 else c(R.color.card),
                    12, if (m == st.labelMode) c(R.color.text_main) else c(R.color.card_stroke), dp(if (m == st.labelMode) 2 else 1)
                )
            }
        }

        openDialog("🏷", "ڕەنگی نووسینی تەنیش دوگمەکان", "باگراوندی شووشەیی ئەو نووسینانەی لەتەنیشت دوگمەکانن.", false,
            { dlg -> listOf(dlgBtn("داخستن", 2) { dlg.dismiss() }) }
        ) { body ->
            val pv = subCard(body, "پێشبینین")
            preview = TextView(this).apply {
                text = "وەرگێڕانی شاشە"
                textSize = 15f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(10), dp(14), dp(10))
            }
            pv.addView(preview, matchWrap())

            val md = subCard(body, "جۆر")
            listOf(
                0 to "گرادیێنتی Gemini (شین ← مۆر ← پەمەیی)",
                1 to "ڕەنگی هەمان ئایکۆنی دوگمەکە",
                2 to "ڕەنگێکی دیاریکراو (لە خوارەوە هەڵیبژێرە)"
            ).forEach { (m, name) ->
                val b = TextView(this).apply {
                    text = name
                    textSize = 13.5f
                    gravity = Gravity.CENTER
                    setTextColor(c(R.color.text_main))
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    setOnClickListener { st.labelMode = m; refresh() }
                }
                modeBtns.add(m to b)
                md.addView(b, matchWrap(bottom = dp(6)))
            }

            val card = subCard(body, "ڕەنگی دیاریکراو")
            fun pick(col: Int) { st.labelColor = col; st.labelMode = 2; refresh() }
            swatchGrid(card, st.labelColor, false) { pick(it) }
            freeColor(card) { pick(it) }
            card.addView(note("دوای گۆڕین، پانێلەکە یەکجار بوەستێنە و دووبارە دەستپێبکەرەوە تا ڕەنگە نوێیەکان دەربکەون."), matchWrap().apply { topMargin = dp(6) })
            refresh()
        }
    }

    private fun showTextBgDialog() {
        val st = TranslatorSettings(this)
        lateinit var preview: TextView
        fun refresh() {
            val a = st.overlayBgAlpha
            preview.background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor((st.overlayBg and 0x00FFFFFF) or (a shl 24))
            }
            preview.setTextColor(st.overlayFg)
        }

        fun colorSection(body: LinearLayout, title: String, isBg: Boolean) {
            val card = subCard(body, title)
            fun pick(col: Int) { if (isBg) st.overlayBg = col else st.overlayFg = col; refresh() }
            swatchGrid(card, if (isBg) st.overlayBg else st.overlayFg, false) { pick(it) }
            freeColor(card) { pick(it) }
        }

        openDialog("🖍", "ڕەنگی باگراوندی نووسین", "ڕەنگی باگراوند و ڕەنگی دەقی وەرگێڕدراوی سەر شاشە.", false,
            { dlg ->
                listOf(
                    dlgBtn("بنەڕەت", 1) {
                        st.overlayBg = 0xFF000000.toInt(); st.overlayFg = 0xFFFFFFFF.toInt(); st.overlayBgAlpha = 255
                        refresh(); toast("گەڕایەوە بۆ بنەڕەت (ڕەش + سپی)")
                    },
                    dlgBtn("داخستن", 2) { dlg.dismiss() }
                )
            }
        ) { body ->
            val pv = subCard(body, "پێشبینین")
            preview = TextView(this).apply {
                text = "نموونەی دەقی وەرگێڕدراو"
                textSize = 18f
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(14), dp(16), dp(14), dp(16))
            }
            pv.addView(preview, matchWrap())
            refresh()

            val autoCard = subCard(body, "ڕەنگی خۆکار (وەک Google)")
            autoCard.addView(styledCheck("ڕەنگی باگراوندی بابلە ڕەسەنەکە بەکاربهێنە", st.overlayAuto).apply {
                setOnCheckedChangeListener { _, on -> st.overlayAuto = on }
            }, matchWrap())
            autoCard.addView(note("چالاک بێت: وەرگێڕانەکە بە ڕەنگی هەمان بابل دەنووسرێت (ڕەش لەسەر ڕەش، سپی لەسەر سپی) و دەقەکە خۆکارانە ڕەش یان سپی دەبێت. ڕەنگەکانی خوارەوە تەنها کاتێک بەکاردێن کە ئەمە کوژاوە بێت."), matchWrap().apply { topMargin = dp(6) })

            colorSection(body, "ڕەنگی باگراوند", true)

            val op = subCard(body, "ڕوونیی باگراوند")
            val seek = SeekBar(this).apply {
                max = 255 - 30
                progress = st.overlayBgAlpha - 30
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) { st.overlayBgAlpha = progress + 30; refresh() }
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            op.addView(seek, LinearLayout.LayoutParams(-1, dp(34)))
            op.addView(note("لای چەپ = زیاتر ڕوون (دەقە ڕەسەنەکە لە ژێرەوە دیار دەبێت)، لای ڕاست = تەواو ڕەش/پڕ."), matchWrap().apply { topMargin = dp(6) })

            colorSection(body, "ڕەنگی دەق", false)
        }
    }

    private fun showIconColorDialog() {
        val st = TranslatorSettings(this)
        val dens = resources.displayMetrics.density
        val kinds = listOf(
            GlyphIcon.AUTO to "وەرگێڕانی خۆکار",
            GlyphIcon.TRANSLATE to "وەرگێڕانی شاشە",
            GlyphIcon.SPEAK to "خوێندنەوە بە دەنگ",
            GlyphIcon.REGION to "ڕووبەر",
            GlyphIcon.MIC to "قسەکردن بۆ نووسین",
            GlyphIcon.STOP to "وەستاندن",
            GlyphIcon.CLOSE to "داخستن",
            GlyphIcon.CHEVRON to "کەمکردنەوە"
        )
        var selected = kinds[0].first
        var lastColor = 0
        val previews = ArrayList<GlyphIcon>()
        val frames = ArrayList<Pair<Int, View>>()

        fun frameBg(sel: Boolean) = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0x66101828)
            setStroke(dp(if (sel) 3 else 1), if (sel) c(R.color.text_main) else Color.parseColor("#55888888"))
        }
        fun refresh() {
            previews.forEach { it.invalidate() }
            frames.forEach { (k, f) -> f.background = frameBg(k == selected) }
        }
        fun pick(color: Int) {
            lastColor = color
            st.setIconColor(selected, color)
            refresh()
        }

        openDialog("🎨", "ڕەنگی هێماکان", null, false,
            { dlg ->
                listOf(
                    dlgBtn("هەموویان", 0) {
                        if (lastColor == 0) toast("سەرەتا ڕەنگێک هەڵبژێرە")
                        else { kinds.forEach { st.setIconColor(it.first, lastColor) }; refresh(); toast("بۆ هەموو هێماکان دانرا") }
                    },
                    dlgBtn("بنەڕەت", 1) {
                        kinds.forEach { st.setIconColor(it.first, 0) }
                        lastColor = 0
                        refresh()
                        toast("ڕەنگەکان گەڕانەوە بۆ بنەڕەت")
                    },
                    dlgBtn("داخستن", 2) { dlg.dismiss() }
                )
            }
        ) { body ->
            // ١. هەڵبژاردنی هێما
            val sc1 = subCard(body, "هێمایەک هەڵبژێرە")
            kinds.chunked(4).forEach { rowKinds ->
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowKinds.forEach { (k, name) ->
                    val cell = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER_HORIZONTAL
                        setOnClickListener { selected = k; refresh() }
                    }
                    val frame = FrameLayout(this)
                    val glyph = GlyphIcon(this, k).apply { background = GlassOrbDrawable(Color.WHITE, dens) }
                    previews.add(glyph)
                    frame.addView(glyph, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.CENTER))
                    frames.add(k to frame)
                    cell.addView(frame, LinearLayout.LayoutParams(dp(56), dp(56)))
                    cell.addView(TextView(this).apply {
                        text = name
                        textSize = 10.5f
                        gravity = Gravity.CENTER
                        setTextColor(c(R.color.text_dim))
                        setPadding(0, dp(3), 0, 0)
                    }, LinearLayout.LayoutParams(-2, -2))
                    r.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
                }
                sc1.addView(r, matchWrap(bottom = dp(8)))
            }
            refresh()

            // ٢. ستایلی ئامادەکراو: هەموو هێماکان بە یەک دەستلێدان
            val scP = subCard(body, "ستایلی ئامادەکراو (هەموو هێماکان)")
            val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val applyKinds = listOf(GlyphIcon.AUTO, GlyphIcon.TRANSLATE, GlyphIcon.SPEAK, GlyphIcon.REGION, GlyphIcon.MIC)
            ICON_PRESETS.forEach { (name, cols) ->
                val chip = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    setOnClickListener {
                        applyKinds.forEachIndexed { i, k -> st.setIconColor(k, cols[i].toInt()) }
                        lastColor = cols[0].toInt()
                        refresh()
                        toast("ستایلی «$name» دانرا")
                    }
                }
                chip.addView(View(this).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, cols.map { it.toInt() }.toIntArray()).apply {
                        cornerRadius = dp(14).toFloat()
                        setStroke(dp(1), Color.parseColor("#55888888"))
                    }
                }, LinearLayout.LayoutParams(dp(74), dp(28)))
                chip.addView(TextView(this).apply {
                    text = name
                    textSize = 11f
                    gravity = Gravity.CENTER
                    setTextColor(c(R.color.text_dim))
                    setPadding(0, dp(3), 0, 0)
                }, LinearLayout.LayoutParams(-2, -2))
                presetRow.addView(chip)
            }
            scP.addView(HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(presetRow)
            }, matchWrap())

            // ٣. ڕەنگە ئامادەکراوەکان (↺ = بنەڕەت)
            val sc2 = subCard(body, "ڕەنگێک هەڵبژێرە")
            swatchGrid(sc2, null, true) { pick(it) }

            // ٤. ڕەنگی ئازاد: هەر ڕەنگێک دەتەوێت
            val sc3 = subCard(body, "ڕەنگی ئازاد (هەر ڕەنگێک دەتەوێت)")
            freeColor(sc3) { pick(it) }
            sc3.addView(note("ڕەنگەکان بۆ هێمای هەڵبژێردراو دادەنرێن. ئەگەر بابلەکان ئێستا کراوەن، یەکجار بیانوەستێنە و دووبارە دەستپێبکەرەوە تا ڕەنگە نوێیەکان دەربکەون."), matchWrap().apply { topMargin = dp(6) })
        }
    }

    private fun showA11yDialog() {
        val on = MangaAccessibilityService.isEnabled(this)
        val st = TranslatorSettings(this)
        lateinit var autoCb: CheckBox
        openDialog("♿", "Accessibility", "دوای چالاککردن، هەر جارێک پەنجەرەی ڕێگەپێدانی گرتنی شاشە دەرناکەوێت.", false,
            { dlg ->
                listOf(
                    dlgBtn("هەڵگرتن", 1) { st.a11yAutoStart = autoCb.isChecked; toast("هەڵگیرا"); dlg.dismiss() },
                    dlgBtn(if (on) "ڕێکخستنەکان" else "چالاککردن", 0) {
                        try { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) { toast("نەکرایەوە") }
                        dlg.dismiss()
                    },
                    dlgBtn("داخستن", 2) { dlg.dismiss() }
                )
            }
        ) { body ->
            val sc = subCard(body)
            autoCb = styledCheck("پانێلی بابلەکان خۆکارانە دەرکەوێت کاتێک Accessibility چالاکە (بێ دەستپێکردن)", st.a11yAutoStart)
            sc.addView(autoCb, matchWrap(bottom = dp(8)))
            sc.addView(note(
                (if (!MangaAccessibilityService.supported()) "ئەم تایبەتمەندییە Android 11 یان نوێتر پێویستە؛ ئەندرۆیدەکەت پشتگیری ناکات.\n\n"
                else if (on) "✓ چالاکە. «دەستپێکردن» ئێستا بێ داواکردنی ڕێگەپێدانی گرتنی شاشە کار دەکات.\n\n" else "") +
                    "چۆن: Settings ← Accessibility ← Installed apps ← «وەڕگێڕی شاشە» ← چالاک بکە.\n" +
                    "ئەگەر ئەندرۆید «Restricted setting» ی نیشاندا: App info ی ئەپەکە ← ⋮ ← Allow restricted settings، پاشان دووبارە چالاکی بکە.\n\n" +
                    "شاشە تەنها لە کاتی بەکارهێنانی فەرمانێک دەگیرێت (نە هەمیشە، و نیشانەی هاوبەشکردنی شاشە نامێنێت). تەنها وێنەی شاشە دەگرێت؛ هیچ دەقێک لە ئەپەکانی تر ناخوێنێتەوە. ئەگەر ناچالاک بکەیت، ئەپەکە دووبارە ڕێگەپێدانی ئاسایی داوا دەکات. " +
                    "سنوور: نزیکەی ٣ وێنە لە چرکەیەکدا، و ئەپە FLAG_SECURE ـەکان ڕەش دەبن."
            ))
        }
    }

    private fun showLangDialog() {
        val st = TranslatorSettings(this)
        lateinit var lang: Spinner
        openDialog("🌐", "زمانی دەق (خۆکار و شاشە)", "ئەم هەڵبژاردنە تەنها بۆ وەرگێڕانی خۆکار و وەرگێڕانی شاشەیە. دۆخی «ڕووبەر» بەکاری ناهێنێت و هەر زمانێک خۆی دەناسێتەوە. وەرگێڕان هەمیشە بۆ سۆرانییە.", false,
            { dlg ->
                listOf(
                    dlgBtn("هەڵگرتن", 0) {
                        st.sourceLang = SourceLangs.codes[lang.selectedItemPosition.coerceIn(0, SourceLangs.codes.lastIndex)]
                        toast("هەڵگیرا"); dlg.dismiss()
                    },
                    dlgBtn("پاشگەزبوونەوە", 2) { dlg.dismiss() }
                )
            }
        ) { body ->
            val sc = subCard(body)
            lang = addSpinner(sc, SourceLangs.labels, SourceLangs.codes.indexOf(st.sourceLang))
            sc.addView(note(
                "«خۆکار» ئینگلیزی، چینی، جاپانی و کۆری خۆی دەناسێتەوە. بۆ عەرەبی باشترە ڕاستەوخۆ «عەرەبی» هەڵبژێریت؛ " +
                    "یەکەم جار فایلی OCR ی عەرەبی (~٢MB) دادەبەزێت و دواتر ئۆفلاین کار دەکات. " +
                    "ئەگەر زمانەکە گۆڕی، دووبارە دەستپێکردن دابگرە. ئینتەرنێت بۆ وەرگێڕان پێویستە."
            ))
        }
    }

    private fun showKeyDialog() {
        val st = TranslatorSettings(this)
        lateinit var googleKey: EditText
        openDialog("🔑", "کلیلی Google", KEY_SPEECH, false,
            { dlg ->
                listOf(
                    dlgBtn("هەڵگرتن", 0) { st.googleKey = googleKey.text.toString(); toast("هەڵگیرا"); dlg.dismiss() },
                    dlgBtn("پاشگەزبوونەوە", 2) { dlg.dismiss() }
                )
            }
        ) { body ->
            val sc = subCard(body)
            googleKey = styledEdit("کلیلی API ی Google Cloud Translation", st.googleKey, false)
            sc.addView(googleKey, matchWrap(bottom = dp(8)))
            sc.addView(note(
                "ئارەزوومەندانەیە. ئەگەر کلیلت نییە، ئەم خانەیە بەتاڵ بهێڵەرەوە. بێ کلیلیش وەرگێڕان بە Google Translate کار دەکات؛ " +
                    "ئەگەر کلیلت هەیە، ڕێگای فەرمی بەکار دێت کە جێگیرترە. ئینتەرنێت پێویستە."
            ))
        }
    }

    private fun showVoiceDialog() {
        val st = TranslatorSettings(this)
        lateinit var key: EditText
        lateinit var voice: Spinner
        lateinit var autoSpeak: CheckBox
        lateinit var fast: CheckBox
        lateinit var textHashCb: CheckBox
        lateinit var autoHide: CheckBox
        lateinit var glassCb: CheckBox
        lateinit var localKu: CheckBox
        lateinit var skipLocalCb: CheckBox
        lateinit var offlineCb: CheckBox
        lateinit var pawanCb: CheckBox
        lateinit var pawanVoiceSp: Spinner
        lateinit var latinCb: CheckBox
        lateinit var pawanLangSp: Spinner
        lateinit var offlineVoice: Spinner
        var pGain = st.pawanGain
        var pRate = st.pawanRate
        var pSoft = st.pawanSoft
        val voices = listOf("Kore", "Aoede", "Charon", "Puck")
        val offlineVoices = listOf(
            "ئینگلیزی (لاتینیی کوردی)", "کوردیی نیورالی (Berfin، ONNX) — باشترین"
        )

        fun saveAll() {
            st.geminiTtsKey = key.text.toString()
            st.geminiTtsVoice = voice.selectedItem?.toString() ?: TranslatorSettings.DEFAULT_GEMINI_VOICE
            st.autoSpeak = autoSpeak.isChecked
            st.fast = fast.isChecked
            st.textHashDetect = textHashCb.isChecked
            st.localKurdish = localKu.isChecked
            st.skipLocalOcrOnLow = skipLocalCb.isChecked
            st.autoHideOverlay = autoHide.isChecked
            st.coloredGlass = glassCb.isChecked
            GlassStyle.colored = glassCb.isChecked
            st.offlineTts = offlineCb.isChecked
            st.pawanTts = pawanCb.isChecked
            st.latinKurdish = latinCb.isChecked
            st.pawanVoice = if (pawanVoiceSp.selectedItemPosition == 1) "male" else "female"
            st.pawanLang = PAWAN_LANGS.getOrElse(pawanLangSp.selectedItemPosition) { "ckb" }
            st.pawanGain = pGain
            st.pawanRate = pRate
            st.pawanSoft = pSoft
            st.offlineVoice = if (offlineVoice.selectedItemPosition == 1) KurdishVoiceText.PIPER else KurdishVoiceText.EN
        }

        openDialog("🔊", "ڕێکخستنی دەنگ", VOICE_SPEECH, true,
            { dlg ->
                listOf(
                    dlgBtn("هەڵگرتن", 0) { saveAll(); toast("هەڵگیرا"); dlg.dismiss() },
                    dlgBtn("تاقیکردنەوە", 1) {
                        saveAll()
                        val t = testTts ?: SoraniTts(this, st).also { testTts = it }
                        t.speak(listOf("سڵاو، ئەمە تاقیکردنەوەی دەنگە."), onState = {}, onError = { m -> toast(m) })
                    },
                    dlgBtn("داخستن", 2) { dlg.dismiss() }
                )
            }
        ) { body ->
            // ٠. Pawan TTS
            val pw = subCard(body, "دەنگی Pawan (tts.pawan.krd)")
            pawanCb = styledCheck("خوێندنەوە بە Pawan TTS (پێویستی بە ئینتەرنێت و چوونەژوورەوە هەیە)", st.pawanTts)
            pw.addView(pawanCb, matchWrap(bottom = dp(8)))
            latinCb = styledCheck("کوردیی لاتینی (aw mawzw3a...) پێش خوێندنەوە بگۆڕە بۆ پیتی کوردی (بە Gemini، بێ کلیل ڕێسای سادە)", st.latinKurdish)
            pw.addView(latinCb, matchWrap(bottom = dp(8)))
            pw.addView(note("دەنگ"), matchWrap(bottom = dp(2)))
            pawanVoiceSp = addSpinner(pw, listOf("ئافرەت ♀", "پیاو ♂"), if (st.pawanVoice == "male") 1 else 0)
            pw.addView(note("زمان"), matchWrap(bottom = dp(2)))
            pawanLangSp = addSpinner(
                pw,
                listOf("کوردی سۆرانی", "بادینی", "Kurmancî", "العربية الفصحى", "اللهجة العراقية", "English"),
                PAWAN_LANGS.indexOf(st.pawanLang).coerceAtLeast(0)
            )
            // ڕێکخستنی دەنگ: «تاقیکردنەوە» بگرە و گوێ بگرە، پاشان سلایدەرەکان بگۆڕە
            fun tuneBar(title: (Int) -> String, lo: Int, hi: Int, cur: Int, set: (Int) -> Unit) {
                val tv = note(title(cur))
                pw.addView(tv, matchWrap(bottom = dp(2)))
                pw.addView(SeekBar(this).apply {
                    max = hi - lo
                    progress = cur - lo
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { set(p + lo); (tv as? TextView)?.text = title(p + lo) }
                        override fun onStartTrackingTouch(sb: SeekBar?) {}
                        override fun onStopTrackingTouch(sb: SeekBar?) {}
                    })
                }, matchWrap(bottom = dp(6)))
            }
            tuneBar({ "ئاستی دەنگ: $it% (ئەگەر زۆر بەرزە دایبەزێنە)" }, 30, 100, pGain) { pGain = it }
            tuneBar({ "تۆن/خێرایی: $it% (کەمتر = قوڵتر و هێواشتر، زیاتر = تیژتر و خێراتر)" }, 80, 120, pRate) { pRate = it }
            tuneBar({ "نەرمکردن: $it% (دەنگی تیژ/«گڕ» کەم دەکاتەوە)" }, 0, 100, pSoft) { pSoft = it }
            pw.addView(note("«تاقیکردنەوە» ی خوارەوە بگرە تا ڕێکخستنەکان تاقی بکەیتەوە (ئەوە خۆکارانە هەڵدەگیرێت)."))
            pw.addView(android.widget.Button(this).apply {
                text = "چوونەژوورەوە بۆ Pawan TTS"
                setOnClickListener { startActivity(android.content.Intent(this@MainActivity, PawanLoginActivity::class.java)) }
            }, matchWrap(bottom = dp(8)))
            pw.addView(note("یەک جار بچۆ ژوورەوە و دوگمەی «تەواو بوو» بگرە. دوای ئەوە خوێندنەوە لە پشتەوە ئۆتۆماتیکی دەبێت."))

            // ١. خوێندنەوەی ئۆفلاین
            val off = subCard(body, "خوێندنەوەی ئۆفلاین (بێ ئینتەرنێت)")
            offlineCb = styledCheck("خوێندنەوەی ئۆفلاین: کوردی بە دەنگی ناو مۆبایل دەخوێنرێتەوە", st.offlineTts)
            off.addView(offlineCb, matchWrap(bottom = dp(8)))
            offlineVoice = addSpinner(off, offlineVoices, if (st.offlineVoice == KurdishVoiceText.PIPER) 1 else 0)
            off.addView(note(
                "«ئینگلیزی» پێویستی بە دەنگی ئینگلیزی هەیە (Settings ← Text-to-speech ← Google ← Install voice data) و کوردییەکە بە پیتی ئینگلیزی دەخوێنێتەوە، بۆیە نزیکە. " +
                    "«کوردیی نیورالی» پێویستی بە دەنگی سیستەم نییە. کلیلی Gemini لەم دۆخەدا پێویست نییە."
            ))

            // دەنگی کوردیی نیورالی وەک «دەنگی سیستەم»: TalkBack/Accessibility و هەموو ئەپێک کە دەنگی سیستەم بەکاردێنێت
            val sysCb = styledCheck(
                "دەنگی کوردیی نیورالی وەک دەنگی سیستەم (Accessibility/TalkBack و ئەپەکانی تر) — بە هەڵبژاردنی خۆت",
                SystemVoice.isEnabled(applicationContext)
            )
            sysCb.setOnCheckedChangeListener { _, on ->
                if (on && !PiperTts.isInstalled(applicationContext)) {
                    android.widget.Toast.makeText(
                        this, "سەرەتا مۆدێلی کوردیی نیورالی بهێنە (دوگمەی «هێنانی مۆدێل»)", android.widget.Toast.LENGTH_LONG
                    ).show()
                    sysCb.isChecked = false
                } else {
                    SystemVoice.setEnabled(applicationContext, on)
                }
            }
            off.addView(sysCb, matchWrap(bottom = dp(6)))
            off.addView(android.widget.Button(this).apply {
                text = "کردنەوەی ڕێکخستنی دەنگی سیستەم (Text-to-speech)"
                setOnClickListener { SystemVoice.openSystemSettings(this@MainActivity) }
            }, matchWrap(bottom = dp(6)))
            off.addView(note(
                "دوای چالاککردن: لە ڕێکخستنی دەنگی سیستەم «وەڕگێڕی شاشە» وەک Preferred engine هەڵبژێرە و زمان بکە بە کوردی (ناوەندی). " +
                    "ئەو کاتە TalkBack و Select to Speak و هەر ئەپێکی دەنگی سیستەم بەکاربهێنێت، بێ ئینتەرنێت بە دەنگی کوردی دەخوێنێتەوە. " +
                    "بۆ گەڕانەوە، هەمان شوێن engine ـی جاران هەڵبژێرەوە یان ئەم هەڵبژاردنە بکوژێنەوە."
            ))

            // ٢. ڕەفتاری خوێندنەوە
            val beh = subCard(body, "ڕەفتاری خوێندنەوە")
            autoHide = styledCheck("دوای تەواوبوونی خوێندنەوە، وەرگێڕانی سەر شاشە خۆکارانە بشارێتەوە", st.autoHideOverlay)
            localKu = styledCheck("ناسینەوەی خێرای کوردی (لەسەر مۆبایل): ئەگەر ڕووبەرەکە کوردی بوو، بێ چاوەڕێی AI یەکسەر دەیخوێنێتەوە", st.localKurdish)
            skipLocalCb = styledCheck("مۆبایلی ئاست نزم: Tesseract (OCR ی ناوخۆیی) بپەڕێنە و یەکسەر Gemini بەکاربهێنە، خێراتر و سووکتر (پێویستی بە کلیلی Gemini و دۆخی «ڕامی کەم» هەیە)", st.skipLocalOcrOnLow)
            autoSpeak = styledCheck("دوای وەرگێڕانی دەستی شاشە، دەقەکە خۆکارانە بە دەنگ بخوێنەوە", st.autoSpeak)
            fast = styledCheck("دۆخی خێرا (دۆخی نوێ): مۆدێلی سووکتر، زۆر خێراتر؛ ئەگەر وەرگێڕان باش نەبوو، ڕایبگرە", st.fast)
            beh.addView(autoHide, matchWrap(bottom = dp(4)))
            beh.addView(localKu, matchWrap(bottom = dp(4)))
            beh.addView(skipLocalCb, matchWrap(bottom = dp(4)))
            beh.addView(autoSpeak, matchWrap(bottom = dp(4)))
            glassCb = styledCheck("شووشەی ڕەنگاوڕەنگ (ڕەنگی Gemini)؛ ئەگەر لێی بدەیتەوە، شووشەی تەواو ڕوونی بێ ڕەنگ دەبێت (دوای دووبارە دەستپێکردنی پانێلەکە)", st.coloredGlass)
            textHashCb = styledCheck("ناسینەوەی گۆڕانی پەڕە بە دەقی Accessibility (جگە لە پیکسێل): ڤیدیۆ و ئەنیمەیشن وەرگێڕانەکە ناسڕنەوە؛ ئەگەر کێشەی دروست کرد ڕایبگرە (تەنها پیکسێل بەکاردێت)", st.textHashDetect)
            beh.addView(fast, matchWrap(bottom = dp(4)))
            beh.addView(textHashCb, matchWrap(bottom = dp(4)))
            beh.addView(glassCb, matchWrap())

            // ٣. Gemini
            val gem = subCard(body, "Gemini (ئارەزوومەندانە)")
            // ڕێنمایی دروستکردنی کلیل
            gem.addView(note(
                "چۆن کلیلێک دروست بکەم؟ (خۆڕایی و بێ کارتی بانکی)\n" +
                    "١. دوگمەی «دروستکردنی کلیل» لە خوارەوە دابگرە؛ Google AI Studio دەکرێتەوە.\n" +
                    "٢. بە ئەکاونتی گوگڵی خۆت بچۆ ژوورەوە.\n" +
                    "٣. دوگمەی «Create API key» دابگرە (ئەگەر پڕۆژەی لێپرسییەوە، پڕۆژەیەکی نوێ هەڵبژێرە).\n" +
                    "٤. کلیلەکە کۆپی بکە (زۆرجار بە AIza دەست پێدەکات).\n" +
                    "٥. بگەڕێوە بۆ ئەم ئەپە و «لکاندن» دابگرە، پاشان «پشکنینی کلیل».\n" +
                    "ئاگاداری: کلیلەکەت لای کەس مەنێرە؛ هەرکەسێک هەیبێت دەتوانێت quota ـی تۆ بەکاربهێنێت."
            ), matchWrap(bottom = dp(8)))
            val keyBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            keyBtns.addView(dlgBtn("🔑 دروستکردنی کلیل", 0) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(GEMINI_KEY_URL))) }
                catch (_: Exception) { toast("وێبگەڕ نەکرایەوە. ئەم لینکە بکەرەوە: $GEMINI_KEY_URL") }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(4) })
            keyBtns.addView(dlgBtn("📋 لکاندن", 1) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty()
                when {
                    t.length < 20 || t.any { it.isWhitespace() } -> toast("لە کلیپبۆردەکەتدا کلیل نییە. سەرەتا کلیلەکە کۆپی بکە")
                    GeminiKeys.parse(key.text.toString()).contains(t) -> toast("ئەم کلیلە پێشتر لێرەیە")
                    else -> {
                        key.setText((key.text.toString().trim() + "\n" + t).trim())
                        toast("کلیلەکە لکێندرا ✓")
                    }
                }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
            gem.addView(keyBtns, matchWrap(bottom = dp(8)))

            key = styledEdit("کلیلی Gemini API (دەتوانیت ٢ یان ٣ کلیل بنووسیت، هەر یەکێک لە دێڕێک)", st.geminiTtsKey, true)
            gem.addView(key, matchWrap(bottom = dp(8)))
            gem.addView(dlgBtn("✔ پشکنینی کلیل", 1) {
                toast("خەریکی پشکنینم…")
                checkGeminiKeys(key.text.toString()) { msg -> toast(msg) }
            }, matchWrap(bottom = dp(8)))
            voice = addSpinner(gem, voices, voices.indexOf(st.geminiTtsVoice).coerceAtLeast(0))
            gem.addView(note(
                "خوێندنەوە بە Gemini TTS ـە و کوردیی ناوەندی/سۆرانی پشتیوانی دەکات. Gemini API لە سنووری خۆڕاییی Google بەکاردێت؛ " +
                    "quota و rate limit هەیە. ئەم کلیلی Gemini API جیاوازە لە کلیلی Google Translate. ئینتەرنێت پێویستە."
            ))
        }
    }

    /** هەر کلیلێک بە داواکارییەکی بچووک (لیستی مۆدێلەکان) دەپشکنێت؛ ئەنجام لەسەر main thread دەگەڕێتەوە. */
    private fun checkGeminiKeys(raw: String, done: (String) -> Unit) {
        val keys = GeminiKeys.parse(raw)
        if (keys.isEmpty()) { done("هیچ کلیلێک نەنووسراوە"); return }
        Thread {
            var ok = 0
            var bad = 0
            var netFail = 0
            for (k in keys) {
                try {
                    val c = java.net.URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1")
                        .openConnection() as java.net.HttpURLConnection
                    c.setRequestProperty("x-goog-api-key", k)
                    c.connectTimeout = 10_000
                    c.readTimeout = 10_000
                    val code = c.responseCode
                    c.disconnect()
                    if (code in 200..299) ok++ else bad++
                } catch (_: Exception) {
                    netFail++
                }
            }
            val msg = when {
                ok == 0 && bad == 0 -> "پەیوەندی سەرنەکەوت؛ ئینتەرنێتەکەت بپشکنە و دووبارە هەوڵ بدەرەوە"
                bad == 0 && netFail == 0 -> if (ok == 1) "✓ کلیلەکە ڕاستە و کار دەکات" else "✓ هەر $ok کلیلەکە ڕاستن"
                ok == 0 -> "✗ کلیلەکە ڕاست نییە (یان Gemini API بۆی چالاک نەکراوە). دووبارە کۆپی بکە و بلکێنە"
                else -> "$ok کلیل ڕاستن، $bad کلیل هەڵەن؛ ئەوانەی هەڵەن بسڕەوە"
            }
            runOnUiThread { done(msg) }
        }.start()
    }

    private var a11yAtBuild = false

    override fun onResume() {
        super.onResume()
        // دوای گەڕانەوە لە ڕێکخستنەکانی Accessibility، دوگمەکە نوێ بکەرەوە
        if (MangaAccessibilityService.isEnabled(this) != a11yAtBuild) { recreate(); return }
        handler.post(poller)
    }

    override fun onPause() {
        handler.removeCallbacks(poller)
        super.onPause()
    }

    override fun onDestroy() {
        Narrator.stop()
        testTts?.shutdown()
        testTts = null
        super.onDestroy()
    }

    /**
     * پێداویستییەکان تەنها تا ئەنجام نەدراون دەردەکەون و دوای تەواوبوون بەتەواوی دەشاردرێنەوە:
     * ١. ڕێگەپێدانی پیشاندان (نارنجی)  ٢. دابەزاندنی مۆدێلەکان بە ڕێژەی پێشکەوتن (شین)
     */
    private fun updateStatus() {
        if (!overlayOk()) {
            val col = Color.parseColor("#FFB020")
            statusText.visibility = View.VISIBLE
            statusText.text = "● ڕێگەپێدانی پیشاندان پێویستە، لێرە دابگرە"
            statusText.setTextColor(col)
            statusText.background = rounded(Color.parseColor("#3A2A10"), 20, col, dp(1))
            statusText.setOnClickListener { openOverlaySettings() }
            return
        }
        val pct = Downloads.percent(this)
        if (pct == null) {
            statusText.visibility = View.GONE
            return
        }
        Downloads.ensureAll(this)
        statusText.visibility = View.VISIBLE
        statusText.text = "⬇ ئامادەکردنی پێداویستییەکان... " + pct + "%"
        statusText.setTextColor(pal.a1)
        statusText.background = rounded((pal.a1 and 0x00FFFFFF) or 0x1A000000, 20, (pal.a1 and 0x00FFFFFF) or 0x66000000, dp(1))
        statusText.setOnClickListener(null)
        statusText.isClickable = false
    }

    /** ڕێگەپێدانی پیشاندان، یان Accessibility چالاک بێت (کە خۆی دەتوانێت پەنجەرە نیشان بدات) */
    private fun overlayOk(): Boolean =
        Settings.canDrawOverlays(this) || (MangaAccessibilityService.supported() && MangaAccessibilityService.isEnabled(this))

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun startFlow() {
        if (!overlayOk()) {
            toast("سەرەتا ڕێگەپێدانی پیشاندان چالاک بکە")
            openOverlaySettings()
            return
        }

        // Android 13+: ڕێگەپێدانی ئاگادارکردنەوە بۆ نیشاندانی ئاگادارکردنەوەی خزمەتگوزاری
        val viaA11y = MangaAccessibilityService.supported() && MangaAccessibilityService.isEnabled(this)
        if (!viaA11y && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }

        askMicThenCapture()
    }

    /** مایک پێویستە بۆ «قسەکردن بۆ نووسین»؛ ئەگەر ڕێگەی نەدا، دوگمەکانی تر هەر کار دەکەن. */
    private fun askMicThenCapture() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        requestScreenCapture()
    }

    @Suppress("DEPRECATION")
    private fun isRunning(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        return am.getRunningServices(100).any { it.service.className == OverlayService::class.java.name }
    }

    private fun requestScreenCapture() {
        // Accessibility چالاک بێت: بێ پەنجەرەی ڕێگەپێدانی گرتنی شاشە دەست پێدەکات
        if (MangaAccessibilityService.supported() && MangaAccessibilityService.isEnabled(this)) {
            val svc = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_START
                putExtra(OverlayService.EXTRA_USE_A11Y, true)
            }
            ContextCompat.startForegroundService(this, svc)
            toast("بابلەکان دەرکەوتن. دەتوانیت بچیتە سەر ئەپی مانگاکەت")
            moveTaskToBack(true)
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            // با ڕێگەپێدان یان بێ ڕێگەپێدان بەردەوام دەبین؛ خزمەتگوزاری هەر کار دەکات
            askMicThenCapture()
        } else if (requestCode == REQ_MIC) {
            if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
                toast("مایک ڕێگەی پێنەدرا؛ «قسە» کار ناکات، بەڵام «ڕ» کار دەکات")
            }
            requestScreenCapture()
        }
    }

    @Deprecated("Deprecated in Java")
    private var piperStatus: TextView? = null

    @Volatile private var voiceDl = -1   // -1 = دانەبەزاندووە، 0..100 = لە داگرتندایە

    /** ئەگەر دەنگی کوردی نەهێنرابوو، خۆکارانە دایدەبەزێنێت (تەنها یەکجار، ~٦٠MB). */
    private fun autoDownloadVoice() {
        if (PiperTts.isInstalled(this) || voiceDl >= 0) return
        voiceDl = 0
        refreshPiperStatus()
        val h = Handler(Looper.getMainLooper())
        Thread {
            val err = PiperTts.download(applicationContext) { p ->
                voiceDl = p
                h.post { refreshPiperStatus() }
            }
            voiceDl = -1
            h.post {
                refreshPiperStatus()
                if (err != null) toast(err)
            }
        }.start()
    }

    @Volatile private var ocrDl = false

    /** فایلی زمانی کوردیی OCR ی خێرا (~٣MB)، یەکجار خۆکارانە دادەبەزێت. */
    private var sttDl = false
    /** مۆدێلی نووسینی ئۆفلاین بێ دوگمە و بێ پرسیار، بە بێدەنگی لە پاشبنەما دادەبەزێت (تەنها لەسەر WiFi). */
    private fun autoDownloadStt() {
        if (VekolStt.isReady(this) || sttDl) return
        val metered = try {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager).isActiveNetworkMetered
        } catch (_: Throwable) { false }
        if (metered) return
        sttDl = true
        Thread {
            try { VekolStt.download(applicationContext) { _, _, _ -> } } catch (_: Throwable) {}
            sttDl = false
        }.start()
    }

    private fun autoDownloadOcr() {
        if (LocalKurdishOcr.isInstalled(this) || ocrDl) return
        ocrDl = true
        val h = Handler(Looper.getMainLooper())
        Thread {
            LocalKurdishOcr.download(applicationContext)
            ocrDl = false
        }.start()
    }

    private fun refreshPiperStatus() {
        if (voiceDl >= 0) { piperStatus?.text = "دەنگی کوردی دادەبەزێت... $voiceDl%"; return }
        piperStatus?.text = if (PiperTts.isInstalled(this))
            "مۆدێلی کوردیی نیورالی: هێنراوە ✓"
        else
            "مۆدێلی کوردیی نیورالی: نەهێنراوە (دوگمەی «داگرتن» بکە)"
    }

    private fun importPiperModel(data: Intent) {
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
        data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        toast("مۆدێل دەهێنرێت... (چەند چرکەیەک)")
        Thread {
            val err = PiperTts.importModel(applicationContext, uris)
            Handler(Looper.getMainLooper()).post {
                refreshPiperStatus()
                toast(err ?: "مۆدێلی کوردی هێنرا ✓")
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PIPER_MODEL) {
            if (resultCode == Activity.RESULT_OK && data != null) importPiperModel(data)
            return
        }
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val svc = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                    putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(OverlayService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, svc)
                toast("بابلەکان دەرکەوتن. دەتوانیت بچیتە سەر ئەپی مانگاکەت")
                moveTaskToBack(true)
            } else {
                toast("ڕێگەپێدانی گرتنی شاشە وەرنەگیرا")
            }
        }
    }

    private fun stopTranslator() {
        stopService(Intent(this, OverlayService::class.java))
        toast("وەستێنرا")
    }

    // ---------- یارمەتیدەرەکان ----------

    private val pal by lazy { Palettes.get(TranslatorSettings(this).theme) }

    /** ڕەنگەکان لە پاڵێتی هەڵبژێردراو وەردەگیرێن؛ کارتەکان شووشەیین (ڕوونی نیمچە). */
    private fun c(id: Int): Int = when (id) {
        R.color.bg_dark -> pal.bgBottom
        R.color.card -> Color.parseColor(if (pal.light) "#FFFFFF" else "#1AFFFFFF")
        R.color.card_stroke -> Color.parseColor(if (pal.light) "#E6EBF5" else "#40FFFFFF")
        R.color.accent_blue -> pal.a1
        R.color.accent_cyan -> pal.a2
        R.color.text_main -> if (pal.light) Color.parseColor("#0F172A") else Color.WHITE
        R.color.text_dim -> Color.parseColor(if (pal.light) "#64748B" else "#C5D5EE")
        else -> ContextCompat.getColor(this, id)
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int = 0, strokeW: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (strokeW > 0) setStroke(strokeW, stroke)
    }

    private fun gradient(from: Int, to: Int) = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(from, to)
    ).apply { cornerRadius = dp(18).toFloat() }

    private fun outline(color: Int) =
        if (pal.light) rounded(Color.WHITE, 18, (color and 0x00FFFFFF) or 0x66000000, dp(1))
        else rounded(Color.TRANSPARENT, 18, color, dp(2))

    private fun cardElev() = if (pal.light) dp(3).toFloat() else 0f

    private fun cardBg(selected: Boolean) =
        if (selected) rounded((pal.a2 and 0x00FFFFFF) or 0x33000000, 18, pal.a2, dp(2))
        else rounded(c(R.color.card), 18, c(R.color.card_stroke), dp(1))

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(c(R.color.text_dim))
    }

    private fun modeCard(title: String, desc: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        isClickable = true
        addView(TextView(context).apply {
            text = title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(c(R.color.text_main))
        })
        addView(TextView(context).apply {
            text = desc
            textSize = 13f
            setTextColor(c(R.color.text_dim))
        })
    }

    private fun button(label: String, bg: Drawable, textColor: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(textColor)
        stateListAnimator = null
        minHeight = dp(56)
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), bg, null)
        setOnClickListener { onClick() }
    }

    private fun matchWrap(bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = bottom }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val GEMINI_KEY_URL = "https://aistudio.google.com/apikey"
        /** ڕەنگە مۆدێرنەکان بۆ هەموو پەنجەرەکانی ڕەنگ: زیندوو، پاستێل، قووڵ، بێلایەن */
        private val MODERN_SWATCHES: List<Int> = listOf(
            0xFFFF3B5C, 0xFFFF6B35, 0xFFFFB020, 0xFFFFE066, 0xFFB8F34A, 0xFF22E58A,
            0xFF14D9C4, 0xFF22D3EE, 0xFF3B9BFF, 0xFF4285F4, 0xFF5B6CFF, 0xFF8B5CF6,
            0xFFC264FF, 0xFFFF4FD8, 0xFFFF5C9A,
            0xFFFFB3C1, 0xFFFFCBA4, 0xFFFFE8A3, 0xFFC8F7C5, 0xFFA8EDEA, 0xFFA5D8FF,
            0xFFC5B8FF, 0xFFE9B8FF,
            0xFF9B1D3F, 0xFFC2410C, 0xFF166534, 0xFF0F766E, 0xFF1D4ED8, 0xFF4C1D95, 0xFF831843,
            0xFFFFFFFF, 0xFFE5E7EB, 0xFF9CA3AF, 0xFF4B5563, 0xFF1A1D29, 0xFF000000
        ).map { it.toInt() }

        /** ستایلی ئامادەکراوی هێماکان: خۆکار، وەرگێڕانی شاشە، دەنگ، ڕووبەر، مایک */
        private val ICON_PRESETS: List<Pair<String, List<Long>>> = listOf(
            "ئۆرۆرا" to listOf(0xFF22E58A, 0xFF22D3EE, 0xFF8B5CF6, 0xFF3B9BFF, 0xFFC264FF),
            "خۆرئاوا" to listOf(0xFFFFB020, 0xFFFF6B35, 0xFFFF3B5C, 0xFFFF5C9A, 0xFFC264FF),
            "نیۆن" to listOf(0xFFB8F34A, 0xFF14D9C4, 0xFFFF4FD8, 0xFFFFE066, 0xFF5B6CFF),
            "پاستێل" to listOf(0xFFC8F7C5, 0xFFA5D8FF, 0xFFE9B8FF, 0xFFA8EDEA, 0xFFFFB3C1),
            "زەریا" to listOf(0xFF14D9C4, 0xFF3B9BFF, 0xFF5B6CFF, 0xFF22D3EE, 0xFF0F766E),
            "شیرینی" to listOf(0xFFFF5C9A, 0xFFFFB3C1, 0xFFC264FF, 0xFFFFE066, 0xFFFF6B35),
            "سپی" to listOf(0xFFFFFFFF, 0xFFE5E7EB, 0xFF9CA3AF, 0xFFE5E7EB, 0xFFFFFFFF)
        )

        private const val KEY_SPEECH =
            "لێرە کلیلی گووگڵ دادەنێیت. ئەمە ئارەزوومەندانەیە. ئەگەر کلیلت نییە، بەتاڵی بهێڵەرەوە و ئەپەکە هەر کار دەکات."
        private const val VOICE_SPEECH =
            "ئەمە ڕێکخستنی دەنگە. دەتوانیت دەنگی کوردی داببەزێنیت، کلیلی جێمینای دابنێیت، و دەنگەکە تاقی بکەیتەوە. دوای ڕێکخستن، دوگمەی هەڵگرتن دابگرە."
        private const val REQ_NOTIF = 1001
        private const val REQ_CAPTURE = 1002
        private const val REQ_MIC = 1003
        private const val REQ_PIPER_MODEL = 1004
    }
}
