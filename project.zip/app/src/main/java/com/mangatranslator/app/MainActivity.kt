package com.mangatranslator.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.app.AlertDialog
import android.text.InputType
import android.widget.Button
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.HorizontalScrollView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.widget.CheckBox
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.Spinner
import androidx.core.content.ContextCompat

/**
 * شاشەی سەرەکی:
 * ١. ڕێگەپێدانی پیشاندان لەسەر ئەپەکانی تر
 * ٢. دەستپێکردن (گرتنی شاشە + بابلی شەمەندەفەر)
 * ٣. وەستاندن
 * ٤. کلیلی Google (ئارەزوومەندانە)
 */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private var testTts: SoraniTts? = null
    private val handler = Handler(Looper.getMainLooper())

    private val poller = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(36), pad, dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ---- سەرەوە: لۆگۆ + ناو + دۆخ ----
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.app_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(104), dp(104)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(12)
        })
        root.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(c(R.color.text_main))
            gravity = Gravity.CENTER
        }, matchWrap(bottom = dp(4)))
        root.addView(TextView(this).apply {
            text = "وەرگێڕانی ڕاستەوخۆی شاشە بۆ کوردیی سۆرانی"
            textSize = 14f
            setTextColor(c(R.color.text_dim))
            gravity = Gravity.CENTER
        }, matchWrap(bottom = dp(16)))

        statusText = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        root.addView(statusText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(24) })

        // ---- هەڵبژاردنی دۆخ (کارتی جوان) ----
        val modeSt = TranslatorSettings(this)
        root.addView(sectionTitle("دۆخی ئەپ"), matchWrap(bottom = dp(8)))
        val cardOld = modeCard("دۆخی کۆن", "بابلەکانی «ک» · «وەر» · «دەنگ»")
        val cardNew = modeCard("دۆخی نوێ", "ڕووبەر (هەموو زمانێک) + قسەکردن بۆ نووسین")
        fun paintModes(m: Int) {
            cardOld.background = cardBg(m == 0)
            cardNew.background = cardBg(m == 1)
        }
        paintModes(modeSt.mode)
        cardOld.setOnClickListener {
            modeSt.mode = 0; paintModes(0)
            if (isRunning()) toast("بۆ گۆڕینی دۆخ، سەرەتا «وەستاندن» بکە و دووبارە «دەستپێکردن»")
        }
        cardNew.setOnClickListener {
            modeSt.mode = 1; paintModes(1)
            if (isRunning()) toast("بۆ گۆڕینی دۆخ، سەرەتا «وەستاندن» بکە و دووبارە «دەستپێکردن»")
        }
        root.addView(cardOld, matchWrap(bottom = dp(10)))
        root.addView(cardNew, matchWrap(bottom = dp(24)))

        // ---- ڕەنگی ئەپ ----
        root.addView(sectionTitle("ڕەنگی ئەپ"), matchWrap(bottom = dp(8)))
        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Palettes.all.forEachIndexed { i, p ->
            val sel = i == modeSt.theme
            swatches.addView(TextView(this).apply {
                text = if (sel) "✓" else ""
                setTextColor(if (p.light) Color.parseColor("#101828") else Color.WHITE)
                textSize = 18f
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.a2, p.a1, p.bgBottom)).apply {
                    shape = GradientDrawable.OVAL
                    setStroke(dp(if (sel) 3 else 1), if (sel) c(R.color.text_main) else Color.parseColor("#66888888"))
                }
                setOnClickListener { if (!sel) { modeSt.theme = i; recreate() } }
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) })
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(swatches)
        }, matchWrap(bottom = dp(24)))

        // ---- خێرایی دەنگ (وەک YouTube) ----
        root.addView(sectionTitle("خێرایی دەنگ"), matchWrap(bottom = dp(8)))
        val chips = ArrayList<Pair<Float, TextView>>()
        fun paintChips() {
            val cur = modeSt.speechSpeed
            for ((v, tv) in chips) {
                val sel = v == cur
                tv.background = if (sel) gradient(c(R.color.accent_blue), c(R.color.accent_cyan))
                else rounded(c(R.color.card), 16, c(R.color.card_stroke), dp(1))
                tv.setTextColor(if (sel) Color.WHITE else c(R.color.text_main))
            }
        }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in TranslatorSettings.SPEEDS) {
            val label = if (v == 1f) "ئاسایی" else "${v.toString().trimEnd('0').trimEnd('.')}x"
            val tv = TextView(this).apply {
                text = label
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(16), 0, dp(16), 0)
                setOnClickListener { modeSt.speechSpeed = v; paintChips() }
            }
            chips.add(v to tv)
            chipRow.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(42)).apply { marginEnd = dp(8) })
        }
        paintChips()
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow)
        }, matchWrap(bottom = dp(24)))

        // ---- شاردنەوەی بابلەکان لە لێواری شاشە ----
        root.addView(sectionTitle("چوونە لێواری شاشە"), matchWrap(bottom = dp(4)))
        val steps = TranslatorSettings.DOCK_STEPS
        fun fmt(sec: Int): String =
            if (sec < 60) "$sec چرکە"
            else {
                val m = sec / 60f
                (if (m % 1f == 0f) m.toInt().toString() else m.toString()) + " خولەک"
            }
        val dockLabel = TextView(this).apply {
            textSize = 14f
            setTextColor(c(R.color.text_main))
        }
        val curIdx = steps.indexOfFirst { it >= modeSt.dockDelaySec }.let { if (it < 0) steps.lastIndex else it }
        dockLabel.text = "بابلەکان دوای " + fmt(steps[curIdx]) + " بێ بەکارهێنان دەچنە لێوار"
        val dockBar = SeekBar(this).apply {
            max = steps.lastIndex
            progress = curIdx
            progressTintList = ColorStateList.valueOf(pal.a2)
            thumbTintList = ColorStateList.valueOf(pal.a2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    dockLabel.text = "بابلەکان دوای " + fmt(steps[p]) + " بێ بەکارهێنان دەچنە لێوار"
                    if (fromUser) modeSt.dockDelaySec = steps[p]
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(dockLabel, matchWrap(bottom = dp(4)))
        root.addView(dockBar, matchWrap(bottom = dp(24)))

        // ---- نووسینی ئۆفلاین (قسە ← نووسین بێ ئینتەرنێت) ----
        root.addView(sectionTitle("نووسینی ئۆفلاین (Vekol)"), matchWrap(bottom = dp(4)))
        val sttCb = CheckBox(this).apply {
            text = "قسە ← نووسین بە مۆدێلی ئۆفلاین (بێ ئینتەرنێت)؛ ئەگەر نەدابەزێندرابوو Gemini بەکاردێت"
            setTextColor(c(R.color.text_main))
            isChecked = modeSt.offlineStt
            setOnCheckedChangeListener { _, v -> modeSt.offlineStt = v }
        }
        val sttStatus = TextView(this).apply {
            textSize = 13f
            setTextColor(c(R.color.text_dim))
        }
        fun refreshStt() {
            sttStatus.text = if (VekolStt.isReady(this@MainActivity)) "مۆدێل دابەزێندراوە ✓ (مۆڵەت: CC-BY-NC، تەنها نا-بازرگانی)"
            else "مۆدێل دانەبەزێندراوە. نزیکەی ٢٩١ مێگابایت؛ لەسەر WiFi باشترە"
        }
        refreshStt()
        val sttBtn = button("⬇  دابەزاندنی مۆدێلی کوردی", outline(c(R.color.accent_cyan)), c(R.color.accent_cyan)) { }
        var sttBusy = false
        sttBtn.setOnClickListener {
            if (sttBusy) return@setOnClickListener
            if (VekolStt.isReady(this)) {
                toast("مۆدێلەکە پێشتر دابەزێندراوە")
                return@setOnClickListener
            }
            sttBusy = true
            sttBtn.isEnabled = false
            Thread {
                try {
                    VekolStt.download(this) { done, total, name ->
                        handler.post {
                            sttStatus.text = "دەدابەزێت: " + name + "\n" +
                                (done / 1_048_576) + " / " + (total / 1_048_576) + " مێگابایت"
                        }
                    }
                    handler.post { refreshStt(); toast("مۆدێلی کوردی دابەزێندرا ✓") }
                } catch (t: Throwable) {
                    handler.post {
                        sttStatus.text = "دابەزاندن پچڕا: " + (t.message ?: t.javaClass.simpleName).take(120) +
                            "\nدووبارە دوگمەکە دابگرە، لەو شوێنەوە بەردەوام دەبێت"
                    }
                } finally {
                    handler.post { sttBusy = false; sttBtn.isEnabled = true }
                }
            }.start()
        }
        root.addView(sttCb, matchWrap(bottom = dp(4)))
        root.addView(sttStatus, matchWrap(bottom = dp(8)))
        root.addView(sttBtn, matchWrap(bottom = dp(24)))

        // ---- دوگمەکان ----
        root.addView(
            button("١. ڕێگەپێدانی پیشاندان", outline(c(R.color.accent_cyan)), c(R.color.accent_cyan)) { openOverlaySettings() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("▶  ٢. دەستپێکردن", gradient(c(R.color.accent_blue), c(R.color.accent_cyan)), Color.WHITE) { startFlow() },
            matchWrap(bottom = dp(12))
        )
        root.addView(
            button("■  ٣. وەستاندن", outline(Color.parseColor("#FF5C6C")), Color.parseColor("#FF5C6C")) { stopTranslator() },
            matchWrap(bottom = dp(20))
        )

        // ---- ڕێکخستنەکان: دوو دوگمە لە تەنیشت یەک ----
        root.addView(sectionTitle("ڕێکخستنەکان"), matchWrap(bottom = dp(8)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(
            button("🔊 دەنگ", rounded(c(R.color.card), 14, c(R.color.card_stroke), dp(1)), c(R.color.text_main)) { showVoiceDialog() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) }
        )
        row.addView(
            button("🔑 کلیلی Google", rounded(c(R.color.card), 14, c(R.color.card_stroke), dp(1)), c(R.color.text_main)) { showKeyDialog() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) }
        )
        root.addView(row, matchWrap(bottom = dp(24)))

        // ---- یارمەتی ----
        val help = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(c(R.color.card), 18, c(R.color.card_stroke), dp(1))
        }
        help.addView(TextView(this).apply {
            text = "چۆن بەکاری بهێنم؟"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(c(R.color.accent_cyan))
        }, matchWrap(bottom = dp(8)))
        help.addView(TextView(this).apply {
            text = "دۆخی کۆن، سێ بابل دەردەکەون:\n" +
                "«ک» = وەرگێڕانی خۆکار (سەوز = چالاک)\n" +
                "«وەر» = وەرگێڕانی شاشەی ئێستا (درێژ بگرە بۆ شاردنەوە)\n" +
                "«دەنگ» = خوێندنەوەی وەرگێڕانەکان بە دەنگ\n" +
                "\nدۆخی نوێ، دوو بابل دەردەکەون:\n" +
                "«ڕ» = ڕووبەرێک بکێشە؛ دەیکات بە کوردی و دەیخوێنێتەوە\n" +
                "«قسە» = بە کوردی قسە بکە؛ دەنووسرێت و کۆپی دەکرێت\n" +
                "(کلیلی Gemini پێویستە)"
            textSize = 13f
            setLineSpacing(0f, 1.25f)
            setTextColor(c(R.color.text_dim))
        })
        root.addView(help, matchWrap())

        window.statusBarColor = pal.bgTop
        window.navigationBarColor = pal.bgBottom
        if (pal.light) {
            var f = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = f
        }
        setContentView(FrameLayout(this).apply {
            addView(GlassBackground(this@MainActivity, pal),
                FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(ScrollView(this@MainActivity).apply {
                isFillViewport = true
                setBackgroundColor(Color.TRANSPARENT)
                addView(root)
            })
        })
        autoDownloadVoice()
        autoDownloadOcr()
    }

    private fun showKeyDialog() {
        val st = TranslatorSettings(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(0))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val googleKey = EditText(this).apply {
            hint = "کلیلی API ی Google Cloud Translation"
            setText(st.googleKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(googleKey)
        box.addView(TextView(this).apply {
            text = "ئارەزوومەندانەیە. ئەگەر کلیلت نییە، ئەم خانەیە بەتاڵ بهێڵەرەوە. بێ کلیلیش وەرگێڕان بە Google Translate کار دەکات؛ " +
                "ئەگەر کلیلت هەیە، ڕێگای فەرمی بەکار دێت کە جێگیرترە. ئینتەرنێت پێویستە."
            textSize = 13f
        })

        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("کلیلی Google")
            .setView(box)
            .setPositiveButton("هەڵگرتن") { _, _ ->
                st.googleKey = googleKey.text.toString()
                toast("هەڵگیرا")
            }
            .setNegativeButton("پاشگەزبوونەوە", null)
            .show()
    }


    private fun showVoiceDialog() {
        val st = TranslatorSettings(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(0))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val key = EditText(this).apply {
            hint = "کلیلی Gemini API (دەتوانیت ٢ یان ٣ کلیل بنووسیت، هەر یەکێک لە دێڕێک)"
            setText(st.geminiTtsKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 2
        }
        val voices = listOf("Kore", "Aoede", "Charon", "Puck")
        val voice = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices)
            setSelection(voices.indexOf(st.geminiTtsVoice).coerceAtLeast(0))
        }
        val autoSpeak = CheckBox(this).apply {
            text = "دوای وەرگێڕانی دەستی شاشە، دەقەکە خۆکارانە بە دەنگ بخوێنەوە"
            isChecked = st.autoSpeak
        }
        val fast = CheckBox(this).apply {
            text = "دۆخی خێرا (دۆخی نوێ): مۆدێلی سووکتر، زۆر خێراتر؛ ئەگەر وەرگێڕان باش نەبوو، ڕایبگرە"
            isChecked = st.fast
        }
        val autoHide = CheckBox(this).apply {
            text = "دوای تەواوبوونی خوێندنەوە، وەرگێڕانی سەر شاشە خۆکارانە بشارێتەوە"
            isChecked = st.autoHideOverlay
        }
        val localKu = CheckBox(this).apply {
            text = "ناسینەوەی خێرای کوردی (لەسەر مۆبایل): ئەگەر ڕووبەرەکە کوردی بوو، بێ چاوەڕێی AI یەکسەر دەیخوێنێتەوە"
            isChecked = st.localKurdish
        }
        val offlineCb = CheckBox(this).apply {
            text = "خوێندنەوەی ئۆفلاین (بێ ئینتەرنێت): کوردی بە دەنگی ناو مۆبایل دەخوێنرێتەوە"
            isChecked = st.offlineTts
        }
        box.addView(autoHide)
        box.addView(localKu)
        box.addView(offlineCb)
        val offlineVoices = listOf("ئینگلیزی (لاتینیی کوردی)", "عەرەبی", "تورکی (کۆن)", "فارسیی سیستەم (زۆرجار نییە)", "کوردیی نیورالی (Berfin، ONNX) — باشترین")
        val offlineVoice = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, offlineVoices)
            setSelection(st.offlineVoice)
        }
        box.addView(offlineVoice)
        piperStatus = TextView(this).apply { textSize = 12f }
        refreshPiperStatus()
        box.addView(piperStatus)
        box.addView(Button(this).apply {
            text = "داگرتنی دەنگی کوردی (خۆکار)"
            setOnClickListener { autoDownloadVoice() }
        })
        box.addView(Button(this).apply {
            text = "هێنانی مۆدێلی کوردی لە فایل (ئارەزوومەندانە)"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                try { startActivityForResult(i, REQ_PIPER_MODEL) } catch (_: Exception) { toast("فایل هەڵبژێر نەکرایەوە") }
            }
        })
        box.addView(TextView(this).apply {
            text = "پێویستی: دەنگی هەڵبژێردراو دابەزێنە (Settings ← Text-to-speech ← Google ← Install voice data). " +
                "دەنگی کوردیی ئۆفلاین لە ئەندرۆید نییە، بۆیە کوردییەکە نزیکە و وردی Gemini ی نییە. کلیلی Gemini لەم دۆخەدا پێویست نییە."
            textSize = 12f
        })
        box.addView(key)
        box.addView(voice)
        box.addView(autoSpeak)
        box.addView(fast)
        box.addView(TextView(this).apply {
            text = "خوێندنەوە بە Gemini TTS ـە و کوردیی ناوەندی/سۆرانی پشتیوانی دەکات. " +
                "Gemini API لە سنووری خۆڕاییی Google بەکاردێت؛ quota و rate limit هەیە. " +
                "ئەم کلیلی Gemini API جیاوازە لە کلیلی Google Translate. ئینتەرنێت پێویستە."
            textSize = 13f
        })

        fun saveAll() {
            st.geminiTtsKey = key.text.toString()
            st.geminiTtsVoice = voice.selectedItem?.toString() ?: TranslatorSettings.DEFAULT_GEMINI_VOICE
            st.autoSpeak = autoSpeak.isChecked
            st.fast = fast.isChecked
            st.localKurdish = localKu.isChecked
            st.autoHideOverlay = autoHide.isChecked
            st.offlineTts = offlineCb.isChecked
            st.offlineVoice = offlineVoice.selectedItemPosition
        }

        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("ڕێکخستنی دەنگ")
            .setView(box)
            .setPositiveButton("هەڵگرتن") { _, _ ->
                saveAll()
                toast("هەڵگیرا")
            }
            .setNeutralButton("تاقیکردنەوە") { _, _ ->
                saveAll()
                val t = testTts ?: SoraniTts(this, st).also { testTts = it }
                t.speak(
                    listOf("سڵاو، ئەمە تاقیکردنەوەی دەنگە."),
                    onState = {},
                    onError = { toast(it) }
                )
            }
            .setNegativeButton("پاشگەزبوونەوە", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        handler.post(poller)
    }

    override fun onPause() {
        handler.removeCallbacks(poller)
        super.onPause()
    }

    override fun onDestroy() {
        testTts?.shutdown()
        testTts = null
        super.onDestroy()
    }

    private fun updateStatus() {
        val ok = Settings.canDrawOverlays(this)
        val col = if (ok) c(R.color.accent_green) else Color.parseColor("#FFB020")
        statusText.text = if (ok) "● ڕێگەپێدانی پیشاندان: چالاکە" else "● ڕێگەپێدانی پیشاندان: هێشتا نەدراوە"
        statusText.setTextColor(col)
        statusText.background = rounded(if (ok) Color.parseColor("#0F2E22") else Color.parseColor("#3A2A10"), 20, col, dp(1))
    }

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            toast("سەرەتا ڕێگەپێدانی پیشاندان چالاک بکە")
            openOverlaySettings()
            return
        }

        // Android 13+: ڕێگەپێدانی ئاگادارکردنەوە بۆ نیشاندانی ئاگادارکردنەوەی خزمەتگوزاری
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }

        askMicThenCapture()
    }

    /** دۆخی نوێ مایک پێویستە (قسەکردن بۆ نووسین)؛ ئەگەر ڕێگەی نەدا، ڕووبەرەکە هەر کار دەکات. */
    private fun askMicThenCapture() {
        if (TranslatorSettings(this).mode == 1 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        requestScreenCapture()
    }

    @Suppress("DEPRECATION")
    private fun isRunning(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        return am.getRunningServices(100).any { it.service.className == OverlayService::class.java.name }
    }

    private fun requestScreenCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            // با ڕێگەپێدان یان بێ ڕێگەپێدان بەردەوام دەبین؛ خزمەتگوزاری هەر کار دەکات
            askMicThenCapture()
        } else if (requestCode == REQ_MIC) {
            if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
                toast("مایک ڕێگەی پێنەدرا؛ «قسە» کار ناکات، بەڵام «ڕ» کار دەکات")
            }
            requestScreenCapture()
        }
    }

    @Deprecated("Deprecated in Java")
    private var piperStatus: TextView? = null

    @Volatile private var voiceDl = -1   // -1 = دانەبەزاندووە، 0..100 = لە داگرتندایە

    /** ئەگەر دەنگی کوردی نەهێنرابوو، خۆکارانە دایدەبەزێنێت (تەنها یەکجار، ~٦٠MB). */
    private fun autoDownloadVoice() {
        if (PiperTts.isInstalled(this) || voiceDl >= 0) return
        voiceDl = 0
        refreshPiperStatus()
        val h = Handler(Looper.getMainLooper())
        Thread {
            val err = PiperTts.download(applicationContext) { p ->
                voiceDl = p
                h.post { refreshPiperStatus() }
            }
            voiceDl = -1
            h.post {
                refreshPiperStatus()
                toast(err ?: "دەنگی کوردی داگیرا ✓")
            }
        }.start()
    }

    @Volatile private var ocrDl = false

    /** فایلی زمانی کوردیی OCR ی خێرا (~٣MB)، یەکجار خۆکارانە دادەبەزێت. */
    private fun autoDownloadOcr() {
        if (LocalKurdishOcr.isInstalled(this) || ocrDl) return
        ocrDl = true
        val h = Handler(Looper.getMainLooper())
        Thread {
            val err = LocalKurdishOcr.download(applicationContext)
            ocrDl = false
            if (err != null) h.post { toast(err) }
        }.start()
    }

    private fun refreshPiperStatus() {
        if (voiceDl >= 0) { piperStatus?.text = "دەنگی کوردی دادەبەزێت... $voiceDl%"; return }
        piperStatus?.text = if (PiperTts.isInstalled(this))
            "مۆدێلی کوردیی نیورالی: هێنراوە ✓"
        else
            "مۆدێلی کوردیی نیورالی: نەهێنراوە (دوگمەی «داگرتن» بکە)"
    }

    private fun importPiperModel(data: Intent) {
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
        data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        toast("مۆدێل دەهێنرێت... (چەند چرکەیەک)")
        Thread {
            val err = PiperTts.importModel(applicationContext, uris)
            Handler(Looper.getMainLooper()).post {
                refreshPiperStatus()
                toast(err ?: "مۆدێلی کوردی هێنرا ✓")
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PIPER_MODEL) {
            if (resultCode == Activity.RESULT_OK && data != null) importPiperModel(data)
            return
        }
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val svc = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                    putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(OverlayService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, svc)
                toast("بابلەکان دەرکەوتن. دەتوانیت بچیتە سەر ئەپی مانگاکەت")
                moveTaskToBack(true)
            } else {
                toast("ڕێگەپێدانی گرتنی شاشە وەرنەگیرا")
            }
        }
    }

    private fun stopTranslator() {
        stopService(Intent(this, OverlayService::class.java))
        toast("وەستێنرا")
    }

    // ---------- یارمەتیدەرەکان ----------

    private val pal by lazy { Palettes.get(TranslatorSettings(this).theme) }

    /** ڕەنگەکان لە پاڵێتی هەڵبژێردراو وەردەگیرێن؛ کارتەکان شووشەیین (ڕوونی نیمچە). */
    private fun c(id: Int): Int = when (id) {
        R.color.bg_dark -> pal.bgBottom
        R.color.card -> Color.parseColor(if (pal.light) "#B3FFFFFF" else "#1AFFFFFF")
        R.color.card_stroke -> Color.parseColor(if (pal.light) "#22000000" else "#40FFFFFF")
        R.color.accent_blue -> pal.a1
        R.color.accent_cyan -> pal.a2
        R.color.text_main -> if (pal.light) Color.parseColor("#101828") else Color.WHITE
        R.color.text_dim -> Color.parseColor(if (pal.light) "#51607A" else "#C5D5EE")
        else -> ContextCompat.getColor(this, id)
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int = 0, strokeW: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (strokeW > 0) setStroke(strokeW, stroke)
    }

    private fun gradient(from: Int, to: Int) = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(from, to)
    ).apply { cornerRadius = dp(16).toFloat() }

    private fun outline(color: Int) = rounded(Color.TRANSPARENT, 16, color, dp(2))

    private fun cardBg(selected: Boolean) =
        if (selected) rounded((pal.a2 and 0x00FFFFFF) or 0x33000000, 18, pal.a2, dp(2))
        else rounded(c(R.color.card), 18, c(R.color.card_stroke), dp(1))

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(c(R.color.text_dim))
    }

    private fun modeCard(title: String, desc: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        isClickable = true
        addView(TextView(context).apply {
            text = title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(c(R.color.text_main))
        })
        addView(TextView(context).apply {
            text = desc
            textSize = 13f
            setTextColor(c(R.color.text_dim))
        })
    }

    private fun button(label: String, bg: Drawable, textColor: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(textColor)
        stateListAnimator = null
        minHeight = dp(54)
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), bg, null)
        setOnClickListener { onClick() }
    }

    private fun matchWrap(bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = bottom }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val REQ_NOTIF = 1001
        private const val REQ_CAPTURE = 1002
        private const val REQ_MIC = 1003
        private const val REQ_PIPER_MODEL = 1004
    }
}
