package com.mangatranslator.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * چاکردنی هەڵە بچووکەکانی دەقی نووسراو (دوای مۆدێلی ئۆفلاینی Vekol) بە Gemini.
 *
 * بۆ ئەوەی خاو نەکاتەوە:
 *  - تەنها دەق دەنێرێت (نە دەنگ) و مۆدێلی خێرا (fast) + بیرکردنەوەی کەمترین ئاست بەکاردێنێت
 *  - کاتی چاوەڕێکردن کورتە (٤ چرکە پەیوەندی، ٧ چرکە وەڵام)
 *  - ئەگەر هەر شتێک هەڵە بوو یان وەڵامەکە گومانلێکراو بوو، null دەگەڕێتەوە و دەقە ئۆفلاینەکە وەک خۆی دەمێنێتەوە
 * لە thread ی پاشبنەما بانگ بکرێت.
 */
object KurdishTextFix {

    private const val PROMPT =
        "You are a proofreader for Central Kurdish (Sorani) text that was produced by a speech-to-text model. " +
            "Fix ONLY small mistakes: wrong or confused letters (ی not ي, ک not ك, ە, ێ, ۆ, ڵ, ڕ, وو), wrongly split or joined words, " +
            "obvious misheard words that are clearly wrong from context, and punctuation (، . ؟). " +
            "Do NOT rephrase, translate, summarize, shorten, extend or explain. Keep the meaning and the word order. " +
            "Keep English words in Latin letters and numbers as digits. " +
            "If the text is already correct, return it unchanged. Return ONLY the corrected text on a single line.\n\nText:\n"

    private const val PROMPT_MANUAL =
        "You are an expert editor of Central Kurdish (Sorani). The following text was produced by a speech-to-text model " +
            "and the speaker says it contains mistakes or garbled words. Correct it into clear, natural, correct Sorani Kurdish " +
            "in Arabic script (ی not ي, ک not ك, ە, ێ, ۆ, ڵ, ڕ, وو), fixing misheard or nonsense words from context, " +
            "wrongly split or joined words, and punctuation (، . ؟). Keep the original meaning and intent; do NOT translate, " +
            "summarize, explain or add new ideas. Keep English words in Latin letters and numbers as digits. " +
            "Return ONLY the corrected text.\n\nText:\n"

    /**
     * چاککردنی دەستی (کاتێک بەکارهێنەر دووگمەی «چاک بکە» دادەگرێت): ئازادترە لە fix() و مۆدێلی بەهێزتر بەکاردێنێت.
     * دەقی چاککراو دەگەڕێنێتەوە (ڕەنگە هەمان دەق بێت)، یان null ئەگەر نەکرا. لە thread ی پاشبنەما بانگ بکرێت.
     */
    fun fixManual(text: String, keysRaw: String): String? {
        val src = text.trim()
        if (src.isEmpty() || keysRaw.isBlank()) return null
        return try {
            val out = GeminiKeys.withKeys(keysRaw) { key ->
                GeminiModels.call(false) { m, think ->
                    post(body(src, m, think, PROMPT_MANUAL, 1024), key, m, 8_000, 30_000)
                }
            }.trim().trim('"', '`').trim()
            if (out.isEmpty()) return null
            val ratio = out.length.toFloat() / src.length
            if (ratio < 0.4f || ratio > 2.5f) null else out
        } catch (_: Throwable) {
            null
        }
    }

    /** دەقی چاککراو، یان null ئەگەر نەکرا / متمانەی پێ ناکرێت. */
    fun fix(text: String, keysRaw: String): String? {
        val src = text.trim()
        if (src.length < 3 || keysRaw.isBlank()) return null
        return try {
            val out = GeminiKeys.withKeys(keysRaw) { key ->
                GeminiModels.call(true) { m, think -> post(body(src, m, think), key, m) }
            }
            accept(src, out)
        } catch (_: Throwable) {
            null
        }
    }

    private fun body(src: String, model: String, think: Boolean, prompt: String = PROMPT, maxTokens: Int = 512): String {
        val gen = JSONObject().put("temperature", 0).put("maxOutputTokens", maxTokens)
        if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
        return JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", prompt + src))
                    )
                )
            )
            .put("generationConfig", gen)
            .toString()
    }

    /** پاراستن: دەبێت هێشتا هەمان دەق بێت (درێژی و ژمارەی وشە نزیک بێت)، نەک شرۆڤە یان وەرگێڕان. */
    private fun accept(src: String, raw: String): String? {
        val out = raw.trim().trim('"', '`').replace(Regex("\\s+"), " ")
        if (out.isEmpty()) return null
        val ratio = out.length.toFloat() / src.length
        if (ratio < 0.7f || ratio > 1.4f) return null
        val a = src.split(' ').size
        val b = out.split(' ').size
        if (kotlin.math.abs(a - b) > maxOf(2, a * 3 / 10)) return null
        return out
    }

    private fun post(body: String, key: String, model: String, connectMs: Int = 4_000, readMs: Int = 7_000): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = connectMs
            c.readTimeout = readMs
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try {
                    JSONObject(resp).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    resp
                }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            return try {
                val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").optJSONArray("parts")
                if (parts == null || parts.length() == 0) "" else parts.getJSONObject(0).optString("text", "")
            } catch (_: Exception) {
                throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
            }
        } finally {
            c.disconnect()
        }
    }
}
