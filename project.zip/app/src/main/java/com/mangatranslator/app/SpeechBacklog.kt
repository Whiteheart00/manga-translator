package com.mangatranslator.app

/**
 * ڕیزی دەنگی ژێرنووسی زیندوو (فەنکشنی پاک، بێ Android، تاقیکراو).
 *
 * پێشتر: تەنها «نوێترین» دەمایەوە و دێڕی کۆن لە ناوەڕاستی ڕستە دەبڕدرا ← ڕستەکان نیوەچڵ دەخوێنرانەوە.
 * ئێستا: ڕستەی ئێستا تەواو دەخوێنرێتەوە؛ ئەوانەی لە ماوەی ئەودا هاتوون لە ڕیزدا دەمێننەوە (تا [maxQueue])
 * و دواتر پێکەوە لە یەک دەنگدا دەخوێنرێنەوە، کەمێک خێراتر ([Batch.boost]) بۆ ئەوەی لە ئاخێوەرەکە دوا نەکەوین.
 * دێڕی زۆر کۆن ([staleMs]) فڕێدەدرێت.
 */
class SpeechBacklog(
    private val maxQueue: Int = 4,
    private val staleMs: Long = 7_000L,
    private val maxChars: Int = 260,
    private val maxBoost: Float = 1.35f
) {
    class Batch(val text: String, val boost: Float, val count: Int)

    private class Line(val text: String, val at: Long)

    private val q = ArrayDeque<Line>()

    fun isEmpty() = q.isEmpty()
    fun size() = q.size
    fun clear() = q.clear()

    fun add(text: String, now: Long) {
        val t = text.trim()
        if (t.isEmpty()) return
        q.addLast(Line(t, now))
        while (q.size > maxQueue) q.removeFirst()
    }

    /** چەند ms کۆنترین دێڕی چاوەڕێ ماوەتەوە (٠ ئەگەر ڕیز بەتاڵ بێت) */
    fun oldestWait(now: Long): Long = if (q.isEmpty()) 0L else now - q.first().at

    /** هەموو دێڕە چاوەڕێکراوەکان وەک یەک بەش دەگەڕێنێتەوە و ڕیزەکە بەتاڵ دەکات؛ null ئەگەر شتێک نەمابێت. */
    fun take(now: Long): Batch? {
        while (q.isNotEmpty() && now - q.first().at > staleMs) q.removeFirst()
        if (q.isEmpty()) return null
        val waited = now - q.first().at
        val items = ArrayList(q)
        q.clear()
        // دێڕە کۆنەکان لابەرە تا دەقە یەکگرتووەکە زۆر درێژ نەبێت (نوێترینەکان دەمێنن)
        while (items.size > 1 && items.sumOf { it.text.length + 1 } > maxChars) items.removeAt(0)
        val text = if (items.size == 1) items[0].text else items.joinToString(" ") { endPunct(it.text) }
        var boost = 1f + 0.12f * (items.size - 1)
        if (waited > 1_500L) boost += 0.1f
        return Batch(text, boost.coerceIn(1f, maxBoost), items.size)
    }

    private fun endPunct(s: String): String {
        val last = s.last()
        return if (last in ".!?؟،,…:;") s else "$s،"
    }
}
