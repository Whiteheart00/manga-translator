package com.mangatranslator.app

import android.content.Context
import android.graphics.Rect
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo

/**
 * خوێندنەوەی دەقی شاشە ڕاستەوخۆ لە دره‌ختی Accessibility (وەک Google Translate): بێ OCR، خێرا،
 * و بۆ هەموو زمانێک (سیریلی، تایلەندی، عیبری، هیندی…) کار دەکات، تەنانەت ئەگەر چەند زمانێک لەسەر شاشە بێت.
 * ئەگەر ئەپەکە دەقی ڕاستەقینە نەدات (مانگا وەک وێنە، یاری) هیچ ناگەڕێنێتەوە و OcrEngine OCR بەکاردێنێت.
 */
object ScreenText {
    private const val MAX_NODES = 4000
    private const val MAX_DEPTH = 60

    /** کەمترین ژمارەی بلۆکی دەق (و پیت) بۆ ئەوەی ئیمزای دەقی متمانەپێکراو بێت. */
    private const val SIG_MIN_BOXES = 3
    private const val SIG_MIN_LETTERS = 30

    /** ئیمزای دەقی بلۆکەکان (بێ شوێن). ٠ = دەقی پێویست نییە بۆ متمانەکردن (وێنە/مانگا). فەنکشنی پاک و تاقیکراو. */
    fun signatureOf(texts: List<String>): Int {
        if (texts.size < SIG_MIN_BOXES) return 0
        if (texts.sumOf { t -> t.count { it.isLetter() } } < SIG_MIN_LETTERS) return 0
        var h = 17
        for (t in texts) h = h * 31 + t.hashCode()
        return if (h == 0) 1 else h
    }

    /**
     * ئیمزای دەقی ئێستای شاشە لە Accessibility. ئەگەر ئەپەکە دەقی ڕاستەقینە نەدات (مانگا وەک وێنە، یاری)
     * یان کەمتر لە ٣ بلۆکی دەق هەبێت، ٠ دەگەڕێتەوە و بانگکەر تەنها پشت بە پیکسێل دەبەستێت.
     */
    fun signature(ctx: Context): Int {
        if (MangaAccessibilityService.instance == null) return 0
        return signatureOf(collect(ctx, 1000, 1000).map { it.text })
    }

    /** بۆکسەکان بە پیکسێلی وێنەی گیراو (frameW × frameH) دەگەڕێنرێنەوە. */
    fun collect(ctx: Context, frameW: Int, frameH: Int): List<TextBox> {
        val svc = MangaAccessibilityService.instance ?: return emptyList()
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        if (dm.widthPixels <= 0 || dm.heightPixels <= 0) return emptyList()
        val sx = frameW.toFloat() / dm.widthPixels
        val sy = frameH.toFloat() / dm.heightPixels

        val roots = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in svc.windows.orEmpty()) w.root?.let { roots.add(it) }
        } catch (_: Throwable) {}
        if (roots.isEmpty()) svc.rootInActiveWindow?.let { roots.add(it) }

        val out = ArrayList<TextBox>()
        var count = 0
        val tmp = Rect()
        /** دەگەڕێنێتەوە ژمارەی دەقی دۆزراوە لەم لقە (بۆ ئەوەی دایک contentDescription ـی خۆی نەخاتە سەر منداڵەکان) */
        fun walk(n: AccessibilityNodeInfo, depth: Int): Int {
            if (count++ > MAX_NODES || depth > MAX_DEPTH) return 0
            if (!n.isVisibleToUser) return 0
            var found = 0
            for (i in 0 until n.childCount) {
                val c = try { n.getChild(i) } catch (_: Throwable) { null } ?: continue
                found += walk(c, depth + 1)
            }
            val own = n.text?.toString()?.trim().orEmpty()
            // فەیسبووک و ئەپە Litho/React ـەکان دەقی پۆست لە contentDescription دەنووسن نەک text:
            // تەنها ئەو کاتە بەکاردێت کە لقەکە هیچ دەقی تری نییە و کلیک/وێنەی گەورە نییە
            val desc = if (own.isEmpty() && found == 0) n.contentDescription?.toString()?.trim().orEmpty() else ""
            val txt = if (own.isNotEmpty()) own else desc
            // ڕووکاری ئەپ (کات، بەروار، Like/Comment/Share، دۆخی چات…) هەرگیز نەخوێندرێتەوە و وەرنەگێڕدرێت
            val noise = txt.isNotEmpty() &&
                (UiNoise.isNoise(txt, ui = true) || UiNoise.isNoiseId(n.viewIdResourceName, txt.length))
            if (txt.isNotEmpty() && !n.isPassword && !noise) {
                n.getBoundsInScreen(tmp)
                val r = Rect(
                    (tmp.left * sx).toInt().coerceIn(0, frameW), (tmp.top * sy).toInt().coerceIn(0, frameH),
                    (tmp.right * sx).toInt().coerceIn(0, frameW), (tmp.bottom * sy).toInt().coerceIn(0, frameH)
                )
                val tooBig = own.isEmpty() && r.width().toLong() * r.height() > frameW.toLong() * frameH * 0.45
                val letters = txt.count { it.isLetter() }
                if (r.width() > 2 && r.height() > 2 && !tooBig && letters >= 2 &&
                    out.none { TextFilter.overlapsMostly(it.rect, r) && it.text == txt.take(1500) }) {
                    out.add(TextBox(r, txt.take(1500)))
                    found++
                }
            }
            return found
        }
        for (r in roots) {
            if (r.packageName?.toString() == ctx.packageName) continue   // ئۆڤەرلەی خۆمان نەخوێنرێتەوە
            walk(r, 0)
        }
        return out
    }
}
