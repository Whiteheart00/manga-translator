package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Display
import androidx.annotation.RequiresApi
import java.util.concurrent.Executor

/**
 * گرتنی شاشە بە Accessibility (takeScreenshot)؛ بێ پەنجەرەی ڕێگەپێدانی MediaProjection.
 * سنووری سیستەم: نزیکەی ٣ وێنە لە چرکەیەکدا، بۆیە لە دۆخی خۆکار ~٤٠٠ms جارێک فرەیم دەدات.
 * ئەپە FLAG_SECURE ـەکان وێنەی ڕەش دەدەن (وەک MediaProjection).
 */
@RequiresApi(30)
class AccessibilityCapturer(
    context: Context,
    private val onFirstFrame: () -> Unit,
    private val onUnavailable: () -> Unit
) : FrameSource {

    private val thread = HandlerThread("a11y-capture").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { handler.post(it) }

    @Volatile private var released = false
    @Volatile private var inFlight = false
    @Volatile private var inFlightSince = 0L
    private var last: Bitmap? = null
    private var firstNotified = false

    @Volatile
    override var frameListener: ((Bitmap) -> Unit)? = null

    private val tick = object : Runnable {
        override fun run() {
            if (released) return
            val l = frameListener
            if (l == null) { handler.postDelayed(this, IDLE_MS); return }
            shoot { bmp ->
                if (bmp != null) l(bmp)   // خاوەندارێتی bitmap دەدرێت بە listener (کۆپیکردنی زیادە نەماوە)
                handler.postDelayed(this, if (DeviceProfile.low) ACTIVE_MS_LOW else ACTIVE_MS)
            }
        }
    }

    override fun start() { handler.post(tick) }

    /** یەک وێنە؛ cb لە thread ی گرتنەوە. bitmap ی دراو هی cb ـە. */
    private fun shoot(cb: (Bitmap?) -> Unit) {
        val svc = MangaAccessibilityService.instance
        if (svc == null) { cb(null); if (!released) onUnavailable(); return }
        if (inFlight) {
            // ئەگەر takeScreenshot هەرگیز callback ی نەکرد، ڕایبگرە تا خۆکار بۆ هەمیشە نەوەستێت
            if (android.os.SystemClock.elapsedRealtime() - inFlightSince > 4000) inFlight = false
            else { cb(null); return }
        }
        inFlight = true
        inFlightSince = android.os.SystemClock.elapsedRealtime()
        try {
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, executor,
                object : android.accessibilityservice.AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: android.accessibilityservice.AccessibilityService.ScreenshotResult) {
                        var out: Bitmap? = null
                        try {
                            val hb = r.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hw?.recycle()
                            hb.close()
                            if (soft != null) {
                                val sc = if (DeviceProfile.low) SCALE_LOW else SCALE
                                out = Bitmap.createScaledBitmap(
                                    soft, (soft.width * sc).toInt().coerceAtLeast(2),
                                    (soft.height * sc).toInt().coerceAtLeast(2), true
                                )
                                if (out !== soft) soft.recycle()
                            }
                        } catch (t: Throwable) {
                            Log.e(TAG, "screenshot convert failed", t)
                        }
                        inFlight = false
                        if (out != null && !firstNotified) { firstNotified = true; onFirstFrame() }
                        // کۆپییەکە تەنها بۆ requestFrame ی یەدەگە؛ لە دۆخی خۆکار (listener هەیە) ناکرێت تا ٦MB لە هەر فرەیمێک نەخرێتە سەر ڕام
                        if (out != null && frameListener == null) { last?.recycle(); last = out.copy(Bitmap.Config.ARGB_8888, false) }
                        cb(out)
                    }

                    override fun onFailure(errorCode: Int) {
                        Log.w(TAG, "takeScreenshot failed: $errorCode")
                        inFlight = false
                        cb(null)
                    }
                })
        } catch (t: Throwable) {
            Log.e(TAG, "takeScreenshot threw", t)
            inFlight = false
            cb(null)
        }
    }

    override fun requestFrame(delayMs: Long, cb: (Bitmap?) -> Unit) {
        fun attempt(left: Int) {
            shoot { bmp ->
                when {
                    bmp != null -> cb(bmp)
                    left > 0 && !released -> handler.postDelayed({ attempt(left - 1) }, RETRY_MS)
                    else -> cb(last?.copy(Bitmap.Config.ARGB_8888, false))
                }
            }
        }
        handler.postDelayed({ attempt(4) }, delayMs)
    }

    override fun release() {
        released = true
        frameListener = null
        handler.post { last?.recycle(); last = null }
        thread.quitSafely()
    }

    companion object {
        private const val TAG = "A11yCapturer"
        private const val SCALE = 0.75f
        private const val SCALE_LOW = 0.55f
        private const val ACTIVE_MS_LOW = 550L
        private const val ACTIVE_MS = 400L   // سنووری سیستەم ≈ ٣٣٣ms
        private const val IDLE_MS = 700L
        private const val RETRY_MS = 380L
    }
}
