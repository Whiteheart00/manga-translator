package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/**
 * گرتنی شاشە بە MediaProjection + ImageReader.
 *
 * هەر ٢٥٠ms فرەیمێک (≈ ٤/چرکە) دەدات بە `frameListener`.
 * ئەو کەسەی فرەیمەکە وەردەگرێت خۆی دەبێت recycle ی بکات.
 */
class ScreenCapturer(
    context: Context,
    private val projection: MediaProjection,
    private val onFirstFrame: () -> Unit,
    private val onProjectionStopped: () -> Unit
) {
    private val appContext = context.applicationContext
    private val thread = HandlerThread("screen-capture").apply { start() }
    private val handler = Handler(thread.looper)

    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var lastFrameTime = 0L
    private var firstFrameNotified = false

    /** لە thread ی گرتنەوە بانگ دەکرێت. */
    @Volatile
    var frameListener: ((Bitmap) -> Unit)? = null

    @Volatile
    var frameCount: Long = 0L
        private set

    val isRunning: Boolean get() = display != null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.d(TAG, "MediaProjection stopped by system/user")
            stop()
            onProjectionStopped()
        }
    }

    init {
        // Android 14 داوا دەکات callback پێش دروستکردنی VirtualDisplay تۆمار بکرێت
        projection.registerCallback(projectionCallback, handler)
    }

    fun start() {
        if (isRunning) return

        val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val width = (metrics.widthPixels * SCALE).toInt().coerceAtLeast(2)
        val height = (metrics.heightPixels * SCALE).toInt().coerceAtLeast(2)
        val dpi = metrics.densityDpi

        firstFrameNotified = false
        frameCount = 0

        val r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ ir -> onImage(ir) }, handler)
        reader = r

        display = projection.createVirtualDisplay(
            "manga-translator-capture",
            width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
        Log.d(TAG, "Capture started ${width}x$height")
    }

    fun stop() {
        display?.release()
        display = null
        reader?.setOnImageAvailableListener(null, null)
        reader?.close()
        reader = null
        Log.d(TAG, "Capture stopped")
    }

    /** لە کاتی داخستنی خزمەتگوزاری بانگ بکرێت. */
    fun release() {
        stop()
        frameListener = null
        try {
            projection.unregisterCallback(projectionCallback)
            projection.stop()
        } catch (_: Exception) {
        }
        thread.quitSafely()
    }

    private fun onImage(ir: ImageReader) {
        val image = try {
            ir.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return

        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrameTime < FRAME_INTERVAL_MS) return
            lastFrameTime = now

            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * image.width

            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            padded.copyPixelsFromBuffer(plane.buffer)
            val frame = if (padded.width == image.width) {
                padded
            } else {
                Bitmap.createBitmap(padded, 0, 0, image.width, image.height).also {
                    padded.recycle()
                }
            }

            frameCount++
            if (!firstFrameNotified) {
                firstFrameNotified = true
                onFirstFrame()
            }

            val listener = frameListener
            if (listener != null) listener(frame) else frame.recycle()
        } catch (e: Exception) {
            Log.e(TAG, "frame error", e)
        } finally {
            image.close()
        }
    }

    companion object {
        private const val TAG = "ScreenCapturer"
        private const val SCALE = 0.75f          // ڕێزولیوشنی گرتن (بۆ OCR باشتر لە ٠.٥)
        private const val FRAME_INTERVAL_MS = 250L // ≈ ٤ فرەیم لە چرکەیەکدا
    }
}
