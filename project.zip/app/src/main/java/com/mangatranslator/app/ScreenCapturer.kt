package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/**
 * گرتنی شاشە بە MediaProjection + ImageReader.
 *
 * VirtualDisplay تەنها یەکجار دروست دەکرێت و تا کۆتایی دەمێنێت (Android 14 ڕێگە نادات دووبارە دروست بکرێت).
 * هەر چەند ms جارێک (خێرا کاتێک frameListener هەیە، هێواش کاتێک نییە) دوایین فرەیم دەدات بە `frameListener`؛
 * ئەگەر شاشە نەگۆڕابێت هەمان فرەیم دووبارە دەدرێت، بۆیە ناوەستێت.
 * ئەو کەسەی فرەیمەکە وەردەگرێت خۆی دەبێت recycle ی بکات (کۆپییەکە دەدرێت).
 */
class ScreenCapturer(
    context: Context,
    private val projection: MediaProjection,
    private val onFirstFrame: () -> Unit,
    private val onProjectionStopped: () -> Unit
) {
    private val appContext = context.applicationContext
    private val thread = HandlerThread("screen-capture").apply { start() }
    private val handler = Handler(thread.looper)

    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var last: Bitmap? = null
    private var firstFrameNotified = false
    @Volatile private var released = false

    /** لە thread ی گرتنەوە بانگ دەکرێت. */
    @Volatile
    var frameListener: ((Bitmap) -> Unit)? = null

    val isRunning: Boolean get() = display != null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.d(TAG, "MediaProjection stopped by system/user")
            stop()
            onProjectionStopped()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (released || reader == null) return
            val b = grab()
            val listener = frameListener
            if (b != null && listener != null) {
                listener(b.copy(Bitmap.Config.ARGB_8888, false))
            }
            handler.postDelayed(this, if (listener != null) ACTIVE_INTERVAL_MS else IDLE_INTERVAL_MS)
        }
    }

    init {
        // Android 14 داوا دەکات callback پێش دروستکردنی VirtualDisplay تۆمار بکرێت
        projection.registerCallback(projectionCallback, handler)
    }

    fun start() {
        if (isRunning) return

        val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val width = (metrics.widthPixels * SCALE).toInt().coerceAtLeast(2)
        val height = (metrics.heightPixels * SCALE).toInt().coerceAtLeast(2)

        firstFrameNotified = false
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection.createVirtualDisplay(
            "manga-translator-capture",
            width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        handler.post(tick)
        Log.d(TAG, "Capture started ${width}x$height")
    }

    private fun stop() {
        handler.removeCallbacks(tick)
        display?.release()
        display = null
        reader?.close()
        reader = null
    }

    /** دوای `delayMs` دوایین فرەیم (کۆپی) دەدات بە `cb` (لە thread ی گرتنەوە؛ cb دەبێت recycle ی بکات). */
    fun requestFrame(delayMs: Long, cb: (Bitmap?) -> Unit) {
        handler.postDelayed({
            val b = if (reader != null) grab() else null
            cb(b?.copy(Bitmap.Config.ARGB_8888, false))
        }, delayMs)
    }

    /** لە کاتی داخستنی خزمەتگوزاری بانگ بکرێت. */
    fun release() {
        released = true
        frameListener = null
        handler.post {
            stop()
            last?.recycle()
            last = null
        }
        try {
            projection.unregisterCallback(projectionCallback)
            projection.stop()
        } catch (_: Exception) {
        }
        thread.quitSafely()
    }

    /** تەنها لە thread ی گرتنەوە. فرەیمی نوێ دەخوێنێتەوە؛ ئەگەر نەبوو دوایین فرەیم دەگەڕێنێتەوە. */
    private fun grab(): Bitmap? {
        val r = reader ?: return last
        val image = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return last

        try {
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * image.width

            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            padded.copyPixelsFromBuffer(plane.buffer)
            val frame = if (padded.width == image.width) {
                padded
            } else {
                Bitmap.createBitmap(padded, 0, 0, image.width, image.height).also { padded.recycle() }
            }
            last?.recycle()
            last = frame

            if (!firstFrameNotified) {
                firstFrameNotified = true
                onFirstFrame()
            }
        } catch (e: Exception) {
            Log.e(TAG, "frame error", e)
        } finally {
            image.close()
        }
        return last
    }

    companion object {
        private const val TAG = "ScreenCapturer"
        private const val SCALE = 0.75f              // ڕێزولیوشنی گرتن
        private const val ACTIVE_INTERVAL_MS = 150L  // کاتێک وەرگێڕانی خۆکار چالاکە
        private const val IDLE_INTERVAL_MS = 700L    // دەنا
    }
}
