package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/**
 * گرتنی شاشە بە MediaProjection + ImageReader.
 *
 * VirtualDisplay تەنها یەکجار دروست دەکرێت و تا کۆتایی دەمێنێت (Android 14 ڕێگە نادات دووبارە دروست بکرێت).
 * هەر چەند ms جارێک (خێرا کاتێک frameListener هەیە، هێواش کاتێک نییە) دوایین فرەیم دەدات بە `frameListener`؛
 * ئەگەر شاشە نەگۆڕابێت هەمان فرەیم دووبارە دەدرێت، بۆیە ناوەستێت.
 * ئەو کەسەی فرەیمەکە وەردەگرێت خۆی دەبێت recycle ی بکات (کۆپییەکە دەدرێت).
 */
class ScreenCapturer(
    context: Context,
    private val projection: MediaProjection,
    private val onFirstFrame: () -> Unit,
    private val onProjectionStopped: () -> Unit
) : FrameSource {
    private val appContext = context.applicationContext
    private val load = CaptureLoad(appContext)
    private val thread = HandlerThread("screen-capture").apply { start() }
    private val handler = Handler(thread.looper)

    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var last: Bitmap? = null
    /** بۆ ڕیزی پڕکراوی ImageReader؛ یەکجار دروست دەکرێت و دووبارە بەکاردێتەوە (نەک هەر فرەیمێک) */
    private var padded: Bitmap? = null
    private var lastNewFrameAt = 0L
    @Volatile private var kickUntil = 0L
    private var lastRepeatAt = 0L
    private var firstFrameNotified = false
    @Volatile private var released = false

    /** لە thread ی گرتنەوە بانگ دەکرێت. */
    @Volatile
    override var frameListener: ((Bitmap) -> Unit)? = null

    /**
     * بێ کۆپی (زۆر خێراتر): `last` خۆی دەدرێت (نەک کۆپییەکی ٦MB)، و boolean = ئایا فرەیمی نوێیە.
     * وەرگر نابێت recycle ی بکات یان بیهێڵێتەوە، و دەبێت زوو تەواو بێت؛ هەمان thread ی گرتنەوەیە.
     */
    @Volatile
    var rawFrameListener: ((Bitmap, Boolean) -> Unit)? = null

    val isRunning: Boolean get() = display != null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.d(TAG, "MediaProjection stopped by system/user")
            stop()
            onProjectionStopped()
        }
    }

    private var curW = 0
    private var curH = 0
    private var sizeCheckAt = 0L

    /**
     * ئەگەر شاشە سوڕایەوە (یوتوب فوڵسکرین ← لاندسکەیپ)، VirtualDisplay ی جێگیر دەمێنێتەوە بە قەبارەی کۆن و ناوەڕۆکی
     * لاندسکەیپ بچووک و لەگەڵ بارە ڕەشەکان لەناو فرەیمی پۆرترەیت دەردەکەوێت (OCR هیچ نابینێت). ئێستا resize() +
     * ImageReader ی نوێ: هەمان VirtualDisplay دەمێنێتەوە (Android 14 ڕێگە نادات دووبارە دروست بکرێت، بەڵام resize ڕێگەپێدراوە).
     */
    private fun checkSize() {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - sizeCheckAt < 400L) return
        sizeCheckAt = now
        val d = display ?: return
        val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        val scale = if (DeviceProfile.low) SCALE_LOW else SCALE
        val w = (m.widthPixels * scale).toInt().coerceAtLeast(2)
        val h = (m.heightPixels * scale).toInt().coerceAtLeast(2)
        if (w == curW && h == curH) return
        try {
            val nr = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            d.resize(w, h, m.densityDpi)
            d.surface = nr.surface
            val old = reader
            reader = nr
            curW = w
            curH = h
            try { old?.close() } catch (_: Exception) { }
            Log.d(TAG, "Capture resized ${w}x$h")
        } catch (e: Throwable) {
            Log.w(TAG, "resize failed: ${e.message}")
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (released || reader == null) return
            checkSize()
            val raw = rawFrameListener
            // Drain the queue without copying full-screen pixels when nobody
            // needs frames, or while the display is off. Keep VirtualDisplay
            // alive because Android 14 does not allow recreating this session.
            if (!load.interactive || (raw == null && frameListener == null && firstFrameNotified)) {
                try { reader?.acquireLatestImage()?.close() } catch (_: Exception) { }
                handler.postDelayed(this, IDLE_INTERVAL_MS)
                return
            }
            if (raw != null) {
                val before = lastNewFrameAt
                val rb = grab()
                if (rb != null) raw(rb, lastNewFrameAt != before)
                handler.postDelayed(this, activeInterval())
                return
            }
            val listener = frameListener
            val prevAt = lastNewFrameAt
            val b = grab()
            if (b != null && listener != null) {
                val now = android.os.SystemClock.elapsedRealtime()
                val isNew = lastNewFrameAt != prevAt
                // فرەیمی نوێ هات، یان تازە گۆڕانکاری بوو (وەک forceRescan) ← دەستبەجێ بنێرە.
                // دەنا شاشە نەگۆڕاوە و کۆپیکردنی ٦MB هەر ١٥٠ms بێ سوودە؛ لە ڕامی کەمدا تەنها هەر ١ چرکە جارێک.
                val fresh = now - lastNewFrameAt < 1200L || now < kickUntil
                val slowOk = now - lastRepeatAt >= (if (DeviceProfile.low) 900L else 0L)
                if (isNew || fresh || slowOk) {
                    lastRepeatAt = now
                    listener(b.copy(Bitmap.Config.ARGB_8888, false))
                }
            }
            handler.postDelayed(this, if (listener != null) activeInterval() else IDLE_INTERVAL_MS)
        }
    }

    private fun activeInterval() = if (DeviceProfile.low) ACTIVE_INTERVAL_LOW_MS else ACTIVE_INTERVAL_MS

    /** لەسەر هەر thread بانگ بکرێت: بۆ ٣ چرکەی داهاتوو فرەیمی دووبارە بدە (بۆ forceRescan) */
    override fun kick() {
        kickUntil = android.os.SystemClock.elapsedRealtime() + 3000L
    }

    init {
        // Android 14 داوا دەکات callback پێش دروستکردنی VirtualDisplay تۆمار بکرێت
        projection.registerCallback(projectionCallback, handler)
    }

    override fun start() {
        if (isRunning) return

        val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val scale = if (DeviceProfile.low) SCALE_LOW else SCALE
        val width = (metrics.widthPixels * scale).toInt().coerceAtLeast(2)
        val height = (metrics.heightPixels * scale).toInt().coerceAtLeast(2)

        firstFrameNotified = false
        curW = width
        curH = height
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection.createVirtualDisplay(
            "manga-translator-capture",
            width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        handler.post(tick)
        Log.d(TAG, "Capture started ${width}x$height")
    }

    private fun stop() {
        handler.removeCallbacks(tick)
        display?.release()
        display = null
        reader?.close()
        reader = null
    }

    /** دوای `delayMs` دوایین فرەیم (کۆپی) دەدات بە `cb` (لە thread ی گرتنەوە؛ cb دەبێت recycle ی بکات). */
    override fun requestFrame(delayMs: Long, cb: (Bitmap?) -> Unit) {
        handler.postDelayed({
            val b = if (reader != null) grab() else null
            cb(b?.copy(Bitmap.Config.ARGB_8888, false))
        }, delayMs)
    }

    /** لە کاتی داخستنی خزمەتگوزاری بانگ بکرێت. */
    override fun release() {
        released = true
        frameListener = null
        rawFrameListener = null
        handler.post {
            stop()
            last?.recycle()
            last = null
            padded?.recycle()
            padded = null
        }
        try {
            projection.unregisterCallback(projectionCallback)
            projection.stop()
        } catch (_: Exception) {
        }
        thread.quitSafely()
    }

    /**
     * تەنها لە thread ی گرتنەوە. فرەیمی نوێ دەخوێنێتەوە؛ ئەگەر نەبوو دوایین فرەیم دەگەڕێنێتەوە.
     * هەمان bitmap (`last`) دووبارە بەکاردێتەوە ئەگەر قەبارە نەگۆڕابێت، بۆ ئەوەی هەر فرەیمێک ١٠-١٢MB زیاتر نەبێتە زبڵ.
     */
    private fun grab(): Bitmap? {
        val r = reader ?: return last
        val image = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return last

        try {
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * image.width
            val w = image.width
            val h = image.height

            var out = last
            if (out == null || out.isRecycled || out.width != w || out.height != h) {
                out?.recycle()
                out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            }
            val o: Bitmap = out
            if (rowPadding == 0) {
                o.copyPixelsFromBuffer(plane.buffer)
            } else {
                val pw = w + rowPadding / pixelStride
                var pad = padded
                if (pad == null || pad.isRecycled || pad.width != pw || pad.height != h) {
                    pad?.recycle()
                    pad = Bitmap.createBitmap(pw, h, Bitmap.Config.ARGB_8888)
                    padded = pad
                }
                pad!!.copyPixelsFromBuffer(plane.buffer)
                Canvas(o).drawBitmap(pad, 0f, 0f, null)
            }
            last = o
            lastNewFrameAt = android.os.SystemClock.elapsedRealtime()

            if (!firstFrameNotified) {
                firstFrameNotified = true
                onFirstFrame()
            }
        } catch (e: Exception) {
            Log.e(TAG, "frame error", e)
        } finally {
            image.close()
        }
        return last
    }

    companion object {
        private const val TAG = "ScreenCapturer"
        private const val SCALE = 0.75f              // ڕێزولیوشنی گرتن
        private const val SCALE_LOW = 0.55f          // ڕامی کەم: ٪٤٦ پیکسێلی کەمتر
        private const val ACTIVE_INTERVAL_LOW_MS = 220L
        private const val ACTIVE_INTERVAL_MS = 150L  // کاتێک وەرگێڕانی خۆکار چالاکە
        private const val IDLE_INTERVAL_MS = 700L    // دەنا
    }
}
