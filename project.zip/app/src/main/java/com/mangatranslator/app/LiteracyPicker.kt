package com.mangatranslator.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * پرسیاری «خوێندەواریت؟» بە دیزاینی ئەپەکە (پاشبنەمای شووشەیی + کارتی شووشەیی).
 * دوو کارتی گەورە بە ژمارە: 1 = خوێندەوار، 2 = نەخوێندەوار. دەنگەکە ژمارەکان دەڵێت و هەر ١٨ چرکە دووبارە دەبێتەوە.
 */
object LiteracyPicker {

    class Handle(val view: View, val speakNow: () -> Unit)

    private const val SPEECH =
        "تۆ خوێندەواریت؟ ئەگەر خوێندەواریت، ژمارە یەک دابگرە. ئەگەر خوێندەوار نیت، ژمارە دوو دابگرە."

    fun show(act: Activity, host: FrameLayout, pal: Palette, onChosen: (Int) -> Unit): Handle {
        val ui = Handler(Looper.getMainLooper())
        val dens = act.resources.displayMetrics.density
        fun dp(v: Int) = (v * dens).toInt()

        val textMain = if (pal.light) Color.parseColor("#0F172A") else Color.WHITE
        val textDim = if (pal.light) Color.parseColor("#64748B") else Color.parseColor("#C5D5EE")
        val cardFill = Color.parseColor(if (pal.light) "#FFFFFF" else "#1AFFFFFF")
        val cardStroke = Color.parseColor(if (pal.light) "#E6EBF5" else "#40FFFFFF")

        val overlay = FrameLayout(act).apply { isClickable = true }
        overlay.addView(GlassBackground(act, pal), FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(22), dp(48), dp(22), dp(40))
        }

        // لۆگۆ
        val logoWrap = FrameLayout(act).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(cardFill)
                setStroke(dp(1), cardStroke)
            }
        }
        logoWrap.addView(ImageView(act).apply {
            setImageResource(R.drawable.app_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(84), dp(84)))
        col.addView(logoWrap, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(18) })

        col.addView(TextView(act).apply {
            text = "تۆ خوێندەواریت؟"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textMain)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        col.addView(TextView(act).apply {
            text = "یەکێکیان دابگرە"
            textSize = 14f
            setTextColor(textDim)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(26) })

        fun choose(n: Int) {
            TranslatorSettings(act).literacy = n
            ui.removeCallbacksAndMessages(null)
            Narrator.stop()
            host.removeView(overlay)
            onChosen(n)
        }

        fun option(n: Int, label: String, from: Int, to: Int): View {
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(14), dp(14), dp(20), dp(14))
                isClickable = true
                background = GradientDrawable().apply {
                    cornerRadius = dp(24).toFloat()
                    setColor(cardFill)
                    setStroke(dp(1), cardStroke)
                }
                setOnClickListener { choose(n) }
                elevation = if (pal.light) 6f * dens else 0f
            }
            row.addView(TextView(act).apply {
                text = n.toString()
                textSize = 34f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(from, to)).apply {
                    shape = GradientDrawable.OVAL
                    setStroke(dp(2), Color.parseColor("#B3FFFFFF"))
                }
            }, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginEnd = dp(16) })
            row.addView(TextView(act).apply {
                text = label
                textSize = 21f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(textMain)
            })
            return row
        }

        col.addView(option(1, "خوێندەوارم", Color.parseColor("#14B87A"), pal.a2),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        col.addView(option(2, "نەخوێندەوارم", Color.parseColor("#FF7A45"), Color.parseColor("#FFD166")),
            LinearLayout.LayoutParams(-1, -2))

        overlay.addView(ScrollView(act).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }, FrameLayout.LayoutParams(-1, -1))
        host.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        val tick = object : Runnable {
            override fun run() {
                if (overlay.parent == null) return
                if (Narrator.isReady(act)) {
                    Narrator.speak(act, SPEECH)
                    ui.postDelayed(this, 18000)
                } else {
                    ui.postDelayed(this, 1500)
                }
            }
        }
        ui.postDelayed(tick, 700)

        return Handle(overlay) { if (Narrator.isReady(act)) Narrator.speak(act, SPEECH) }
    }
}
