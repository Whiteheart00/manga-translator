package com.mangatranslator.app

import android.content.Context

/** ڕێکخستنەکانی وەرگێڕان: ئۆفلاین / Claude / Google */
class TranslatorSettings(ctx: Context) {

    enum class Mode { OFFLINE, CLAUDE, GOOGLE }

    private val p = ctx.getSharedPreferences("translator_settings", Context.MODE_PRIVATE)

    var mode: Mode
        get() = try {
            Mode.valueOf(p.getString("mode", Mode.OFFLINE.name)!!)
        } catch (_: Exception) {
            Mode.OFFLINE
        }
        set(v) = p.edit().putString("mode", v.name).apply()

    var claudeKey: String
        get() = p.getString("claude_key", "") ?: ""
        set(v) = p.edit().putString("claude_key", v.trim()).apply()

    var googleKey: String
        get() = p.getString("google_key", "") ?: ""
        set(v) = p.edit().putString("google_key", v.trim()).apply()

    /** بەکارهێنەر پشتڕاستی دەکاتەوە کە +١٨ ساڵە و مانگای گەورەسالان دەخوێنێتەوە */
    var adultConfirmed: Boolean
        get() = p.getBoolean("adult_confirmed", false)
        set(v) = p.edit().putBoolean("adult_confirmed", v).apply()
}
