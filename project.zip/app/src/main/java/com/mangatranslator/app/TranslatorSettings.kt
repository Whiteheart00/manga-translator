package com.mangatranslator.app

import android.content.Context

/** ڕێکخستنی وەرگێڕان: کلیلی Google (ئارەزوومەندانە؛ بێ کلیلیش کار دەکات) */
class TranslatorSettings(ctx: Context) {

    private val p = ctx.getSharedPreferences("translator_settings", Context.MODE_PRIVATE)

    var googleKey: String
        get() = p.getString("google_key", "") ?: ""
        set(v) = p.edit().putString("google_key", v.trim()).apply()
}
