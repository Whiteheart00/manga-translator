package com.mangatranslator.app

import android.content.Context

/**
 * ڕێکخستنی وەرگێڕان و خوێندنەوەی دەنگ:
 *  - کلیلی Google Cloud Translation بۆ وەرگێڕان
 *  - کلیلی Gemini API بۆ خوێندنەوەی دەقی سۆرانی بە TTS
 */
class TranslatorSettings(ctx: Context) {

    private val p = ctx.getSharedPreferences("translator_settings", Context.MODE_PRIVATE)

    var googleKey: String
        get() = p.getString("google_key", "") ?: ""
        set(v) = p.edit().putString("google_key", v.trim()).apply()

    /** کلیلی Gemini API بۆ خوێندنەوەی سۆرانی؛ جیاوازە لە کلیلی Cloud Translation. */
    var geminiTtsKey: String
        get() = p.getString("gemini_tts_key", "") ?: ""
        set(v) = p.edit().putString("gemini_tts_key", v.trim()).apply()

    /** دەنگەکانی Gemini TTS: Kore, Aoede, Charon, Puck */
    var geminiTtsVoice: String
        get() = p.getString("gemini_tts_voice", DEFAULT_GEMINI_VOICE) ?: DEFAULT_GEMINI_VOICE
        set(v) = p.edit().putString("gemini_tts_voice", v.trim().ifBlank { DEFAULT_GEMINI_VOICE }).apply()

    /** شووشەی ڕەنگاوڕەنگ (true) یان بێ ڕەنگ و ڕوون (false) */
    var coloredGlass: Boolean
        get() = p.getBoolean("colored_glass", true)
        set(v) = p.edit().putBoolean("colored_glass", v).apply()

    /** دوای تەواوبوونی وەرگێڕانی دەستی شاشە، دەقەکە بە دەنگ بخوێنەوە */
    var autoSpeak: Boolean
        get() = p.getBoolean("auto_speak", true)
        set(v) = p.edit().putBoolean("auto_speak", v).apply()

    /** دۆخی خێرا بۆ دۆخی نوێ: مۆدێلی سووکتر (خێراتر، کەمێک کەمتر وردی). */
    var fast: Boolean
        get() = p.getBoolean("fast", true)
        set(v) = p.edit().putBoolean("fast", v).apply()

    /** خوێندنەوەی ئۆفلاین (بێ ئینتەرنێت): کوردی دەکرێت بە دەقی نزیک لە دەنگ + دەنگی ئۆفلاینی ناو مۆبایل (ئینگلیزی/عەرەبی/تورکی) */
    var offlineTts: Boolean
        get() = p.getBoolean("offline_tts", true)
        set(v) = p.edit().putBoolean("offline_tts", v).apply()

    /** خوێندنەوە بە tts.pawan.krd (WebView + cookie)؛ پێش Gemini و ئۆفلاین بەکار دێت */
    var pawanTts: Boolean
        get() = p.getBoolean("pawan_tts", false)
        set(v) = p.edit().putBoolean("pawan_tts", v).apply()

    /** کوردیی لاتینی (aw mawzw3a...) بگۆڕە بۆ پیتی کوردی پێش خوێندنەوە بە Pawan؛ بە Gemini ئەگەر کلیل هەبوو */
    var latinKurdish: Boolean
        get() = p.getBoolean("latin_kurdish", true)
        set(v) = p.edit().putBoolean("latin_kurdish", v).apply()

    /** دەنگی Pawan: "female" یان "male" (وەک ماڵپەڕەکە) */
    var pawanVoice: String
        get() = if (p.getString("pawan_voice", "female") == "male") "male" else "female"
        set(v) = p.edit().putString("pawan_voice", if (v == "male") "male" else "female").apply()

    /** ڕێکخستنی دەنگی Pawan: ئاستی دەنگ ٣٠..١٠٠٪ */
    var pawanGain: Int
        get() = p.getInt("pawan_gain", 100).coerceIn(30, 100)
        set(v) = p.edit().putInt("pawan_gain", v.coerceIn(30, 100)).apply()

    /** تۆن/خێرایی ٨٠..١٢٠٪ (کەمتر = قوڵتر و هێواشتر) */
    var pawanRate: Int
        get() = p.getInt("pawan_rate", 100).coerceIn(80, 120)
        set(v) = p.edit().putInt("pawan_rate", v.coerceIn(80, 120)).apply()

    /** نەرمکردن ٠..١٠٠٪ (دەنگی تیژ/«گڕ» کەم دەکاتەوە) */
    var pawanSoft: Int
        get() = p.getInt("pawan_soft", 0).coerceIn(0, 100)
        set(v) = p.edit().putInt("pawan_soft", v.coerceIn(0, 100)).apply()

    /** زمانی Pawan: ckb، badini، kmr، ar، ar_iq، en (وەک ماڵپەڕەکە) */
    var pawanLang: String
        get() = (p.getString("pawan_lang", "ckb") ?: "ckb").takeIf { it in PAWAN_LANGS } ?: "ckb"
        set(v) = p.edit().putString("pawan_lang", if (v in PAWAN_LANGS) v else "ckb").apply()

    /** دەنگی ئۆفلاین: 0 = ئینگلیزی، 1 = عەرەبی، 2 = تورکی (کۆن)، 3 = فارسیی سیستەم (زۆرجار نییە)، 4 = Piper نیورالی (بنەڕەت؛ پێویستی بە دەنگی سیستەم نییە) */
    var offlineVoice: Int
        get() = p.getInt("offline_voice", 4).coerceIn(0, 4)
        set(v) = p.edit().putInt("offline_voice", v).apply()

    /** دۆخی ئەپ: 0 = کۆن (ک / وەر / دەنگ)، 1 = نوێ (ڕووبەر + قسەکردن بۆ نووسین) */
    var mode: Int
        get() = p.getInt("app_mode", 0).coerceIn(0, 1)
        set(v) = p.edit().putInt("app_mode", v).apply()

    /** ڕەنگی ئەپ: ئیندێکسی Palettes.all */
    var theme: Int
        get() = p.getInt("app_theme", 8).coerceIn(0, Palettes.all.lastIndex)
        set(v) = p.edit().putInt("app_theme", v).apply()

    /** ناسینەوەی خێرای کوردی لەسەر مۆبایل: ئەگەر دەقەکە کوردی بوو بێ Gemini یەکسەر دەیخوێنێتەوە */
    var localKurdish: Boolean
        get() = p.getBoolean("local_kurdish", true)
        set(v) = p.edit().putBoolean("local_kurdish", v).apply()

    /** خێرایی دەنگ وەک YouTube: 0.5x ... 2x */
    var speechSpeed: Float
        get() = p.getFloat("speech_speed", 1f).coerceIn(0.5f, 2f)
        set(v) = p.edit().putFloat("speech_speed", v.coerceIn(0.5f, 2f)).apply()

    /** وەرگێڕانی سەر شاشە دوای تەواوبوونی خوێندنەوە خۆکارانە بشارێتەوە */
    var autoHideOverlay: Boolean
        get() = p.getBoolean("auto_hide_overlay", true)
        set(v) = p.edit().putBoolean("auto_hide_overlay", v).apply()

    /** قسە ← نووسین بە مۆدێلی ئۆفلاینی Vekol (ئەگەر دابەزێندرابێت)؛ ئەگەرنا Gemini. */
    var offlineStt: Boolean
        get() = p.getBoolean("offline_stt", false)
        set(v) = p.edit().putBoolean("offline_stt", v).apply()

    /** فێربوون: کاتێک بەکارهێنەر «چاک بکە» دادەگرێت، وشە چاککراوەکان پاشەکەوت دەکرێن و دوای دووجار خۆکارانە جێبەجێ دەکرێن. بنەڕەت: کوژاوە. */
    var learnFix: Boolean
        get() = p.getBoolean("learn_fix", false)
        set(v) = p.edit().putBoolean("learn_fix", v).apply()

    /** ناوەکانی بەکارهێنەر (کەس، شوێن...) کە دەبێت دەنگەکە بۆیان ڕێک بخرێت. هەر ناوێک لە دێڕێک یان بە کۆما جیا دەکرێتەوە. */
    var myNames: String
        get() = p.getString("my_names", "") ?: ""
        set(v) = p.edit().putString("my_names", v).apply()

    /** ناوەکانی بەکارهێنەر + ناوە جێگیرکراوە شاراوەکانی بەشی فێربوون (بۆ ڕێکخستنی دەنگ). */
    val myNameList: List<String>
        get() = (myNames.split(Regex("[\\n,،;؛]")).map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(50) +
            KurdishBuiltinNames.LIST).distinct()

    /** وەرگێڕانەکە تەنها کاتێک نوێ دەبێتەوە کە ئەم ڕێژەیەی شاشە گۆڕابێت: ١٠٪ تا ٩٠٪ (بنەڕەت ٥٠٪) */
    var changePercent: Int
        get() = p.getInt("change_percent", 50).coerceIn(10, 90)
        set(v) = p.edit().putInt("change_percent", v.coerceIn(10, 90)).apply()

    /** دوای چەند چرکە بابلەکان بچنە لێواری شاشە: ٥ چرکە تا ٥ خولەک (٣٠٠ چرکە) */
    var dockDelaySec: Int
        get() = p.getInt("dock_delay_sec", 10).coerceIn(5, 300)
        set(v) = p.edit().putInt("dock_delay_sec", v.coerceIn(5, 300)).apply()

    /** دوگمەکانی پانێلی floating کە بەکارهێنەر شاردوویەتی (کلیلەکان: auto, translate, speak, region, mic) */
    var hiddenItems: Set<String>
        get() = (p.getString("hidden_items", "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        set(v) = p.edit().putString("hidden_items", v.joinToString(",")).apply()

    fun isItemHidden(key: String): Boolean = key in hiddenItems

    fun setItemHidden(key: String, hidden: Boolean) {
        hiddenItems = if (hidden) hiddenItems + key else hiddenItems - key
    }

    /** دوای چەند خولەک بێکاری مۆدێلە ئۆفلاینەکان لە ڕام دەربهێنرێن: 0 = هەرگیز (خێراترە، بەڵام ڕامی زیاتر) */
    var modelIdleMin: Int
        get() = p.getInt("model_idle_min", 2).let { if (it in IDLE_STEPS) it else 2 }
        set(v) = p.edit().putInt("model_idle_min", v).apply()

    /** خوێندەواری: 0 = هێشتا نەپرسراوە، 1 = خوێندەوار، 2 = نەخوێندەوار (ئەپەکە هەموو شتێک بە دەنگ دەخوێنێتەوە) */
    var literacy: Int
        get() = p.getInt("literacy", 0).coerceIn(0, 2)
        set(v) = p.edit().putInt("literacy", v).apply()

    /** ڕێنماییی یەکەمجار (coach marks) تەواو بووە */
    var tourDone: Boolean
        get() = p.getBoolean("tour_done", false)
        set(v) = p.edit().putBoolean("tour_done", v).apply()

    /** زمانی دەقی سەر شاشە: auto / en / ar / ja / zh / ko */
    var sourceLang: String
        get() = (p.getString("source_lang", "auto") ?: "auto").let { if (it in SourceLangs.codes) it else "auto" }
        set(v) = p.edit().putString("source_lang", v).apply()

    /** کاتێک Accessibility چالاکە، پانێلی بابلەکان خۆکارانە دەرکەوێت (بێ دەستپێکردن)؛ شاشە تەنها لە کاتی بەکارهێنانی فەرمانێک دەگیرێت */
    var a11yAutoStart: Boolean
        get() = p.getBoolean("a11y_autostart", true)
        set(v) = p.edit().putBoolean("a11y_autostart", v).apply()

    /** ڕەنگی باگراوند، ڕەنگی دەق، و ڕوونیی (٣٠..٢٥٥) بۆکسە وەرگێڕدراوەکانی سەر شاشە */
    var overlayBg: Int
        get() = p.getInt("overlay_bg", 0xFF000000.toInt())
        set(v) = p.edit().putInt("overlay_bg", v or 0xFF000000.toInt()).apply()
    /** ڕەنگی باگراوندی بابلە ڕەسەنەکە بخوێنرێتەوە و وەرگێڕانەکە بەو ڕەنگە بنووسرێت (وەک Google) */
    var overlayAuto: Boolean
        get() = p.getBoolean("overlay_auto", true)
        set(v) = p.edit().putBoolean("overlay_auto", v).apply()
    var overlayFg: Int
        get() = p.getInt("overlay_fg", 0xFFFFFFFF.toInt())
        set(v) = p.edit().putInt("overlay_fg", v or 0xFF000000.toInt()).apply()
    var overlayBgAlpha: Int
        get() = p.getInt("overlay_bg_alpha", 255).coerceIn(30, 255)
        set(v) = p.edit().putInt("overlay_bg_alpha", v.coerceIn(30, 255)).apply()

    /** باگراوندی نووسینەکانی تەنیشت دوگمەکان: 0 = گرادیێنتی Gemini، 1 = ڕەنگی هەمان ئایکۆن، 2 = ڕەنگی دیاریکراو */
    var labelMode: Int
        get() = p.getInt("label_mode", 0).coerceIn(0, 2)
        set(v) = p.edit().putInt("label_mode", v.coerceIn(0, 2)).apply()
    var labelColor: Int
        get() = p.getInt("label_color", 0xFF4285F4.toInt())
        set(v) = p.edit().putInt("label_color", v or 0xFF000000.toInt()).apply()

    /** ڕەنگی هێمای بابلەکان کە بەکارهێنەر هەڵیبژاردووە؛ 0 = ڕەنگی بنەڕەت */
    fun iconColor(kind: Int): Int = p.getInt("icon_color_$kind", 0)

    /** color = 0 واتە گەڕانەوە بۆ ڕەنگی بنەڕەت */
    fun setIconColor(kind: Int, color: Int) {
        if (color == 0) p.edit().remove("icon_color_$kind").apply()
        else p.edit().putInt("icon_color_$kind", color or 0xFF000000.toInt()).apply()
    }

    companion object {
        val DOCK_STEPS = listOf(5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240, 300)
        /** دوگمەکانی پانێل: کلیل ← ناو (بەو ڕیزبەندییەی لە پانێلەکەدا دەردەکەون) */
        val PANEL_ITEMS = listOf(
            "auto" to "وەرگێڕانی خۆکار",
            "translate" to "وەرگێڕانی شاشە",
            "speak" to "خوێندنەوە بە دەنگ",
            "region" to "دیاریکردنی ڕووبەر",
            "mic" to "قسەکردن بۆ نووسین"
        )
        val IDLE_STEPS = listOf(2, 5, 10, 0)
        val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
        const val DEFAULT_GEMINI_VOICE = "Kore"
    }
}

/** کۆدی زمانەکانی tts.pawan.krd بە ڕیزی پیشاندان */
val PAWAN_LANGS = listOf("ckb", "badini", "kmr", "ar", "ar_iq", "en")
