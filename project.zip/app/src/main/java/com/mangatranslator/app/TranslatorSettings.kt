package com.mangatranslator.app

import android.content.Context

/**
 * ڕێکخستنی وەرگێڕان و دەنگ:
 *  - کلیلی Google (ئارەزوومەندانە؛ بێ کلیلیش کار دەکات)
 *  - کلیلی Azure Speech بۆ خوێندنەوەی دەنگی سۆرانی
 */
class TranslatorSettings(ctx: Context) {

    private val p = ctx.getSharedPreferences("translator_settings", Context.MODE_PRIVATE)

    var googleKey: String
        get() = p.getString("google_key", "") ?: ""
        set(v) = p.edit().putString("google_key", v.trim()).apply()

    /** کلیلی Azure Speech (بۆ دەنگی سۆرانی) */
    var azureKey: String
        get() = p.getString("azure_key", "") ?: ""
        set(v) = p.edit().putString("azure_key", v.trim()).apply()

    /** ناوچەی سەرچاوەی Azure، بۆ نموونە westeurope */
    var azureRegion: String
        get() = p.getString("azure_region", DEFAULT_REGION) ?: DEFAULT_REGION
        set(v) = p.edit().putString("azure_region", v.trim().ifBlank { DEFAULT_REGION }).apply()

    /** ناوی دەنگ، بۆ نموونە ckb-IQ-ParwinNeural یان ckb-IQ-AhmedNeural */
    var voice: String
        get() = p.getString("voice", DEFAULT_VOICE) ?: DEFAULT_VOICE
        set(v) = p.edit().putString("voice", v.trim().ifBlank { DEFAULT_VOICE }).apply()

    /** خێرایی دەنگ بە سەدی: لە -50 تا +50 */
    var speedPct: Int
        get() = p.getInt("speed_pct", 0)
        set(v) = p.edit().putInt("speed_pct", v.coerceIn(-50, 50)).apply()

    companion object {
        const val DEFAULT_REGION = "westeurope"
        const val DEFAULT_VOICE = "ckb-IQ-ParwinNeural"
    }
}
