package com.mangatranslator.app

import android.content.Context

/**
 * ڕێکخستنی وەرگێڕان و خوێندنەوەی دەنگ:
 *  - کلیلی Google Cloud Translation بۆ وەرگێڕان
 *  - کلیلی Gemini API بۆ خوێندنەوەی دەقی سۆرانی بە TTS
 */
class TranslatorSettings(ctx: Context) {

    private val p = ctx.getSharedPreferences("translator_settings", Context.MODE_PRIVATE)

    var googleKey: String
        get() = p.getString("google_key", "") ?: ""
        set(v) = p.edit().putString("google_key", v.trim()).apply()

    /** کلیلی Gemini API بۆ خوێندنەوەی سۆرانی؛ جیاوازە لە کلیلی Cloud Translation. */
    var geminiTtsKey: String
        get() = p.getString("gemini_tts_key", "") ?: ""
        set(v) = p.edit().putString("gemini_tts_key", v.trim()).apply()

    /** دەنگەکانی Gemini TTS: Kore, Aoede, Charon, Puck */
    var geminiTtsVoice: String
        get() = p.getString("gemini_tts_voice", DEFAULT_GEMINI_VOICE) ?: DEFAULT_GEMINI_VOICE
        set(v) = p.edit().putString("gemini_tts_voice", v.trim().ifBlank { DEFAULT_GEMINI_VOICE }).apply()

    /** دوای تەواوبوونی وەرگێڕانی دەستی شاشە، دەقەکە بە دەنگ بخوێنەوە */
    var autoSpeak: Boolean
        get() = p.getBoolean("auto_speak", false)
        set(v) = p.edit().putBoolean("auto_speak", v).apply()

    companion object {
        const val DEFAULT_GEMINI_VOICE = "Kore"
    }
}
