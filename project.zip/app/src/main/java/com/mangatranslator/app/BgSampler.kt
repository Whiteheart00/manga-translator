package com.mangatranslator.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect

/** ڕەنگی باگراوندی دەورووبەری دەقێک لە وێنەکەدا دەخوێنێتەوە (ڕەنگی زاڵ)، بۆ ئەوەی وەرگێڕانەکە وەک Google بەسەر بابلەکەدا بنووسرێت. */
object BgSampler {

    /** ARGB ی ڕەنگی زاڵ، یان 0 ئەگەر نەتوانرا. */
    fun sample(bmp: Bitmap, r: Rect): Int {
        return try {
            if (bmp.isRecycled) return 0
            val m = 3
            val l = (r.left - m).coerceIn(0, bmp.width - 1)
            val t = (r.top - m).coerceIn(0, bmp.height - 1)
            val rr = (r.right + m).coerceIn(0, bmp.width - 1)
            val b = (r.bottom + m).coerceIn(0, bmp.height - 1)
            if (rr <= l || b <= t) return 0
            val counts = HashMap<Int, IntArray>()  // bucket -> [n, sumR, sumG, sumB]
            fun add(x: Int, y: Int) {
                val c = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
                val k = ((Color.red(c) shr 4) shl 8) or ((Color.green(c) shr 4) shl 4) or (Color.blue(c) shr 4)
                val a = counts.getOrPut(k) { IntArray(4) }
                a[0]++; a[1] += Color.red(c); a[2] += Color.green(c); a[3] += Color.blue(c)
            }
            val steps = 24
            for (i in 0..steps) {
                val x = l + (rr - l) * i / steps
                val y = t + (b - t) * i / steps
                add(x, t); add(x, b); add(l, y); add(rr, y)
            }
            val best = counts.values.maxByOrNull { it[0] } ?: return 0
            Color.rgb(best[1] / best[0], best[2] / best[0], best[3] / best[0])
        } catch (_: Throwable) {
            0
        }
    }
}
