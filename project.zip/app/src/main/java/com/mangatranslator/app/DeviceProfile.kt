package com.mangatranslator.app

import android.app.ActivityManager
import android.content.Context

/**
 * دۆزینەوەی مۆبایلی ڕامی کەم (٤ یان ٦ گیگ و خاو).
 * هەموو بەشەکانی تر `DeviceProfile.low` دەپرسن و لەسەر ئەو بنەمایە سووکتر کار دەکەن.
 * تەنها یەکجار لە OverlayService/MainActivity بە `init(ctx)` ئامادە دەکرێت.
 */
object DeviceProfile {
    @Volatile private var cached: Boolean? = null

    /** true = مۆبایلی ڕامی کەم؛ ئەگەر init نەکرابێت false */
    val low: Boolean get() = cached ?: false

    fun init(ctx: Context) {
        if (cached != null) return
        refresh(ctx)
    }

    /** دوای گۆڕینی ڕێکخستنەکە دووبارە بانگ بکرێت */
    fun refresh(ctx: Context) {
        val app = ctx.applicationContext
        cached = when (TranslatorSettings(app).lowRamMode) {
            1 -> true
            2 -> false
            else -> detect(app)
        }
    }

    private fun detect(ctx: Context): Boolean = try {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        // مۆبایلی ٦ گیگ نزیکەی ٥.٥ گیگ نیشان دەدات، ٨ گیگ نزیکەی ٧.٤؛ سنوور = ٦.٨ گیگ
        am.isLowRamDevice || mi.totalMem <= 6_800_000_000L
    } catch (_: Throwable) {
        false
    }
}
