package com.mangatranslator.app

import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** هەڵەی API ی Gemini لەگەڵ کۆدی HTTP، بۆ ئەوەی بزانین کلیلێک پشوو بدرێت یان نا. */
class ApiException(val code: Int, msg: String) : IOException(msg)

/**
 * چەند کلیلی Gemini (هەر یەکێک لە دێڕێک): بە نۆرە بەکاردێن و ئەگەر یەکێک تەواو بوو (429) یان هەڵە بوو،
 * کلیلی دواتر بەکاردێت.
 */
object GeminiKeys {
    private val sep = Regex("[\\s,;]+")
    private val cool = ConcurrentHashMap<String, Long>()
    private var rr = 0

    fun parse(raw: String): List<String> = raw.split(sep).filter { it.length > 10 }.distinct()

    @Synchronized
    fun next(raw: String): String {
        val ks = parse(raw)
        if (ks.isEmpty()) return ""
        val now = System.currentTimeMillis()
        for (i in ks.indices) {
            val k = ks[(rr + i) % ks.size]
            if ((cool[k] ?: 0L) <= now) {
                rr = (rr + i + 1) % ks.size
                return k
            }
        }
        val k = ks.minByOrNull { cool[it] ?: 0L }!!
        rr = (ks.indexOf(k) + 1) % ks.size
        return k
    }

    fun rest(key: String, code: Int) {
        val ms = when {
            code == 429 -> 30_000L
            code == 400 -> 2 * 60_000L
            code == 401 || code == 403 -> 10 * 60_000L
            code >= 500 -> 5_000L
            else -> return
        }
        cool[key] = System.currentTimeMillis() + ms
    }

    /** `block` بە هەر کلیلێک تاقی دەکاتەوە تا یەکێکیان سەرکەوت. */
    fun <T> withKeys(raw: String, block: (String) -> T): T {
        val n = maxOf(1, parse(raw).size)
        var last: Exception? = null
        repeat(n) {
            val k = next(raw)
            try {
                return block(k)
            } catch (e: ApiException) {
                rest(k, e.code)
                last = e
            }
        }
        throw last ?: IOException("no key")
    }
}

/**
 * مۆدێلی Gemini ی بینین/دەنگ/دەق. ئەگەر مۆدێلێک نەمابوو (404)، خۆکارانە مۆدێلی دواتر تاقی دەکرێتەوە،
 * و مۆدێلی کارا بیر دەکرێتەوە. ئەگەر پارامەتری بیرکردنەوە (thinking) قبوڵ نەکرا (400)، بێ ئەو تاقی دەکرێتەوە.
 */
object GeminiModels {
    private val QUALITY = listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash")
    private val FAST = listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-3.6-flash", "gemini-2.5-flash-lite", "gemini-2.5-flash")

    @Volatile
    private var okQuality: String? = null
    @Volatile
    private var okFast: String? = null

    private const val PREFS = "gemini_models"
    @Volatile
    private var prefs: android.content.SharedPreferences? = null

    /**
     * مۆدێلە سەرکەوتووەکان لە SharedPreferences دەپارێزێت، بۆ ئەوەی دوای داخستنی ئەپ یەکەمجار
     * مۆدێلە هەڵەکان (404/429) دووبارە تاقی نەکرێنەوە. دەتوانرێت چەند جارێک بانگ بکرێت.
     */
    @Synchronized
    fun init(ctx: android.content.Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        prefs = p
        // تەنها ئەگەر هێشتا لە لیستەکەدا بێت (مۆدێلێکی لابراو بەکارنایەت)
        if (okQuality == null) okQuality = p.getString("ok_quality", null)?.takeIf { it in QUALITY }
        if (okFast == null) okFast = p.getString("ok_fast", null)?.takeIf { it in FAST }
    }

    private fun remember(fast: Boolean, model: String) {
        val old = if (fast) okFast else okQuality
        if (fast) okFast = model else okQuality = model
        // تەنها کاتێک دەنووسرێت کە مۆدێلەکە گۆڕابێت، نەک لە هەر داواکارییەک
        if (old != model) prefs?.edit()?.putString(if (fast) "ok_fast" else "ok_quality", model)?.apply()
    }

    /** بۆ خێرایی: بیرکردنەوە بە کەمترین ئاستی ببە. */
    fun thinking(model: String): org.json.JSONObject =
        if (model.startsWith("gemini-2.5")) org.json.JSONObject().put("thinkingBudget", 0)
        else org.json.JSONObject().put("thinkingLevel", "minimal")

    fun <T> call(fast: Boolean = false, post: (model: String, think: Boolean) -> T): T {
        val order = (listOfNotNull(if (fast) okFast else okQuality) + (if (fast) FAST else QUALITY)).distinct()
        var last: ApiException? = null
        for (m in order) {
            for (think in listOf(true, false)) {
                try {
                    val r = post(m, think)
                    remember(fast, m)
                    return r
                } catch (e: ApiException) {
                    last = e
                    if (e.code == 404) break               // مۆدێلەکە نییە ← مۆدێلی دواتر
                    if (e.code == 400 && think) continue   // لەوانەیە thinking قبوڵ نەکرابێت
                    // quota (429) یان قەرەباڵغی/هەڵەی سێرڤەر: مۆدێلی دواتر quota ی جیاوازی هەیە
                    if (e.code == 429 || e.code == 500 || e.code == 503 || e.code == 504) break
                    throw e
                }
            }
        }
        throw last ?: IOException("هیچ مۆدێلێکی Gemini کار ناکات")
    }
}
