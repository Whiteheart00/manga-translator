package com.mangatranslator.app

import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** هەڵەی API ی Gemini لەگەڵ کۆدی HTTP، بۆ ئەوەی بزانین کلیلێک پشوو بدرێت یان نا. */
class ApiException(val code: Int, msg: String) : IOException(msg)

/**
 * چەند کلیلی Gemini (هەر یەکێک لە دێڕێک): بە نۆرە بەکاردێن و ئەگەر یەکێک تەواو بوو (429) یان هەڵە بوو،
 * کلیلی دواتر بەکاردێت.
 */
object GeminiKeys {
    private val sep = Regex("[\\s,;]+")
    private val cool = ConcurrentHashMap<String, Long>()
    private var rr = 0

    fun parse(raw: String): List<String> = raw.split(sep).filter { it.length > 10 }.distinct()

    @Synchronized
    fun next(raw: String): String {
        val ks = parse(raw)
        if (ks.isEmpty()) return ""
        val now = System.currentTimeMillis()
        for (i in ks.indices) {
            val k = ks[(rr + i) % ks.size]
            if ((cool[k] ?: 0L) <= now) {
                rr = (rr + i + 1) % ks.size
                return k
            }
        }
        val k = ks.minByOrNull { cool[it] ?: 0L }!!
        rr = (ks.indexOf(k) + 1) % ks.size
        return k
    }

    fun rest(key: String, code: Int) {
        val ms = when {
            code == 429 -> 30_000L
            code == 400 -> 2 * 60_000L
            code == 401 || code == 403 -> 10 * 60_000L
            code >= 500 -> 5_000L
            else -> return
        }
        cool[key] = System.currentTimeMillis() + ms
    }

    /** `block` بە هەر کلیلێک تاقی دەکاتەوە تا یەکێکیان سەرکەوت. */
    fun <T> withKeys(raw: String, block: (String) -> T): T {
        val n = maxOf(1, parse(raw).size)
        var last: Exception? = null
        repeat(n) {
            val k = next(raw)
            try {
                return block(k)
            } catch (e: ApiException) {
                rest(k, e.code)
                last = e
            }
        }
        throw last ?: IOException("no key")
    }
}

/**
 * مۆدێلی Gemini ی بینین/دەنگ/دەق. ئەگەر مۆدێلێک نەمابوو (404)، خۆکارانە مۆدێلی دواتر تاقی دەکرێتەوە،
 * و مۆدێلی کارا بیر دەکرێتەوە. ئەگەر پارامەتری بیرکردنەوە (thinking) قبوڵ نەکرا (400)، بێ ئەو تاقی دەکرێتەوە.
 */
object GeminiModels {
    private val LIST = listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash")

    @Volatile
    private var ok: String? = null

    /** بۆ خێرایی: بیرکردنەوە بە کەمترین ئاستی ببە. */
    fun thinking(model: String): org.json.JSONObject =
        if (model.startsWith("gemini-2.5")) org.json.JSONObject().put("thinkingBudget", 0)
        else org.json.JSONObject().put("thinkingLevel", "minimal")

    fun <T> call(post: (model: String, think: Boolean) -> T): T {
        val order = (listOfNotNull(ok) + LIST).distinct()
        var last: ApiException? = null
        for (m in order) {
            for (think in listOf(true, false)) {
                try {
                    val r = post(m, think)
                    ok = m
                    return r
                } catch (e: ApiException) {
                    last = e
                    if (e.code == 404) break               // مۆدێلەکە نییە ← مۆدێلی دواتر
                    if (e.code == 400 && think) continue   // لەوانەیە thinking قبوڵ نەکرابێت
                    throw e
                }
            }
        }
        throw last ?: IOException("هیچ مۆدێلێکی Gemini کار ناکات")
    }
}
