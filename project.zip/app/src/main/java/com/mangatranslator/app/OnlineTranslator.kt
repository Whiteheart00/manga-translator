package com.mangatranslator.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * وەرگێڕانی ئۆنلاین ئینگلیزی → سۆرانی بە Claude یان Google Cloud Translation.
 * هەموو بانگەکان دەبێت لە thread ی پاشبنەما بن.
 */
object OnlineTranslator {

    private const val TAG = "OnlineTranslator"
    private const val CLAUDE_MODEL = "claude-haiku-4-5-20251001"

    /** هەڵەی تایبەت: مۆدێل وەرگێڕانی ڕەتکردەوە (refusal) */
    class RefusedException : Exception("model refused")

    private fun systemPrompt(adult: Boolean): String {
        val base = "You translate manga speech-bubble text from English into Central Kurdish (Sorani, Arabic script). " +
            "Keep the tone, slang and emotion of the speaker, keep it short enough to fit a speech bubble, " +
            "use Kurdish letters (ی ک ە ێ ۆ ڕ ڵ) not Arabic variants. " +
            "Reply with ONLY the Kurdish translation, no notes, no quotes, no explanations."
        return if (adult)
            base + " The reader is a confirmed adult (18+) reading a lawfully obtained mature manga; " +
                "translate its dialogue faithfully, including crude or sexual wording that appears in the source text."
        else base
    }

    fun claude(text: String, key: String, adult: Boolean): String {
        val body = JSONObject().apply {
            put("model", CLAUDE_MODEL)
            put("max_tokens", 400)
            put("system", systemPrompt(adult))
            put("messages", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("content", text)
            }))
        }
        val res = post(
            "https://api.anthropic.com/v1/messages",
            body.toString(),
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")
        )
        val json = JSONObject(res)
        if (json.optString("stop_reason") == "refusal") throw RefusedException()
        val content = json.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val c = content.getJSONObject(i)
            if (c.optString("type") == "text") sb.append(c.optString("text"))
        }
        val out = sb.toString().trim()
        // ئەگەر وەڵامەکە هیچ پیتی عەرەبی/کوردی تێدا نەبوو، واتە وەرگێڕان نەبووە (ڕەتکردنەوە یان ڕوونکردنەوە)
        if (out.none { it in '\u0600'..'\u06FF' }) throw RefusedException()
        return out
    }

    fun google(text: String, key: String): String {
        val body = JSONObject().apply {
            put("q", text)
            put("source", "en")
            put("target", "ckb")
            put("format", "text")
        }
        val res = post(
            "https://translation.googleapis.com/language/translate/v2?key=" +
                java.net.URLEncoder.encode(key, "UTF-8"),
            body.toString(),
            emptyMap()
        )
        return JSONObject(res)
            .getJSONObject("data")
            .getJSONArray("translations")
            .getJSONObject(0)
            .getString("translatedText")
            .trim()
    }

    private fun post(url: String, body: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 30_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                Log.e(TAG, "HTTP $code: ${text.take(300)}")
                throw java.io.IOException("HTTP $code")
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
