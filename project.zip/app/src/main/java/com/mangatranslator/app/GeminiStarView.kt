package com.mangatranslator.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/**
 * ئەستێرەی چوار-پەڕیی ستایلی Gemini (شین ← مۆر ← پەمەیی) بە درەوشانەوەی نەرم، لێدانی هێواش و ئەستێرەیەکی بچووکی لەرزۆک.
 * کاتێک پانێلەکە کەم دەکرێتەوە ئەمە دەمێنێتەوە. تەنها لە کاتی دیاربووندا ئەنیمەیت دەکات.
 */
class GeminiStarView(ctx: Context) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimDark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        color = 0x4D000000
    }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        color = 0xF2FFFFFF.toInt()
    }
    private val sparkle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val spec = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val small = Path()
    private var phase = 0f

    /** کاتێک وەرگێڕانی خۆکار کارایە: ئەستێرەکە مۆر دەبێت + درەوشانەوەی مۆر + نیشانەی ✓ */
    var auto: Boolean = false
        set(v) { if (field != v) { field = v; invalidate() } }
    private val badge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val badgeRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFFFFFFF.toInt() }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0xFFFFFFFF.toInt()
    }
    private val tickPath = Path()

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 5200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    private fun updateAnim() {
        if (isAttachedToWindow && isShown) { if (!anim.isStarted) anim.start() } else anim.cancel()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); updateAnim() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changed: View, visibility: Int) { super.onVisibilityChanged(changed, visibility); updateAnim() }
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(visibility); updateAnim() }

    private fun star(p: Path, cx: Float, cy: Float, r: Float) {
        p.reset()
        p.moveTo(cx, cy - r)
        p.quadTo(cx, cy, cx + r, cy)
        p.quadTo(cx, cy, cx, cy + r)
        p.quadTo(cx, cy, cx - r, cy)
        p.quadTo(cx, cy, cx, cy - r)
        p.close()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val pulse = 0.5f + 0.5f * sin(phase * 6.2832f)

        // درەوشانەوەی سپیی نەرم
        val hr = minOf(w, h) / 2f
        halo.shader = if (auto)
            RadialGradient(cx, cy, hr, intArrayOf(0xB39B6BFF.toInt(), 0x558B5CF6, 0), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        else
            if (GlassStyle.colored)
                RadialGradient(cx, cy, hr, intArrayOf(0x609B72CB, 0x224285F4, 0), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
            else
                RadialGradient(cx, cy, hr, intArrayOf(0x40FFFFFF, 0x14FFFFFF, 0), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        halo.alpha = (150 + 90 * pulse).toInt()
        c.drawCircle(cx, cy, hr, halo)

        // ئەستێرەی شووشەیی تەواو ڕوون (هێواش دەسوڕێت + دەلێدرێت)
        val r = minOf(w, h) * (0.36f + 0.03f * pulse)
        body.shader = if (auto)
            LinearGradient(cx - r, cy - r, cx + r, cy + r,
                intArrayOf(0xFFC9A8FF.toInt(), 0xFF8B5CF6.toInt(), 0xFF6D3FD6.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        else if (GlassStyle.colored)
            LinearGradient(cx - r, cy - r, cx + r, cy + r,
                intArrayOf(0x884285F4.toInt(), 0x669B72CB, 0x80D96570.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        else
            LinearGradient(cx - r, cy - r, cx + r, cy + r,
                intArrayOf(0x73FFFFFF, 0x14FFFFFF, 0x45FFFFFF), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        star(path, cx, cy, r)
        c.save()
        c.rotate(phase * 90f, cx, cy)
        c.drawPath(path, body)
        rimDark.strokeWidth = 2.8f * d
        c.drawPath(path, rimDark)
        edge.strokeWidth = 1.5f * d
        c.drawPath(path, edge)
        c.restore()

        // دڵۆپی بریسکە: سەرچاوەی ڕووناکی جێگیرە، بۆیە لەگەڵ سووڕانەوەی ئەستێرەکە ناسووڕێتەوە
        val gx = cx - r * 0.16f
        val gy = cy - r * 0.34f
        spec.shader = RadialGradient(gx, gy, r * 0.20f, intArrayOf(0xF2FFFFFF.toInt(), 0), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(gx, gy, r * 0.20f, spec)

        // ئەستێرەی بچووکی بریسکەدار (سەرەوەی لای ڕاست)
        val tw = 0.5f + 0.5f * sin((phase * 2f + 0.25f) * 6.2832f)
        val sr = minOf(w, h) * (0.10f + 0.04f * tw)
        sparkle.alpha = (140 + 115 * tw).toInt()
        star(small, w * 0.80f, h * 0.20f, sr)
        c.drawPath(small, sparkle)

        // نیشانەی ✓ (خۆکار چالاکە)
        if (auto) {
            val bx = w * 0.78f
            val by = h * 0.78f
            val br = minOf(w, h) * 0.17f
            badge.shader = LinearGradient(bx - br, by - br, bx + br, by + br,
                intArrayOf(0xFFA77BFF.toInt(), 0xFF6D3FD6.toInt()), null, Shader.TileMode.CLAMP)
            c.drawCircle(bx, by, br, badge)
            badgeRing.strokeWidth = 1.5f * d
            c.drawCircle(bx, by, br, badgeRing)
            tick.strokeWidth = br * 0.30f
            tickPath.reset()
            tickPath.moveTo(bx - br * 0.45f, by + br * 0.02f)
            tickPath.lineTo(bx - br * 0.10f, by + br * 0.38f)
            tickPath.lineTo(bx + br * 0.48f, by - br * 0.34f)
            c.drawPath(tickPath, tick)
        }
    }
}
