package com.mangatranslator.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import java.io.File

/**
 * بەڕێوەبردنی مۆدێلی وەرگێڕان (NLLB-200 distilled 600M، ONNX، int8).
 * فایلەکان بە DownloadManager ی سیستەم دادەبەزێن (لە پاشبنەما، بە دووبارە هەوڵدانەوە).
 * شوێن: ئەپ → فایلە تایبەتەکانی ئەپ / nllb /
 */
class ModelStore(private val ctx: Context) {

    data class Item(val name: String, val url: String, val size: Long)

    private val base = "https://huggingface.co/Xenova/nllb-200-distilled-600M/resolve/main/"

    val items = listOf(
        Item("encoder.onnx", base + "onnx/encoder_model_quantized.onnx", 419_120_483L),
        Item("decoder.onnx", base + "onnx/decoder_model_quantized.onnx", 470_533_055L),
        Item("tokenizer.json", base + "tokenizer.json", 17_331_224L)
    )

    private val prefs = ctx.getSharedPreferences("model_store", Context.MODE_PRIVATE)

    private val dir: File
        get() = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "nllb")

    fun file(name: String) = File(dir, name)
    val encoderFile: File get() = file("encoder.onnx")
    val decoderFile: File get() = file("decoder.onnx")
    val tokenizerFile: File get() = file("tokenizer.json")

    fun isReady(): Boolean = items.all { file(it.name).length() >= it.size }

    fun progressPercent(): Int {
        val total = items.sumOf { it.size }
        val have = items.sumOf { minOf(file(it.name).length(), it.size) }
        return (have * 100 / total).toInt()
    }

    fun isDownloading(): Boolean {
        val ids = savedIds()
        if (ids.isEmpty()) return false
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val q = DownloadManager.Query().setFilterById(*ids.toLongArray())
        dm.query(q)?.use { c ->
            val col = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            while (c.moveToNext()) {
                val st = c.getInt(col)
                if (st == DownloadManager.STATUS_RUNNING ||
                    st == DownloadManager.STATUS_PENDING ||
                    st == DownloadManager.STATUS_PAUSED
                ) return true
            }
        }
        return false
    }

    /** دەست دەکات بە دابەزاندنی فایلە کەمەکان. */
    fun startDownload() {
        if (isDownloading()) return
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dir.mkdirs()
        val ids = ArrayList<Long>()
        for (item in items) {
            val f = file(item.name)
            if (f.length() >= item.size) continue
            if (f.exists()) f.delete() // پاشماوەی نیمچە تەواو
            val req = DownloadManager.Request(Uri.parse(item.url))
                .setTitle("مۆدێلی وەرگێڕان: ${item.name}")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setDestinationInExternalFilesDir(ctx, null, "nllb/${item.name}")
            ids.add(dm.enqueue(req))
        }
        prefs.edit().putString(KEY_IDS, ids.joinToString(",")).apply()
    }

    private fun savedIds(): List<Long> =
        (prefs.getString(KEY_IDS, "") ?: "")
            .split(",")
            .mapNotNull { it.trim().toLongOrNull() }

    companion object {
        private const val KEY_IDS = "download_ids"
    }
}
