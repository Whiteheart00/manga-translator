package com.mangatranslator.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * کوردی (دەنگ) ← ئینگلیزی بە Gemini: دەنگەکە دەبیسترێت، بە کوردی دەنووسرێتەوە و دەکرێت بە ئینگلیزی.
 * ئینتەرنێت و کلیلی Gemini پێویستە. (ئەگەر کلیل نەبوو، LiveTranslator مۆدێلی ئۆفلاینی Vekol بەکاردێنێت.)
 */
object LiveGemini {

    private const val PROMPT =
        "The audio is Sorani Kurdish speech (کوردی سۆرانی) from a person, game or video, possibly with background music or effects. " +
            "Transcribe exactly what is said in Kurdish (Arabic script) and translate it into natural, short, spoken English. " +
            "If there is no clear human Kurdish speech (only music, effects, noise, silence, or another language), return empty strings. " +
            "Never invent anything that was not said. " +
            "Return ONLY JSON like {\"ku\":\"...\",\"en\":\"...\"}."

    /** WAV (16kHz مۆنۆ) ← (دەقی کوردی، وەرگێڕانی ئینگلیزی)، یان null ئەگەر قسەی کوردیی ڕوون نەبوو. */
    fun kuToEn(wav: ByteArray, keysRaw: String): Pair<String, String>? {
        val b64 = Base64.encodeToString(wav, Base64.NO_WRAP)
        fun body(model: String, think: Boolean): String {
            val gen = JSONObject().put("temperature", 0).put("responseMimeType", "application/json")
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            val parts = JSONArray()
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", b64)))
                .put(JSONObject().put("text", PROMPT))
            return JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                .put("generationConfig", gen)
                .toString()
        }
        val raw = GeminiKeys.withKeys(keysRaw) { key ->
            GeminiModels.call(true) { m, think -> post(body(m, think), key, m) }
        }
        val clean = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val o = try { JSONObject(clean) } catch (_: Exception) { return null }
        val ku = o.optString("ku", "").trim()
        val en = o.optString("en", "").trim()
        return if (en.length < 2) null else Pair(ku, en)
    }

    private fun post(body: String, key: String, model: String): String {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 30_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try {
                    JSONObject(resp).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    resp
                }
                throw ApiException(code, "Gemini $code ${why.take(140)}".trim())
            }
            return try {
                val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").optJSONArray("parts")
                if (parts == null || parts.length() == 0) "" else parts.getJSONObject(0).optString("text", "")
            } catch (_: Exception) {
                throw IOException("Gemini وەڵامی بەتاڵی دایەوە")
            }
        } finally {
            c.disconnect()
        }
    }
}
