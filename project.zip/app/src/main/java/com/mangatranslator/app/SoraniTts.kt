package com.mangatranslator.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * خوێندنەوەی دەقی وەرگێڕدراوی سۆرانی بە Gemini TTS.
 * دەنگ لە API ـی خۆڕایی Gemini (لە سنووری quota ـی Google) داوا دەکرێت.
 * Callbackـەکان لە main thread بانگ دەکرێن؛ speak() و stop() لە main thread بانگ بکرێن.
 */
class SoraniTts(
    private val ctx: Context,
    private val settings: TranslatorSettings
) {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    @Volatile
    private var runId = 0

    @Volatile
    var speaking = false
        private set

    @Volatile
    private var connection: HttpURLConnection? = null

    @Volatile
    private var player: MediaPlayer? = null

    private val audioCache = object : LinkedHashMap<String, ByteArray>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>?) = size > 30
    }

    /** هەموو دەقەکان بە ڕیز دەخرێنە ناو یەک داواکاریی TTS بۆ کەمکردنەوەی API calls. */
    fun speak(texts: List<String>, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        val clean = texts.map { it.trim() }.filter { it.length >= 2 }
        if (clean.isEmpty()) return
        if (settings.geminiTtsKey.isBlank()) {
            onError("سەرەتا کلیلی Gemini API لە «ڕێکخستنی دەنگ» دابنێ. کلیلی Google Translate جیاوازە.")
            return
        }

        val text = clean.joinToString("\n")
        val id = ++runId
        stopPlayback()
        speaking = true
        onState(true)

        worker.execute {
            try {
                val audio = synthesize(text)
                if (id == runId) play(audio, id)
            } catch (t: Throwable) {
                Log.e(TAG, "Gemini TTS failed", t)
                if (id == runId) {
                    val why = (t.message ?: t.javaClass.simpleName).take(220)
                    main.post { onError("خوێندنەوەی Gemini سەرنەکەوت:\n$why") }
                }
            } finally {
                if (id == runId) {
                    speaking = false
                    main.post { onState(false) }
                }
            }
        }
    }

    fun stop() {
        runId++
        speaking = false
        stopPlayback()
    }

    fun shutdown() {
        stop()
        worker.shutdownNow()
    }

    private fun synthesize(text: String): ByteArray {
        val voice = settings.geminiTtsVoice
        val cacheKey = "$voice\u0000$text"
        synchronized(audioCache) { audioCache[cacheKey] }?.let { return it }

        val speech = JSONObject()
            .put("voice", voice)
        val content = JSONObject()
            .put("type", "text")
            .put("text", text)
            .put(
                "annotations",
                JSONArray().put(
                    JSONObject()
                        .put("type", "speech_metadata")
                        .put(
                            "style",
                            "Read this text verbatim in Central Kurdish (Sorani), clearly and naturally. " +
                                "Do not translate, summarize, explain, or add words."
                        )
                )
            )
        val input = JSONObject()
            .put("type", "user_input")
            .put("content", JSONArray().put(content))
        val body = JSONObject()
            .put("model", MODEL)
            .put("input", JSONArray().put(input))
            .put("response_format", JSONObject().put("type", "audio"))
            .put("generation_config", JSONObject().put("speech_config", JSONArray().put(speech)))

        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", settings.geminiTtsKey)
            setRequestProperty("User-Agent", "MangaTranslator-Android")
        }
        connection = conn
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val responseText = if (code in 200..299) {
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else {
                conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            }
            if (code !in 200..299) {
                val detail = try {
                    JSONObject(responseText).optJSONObject("error")?.optString("message").orEmpty()
                } catch (_: Exception) {
                    responseText.take(180)
                }
                val hint = when (code) {
                    400 -> " (داواکاری یان مۆدێل هەڵەیە)"
                    401, 403 -> " (کلیلی Gemini API هەڵەیە یان مۆدێل بۆی چالاک نییە)"
                    429 -> " (سنووری خۆڕایی/خێرایی بەکارهێنان گەیشتووە؛ کەمێک چاوەڕێ بکە)"
                    else -> ""
                }
                throw IOException("Gemini API $code$hint ${detail.take(180)}".trim())
            }

            val json = JSONObject(responseText)
            val encoded = extractAudio(json) ?: throw IOException("Gemini API دەنگی نەگەڕاندەوە")
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            if (bytes.isEmpty()) throw IOException("دەنگی بەتاڵە")
            synchronized(audioCache) { audioCache[cacheKey] = bytes }
            return bytes
        } finally {
            conn.disconnect()
            if (connection === conn) connection = null
        }
    }

    private fun extractAudio(response: JSONObject): String? {
        response.optJSONObject("output_audio")?.optString("data")
            ?.takeIf { it.isNotBlank() }?.let { return it }
        response.optJSONObject("outputAudio")?.optString("data")
            ?.takeIf { it.isNotBlank() }?.let { return it }

        val steps = response.optJSONArray("steps") ?: return null
        for (i in steps.length() - 1 downTo 0) {
            val parts = steps.optJSONObject(i)?.optJSONArray("content") ?: continue
            for (j in parts.length() - 1 downTo 0) {
                val part = parts.optJSONObject(j) ?: continue
                if (part.optString("type") == "audio") {
                    return part.optString("data").takeIf { it.isNotBlank() }
                }
            }
        }
        return null
    }

    private fun play(bytes: ByteArray, id: Int) {
        val file = File(ctx.cacheDir, "gemini_tts.wav")
        file.writeBytes(bytes)

        val finished = CountDownLatch(1)
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener { finished.countDown() }
            mp.setOnErrorListener { _, _, _ ->
                finished.countDown()
                true
            }
            mp.prepare()
            if (id != runId) return
            mp.start()
            while (id == runId && !finished.await(100, TimeUnit.MILLISECONDS)) {
                // چاوەڕێی تەواوبوون یان وەستاندنی خوێندنەوە
            }
        } finally {
            try {
                if (mp.isPlaying) mp.stop()
            } catch (_: Exception) {
            }
            try {
                mp.release()
            } catch (_: Exception) {
            }
            if (player === mp) player = null
        }
    }

    private fun stopPlayback() {
        try {
            connection?.disconnect()
        } catch (_: Exception) {
        }
        try {
            player?.let { if (it.isPlaying) it.stop() }
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val TAG = "SoraniTts"
        private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/interactions"
        private const val MODEL = "gemini-3.8-flash-tts"
    }
}
