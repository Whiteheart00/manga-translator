package com.mangatranslator.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

/**
 * خوێندنەوەی دەقی سۆرانی بە دەنگ.
 *
 * دوو ڕێگا:
 *  ١. Azure Speech (ئەگەر کلیلی Azure دانرابێت): دەنگی عەسەبی ckb-IQ بە ئینتەرنێت.
 *  ٢. TextToSpeech ی خودی ئەندرۆید: تەنها ئەگەر مۆبایلەکە دەنگی سۆرانی (ckb) بپشتگیری بکات.
 *
 * هەموو callbackـەکان لەسەر main thread دەگەڕێنەوە. speak() و stop() لە main thread بانگ بکرێن.
 */
class SoraniTts(
    private val ctx: Context,
    private val settings: TranslatorSettings
) {

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val fetcher = Executors.newSingleThreadExecutor()

    /** هەر speak/stop ژمارەیەکی نوێ وەردەگرێت؛ کارە کۆنەکان خۆیان دەوەستێنن */
    @Volatile
    private var run = 0

    @Volatile
    var speaking = false
        private set

    private var sysTts: TextToSpeech? = null
    private var sysReady = false

    private val audioCache = object : LinkedHashMap<String, ByteArray>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>?) = size > 30
    }

    /**
     * texts بە ڕیزبەندی دەخوێنرێنەوە.
     * onState(true) کاتێک دەستپێدەکات، onState(false) کاتێک تەواو یان وەستێنرا.
     */
    fun speak(texts: List<String>, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        val clean = texts.map { it.trim() }.filter { it.length >= 2 }
        if (clean.isEmpty()) return

        val id = ++run
        stopPlayback()
        speaking = true
        onState(true)

        if (settings.azureKey.isNotBlank()) {
            worker.execute {
                try {
                    speakAzure(clean, id)
                } catch (t: Throwable) {
                    Log.e(TAG, "azure speak failed", t)
                    if (id == run) {
                        val why = (t.message ?: t.javaClass.simpleName).take(160)
                        main.post { onError("دەنگ سەرنەکەوت:\n$why") }
                    }
                } finally {
                    if (id == run) {
                        speaking = false
                        main.post { onState(false) }
                    }
                }
            }
        } else {
            speakSystem(clean, id, onState, onError)
        }
    }

    fun stop() {
        run++
        stopPlayback()
        speaking = false
    }

    fun shutdown() {
        stop()
        worker.shutdownNow()
        fetcher.shutdownNow()
        sysTts?.shutdown()
        sysTts = null
    }

    // ---------- Azure Speech ----------

    private fun speakAzure(texts: List<String>, id: Int) {
        var next: Future<ByteArray>? = fetcher.submit(Callable { synth(texts[0]) })
        for (i in texts.indices) {
            if (id != run) return
            val cur = next ?: return
            // دەنگی بابلی دواتر پێش وادە دەهێنین بۆ ئەوەی نێوانیان بەتاڵ نەبێت
            next = if (i + 1 < texts.size) {
                val t = texts[i + 1]
                fetcher.submit(Callable { synth(t) })
            } else null

            val bytes = try {
                cur.get(30, TimeUnit.SECONDS)
            } catch (e: java.util.concurrent.ExecutionException) {
                throw (e.cause ?: e)
            }
            if (id != run) return
            play(bytes, id)
        }
    }

    private fun synth(text: String): ByteArray {
        synchronized(audioCache) { audioCache[text] }?.let { return it }

        val region = settings.azureRegion.lowercase(Locale.ROOT)
        val voice = settings.voice
        val rate = settings.speedPct
        val rateStr = if (rate >= 0) "+$rate%" else "$rate%"

        val ssml = "<speak version='1.0' xml:lang='ckb-IQ' xmlns='http://www.w3.org/2001/10/synthesis'>" +
            "<voice name='${xmlEscape(voice)}'><prosody rate='$rateStr'>${xmlEscape(text)}</prosody></voice></speak>"

        val conn = URL("https://$region.tts.speech.microsoft.com/cognitiveservices/v1")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 20_000
            conn.doOutput = true
            conn.setRequestProperty("Ocp-Apim-Subscription-Key", settings.azureKey)
            conn.setRequestProperty("Content-Type", "application/ssml+xml")
            conn.setRequestProperty("X-Microsoft-OutputFormat", "audio-24khz-48kbitrate-mono-mp3")
            conn.setRequestProperty("User-Agent", "MangaTranslator")
            conn.outputStream.use { it.write(ssml.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code != 200) {
                val err = try {
                    conn.errorStream?.bufferedReader()?.readText()?.take(120) ?: ""
                } catch (_: Exception) {
                    ""
                }
                val hint = when (code) {
                    401, 403 -> " (کلیل یان ناوچە هەڵەیە)"
                    400 -> " (ناوی دەنگ پشتگیری نەکراوە؟)"
                    429 -> " (سنووری بەکارهێنان تەواو بووە)"
                    else -> ""
                }
                throw IOException("Azure $code$hint $err".trim())
            }
            val bytes = conn.inputStream.use { it.readBytes() }
            if (bytes.isEmpty()) throw IOException("Azure: دەنگی بەتاڵ")
            synchronized(audioCache) { audioCache[text] = bytes }
            return bytes
        } finally {
            conn.disconnect()
        }
    }

    private fun play(bytes: ByteArray, id: Int) {
        val f = File(ctx.cacheDir, "tts_clip.mp3")
        f.writeBytes(bytes)

        val latch = CountDownLatch(1)
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { latch.countDown() }
            mp.setOnErrorListener { _, _, _ ->
                latch.countDown()
                true
            }
            mp.prepare()
            if (id != run) return
            mp.start()
            while (id == run && !latch.await(50, TimeUnit.MILLISECONDS)) {
                // چاوەڕێی تەواوبوونی دەنگ یان وەستاندن
            }
        } finally {
            try {
                if (mp.isPlaying) mp.stop()
            } catch (_: Exception) {
            }
            try {
                mp.release()
            } catch (_: Exception) {
            }
            if (player === mp) player = null
        }
    }

    @Volatile
    private var player: MediaPlayer? = null

    private fun stopPlayback() {
        sysTts?.stop()
        // MediaPlayer لە خودی worker دا دەوەستێت (run گۆڕدرا)
    }

    // ---------- TextToSpeech ی ئەندرۆید (ئەگەر ckb هەبێت) ----------

    private fun speakSystem(
        texts: List<String>,
        id: Int,
        onState: (Boolean) -> Unit,
        onError: (String) -> Unit
    ) {
        val loc = Locale.forLanguageTag("ckb")

        fun go(tts: TextToSpeech) {
            if (id != run) return
            val avail = tts.isLanguageAvailable(loc)
            if (avail < TextToSpeech.LANG_AVAILABLE) {
                speaking = false
                onState(false)
                onError(
                    "ئەم مۆبایلە دەنگی سۆرانی نییە.\n" +
                        "لە «٥. ڕێکخستنی دەنگ» کلیلی Azure Speech دابنێ."
                )
                return
            }
            tts.setLanguage(loc)
            val lastId = "u${texts.size - 1}_$id"
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == lastId && id == run) {
                        speaking = false
                        main.post { onState(false) }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (id == run) {
                        speaking = false
                        main.post { onState(false) }
                    }
                }
            })
            for ((i, t) in texts.withIndex()) {
                tts.speak(
                    t,
                    if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                    null,
                    "u${i}_$id"
                )
            }
        }

        val existing = sysTts
        if (existing != null && sysReady) {
            go(existing)
            return
        }
        sysTts = TextToSpeech(ctx) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    sysReady = true
                    sysTts?.let { go(it) }
                } else {
                    speaking = false
                    onState(false)
                    onError("TextToSpeech ی مۆبایلەکە دەستی پێنەکرد")
                }
            }
        }
    }

    private fun xmlEscape(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("'", "&apos;")
        .replace("\"", "&quot;")

    companion object {
        private const val TAG = "SoraniTts"
    }
}
