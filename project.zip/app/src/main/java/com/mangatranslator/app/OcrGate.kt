package com.mangatranslator.app

/**
 * بڕیاری «ئێستا OCR بکە؟» بۆ ژێرنووسی زیندوو (فەنکشنی پاک، بێ Android، تاقیکراو).
 *
 *  - **یەکەم OCR دوای دیاریکردنی ڕووبەر هیچ چاوەڕێیەک نییە:** هەر یەکەم فرەیم OCR دەکرێت (پێشتر دەبوو ڕاوەستان یان
 *    ٤٥٠ms چاوەڕێ بکرێت).
 *  - **دەقی کوردی (بێ وەرگێڕان):** بۆ خوێندنەوەی خێراتر، چاوەڕێی ڕاوەستانی ڕووبەرەکە کورتتر ([FORCE_KURDISH_MS]) و
 *    نێوانی دوو OCR کەمتر ([GAP_KURDISH_MS]) دەبێت.
 */
object OcrGate {
    const val FORCE_MS = 450L
    const val GAP_MS = 220L
    const val FORCE_KURDISH_MS = 250L
    const val GAP_KURDISH_MS = 150L

    fun forceMs(kurdish: Boolean) = if (kurdish) FORCE_KURDISH_MS else FORCE_MS
    fun gapMs(kurdish: Boolean) = if (kurdish) GAP_KURDISH_MS else GAP_MS

    /**
     * @param first هێشتا هیچ OCR ێک نەکراوە (ڕووبەر تازە دیاری کراوە)
     * @param settled ڕووبەرەکە لە دوایین فرەیمەوە نەگۆڕاوە (ژێرنووس تەواو دەرکەوتووە)
     * @param sinceChangeMs چەند ms لەمەوپێش ڕووبەرەکە گۆڕا (بۆ باگراوندی جووڵاو)
     * @param sinceLastOcrMs چەند ms لەمەوپێش دوایین OCR
     */
    fun shouldRun(
        first: Boolean,
        settled: Boolean,
        sinceChangeMs: Long,
        sinceLastOcrMs: Long,
        ocrBusy: Boolean,
        kurdish: Boolean
    ): Boolean {
        if (ocrBusy) return false
        if (first) return true
        if (sinceLastOcrMs < gapMs(kurdish)) return false
        return settled || sinceChangeMs >= forceMs(kurdish)
    }
}
