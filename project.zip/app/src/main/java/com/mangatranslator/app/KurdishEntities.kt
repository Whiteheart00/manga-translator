package com.mangatranslator.app

import android.content.Context

/**
 * فەرهەنگی ناوی کوردی (کەس، شوێن، گوند، چیا، ڕووبار، قوتابخانە، وەزارەت، زانکۆ) لە داتاسێتی KurdishNamedEntities (CC0).
 * فایلەکە assets/kurdish_entities.txt ـە و بە tools/build_entities.py دروست دەکرێت.
 *
 * لێرە هیچ وشەیەک خۆکارانە ناگۆڕدرێت — چونکە فەرهەنگەکە وشەی باوی وەک «سەرۆک» و «هیوا»ی تێدایە و گۆڕینی ڕاستەوخۆ دەقی دروست تێک دەدات.
 * تەنها [hints] ناوە نزیکەکان دەدۆزێتەوە تا بدرێن بە KurdishTextFix (Gemini) وەک ئاماژە؛ ئەو بە پێی ماناکەی بڕیار دەدات.
 * لە thread ی پاشبنەما بانگ بکرێت (بارکردنی یەکەم ~٣٠٠KB دەخوێنێتەوە).
 */
object KurdishEntities {

    private const val MAX_WORDS = 3          // تا ٣ وشە لە دەقەکەدا بەراورد دەکرێت
    private const val MIN_LEN = 6            // وشەی کورتتر لەمە هەڵەی زۆر دروست دەکات
    private const val LONG_LEN = 9           // لە ٩ پیتەوە ٢ هەڵە ڕێگە پێدراوە

    @Volatile private var all: Set<String>? = null
    @Volatile private var buckets: HashMap<Int, ArrayList<String>>? = null   // کلیل = ژمارەی وشە * 1000 + درێژی

    private val STRIP = Regex("[\u200c\u200d\u0640\u064b-\u0652]")
    private val EDGE_PUNCT = Regex("^[،؛؟!.:,;?\"'()\\[\\]«»]+|[،؛؟!.:,;?\"'()\\[\\]«»]+$")

    /** هاوتای norm() ی tools/build_entities.py و VekolStt.normalizeSorani. */
    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            sb.append(
                when (c) {
                    '\u0643' -> '\u06A9'
                    '\u064A', '\u0649' -> '\u06CC'
                    '\u0629' -> '\u06D5'
                    '\u06BE' -> '\u0647'
                    '\u0624' -> '\u0648'
                    '\u0623', '\u0625', '\u0622', '\u0671', '\u0672' -> '\u0627'
                    else -> c
                }
            )
        }
        return STRIP.replace(sb.toString(), "").trim()
    }

    @Synchronized
    private fun load(ctx: Context) {
        if (all != null) return
        val set = HashSet<String>(24_000)
        val map = HashMap<Int, ArrayList<String>>()
        ctx.assets.open("kurdish_entities.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                val e = line.trim()
                if (e.length < 3 || !set.add(e)) continue
                val words = e.count { it == ' ' } + 1
                if (words > MAX_WORDS) continue
                map.getOrPut(words * 1000 + e.length) { ArrayList() }.add(e)
            }
        }
        buckets = map
        all = set
    }

    /**
     * ناوە نزیکەکان لە دەقەکەدا (بۆ ئاماژە بە Gemini). هەر وشەیەک کە خۆی لە فەرهەنگەکەدایە وەک دروست دادەنرێت و ئاماژەی بۆ نادرێت.
     * لیستی بەتاڵ = هیچ شتێکی نزیک نەدۆزرایەوە، یان فایلەکە نەخوێندرایەوە.
     */
    fun hints(ctx: Context, text: String, max: Int = 6): List<String> {
        return try {
            load(ctx)
            val exact = all ?: return emptyList()
            val bk = buckets ?: return emptyList()
            val toks = text.split(Regex("\\s+"))
                .map { norm(EDGE_PUNCT.replace(it, "")) }
                .filter { it.isNotEmpty() }
            val found = LinkedHashMap<String, Int>()   // ناو -> کەمترین دووری
            for (n in 1..MAX_WORDS) {
                for (i in 0..toks.size - n) {
                    val gram = toks.subList(i, i + n).joinToString(" ")
                    if (gram.length < MIN_LEN || gram in exact) continue
                    val maxD = if (gram.length >= LONG_LEN) 2 else 1
                    for (len in gram.length - maxD..gram.length + maxD) {
                        val list = bk[n * 1000 + len] ?: continue
                        for (e in list) {
                            val d = levenshteinMax(gram, e, maxD)
                            if (d in 1..maxD) {
                                val old = found[e]
                                if (old == null || d < old) found[e] = d
                            }
                        }
                    }
                }
            }
            found.entries.sortedBy { it.value }.take(max).map { it.key }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    /** دووری Levenshtein؛ ئەگەر لە [max] زیاتر بوو max+1 دەگەڕێنێتەوە (زوو دەوەستێت). */
    private fun levenshteinMax(a: String, b: String, max: Int): Int {
        if (kotlin.math.abs(a.length - b.length) > max) return max + 1
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (cur[j] < rowMin) rowMin = cur[j]
            }
            if (rowMin > max) return max + 1
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }
}
