package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveSpeechAttemptTest {
    @Test fun successfulShortWordIsNeverRetriedAfterTextDisappears() {
        val state = LiveSpeechAttempt()
        val queue = SpeechQueue()
        queue.add("باشە.")
        val token = state.begin(queue.take()!!.text)
        assertTrue(state.complete(token)) // even an immediate completion is valid
        assertNull(state.fail(token, sourceVisible = false))
        assertFalse(state.complete(token)) // duplicate callback/watchdog
        assertTrue(queue.isEmpty())
    }
    @Test fun disappearingSubtitleDoesNotCancelCurrentPlayback() {
        val state = LiveSpeechAttempt()
        val token = state.begin("دەنگی ئێستا")
        // Visibility is consulted only on error. No cancellation occurs on blank OCR.
        assertTrue(state.isCurrent(token))
        assertTrue(state.complete(token))
        assertNull(state.fail(token, sourceVisible = false))
    }
    @Test fun genuineFailureRetriesOnlyOnceWhileSourceIsVisible() {
        val state = LiveSpeechAttempt()
        val first = state.begin("باشە.")
        assertEquals("باشە.", state.fail(first, true)!!.retryText)
        assertNull(state.fail(first, true))
        val second = state.begin("باشە.")
        assertNull(state.fail(second, true)!!.retryText)
    }
    @Test fun failureAfterSourceDisappearsDoesNotRestartOldText() {
        val state = LiveSpeechAttempt()
        val token = state.begin("old subtitle")
        assertNull(state.fail(token, false)!!.retryText)
        assertFalse(state.isCurrent(token))
    }
    @Test fun lateCallbacksCannotCompleteTheNextSentence() {
        val state = LiveSpeechAttempt()
        val old = state.begin("first")
        assertTrue(state.complete(old))
        val current = state.begin("second")
        assertFalse(state.complete(old))
        assertNull(state.fail(old, true))
        assertTrue(state.isCurrent(current))
    }
    @Test fun uncertainWatchdogFinishAdvancesWithoutReplay() {
        val state = LiveSpeechAttempt()
        val queue = SpeechQueue(maxChars = 1)
        queue.add("first sentence has enough words."); queue.add("second sentence has enough words.")
        val first = state.begin(queue.take()!!.text)
        assertTrue(state.complete(first)) // playback finished; completion callback is late
        val second = queue.take()!!
        assertEquals("second sentence has enough words.", second.text)
        val next = state.begin(second.text)
        assertNull(state.fail(first, true))
        assertTrue(state.isCurrent(next))
        assertTrue(queue.isEmpty())
    }
    @Test fun stopInvalidatesEveryCallback() {
        val state = LiveSpeechAttempt()
        val token = state.begin("first")
        state.cancel()
        assertFalse(state.complete(token))
        assertNull(state.fail(token, true))
    }
}
