package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class PiperShortSpeechTest {
    private val rate = 22050
    private fun signal() = FloatArray(2205) { if (it % 2 == 0) .1f else -.1f }

    @Test fun singleWordReturnsImmediatelyWithoutFillerOrMinimumDuration() {
        for (word in listOf("نا", "من", "باشە", "سڵاو", "سوپاس")) {
            val attempted = mutableListOf<String>()
            val audio = signal()
            val result = PiperShortSpeech.render("$word.", word, rate,
                synthesize = { attempted += it; audio }, polish = { it })
            assertSame(audio, result)
            assertEquals(listOf("$word."), attempted)
        }
    }
    @Test fun silentOutputRetriesPunctuationOnly() {
        val attempted = mutableListOf<String>()
        val result = PiperShortSpeech.render("نا.", "نا", rate,
            synthesize = { attempted += it; if (attempted.size == 1) FloatArray(rate * 5) else signal() },
            polish = { it })
        assertTrue(PcmSignal.hasSignal(result, rate))
        assertEquals(listOf("نا.", " نا ."), attempted)
    }
    @Test fun allFailedVariantsReturnEmptyForExistingFallback() {
        var calls = 0
        val result = PiperShortSpeech.render("نا.", "نا", rate,
            synthesize = { calls++; FloatArray(rate) }, polish = { it })
        assertTrue(result.isEmpty())
        assertEquals(4, calls)
    }
    @Test fun nullSynthesisIsRetriedAndPolishingSilenceIsNotAccepted() {
        var calls = 0
        val result = PiperShortSpeech.render("نا.", "نا", rate,
            synthesize = { if (++calls == 1) null else signal() }, polish = { FloatArray(rate) })
        assertTrue(result.isEmpty())
        assertEquals(4, calls)
    }
    @Test fun silenceAndInvalidPcmAreRejectedRegardlessOfDuration() {
        assertFalse(PcmSignal.hasSignal(FloatArray(rate * 5), rate))
        assertFalse(PcmSignal.hasSignal(FloatArray(rate) { Float.NaN }, rate))
        assertFalse(PcmSignal.hasSignal(FloatArray(rate) { Float.POSITIVE_INFINITY }, rate))
        assertFalse(PcmSignal.hasSignal(FloatArray(rate) { 1e-7f }, rate))
        assertFalse(PcmSignal.hasSignal(signal(), 0))
        assertTrue(PcmSignal.hasSignal(signal(), rate))
    }
    @Test fun singleClickDoesNotCountAsSpeech() {
        val click = FloatArray(rate).apply { this[0] = 1f }
        assertFalse(PcmSignal.hasSignal(click, rate))
    }
    @Test fun shortAudioFitsNativeBufferWithoutAddingSpokenWords() {
        assertEquals(4410, PiperPlayback.bufferBytes(4096, rate, 2205))
        assertEquals(4096, PiperPlayback.bufferBytes(4096, rate, 100))
        val pcm = shortArrayOf(11, 22, 33)
        assertArrayEquals(shortArrayOf(11, 22, 33, 0, 0), PiperPlayback.fillFirstBuffer(pcm, 5))
        assertSame(pcm, PiperPlayback.fillFirstBuffer(pcm, 3))
    }
    @Test fun longAudioKeepsTheOriginalBufferSize() {
        assertEquals(rate * 4, PiperPlayback.bufferBytes(4096, rate, rate * 5))
        val pcm = ShortArray(rate * 5)
        assertSame(pcm, PiperPlayback.fillFirstBuffer(pcm, rate * 2))
    }
}
