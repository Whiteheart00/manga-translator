package com.mangatranslator.app

import android.graphics.Rect

/**
 * فلتەرکردنی دەقە دۆزراوەکان بێ پێویستی بە دیاریکردنی زمان لەلایەن بەکارهێنەرەوە:
 *  - ئەو دەقانە دەستنیشان دەکات کە بەهۆی OCR ی زمانی هەڵە (مەسەلەن عەرەبی بە ناسێنەری لاتینی) بوونەتە "پیتی شێواو"
 *  - ئەو دەقانە لادەبات کە پێویستیان بە وەرگێڕان نییە (ژمارە، قەبارە S M L XL، کوردیی سۆرانی)
 */
object TextFilter {

    fun isArabicScript(ch: Char) = ch.code in 0x0600..0x06FF || ch.code in 0x0750..0x077F || ch.code in 0xFB50..0xFEFF

    fun arabicLetters(t: String) = t.count { isArabicScript(it) && it.isLetter() }

    private val weirdLatin = "öäüëïÿøåñßœæþðŋĳ"
    private val mixedToken = Regex("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]+$")
    private val okMixed = Regex("^(\\d?[XxSsMmLl]{1,3}|\\d+[Kk]|[1-9][Gg]|\\d+[A-Za-z]{1,2})$", RegexOption.IGNORE_CASE)

    /** ئایا دەقێکی لاتینی لە ڕاستیدا عەرەبیی بە هەڵە خوێندراوەتەوە؟ */
    fun looksLikeMisreadScript(t: String): Boolean {
        if (arabicLetters(t) >= 2) return false
        if (t.any { it in weirdLatin || it in weirdLatin.uppercase() }) return true
        val toks = t.split(Regex("[\\s·•|,.:;!?()\\[\\]-]+")).filter { it.isNotEmpty() }
        if (toks.isEmpty()) return false
        // وشەی تێکەڵی پیت+ژمارە (T7، al7) کە جۆری ئاساییی نییە (3XL، 5G، 4K)
        val badMixed = toks.count { mixedToken.matches(it) && !okMixed.matches(it) }
        if (badMixed >= 1) return true
        // ژمارە لەگەڵ چەند وشەی زۆر کورتی دوو-سێ پیتی: ڕەنگە عەرەبی بێت ("al T7 aobö 3")
        val letterToks = toks.filter { tk -> tk.any { it.isLetter() } }
        val hasDigits = toks.any { tk -> tk.all { it.isDigit() } }
        if (hasDigits && letterToks.isNotEmpty() && letterToks.all { it.length <= 3 } && letterToks.size >= 2) {
            val sizes = Regex("^(XXS|XS|S|M|L|XL|XXL|XXXL)$", RegexOption.IGNORE_CASE)
            if (!letterToks.all { sizes.matches(it) }) return true
        }
        return false
    }

    private val sizeOnly = Regex("^\\s*((XXS|XS|S|M|L|XL|XXL|XXXL|[2-6]XL|SML)[\\s/,-]*)+$", RegexOption.IGNORE_CASE)
    private val sorani = "ەۆێڕڵڤ"

    /** ئایا دەقەکە بە ڕوونی کوردیی سۆرانییە؟ (بۆ پیشاندان و خوێندنەوە بێ وەرگێڕانەوە) */
    fun isLikelySorani(t: String): Boolean {
        val s = t.trim()
        if (s.length < 2) return false
        var letters = 0
        var arabic = 0
        var special = 0
        for (ch in s) {
            if (!ch.isLetter()) continue
            letters++
            if (isArabicScript(ch)) arabic++
            if (ch in sorani) special++
        }
        if (letters < 2) return false
        // پیتی تایبەتی سۆرانی یان زۆرینەی عەرەبی + لانیکەم یەک ە/ێ/ۆ…
        if (special >= 1 && arabic * 100 >= letters * 70) return true
        if (special >= 2) return true
        return false
    }

    /** وشەی ئینگلیزیی ڕاستەقینە (نەک ناو/واتەرمارکی وەک MkIceandfire، @user، abc123) */
    private val englishWord = Regex("(?<![A-Za-z0-9_@#.])[A-Za-z][A-Za-z']+(?![A-Za-z0-9_@])")
    private val camelCase = Regex("[a-z][A-Z]")

    fun hasEnglishWord(t: String): Boolean =
        englishWord.findAll(t).any { !camelCase.containsMatchIn(it.value) }

    /** کوردیی تەواو و بێ هیچ وشەیەکی ئینگلیزی ← هەرگیز دووبارە وەرناگێڕدرێت */
    fun isAlreadyKurdish(t: String): Boolean = isLikelySorani(t) && !hasEnglishWord(t)

    /** ئایا ئەم دەقە شایەنی وەرگێڕانە؟ */
    fun worthTranslating(t: String): Boolean {
        val s = t.trim()
        if (s.isEmpty()) return false
        val letters = s.count { it.isLetter() }
        if (letters == 0) return false                         // ژمارە / هێما
        val cjkOrArabic = s.any { it.code >= 0x2E80 || isArabicScript(it) }
        if (!cjkOrArabic && letters <= 1) return false         // "O 52"
        if (sizeOnly.matches(s)) return false                  // S M L XL XXL
        if (isAlreadyKurdish(s)) return false                  // پێشتر کوردییە (و وشەی ئینگلیزی تێدا نییە)
        return true
    }

    fun overlapsMostly(a: Rect, b: Rect): Boolean {
        val i = Rect()
        if (!i.setIntersect(a, b)) return false
        val ia = i.width().toLong() * i.height()
        val small = minOf(a.width().toLong() * a.height(), b.width().toLong() * b.height()).coerceAtLeast(1)
        return ia * 10 >= small * 3
    }
}
