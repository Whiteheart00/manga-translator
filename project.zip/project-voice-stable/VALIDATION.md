# Offline Piper stability validation — 2026-11-08

- Gradle `testDebugUnitTest --offline`: BUILD SUCCESSFUL, including Android application/test source compilation.
- 260 JVM tests across 36 suites; 0 failures, 0 errors, 0 skips.
- 11 added tests cover full PCM queue completion, idle vs finished queues, monotonic playback stalls, unsigned/wrapping heads, no false stall while waiting for synthesis, partial-playback retry suppression, and DC rejection.
- All seven existing recorded model PCM files passed the production PCM and short-word path on the first attempt. See verification/results.txt. These were recorded samples, not fresh native/device inference tests.
- Exact low repeated-vowel noise, Android AudioTrack behavior, device temperature/power and end-to-end latency were not reproduced or measured on a phone.
- Full final Gradle log: voice-stable-test.log.
- Source-only delivery; no APK assembled or included.

See [VOICE_STABILITY.md](VOICE_STABILITY.md) for fixes, retry policy and device checks. Prior live-filter/progress optimizations remain in the source; their benchmarks are historical and do not measure these audio changes.
