#!/usr/bin/env python3
"""KurdishNamedEntities-main/*.xlsx  ->  app/src/main/assets/kurdish_entities.txt

بەکارهێنان:  python tools/build_entities.py KurdishNamedEntities-main  app/src/main/assets/kurdish_entities.txt
پێویستی: pip install pandas openpyxl

Companies.xlsx بەکار نایەت (زۆربەی لاتینی و بێ ڕێکخستنە)، و ناوی لاتینی/ژمارەدار فڕێ دەدرێن.
نۆرماڵکردن دەبێت هەمان KurdishEntities.norm() ی Kotlin بێت.
"""
import re, sys, glob, os
import pandas as pd

FILES = ["Persons", "Locations", "Villages", "Mountains", "Rivers", "Caves",
         "Schools", "Ministries", "Universities&institues"]

MAP = {"\u0643": "\u06A9", "\u064A": "\u06CC", "\u0649": "\u06CC", "\u0629": "\u06D5",
       "\u06BE": "\u0647", "\u0624": "\u0648", "\u0623": "\u0627", "\u0625": "\u0627",
       "\u0622": "\u0627", "\u0671": "\u0627", "\u0672": "\u0627"}
STRIP = re.compile("[\u200c\u200d\u0640\u064b-\u0652]")
LATIN_OR_DIGIT = re.compile(r"[A-Za-z0-9\u0660-\u0669\u06F0-\u06F9]")
SUFFIX = re.compile(r"\s+یا\s+تێک[هە]ل\s*$")

def norm(s: str) -> str:
    s = "".join(MAP.get(c, c) for c in s)
    s = STRIP.sub("", s)
    return re.sub(r"\s+", " ", s).strip()

def main(src, dst):
    seen, out = set(), []
    for name in FILES:
        path = os.path.join(src, name + ".xlsx")
        col = pd.read_excel(path, header=None).iloc[:, 0].dropna()
        for raw in col:
            for part in re.split(r"[،,]", str(raw)):
                t = norm(part)
                t = SUFFIX.sub("", t)
                if len(t) < 3 or LATIN_OR_DIGIT.search(t) or t in seen:
                    continue
                seen.add(t); out.append(t)
    out.sort()
    with open(dst, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")
    print(len(out), "entities ->", dst, os.path.getsize(dst) // 1024, "KB")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
