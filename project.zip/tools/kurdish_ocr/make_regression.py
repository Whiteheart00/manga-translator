"""Synthetic smoke corpus, NOT independent real-world OCR validation."""
import argparse,json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ap=argparse.ArgumentParser();ap.add_argument('output',type=Path);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
texts=['کوردستان و زمانی کوردی','ئەمڕۆ هەوا زۆر خۆشە','خوێندنەوەی کتێب زانیاری زیاد دەکات','تکایە ناو و ناونیشانی خۆت بنووسە','ڕێگای شارەکە دوور و درێژە','گوڵ و گوڵاڵە لە باخچەکەدان','پزیشک دەرمانی بۆ نەخۆشەکە نووسی','ژمارەی تەلەفۆن ٠٧٧٠١٢٣٤٥٦٧']
fonts=['/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf','/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']
rows=[]
for font in fonts:
 f=ImageFont.truetype(font,40)
 for text in texts:
  n=len(rows)+1; bbox=f.getbbox(text,direction='rtl');w=bbox[2]-bbox[0];h=bbox[3]-bbox[1]
  im=Image.new('RGB',(w+30,h+30),'white');ImageDraw.Draw(im).text((15-bbox[0],15-bbox[1]),text,font=f,fill='black',direction='rtl');im.save(a.output/f'{n:03}.png')
  rows.append(dict(id=n,split='synthetic_regression',text=text,font=font))
(a.output/'manifest.json').write_text(json.dumps({'samples':rows},ensure_ascii=False,indent=2))
