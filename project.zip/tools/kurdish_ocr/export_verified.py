"""Export only explicitly user-verified line/image pairs, retaining scene-level splits."""
from pathlib import Path
from PIL import Image
import argparse,json,hashlib
ap=argparse.ArgumentParser();ap.add_argument('review',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args()
m=json.loads((a.review/'manifest.json').read_text());assert len(m['samples'])==45
rows=[]
for n,r in enumerate(m['samples'],1):
 assert r['status']=='verified' and r['verified_text'].strip(),r['id']
 original=Image.open(a.review/r['image']).convert('RGB')
 single=int(r['source_image'].split('.')[0]) not in {3,4,8,12,17,18,22,33,34,35}
 box=(0,15,original.width,51) if single else (0,7 if r['id'].endswith('-1') else 6,original.width,46 if r['id'].endswith('-1') else 45)
 for kind in ['lines','tight']:
  dest=a.output/kind;dest.mkdir(parents=True,exist_ok=True)
  (original if kind=='lines' else original.crop(box)).save(dest/f'{n:03}.png')
  (dest/f'{n:03}.gt.txt').write_text(r['verified_text']+'\n',encoding='utf-8')
 rows.append(dict(id=n,review_id=r['id'],source_image=r['source_image'],source_sha256=r['source_sha256'],split=r['split'],text=r['verified_text'],review_box=r['box'],tight_box_within_review=list(box)))
manifest={'status':'All 45 line transcriptions explicitly approved by user in conversation','samples':rows}
for kind in ['lines','tight']:
 dest=a.output/kind;(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 for split in ['train','validation','test']:(dest/f'{split}.ids').write_text(''.join(f"{r['id']:03}\n" for r in rows if r['split']==split))
seen={s:{r['source_image'] for r in rows if r['split']==s} for s in ['train','validation','test']}
assert not(seen['train']&seen['test'] or seen['train']&seen['validation'] or seen['test']&seen['validation'])
print({s:sum(r['split']==s for r in rows) for s in seen})
