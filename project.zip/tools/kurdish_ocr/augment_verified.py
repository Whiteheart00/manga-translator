"""Deterministic synthetic rehearsal/outline augmentation, training scenes only."""
import argparse,json,random,unicodedata,subprocess,os
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from bidi.algorithm import get_display
ap=argparse.ArgumentParser();ap.add_argument('dataset',type=Path);ap.add_argument('crops',type=Path);ap.add_argument('vocabulary',type=Path);ap.add_argument('tessdata',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
rng=random.Random(20261113)
fonts=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf','/usr/share/fonts/truetype/noto/NotoSansArabic-Bold.ttf','/usr/share/fonts/truetype/noto/NotoNaskhArabic-Bold.ttf']
words=[w.strip() for w in a.vocabulary.read_text().splitlines() if 2<len(w.strip())<14 and all('\u0600'<=c<='\u06ff' for c in w.strip())]
trainids=(a.crops/'train.ids').read_text().split(); paths=[];rows=[]
source_names={f"{r['id']:03}":r['source_image'] for r in json.loads((a.crops/'manifest.json').read_text())['samples']}
for i in range(180):
    text=' '.join(rng.choices(words,k=rng.randint(3,7)))
    f=ImageFont.truetype(fonts[i%len(fonts)],rng.choice([28,30,34]))
    stroke=1 if i%3==0 else 2
    bbox=f.getbbox(text,direction='rtl',stroke_width=stroke);w=bbox[2]-bbox[0];h=bbox[3]-bbox[1];sz=(w+6,h+6)
    outline=i%3!=0
    if outline:
        scene=rng.choice(trainids); source=Image.open(a.dataset/'images'/source_names[scene]).convert('RGB')
        # Video content above subtitles; no validation/test image pixels used.
        im=source.crop((0,1080,1080,1360)).resize(sz,Image.Resampling.BILINEAR)
    else: im=Image.new('RGB',sz,'white')
    ImageDraw.Draw(im).text((3-bbox[0],3-bbox[1]),text,font=f,fill='white' if outline else 'black',stroke_width=stroke if outline else 0,stroke_fill='black',direction='rtl')
    p=a.output/f'synthetic-{i:03}.png';im.save(p)
    p.with_suffix('.gt.txt').write_text(text+'\n',encoding='utf-8');w,h=im.size
    p.with_suffix('.box').write_text(f'WordStr 0 0 {w} {h} 0 #{get_display(unicodedata.normalize("NFC",text))}\n\t 0 0 {w} {h} 0\n',encoding='utf-8')
    subprocess.run(['tesseract',str(p),str(p.with_suffix('')),'--tessdata-dir',str(a.tessdata),'-l','ckb','--psm','13','-c','tessedit_train_line_recognizer=1','-c','tessedit_init_config_only=1'],check=True,env={**os.environ,'OMP_THREAD_LIMIT':'1'})
    paths.append(str(p.with_suffix('.lstmf').resolve()));rows.append(dict(id=i,text=text,font=fonts[i%3],outline=outline))
# About half of training exposure is genuine user-provided subtitles.
real=(a.crops/'train.list').read_text().splitlines()
paths += real*5
rng.shuffle(paths)
(a.output/'train.list').write_text('\n'.join(paths)+'\n')
(a.output/'manifest.json').write_text(json.dumps({'seed':20261113,'real_samples':len(real),'real_repetitions':5,'synthetic_samples':rows},ensure_ascii=False,indent=2))
