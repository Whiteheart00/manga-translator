#!/usr/bin/env bash
# Explicitly reviewed 45-line dataset, mixed with deterministic training-only augmentation.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
REVIEW_DIR="$(realpath "${1:?Usage: train_verified.sh REVIEW_DIR SOURCE_DATASET_DIR WORK_DIR}")"
DATASET_DIR="$(realpath "${2:?Missing original dataset directory}")"
mkdir -p "${3:?Missing fresh work directory}"
WORK_DIR="$(realpath "$3")"
export OMP_THREAD_LIMIT=1
mkdir -p "$WORK_DIR/base" "$WORK_DIR/run" "$WORK_DIR/candidate1500" "$WORK_DIR/candidate3000" "$WORK_DIR/original"
BASE_FILE="$WORK_DIR/base/ckb.traineddata"
curl -fL --max-time 120 'https://raw.githubusercontent.com/Shreeshrii/tesstrain-ckb/bf3727a6fa59acf438679a065f867b1672e96654/data/ckbLayer.traineddata' -o "$BASE_FILE"
printf '%s  %s\n' 'b6c9d0fe10dc90b19451686ddd3829a92a202b564c77befdba8f9bac68152852' "$BASE_FILE" | sha256sum -c -
cp "$PROJECT_DIR/app/src/main/assets/ckb.traineddata" "$WORK_DIR/original/ckb.traineddata"
python "$SCRIPT_DIR/export_verified.py" "$REVIEW_DIR" "$WORK_DIR"
python "$SCRIPT_DIR/make_lstmf.py" "$WORK_DIR/tight" "$WORK_DIR/base"
python "$SCRIPT_DIR/augment_verified.py" "$DATASET_DIR" "$WORK_DIR/tight" "$PROJECT_DIR/app/src/main/assets/kurdish_vocab.txt" "$WORK_DIR/base" "$WORK_DIR/augmented"
combine_tessdata -e "$BASE_FILE" "$WORK_DIR/base/ckb.lstm"
lstmtraining --continue_from "$WORK_DIR/base/ckb.lstm" --traineddata "$BASE_FILE" --train_listfile "$WORK_DIR/augmented/train.list" --eval_listfile "$WORK_DIR/tight/validation.list" --model_output "$WORK_DIR/run/ckb" --learning_rate 0.0001 --max_iterations 1500 --target_error_rate 0.01 > "$WORK_DIR/run/train1500.log" 2>&1
lstmtraining --stop_training --convert_to_int --continue_from "$WORK_DIR/run/ckb_checkpoint" --traineddata "$BASE_FILE" --model_output "$WORK_DIR/candidate1500/ckb.traineddata"
cp "$WORK_DIR/run/ckb_checkpoint" "$WORK_DIR/run/iteration1500.checkpoint"
lstmtraining --continue_from "$WORK_DIR/run/ckb_checkpoint" --traineddata "$BASE_FILE" --train_listfile "$WORK_DIR/augmented/train.list" --eval_listfile "$WORK_DIR/tight/validation.list" --model_output "$WORK_DIR/run/ckb" --learning_rate 0.0001 --max_iterations 3000 --target_error_rate 0.01 > "$WORK_DIR/run/train3000.log" 2>&1
lstmtraining --stop_training --convert_to_int --continue_from "$WORK_DIR/run/ckb_checkpoint" --traineddata "$BASE_FILE" --model_output "$WORK_DIR/candidate3000/ckb.traineddata"
python "$SCRIPT_DIR/prepare_app.py" "$WORK_DIR/lines" "$WORK_DIR/app-crops"
for STEP in 1500 3000; do
  python "$SCRIPT_DIR/evaluate_fallback.py" "$WORK_DIR/app-crops" "$WORK_DIR/original" "$WORK_DIR/candidate$STEP" "$WORK_DIR/validation-$STEP.json" --candidate-images "$WORK_DIR/lines"
done
# Review validation metrics before evaluating a selected model on test data.
# Nothing in this script replaces app assets or changes Android runtime.
