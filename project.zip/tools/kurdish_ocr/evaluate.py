"""Compare OCR models on identical subtitle crops. CER/WER are micro averages."""
import argparse, json, os, subprocess, unicodedata
from pathlib import Path

def distance(a,b):
    prev=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        row=[i]
        for j,y in enumerate(b,1): row.append(min(row[-1]+1,prev[j]+1,prev[j-1]+(x!=y)))
        prev=row
    return prev[-1]

def normalize(t):
    t=unicodedata.normalize('NFKC',t).replace('ي','ی').replace('ك','ک').replace('\u200c','').replace('ـ','')
    return ' '.join(''.join(c if c.isalnum() or c.isspace() else ' ' for c in t).split())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('crops',type=Path);ap.add_argument('model_dir',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--split',choices=['train','validation','test','all'],default='validation');ap.add_argument('--psm',default='7');a=ap.parse_args()
    rows=json.loads((a.crops/'manifest.json').read_text())['samples'];result=[]
    for r in rows:
        if a.split!='all' and r['split']!=a.split: continue
        image=a.crops/f"{r['id']:03}.png"
        cmd=['tesseract',str(image),'stdout','--tessdata-dir',str(a.model_dir),'-l','ckb','--psm',a.psm,'-c','tessedit_do_invert=0','-c','load_system_dawg=0','-c','load_freq_dawg=0']
        p=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'OMP_THREAD_LIMIT':'1'},check=True)
        ref=normalize(r['text']);hyp=normalize(p.stdout)
        result.append(dict(id=r['id'],split=r['split'],reference=r['text'],prediction=p.stdout.strip(),normalized_reference=ref,normalized_prediction=hyp,char_errors=distance(ref,hyp),chars=len(ref),word_errors=distance(ref.split(),hyp.split()),words=len(ref.split()),raw_char_errors=distance(r['text'],p.stdout.strip()),raw_chars=len(r['text'])))
    def stats(rs):
        return dict(samples=len(rs),cer=sum(r['char_errors'] for r in rs)/max(1,sum(r['chars'] for r in rs)),wer=sum(r['word_errors'] for r in rs)/max(1,sum(r['words'] for r in rs)),raw_cer=sum(r['raw_char_errors'] for r in rs)/max(1,sum(r['raw_chars'] for r in rs)))
    report={'model_dir':str(a.model_dir),'psm':a.psm,'metric_policy':'NFKC, Arabic y/k normalized, ZWNJ/tatweel removed; punctuation ignored, whitespace collapsed. Raw CER also recorded. Supplied labels may contain transcription errors. Specified PSM on manually cropped lines; not an Android end-to-end benchmark.','summary':stats(result),'by_split':{s:stats([r for r in result if r['split']==s]) for s in sorted(set(r['split'] for r in result))},'samples':result}
    a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report['by_split']))
if __name__=='__main__':main()
