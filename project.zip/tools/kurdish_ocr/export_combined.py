"""Export 69 explicitly approved lines. Preserve old splits; add grouped part2 splits.
Tight rectangles are inference/training diagnostics, not edits to approved review images.
"""
from pathlib import Path
from PIL import Image
import argparse,json,shutil
ap=argparse.ArgumentParser();ap.add_argument('part1',type=Path);ap.add_argument('part2',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();rows=[]
new_bounds={36:(55,90),39:(58,94),40:(51,88),41:(63,105),42:(64,99),43:(53,90),45:(89,129),46:(54,95),47:(60,99),49:(59,100),50:(54,94),51:(65,103),52:(60,101),53:(53,94),54:(55,96),55:(53,95)}
for part,review in [('part1',a.part1),('part2',a.part2)]:
 m=json.loads((review/'manifest.json').read_text())
 assert all(r['status']=='verified' and r['verified_text'].strip() for r in m['samples'])
 for r in m['samples']:
  n=len(rows)+1;source_number=int(Path(r['source_image']).stem);im=Image.open(review/r['image']).convert('RGB')
  if part=='part1':
   single=source_number not in {3,4,8,12,17,18,22,33,34,35}
   box=(0,15,im.width,51) if single else (0,7 if r['id'].endswith('-1') else 6,im.width,46 if r['id'].endswith('-1') else 45)
   split=r['split']
  else:
   split='validation' if source_number in {44,45,49,50} else 'test' if source_number in {52,53,54} else 'train'
   if source_number in new_bounds:
    y0,y1=new_bounds[source_number];box=(0,y0,im.width,y1)
   elif source_number in {37,38}:box=(0,3,im.width,min(im.height,40))
   elif source_number==44:box=(0,2,im.width,im.height-2)
   else:box=(0,1,im.width,im.height-1)
  for kind in ['lines','tight']:
   dst=a.output/kind;dst.mkdir(parents=True,exist_ok=True)
   (im if kind=='lines' else im.crop(box)).save(dst/f'{n:03}.png')
   (dst/f'{n:03}.gt.txt').write_text(r['verified_text']+'\n',encoding='utf-8')
  rows.append(dict(id=n,review_id=r['id'],part=part,source_image=r['source_image'],source_sha256=r['source_sha256'],split=split,text=r['verified_text'],review_box=r['box'],tight_box_within_review=list(box)))
assert len(rows)==69
for kind in ['lines','tight']:
 dst=a.output/kind;(dst/'manifest.json').write_text(json.dumps({'status':'All 69 line transcriptions explicitly approved by user','samples':rows},ensure_ascii=False,indent=2))
 for split in ['train','validation','test']:(dst/f'{split}.ids').write_text(''.join(f"{r['id']:03}\n" for r in rows if r['split']==split))
sets={s:{(r['part'],r['source_image']) for r in rows if r['split']==s} for s in ['train','validation','test']}
assert not(sets['train']&sets['test'] or sets['train']&sets['validation'] or sets['validation']&sets['test'])
print({s:sum(r['split']==s for r in rows) for s in sets})
