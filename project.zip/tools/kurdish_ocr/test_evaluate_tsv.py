"""Regression: a literal quote OCR token must never consume subsequent TSV rows."""
import unittest
from evaluate_fallback import parse_tsv
class TsvTests(unittest.TestCase):
 def test_literal_quote_keeps_subsequent_words_and_confidences(self):
  rows=parse_tsv('level\tconf\ttext\n5\t80\t"\n5\t90\tڕۆزەم\n5\t85\t7134\n')
  self.assertEqual([r['text'] for r in rows],['"','ڕۆزەم','7134'])
  self.assertEqual([float(r['conf']) for r in rows],[80,90,85])
 def test_empty_layout_rows_excluded(self):
  self.assertEqual(parse_tsv('level\tconf\ttext\n4\t-1\t\n'),[])
 def test_balanced_quotes_are_preserved(self):
  self.assertEqual(parse_tsv('level\tconf\ttext\n5\t85\t"ئۆلا"\n')[0]['text'],'"ئۆلا"')
if __name__=='__main__':unittest.main()
