"""Generate WordStr training files with visual bidi order (as tesstrain does)."""
import argparse,os,subprocess,unicodedata
from pathlib import Path
from PIL import Image
from bidi.algorithm import get_display
ap=argparse.ArgumentParser();ap.add_argument('crops',type=Path);ap.add_argument('tessdata',type=Path);a=ap.parse_args()
for p in sorted(a.crops.glob('*.png')):
    text=unicodedata.normalize('NFC',p.with_suffix('.gt.txt').read_text().strip())
    w,h=Image.open(p).size
    p.with_suffix('.box').write_text(f'WordStr 0 0 {w} {h} 0 #{get_display(text)}\n\t 0 0 {w} {h} 0\n',encoding='utf-8')
    subprocess.run(['tesseract',str(p),str(p.with_suffix('')),'--tessdata-dir',str(a.tessdata),'-l','ckb','--psm','13','-c','tessedit_train_line_recognizer=1','-c','tessedit_init_config_only=1'],check=True,env={**os.environ,'OMP_THREAD_LIMIT':'1'})
    if not p.with_suffix('.lstmf').is_file(): raise RuntimeError(f'No lstmf for {p}')
for split in ['train','validation','test']:
    ids=(a.crops/f'{split}.ids').read_text().split()
    (a.crops/f'{split}.list').write_text(''.join(str((a.crops/f'{n}.lstmf').resolve())+'\n' for n in ids))
