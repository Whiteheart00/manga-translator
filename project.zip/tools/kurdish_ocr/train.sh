#!/usr/bin/env bash
# Run with an extracted images/ + labels/ dataset. Requires Tesseract training tools,
# Python with requirements.txt, and the Noto/DejaVu font paths in augment.py.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
DATASET_DIR="$(realpath "${1:?Usage: train.sh DATASET_DIR WORK_DIR}")"
mkdir -p "${2:?Usage: train.sh DATASET_DIR WORK_DIR}"
WORK_DIR="$(realpath "$2")"
export OMP_THREAD_LIMIT=1
mkdir -p "$WORK_DIR/base" "$WORK_DIR/run" "$WORK_DIR/candidate" "$WORK_DIR/original"
BASE_FILE="$WORK_DIR/base/ckb.traineddata"
curl -fL --max-time 120 'https://raw.githubusercontent.com/Shreeshrii/tesstrain-ckb/bf3727a6fa59acf438679a065f867b1672e96654/data/ckbLayer.traineddata' -o "$BASE_FILE"
printf '%s  %s\n' 'b6c9d0fe10dc90b19451686ddd3829a92a202b564c77befdba8f9bac68152852' "$BASE_FILE" | sha256sum -c -
cp "$PROJECT_DIR/app/src/main/assets/ckb.traineddata" "$WORK_DIR/original/ckb.traineddata"
python "$SCRIPT_DIR/prepare.py" "$DATASET_DIR" "$WORK_DIR/crops"
python "$SCRIPT_DIR/prepare.py" "$DATASET_DIR" "$WORK_DIR/tight" --tight
python "$SCRIPT_DIR/make_lstmf.py" "$WORK_DIR/tight" "$WORK_DIR/base"
python "$SCRIPT_DIR/augment.py" "$DATASET_DIR" "$WORK_DIR/tight" "$PROJECT_DIR/app/src/main/assets/kurdish_vocab.txt" "$WORK_DIR/base" "$WORK_DIR/augmented"
combine_tessdata -e "$BASE_FILE" "$WORK_DIR/base/ckb.lstm"
lstmtraining --continue_from "$WORK_DIR/base/ckb.lstm" --traineddata "$BASE_FILE" --train_listfile "$WORK_DIR/augmented/train.list" --eval_listfile "$WORK_DIR/tight/validation.list" --model_output "$WORK_DIR/run/ckb" --learning_rate 0.0001 --max_iterations 1200 --target_error_rate 0.01 > "$WORK_DIR/run/train1200.log" 2>&1
lstmtraining --continue_from "$WORK_DIR/run/ckb_checkpoint" --traineddata "$BASE_FILE" --train_listfile "$WORK_DIR/augmented/train.list" --eval_listfile "$WORK_DIR/tight/validation.list" --model_output "$WORK_DIR/run/ckb" --learning_rate 0.0001 --max_iterations 3000 --target_error_rate 0.01 > "$WORK_DIR/run/train3000.log" 2>&1
lstmtraining --stop_training --convert_to_int --continue_from "$WORK_DIR/run/ckb_checkpoint" --traineddata "$BASE_FILE" --model_output "$WORK_DIR/candidate/ckb.traineddata"
python "$SCRIPT_DIR/prepare_app.py" "$WORK_DIR/crops" "$WORK_DIR/app-crops"
python "$SCRIPT_DIR/evaluate_fallback.py" "$WORK_DIR/app-crops" "$WORK_DIR/original" "$WORK_DIR/candidate" "$WORK_DIR/validation.json" --candidate-images "$WORK_DIR/crops"
python "$SCRIPT_DIR/evaluate_fallback.py" "$WORK_DIR/app-crops" "$WORK_DIR/original" "$WORK_DIR/candidate" "$WORK_DIR/test.json" --candidate-images "$WORK_DIR/crops" --split test
python "$SCRIPT_DIR/make_regression.py" "$WORK_DIR/regression"
python "$SCRIPT_DIR/evaluate_fallback.py" "$WORK_DIR/regression" "$WORK_DIR/original" "$WORK_DIR/candidate" "$WORK_DIR/regression.json" --split all
# Candidate is deliberately not copied into app assets. Review independent metrics.
