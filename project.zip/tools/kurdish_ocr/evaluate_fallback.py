"""Desktop approximation of confidence-gated base/subtitle fallback (no Kotlin filters)."""
import argparse,csv,io,json,os,subprocess
from pathlib import Path
from PIL import Image
from evaluate import normalize,distance

def parse_tsv(tsv):
    """Tesseract TSV uses literal quotes, not CSV-style quoted fields."""
    rows=list(csv.DictReader(io.StringIO(tsv),delimiter='\t',quoting=csv.QUOTE_NONE))
    return [r for r in rows if r.get('text','').strip() and r.get('conf','-1')!='-1']

def recognize(image,model):
    cmd=['tesseract',str(image),'stdout','--tessdata-dir',str(model),'-l','ckb','--psm','6','-c','tessedit_do_invert=0','-c','preserve_interword_spaces=1','-c','load_system_dawg=0','-c','load_freq_dawg=0','-c','tessedit_create_tsv=1']
    p=subprocess.run(cmd,capture_output=True,text=True,check=True,env={**os.environ,'OMP_THREAD_LIMIT':'1'})
    words=parse_tsv(p.stdout)
    conf=sum(float(r['conf']) for r in words)/max(1,len(words))
    # Tesseract TSV emits words in logical reading order for RTL.
    text=' '.join(r['text'] for r in words)
    return dict(text=text,confidence=conf)

def otsu_image(path,out):
    im=Image.open(path).convert('L');hist=im.histogram();total=sum(hist);summ=sum(i*v for i,v in enumerate(hist));sb=wb=0;best=0;th=127
    for t in range(256):
        wb+=hist[t]
        if not wb:continue
        wf=total-wb
        if not wf:break
        sb+=t*hist[t];v=wb*wf*(sb/wb-(summ-sb)/wf)**2
        if v>best:best=v;th=t
    im.point(lambda x:255 if x>th else 0).save(out)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('images',type=Path);ap.add_argument('original',type=Path);ap.add_argument('candidate',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--split',default='validation');ap.add_argument('--candidate-images',type=Path);a=ap.parse_args();results=[]
    for r in json.loads((a.images/'manifest.json').read_text())['samples']:
        if a.split!='all' and r['split']!=a.split:continue
        p=a.images/f"{r['id']:03}.png";original=recognize(p,a.original)
        if original['confidence']<58:
            binary=a.output.parent/f"binary-{r['id']:03}.png";otsu_image(p,binary);b=recognize(binary,a.original);binary.unlink()
            if b['confidence']>original['confidence']:original=b
        selected=original;candidate=None
        if original['confidence']<58:
            candidate=recognize((a.candidate_images/f"{r['id']:03}.png") if a.candidate_images else p,a.candidate)
            if candidate['confidence']>=35 and candidate['confidence']>original['confidence'] and sum('\u0600'<=c<='\u06ff' for c in candidate['text'])>=3:selected=candidate
        ref=normalize(r['text']);oh=normalize(original['text']);sh=normalize(selected['text'])
        results.append(dict(id=r['id'],split=r['split'],reference=r['text'],original=original,candidate=candidate,selected=selected,changed=selected is not original,chars=len(ref),original_errors=distance(ref,oh),selected_errors=distance(ref,sh),words=len(ref.split()),original_word_errors=distance(ref.split(),oh.split()),selected_word_errors=distance(ref.split(),sh.split())))
    def stats(rs):
        return dict(samples=len(rs),changed=sum(r['changed'] for r in rs),base_cer=sum(r['original_errors'] for r in rs)/max(1,sum(r['chars'] for r in rs)),fallback_cer=sum(r['selected_errors'] for r in rs)/max(1,sum(r['chars'] for r in rs)),base_wer=sum(r['original_word_errors'] for r in rs)/max(1,sum(r['words'] for r in rs)),fallback_wer=sum(r['selected_word_errors'] for r in rs)/max(1,sum(r['words'] for r in rs)))
    report=dict(limits='Desktop proxy for Android confidence gating; excludes MixedOcrFilter, vocab correction, early script gate, Kotlin integer confidence truncation. Synthetic corpus is a smoke check only.',summary=stats(results),samples=results)
    a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report['summary']))
if __name__=='__main__':main()
