"""Prepare reviewed single-line subtitle regions; never train on validation/test scenes."""
import argparse, hashlib, json
from pathlib import Path
from PIL import Image

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('dataset',type=Path); ap.add_argument('output',type=Path); ap.add_argument('--tight',action='store_true',help='Training line bounds without excess vertical margins'); a=ap.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    # Multi-line screenshots need line-specific transcription; four additional labels
    # visibly differ from the screen and are excluded rather than guessed.
    excluded={3,4,7,8,9,12,15,17,18,20,22,33,34,35}
    validation={21,23,24} # Same scene, entirely absent from training.
    test={26,27,28,29} # Classroom scene, entirely absent from training/selection.
    rows=[]
    for n in range(1,36):
        if n in excluded: continue
        p=a.dataset/'images'/f'{n:02}.png'; label=a.dataset/'labels'/f'{n:03}.txt'
        text=label.read_text('utf-8').strip()
        # Crop coordinates manually inspected on the 1080x2400 source images.
        box=(180,1483,900,1519) if a.tight else (180,1474,900,1530)
        im=Image.open(p).convert('RGB').crop(box)
        dest=a.output/f'{n:03}.png';im.save(dest)
        (a.output/f'{n:03}.gt.txt').write_text(text+'\n',encoding='utf-8')
        split='validation' if n in validation else 'test' if n in test else 'train'
        rows.append(dict(id=n,split=split,crop=list(box),text=text,image_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    manifest={'source':'https://github.com/Whiteheart00/For-chatgpt/blob/main/kurdish_ocr_dataset.zip','excluded_ids':sorted(excluded),'label_policy':'Original labels unchanged. Known suspect labels and all multiline samples excluded. Remaining labels are not certified ground truth.','samples':rows}
    (a.output/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    for split in ['train','validation','test']:
        (a.output/f'{split}.ids').write_text(''.join(f"{r['id']:03}\n" for r in rows if r['split']==split))
    print({s:sum(r['split']==s for r in rows) for s in ['train','validation','test']})
if __name__=='__main__': main()
