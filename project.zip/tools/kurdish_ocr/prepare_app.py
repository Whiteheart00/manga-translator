"""Desktop approximation of LocalKurdishOcr.prepare, primary grayscale pass.
Pillow bilinear scaling differs from Android Bitmap; post-filtering is not emulated.
"""
import argparse,shutil
from pathlib import Path
from PIL import Image,ImageOps

def prepare(im):
    im=im.convert('RGB'); m=max(im.size)
    k=min(2,900/m) if m<700 else 960/m if m>960 else 1
    sz=tuple(max(1,int(v*k)) for v in im.size)
    im=im.resize(sz,Image.Resampling.BILINEAR)
    vals=[(r*299+g*587+b*114)//1000 for r,g,b in im.getdata()]
    if sum(vals)//len(vals)<110: vals=[255-v for v in vals]
    hist=[0]*256
    for v in vals: hist[v]+=1
    lo=0;acc=0
    while lo<255 and acc+hist[lo]<len(vals)//100:acc+=hist[lo];lo+=1
    hi=255;acc=0
    while hi>0 and acc+hist[hi]<len(vals)//100:acc+=hist[hi];hi-=1
    if hi-lo<30:lo,hi=0,255
    gray=Image.new('L',sz);gray.putdata([max(0,min(255,(v-lo)*255//max(1,hi-lo))) for v in vals])
    return ImageOps.expand(gray,border=12,fill=255)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    for p in a.source.glob('*.png'): prepare(Image.open(p)).save(a.output/p.name)
    shutil.copy2(a.source/'manifest.json',a.output/'manifest.json')
