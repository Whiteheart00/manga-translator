# مانگا وەرگێڕ (Manga Live Translator) — Sorani Kurdish

وەرگێڕانی شاشەی مانگا بۆ **کوردیی سۆرانی**: OCR بە ML Kit لەسەر مۆبایل، وەرگێڕان بە Google Translate، و خوێندنەوەی دەقی وەرگێڕدراو بە **Google Gemini TTS**.

## دەستپێکردن
1. «ڕێگەپێدانی پیشاندان» چالاک بکە.
2. «دەستپێکردن» دابگرە و ڕێگەپێدانی گرتنی شاشە قبوڵ بکە.
3. بچۆ ئەپی مانگاکەت. بابلەکان:
   - **ک** = وەرگێڕانی خۆکار؛ دابگرە (سەوز = چالاک).
   - **وەر** = وەرگێڕانی شاشەی ئێستا؛ درێژ دایبگرە بۆ شاردنەوەی وەرگێڕان.
   - **دەنگ** = خوێندنەوەی وەرگێڕانەکانی شاشە بە دەنگ؛ دووبارە دایبگرە یان درێژ بگرە بۆ وەستاندن.
4. لە «٥. ڕێکخستنی دەنگ» کلیلی **Gemini API** دابنێ و یەکێک لە دەنگەکان هەڵبژێرە. دەتوانیت «تاقیکردنەوە» دابگریت.
5. ئەگەر دەتەوێت دەقی شاشە دوای تەواوبوونی وەرگێڕانی دەستی خۆکارانە بخوێندرێتەوە، خانەی خۆکارخوێندنەوە چالاک بکە. بۆ خوێندنەوەی دەستی، دوگمەی **دەنگ** بەکاربهێنە.

## کلیلی Gemini و بەکارهێنانی خۆڕایی
- کلیلی TTS لە [Google AI Studio](https://aistudio.google.com/api-keys) وەربگرە و لە ڕێکخستنی دەنگی ئەپەکەدا دایبنێ.
- کلیلی TTS **جیاوازە** لە کلیلی Google Translate.
- ئەپەکە `gemini-3.8-flash-tts` بەکاردێنێت. Google Gemini API لە Free Tier ـدا نرخ بۆ ئەم مۆدێلە نیشان نادات/خۆڕاییە، بەڵام **سنووری quota و rate limit** هەیە و دەکرێت بگۆڕێت. زانیاریی نوێ لە [خشتەی نرخی Gemini API](https://ai.google.dev/gemini-api/docs/pricing) ببینە.
- زمانەکە لە Gemini دا «Central Kurdish» ناونراوە و لە TTS پشتیوانی دەکرێت؛ داواکارییەکان بە ئینتەرنێت دەنێردرێن.
- کلیلی Gemini لە خودی ئەپەکەدا لە SharedPreferences هەڵدەگیرێت؛ کلیلی خۆت لە APK ی گشتی یان کۆدی بڵاوکراوەدا مەخە.

## تێبینیی تەکنیکی
- OCR بە ML Kit لەسەر مۆبایلەکە ئەنجام دەدرێت؛ تەنها دەقی وەرگێڕان بۆ Google دەنێردرێت.
- دەقە وەرگێڕدراوەکان بۆ یەک داواکاری TTS کۆدەکرێنەوە بۆ کەمکردنەوەی API calls.
- Android 14+: هەر جارێک دەبێت ڕێگەپێدانی گرتنی شاشە دووبارە بدرێت.
- ئەپەکانی `FLAG_SECURE` وێنەی ڕەش دەدەن و ناگیرێن.


## دوو دۆخ (لە شاشەی سەرەکی هەڵبژێرە، پێش «دەستپێکردن»)
**دۆخی کۆن** وەک خۆی ماوەتەوە: بابلەکانی «ک» و «وەر» و «دەنگ».

**دۆخی نوێ** دوو بابلی هەیە:

### «ڕ» — ڕووبەر
1. بابلی **ڕ** دابگرە؛ شاشە کەمێک تاریک دەبێت.
2. بە پەنجە ئەو ڕووبەرە بکێشە کە دەتەوێت بخوێنرێتەوە (✕ = پاشگەزبوونەوە).
3. ئەپەکە ئەو ڕووبەرە دەگرێت و بە **Gemini** دەیخوێنێتەوە و دەیکات بە سۆرانی؛ **هەموو زمانێک** پشتیوانی دەکرێت.
4. وەرگێڕانەکە لەسەر ڕووبەرەکە دەنووسرێت و خۆکارانە بە دەنگی کوردی دەخوێنرێتەوە.
5. ئەگەر دەقەکە **خۆی کوردیی سۆرانی** بوو، وەرناگێڕدرێت و تەنها دەخوێنرێتەوە.
6. درێژ گرتنی «ڕ» = شاردنەوەی وەرگێڕان و وەستاندنی دەنگ.

### «قسە» — قسەکردن بۆ نووسین
1. بابلی **قسە** دابگرە و بە کوردی قسە بکە (تا ٦٠ چرکە).
2. دووبارە دایبگرە بۆ تەواوکردن.
3. قسەکەت بە **Gemini** دەنووسرێت (سۆرانی، پیتی عەرەبی) و لە کارتێکدا نیشان دەدرێت و **خۆکارانە کۆپی دەکرێت**؛ لە هەر ئەپێک (واتسئەپ، تێلێگرام...) دایبنێ (Paste). «🔊 بیخوێنەوە» دەقەکە دەخوێنێتەوە.
ڕێگەپێدانی مایک پێویستە (لە کاتی دەستپێکردن داوا دەکرێت).

کلیلی Gemini API لە «ڕێکخستنی دەنگ» دادەنرێت. دەتوانیت ٢ یان ٣ کلیل بنووسیت (هەر یەکێک لە دێڕێک)؛ بە نۆرە بەکاردێن و ئەگەر یەکێک تەواو بوو (429) دەچێتە سەر ئەوی تر.

## خێرایی (دۆخی نوێ)
- «دۆخی خێرا» (لە «ڕێکخستنی دەنگ»، بە خۆکار چالاکە): مۆدێلی سووکتر بۆ خوێندنەوەی وێنە و دەنگ بەکاردێت.
- دەقی کوردی دەکرێتە ڕستە ڕستە و هەموو ڕستەکان پێکەوە (بە هەموو کلیلەکان) دەنگیان بۆ دروست دەکرێت؛ یەکەم ڕستە کە ئامادە بوو دەستبەجێ دەپەخشرێت.
- وەرگێڕانەکە لەسەر شاشە دەرەکەوێت پێش ئەوەی دەنگەکە ئامادە بێت.
- کاتی گرتنی شاشە لە ٣٥٠ms بۆ ١٢٠ms کەم کراوە.

## خوێندنەوەی ئۆفلاین (بێ ئینتەرنێت)
- لە «ڕێکخستنی دەنگ» خانەی «خوێندنەوەی ئۆفلاین» چالاک بکە و دەنگەکە هەڵبژێرە: **Piper نیورالی** (بنەڕەت)، **ئینگلیزی**، **عەرەبی** یان **تورکی** (کۆن).
- دەقی کوردی بە `KurdishVoiceText.kt` دەگۆڕدرێت بۆ نووسینێک کە دەنگی هەڵبژێردراو نزیک لە کوردی بیخوێنێتەوە (ئینگلیزی: sh, ch, kh, oo, ee... ؛ عەرەبی: پ←ب، چ←تش، ڕ←ر...؛ فارسی: ڕ←ر، ڵ←ل، ێ←ی، ڤ←و...). کلیلی Gemini پێویست نییە.
- پێویستە دەنگەکە دابەزێنرابێت: Settings ← Text-to-speech ← Google ← Install voice data ← Persian (فارسی) یان English یان Arabic.
- سنوور: ئەندرۆید دەنگی کوردیی ئۆفلاینی نییە، بۆیە کوردییەکە نزیکە و وردی Gemini ی نییە. وەرگێڕان (Google) و خوێندنەوەی ڕووبەر (Gemini) هێشتا ئینتەرنێت پێویستە؛ تەنها خوێندنەوەی دەنگی دەقی کوردی ئۆفلاین دەبێت.

## دەنگی کوردیی نیورالی (Piper / ONNX) — ئۆفلاین، کوالێتی بەرز
مۆدێلی Piper ی کوردیی سۆرانی (دەنگی Berfin، `model.onnx` + `model.onnx.json`) پیتی کوردی ڕاستەوخۆ دەخوێنێتەوە، بێ espeak و بێ گۆڕینی پیت. بە `onnxruntime-android` کار دەکات (لە Gradle خۆکارانە دادەبەزێت، AAR ی دەستی پێویست نییە).

بەکارهێنان:
1. ئەپەکە بنیات بنێ و دایبمەزرێنە.
2. «ڕێکخستنی دەنگ» ← خانەی «خوێندنەوەی ئۆفلاین» چالاک بکە ← «کوردیی نیورالی (Berfin، ONNX)» هەڵبژێرە.
3. دوگمەی «هێنانی مۆدێلی کوردی» دابگرە و zip ی مۆدێلەکە (`kurdish_onnx_model.zip`) یان فایلەکانی `model.onnx` و `model.onnx.json` هەڵبژێرە. مۆدێلەکە دەکرێتە ناو فۆڵدەری ناوخۆیی ئەپەکە، بۆیە پێویست ناکات لە ریپۆ دایبنێیت.
4. «هەڵگرتن» ← «تاقیکردنەوە».

تێبینی: ئەم دۆخە ئینتەرنێت و کلیلی Gemini و دەنگی سیستەم پێویست ناکات.

## نووسینی ئۆفلاینی کوردی (Vekol STT)

- فایلەکان: `VekolStt.kt` + `assets/mel_filters.bin`
- مۆدێل: `RevgeAI/vekol-stt-ckb-base` (Whisper-base ی fine-tune کراو بۆ سۆرانی، ONNX)، نزیکەی ٢٩١ مێگابایت
- لە APK دا نییە؛ لە ڕێکخستنەکانی ئەپ دوگمەی «دابەزاندنی مۆدێلی کوردی» یەکجار دایدەبەزێنێت بۆ `filesDir`
- مۆڵەت: **CC-BY-NC 4.0** (تەنها بۆ بەکارهێنانی نا-بازرگانی). سەرچاوە: https://github.com/Revge/vekol-stt-ckb-edge
- ئەگەر چالاک بێت و مۆدێلەکە دابەزێندرابێت، دوگمەی «قسە» بێ ئینتەرنێت دەنووسێت؛ ئەگەرنا Gemini بەکاردێت


## Accessibility update (v1.1.0)

- On the main screen, the first-run literacy choice offers **1 = literate** and **2 = non-literate**. The selected choice is stored locally and can be changed later from the main screen.
- The offline Sorani Piper voice is downloaded automatically when an internet connection is available. If the voice is still downloading when a non-literate user chooses their mode, the welcome announcement is queued and played when the model is ready.
- In non-literate mode, completed manual screen translations are automatically read aloud even if the normal auto-speak preference is off. The floating speech bubble can still be tapped again to stop/replay according to the existing controls.
- The main screen includes a repeat-reading control for the latest spoken help message.

**Important limitations:** the initial voice model download requires internet, and translation/OCR capabilities vary by mode and configuration. Fully offline translation of arbitrary screen text is not guaranteed; the offline voice only provides speech synthesis for text that the app has already obtained. The Android APK build and runtime behavior must be verified on a device or CI build before distribution.
