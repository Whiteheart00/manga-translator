package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveSubtitleLedgerTest {
    @Test fun unrelatedNonblankLineIsNeverAbsentAndTerminalStatesCannotRegress() {
        val l = LiveSubtitleLedger()
        l.observe("First.", 0); val b = l.observe("Second.", 10).single()
        assertFalse(l.isAbsent)
        l.state(b.id, LiveSubtitleLedger.State.COMPLETE)
        l.state(b.id, LiveSubtitleLedger.State.READY)
        assertEquals(LiveSubtitleLedger.State.COMPLETE, l.segments[b.id]?.state)
        l.observe("", 20); l.observe("", 250); assertTrue(l.isAbsent)
        l.reset(); assertFalse(l.isAbsent)
    }

    @Test fun cjkGrowthEmitsOnlyNewCharacters() {
        val l = LiveSubtitleLedger()
        l.observe("今天。", 0)
        assertEquals("下雨了。", l.observe("今天下雨了。", 100).single().text)
    }

    @Test fun cumulativeTextProducesOnlyFreshWordsWhilePlaying() {
        val l = LiveSubtitleLedger()
        val a = l.observe("Hello everyone.", 0).single()
        l.state(a.id, LiveSubtitleLedger.State.PLAYING)
        val b = l.observe("Hello everyone. Welcome home.", 50).single()
        assertEquals("Welcome home.", b.text)
        assertTrue(b.continuation)
        assertEquals(LiveSubtitleLedger.State.PLAYING, a.state)
        assertTrue(l.observe("Hello everyone. Welcome home.", 100).isEmpty())
    }
    @Test fun rollingTwoLinesDoNotRepeatSharedTail() {
        val l = LiveSubtitleLedger()
        l.observe("We are here. Go home.", 0)
        assertEquals("Take care.", l.observe("Go home. Take care.", 30).single().text)
    }
    @Test fun genuineSameWordsAfterConfirmedBlankAreNewOccurrence() {
        val l = LiveSubtitleLedger()
        val first = l.observe("Yes!", 0).single()
        l.observe("", 10); l.observe("", 200)
        val next = l.observe("Yes!", 250).single()
        assertNotEquals(first.occurrence, next.occurrence)
    }
    @Test fun transientEmptyAndTruncatedOcrDoNotReplay() {
        val l = LiveSubtitleLedger()
        l.observe("Hello my friend.", 0)
        l.observe("", 10)
        assertTrue(l.observe("Hello my friend.", 60).isEmpty())
        assertTrue(l.observe("Hello my", 100).isEmpty())
        assertNull(l.settle(1000))
    }
    @Test fun stableShorterPrefixBecomesANewSubtitle() {
        val l = LiveSubtitleLedger()
        val first = l.observe("Hello my friend.", 0).single()
        assertTrue(l.observe("Hello", 10).isEmpty())
        val next = l.observe("Hello", 200).single()
        assertEquals("Hello", next.text)
        assertNotEquals(first.occurrence, next.occurrence)
    }
    @Test fun shortSemanticChangesAreNotFuzzyDuplicates() {
        val l = LiveSubtitleLedger()
        assertEquals("I can.", l.observe("I can.", 0).single().text)
        assertEquals("I can't.", l.observe("I can't.", 10).single().text)
        assertEquals("She is.", l.observe("She is.", 20).single().text)
        assertEquals("He is.", l.observe("He is.", 30).single().text)
    }
    @Test fun growthSettlesAfter180msWithoutWaitingForNextLine() {
        val l = LiveSubtitleLedger()
        assertTrue(l.observe("Hello", 0).isEmpty())
        assertTrue(l.observe("Hello my friend", 100).isEmpty())
        assertNull(l.settle(279))
        assertEquals("Hello my friend", l.settle(280)?.text)
    }
    @Test fun newLineFlushesPendingTextInOrder() {
        val l = LiveSubtitleLedger()
        l.observe("First short line", 0)
        val segments = l.observe("Different line.", 80)
        assertEquals(listOf("First short line", "Different line."), segments.map { it.text })
    }
    @Test fun failuresAreNotCompletedAndRegionChangeStartsNewOccurrence() {
        val l = LiveSubtitleLedger()
        val a = l.observe("Hello.", 0, "top").single()
        l.state(a.id, LiveSubtitleLedger.State.FAILED)
        val b = l.observe("Hello.", 10, "bottom").single()
        assertNotEquals(a.occurrence, b.occurrence)
        assertEquals(LiveSubtitleLedger.State.FAILED, a.state)
        assertEquals(LiveSubtitleLedger.State.CONFIRMED, b.state)
    }
    @Test fun pauseResetDoesNotRememberOldAudio() {
        val l = LiveSubtitleLedger()
        l.observe("Current screen.", 0)
        l.reset()
        assertEquals("Current screen.", l.observe("Current screen.", 100).single().text)
    }
    @Test fun numbersNamesAndSoraniArePreserved() {
        val l = LiveSubtitleLedger()
        l.observe("سڵاو ئارام.", 0)
        assertEquals("ژمارە ١٢٣!", l.observe("سڵاو ئارام. ژمارە ١٢٣!", 10).single().text)
    }
}
