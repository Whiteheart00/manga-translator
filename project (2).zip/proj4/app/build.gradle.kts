plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mangatranslator.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mangatranslator.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 36
        versionName = "1.3.29"

        // تەنها مۆبایلی ٦٤ بیت: APK بچووکتر دەبێت
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    // ناوی APK ـەکە
    applicationVariants.all {
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName = "وەڕگێڕی_شاشە.apk"
        }
    }

    // واژۆ: لە GitHub Actions کلیلی نوێی "manga" (لە secrets) بەکاردێت؛ بێ ئەو، debug.keystore ی کۆن (بیلدی ناوخۆیی).
    // ئاگاداری: گۆڕینی واژۆ = APK ی نوێ لەسەر ئەپە کۆنەکە دانابەزێت، دەبێت ئەپە کۆنەکە بسڕدرێتەوە.
    val mangaKeystore: String? = System.getenv("ANDROID_KEYSTORE_FILE")?.takeIf { file(it).exists() }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        if (mangaKeystore != null) {
            create("manga") {
                storeFile = file(mangaKeystore)
                storePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ANDROID_KEY_ALIAS") ?: "manga"
                keyPassword = System.getenv("ANDROID_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            if (mangaKeystore != null) signingConfig = signingConfigs.getByName("manga")
        }
        release {
            isMinifyEnabled = false
            if (mangaKeystore != null) signingConfig = signingConfigs.getByName("manga")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // مۆدێلە ONNX ـەکان لە APK دا فشار نادرێن (خێراتر)
    androidResources {
        noCompress += listOf("onnx")
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")

    // کۆروتین بۆ وەرگێڕان (هەڵوەشاندنەوە و کۆدی ڕیزبەند)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // دەنگی نیورالی Piper/VITS (ONNX) بە onnxruntime
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")

    // OCR ئۆفلاین بۆ پیتی لاتین (ئینگلیزی)
    implementation("com.google.mlkit:text-recognition:16.0.0")
    // OCR ئۆفلاین بۆ چینی، جاپانی و کۆری
    implementation("com.google.mlkit:text-recognition-chinese:16.0.0")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.0")
    implementation("com.google.mlkit:text-recognition-korean:16.0.0")
    implementation("com.google.mlkit:text-recognition-devanagari:16.0.0")

    // ناسینەوەی خێرای کوردیی سۆرانی لەسەر مۆبایل (Tesseract، زمانی ckb)
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.7.0")

    // تێستی یەکە (JVM)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")   // org.json ی Android لە تێستی JVM دا هەڵدەدات
}
