Offline neural voice clarity update

Replaced the cascaded exponential low-pass in PiperTts with a second-order Butterworth filter at the user-selected cutoff. The old filter reduced a 6 kHz tone to about 0.707 amplitude even with a 7 kHz setting; the replacement retains more than 0.85. This reduces unnecessary attenuation of consonant detail without presence boost. DC removal, peak-limited RMS normalization, explicit softness controls, inference settings, and pitch are retained. The separate female-reference recipe is unchanged. PCM cache version bumped to v5.

Validation: 8 JVM tests passed (PiperClarityFilterTest and VoiceShaperTest), covering passband detail, -3 dB cutoff, high-frequency attenuation, explicit cutoff behavior, DC rejection, untouched end pause, silence and short buffers. These are objective signal tests, not a listening or pronunciation assessment. No Android APK or device test was run. Synthetic filtering cannot repair pronunciation errors in the source model. Includes prior live OCR and current-screen Resume fixes.

Download source inspected: https://github.com/Whiteheart00/manga-translator/releases/download/v1.0.1/kurdish_onnx_model.zip
