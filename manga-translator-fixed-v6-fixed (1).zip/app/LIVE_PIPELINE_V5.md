# Live subtitles v5 — 1.3.36 (43)

## Implemented behavior
- An occurrence ledger replaces global fuzzy sentence history. Exact word-boundary cumulative and rolling overlap emits only the new suffix. A confirmed blank, unrelated dialogue, orientation or major text-position change creates a new occurrence. Temporary truncated OCR prefixes do not replay accepted text. CJK growth and Sorani word-box ordering are handled.
- Incomplete growing text settles after 180 ms without a change; sentence-ending punctuation releases immediately. Pending text is flushed on a new line or blank. Capture/OCR scheduling from v4 is retained, and OCR results enter the worker before its busy flag is released. Old orientation results are rejected.
- Translation has two primary attempts, then one available alternate service. This fallback applies to live subtitles even for a single-provider selection; the UI explains it. Continuations carry the full source and the previous translated span as context. Only validated successes enter the cache. Final failures are explicit events, never completed speech.
- Offline neural live speech uses one persistent Piper stream and AudioTrack. New suffixes synthesize behind current audio without canceling it. The PCM queue remains bounded; text is retained in order. Backlog boost increases by 0.06 per pending segment to a maximum of 1.25. There is no age-based text dropping.
- Live clip boundaries retain at most 80 ms after commas and 180 ms after sentence endings, with 5-ms fades. No artificial pause or terminal period is appended to continuation text. Interior word pauses are never removed. Existing silence inside a generated clause is not shortened. Normal non-live/Pawan behavior is retained.
- Audio progress follows playback-head frames. Written/possibly played segments are not replayed after failure; unsubmitted segments may retry once. Pause cancels the old session and Resume reads the current screen. PCM cache format is v6.
- The selected OCR region is authoritative. The old duration/fuzzy watermark blacklist is removed from live capture because it could erase dialogue. Select a tight subtitle region to avoid unrelated labels; explicit name exclusions still apply.

## Timing export without screen recording
Open voice settings and select «هەڵگرتنی تۆماری کاتی ژێرنووسی زیندوو» (the timing-export button), then choose a CSV location. It exports the active or latest stopped session. IDs and monotonic event times only: observed capture/OCR start, OCR completed, confirmed, translated, PCM ready, playback started/completed, retry/failure/cancel outcomes. Median and p95 values are computed from available matching events. The bounded report keeps the latest 2000 events. The button label may use «تۆماری کاتی» with export wording.

The observed timestamp is the capture submitted to OCR, not an exact timestamp of when YouTube painted a subtitle. Playback-head measurements do not include Bluetooth/acoustic output delay. Do not describe these numbers as actual video-to-ear latency.

## Verification
397 JVM tests in 58 suites passed with zero failures/errors/skips. Android debug Kotlin compilation, release compilation, release vital lint and assembleRelease succeeded using Gradle 8.9 and SDK 34. Temporary build-only repository/proxy configuration was used to reach dependencies; project repository configuration was retained. Test XML, build log and source patch are supplied separately.

The release APK is UNSIGNED and cannot be installed as delivered. No original signing key was supplied, so no substitute identity was generated. The included GitHub workflow runs tests and builds the debug APK with the existing original signing-key secret ANDROID_DEBUG_KEYSTORE_BASE64; its certificate check is retained. A signed update must use that original key. Version code is now 43.

## Device acceptance still required
1. Play https://youtu.be/retu9BCynLs with the selected region around subtitles; verify at least 20 changes, including a moving background. Export timings after the run.
2. Verify A -> A B -> B C while A is playing: no interruption, no duplicate A, suffixes remain ordered. Check a genuine repeated short line after a blank and after unrelated dialogue.
3. Check Kurdish right-to-left words, Latin mixed text, names, numerals, CJK, very short speech and repeated commas. Listen for clipped consonants and boundary clicks.
4. Pause during synthesis and during playback, then resume on changed and unchanged screens. No pre-pause queue may replay.
5. Temporarily lose network access. Failed translations must be visible in the report; restoration must allow later segments. Long/slow runs may accumulate text backlog because preserving every recognized segment takes precedence over video synchronization.

No phone, emulator, listening study, real-provider latency run or YouTube end-to-end test was performed. Text never captured by OCR cannot be recovered by queue logic. OCR mistakes, source-model pronunciation and ambiguous overlap remain possible; this is not a zero-error guarantee. Synthesis or audio-device failure may leave an unspoken tail, recorded as failure rather than replaying partly heard speech.
