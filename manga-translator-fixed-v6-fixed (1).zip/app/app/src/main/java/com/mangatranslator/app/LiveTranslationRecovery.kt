package com.mangatranslator.app

/** Two primary attempts, then one fallback. Invalid/null output is a failure. */
internal object LiveTranslationRecovery {
    fun run(active: () -> Boolean, primary: () -> String?, fallback: () -> String?,
            retry: () -> Unit = {}): String? {
        repeat(2) { attempt ->
            if (!active()) return null
            try { primary()?.takeIf { it.isNotBlank() }?.let { return it } }
            catch (e: InterruptedException) { throw e }
            catch (_: Exception) {}
            if (attempt == 0) retry()
        }
        if (!active()) return null
        return try { fallback()?.takeIf { it.isNotBlank() } }
        catch (e: InterruptedException) { throw e }
        catch (_: Exception) { null }
    }
}
