package com.mangatranslator.app

import java.io.*
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.UUID
import java.util.zip.CRC32

internal enum class LiveWorkState { QUEUED, TRANSLATING, FAILED_RETRYABLE, TRANSLATED, AUDIO_QUEUED, READY, PLAYING, COMPLETE, FAILED_AUDIO, CANCELLED }
internal data class LiveWork(
    val id: Long, val occurrence: Long, val source: String, val fullSource: String,
    val continuation: Boolean, val observed: Long, val ocrCompleted: Long,
    val provider: String, val context: List<String> = emptyList(),
    val state: LiveWorkState = LiveWorkState.QUEUED, val translated: String = "",
    val attempts: Int = 0, val retryAt: Long = 0, val audioRetries: Int = 0,
    val audioText: String = "", val members: List<Long> = emptyList(), val chunks: List<String> = emptyList(),
    val submittedThrough: Int = -1, val completedThrough: Int = -1,
    val uncertainThrough: Int = -1, val outcome: String = "", val failedThrough: Int = -1
)

/** Session-only private spool. Atomic CRC-protected records and a bounded hot cache. */
internal class LiveSessionStore(
    root: File, private val maxBytes: Long = 50L * 1024 * 1024,
    private val freeBytes: (File) -> Long = { it.usableSpace },
    private val beforeCommit: () -> Unit = {}
) : Closeable {
    companion object {
        private val active = HashSet<String>()
        private const val MAGIC = 0x4c565336
        private const val MAX_FIELD = 256 * 1024
        private const val MAX_RECORD = 512 * 1024
        fun cleanupOrphans(root: File) = synchronized(active) {
            root.listFiles()?.filter { it.name.startsWith("session-") && it.absolutePath !in active }
                ?.forEach { it.deleteRecursively() }
        }
    }
    val directory: File
    private var bytes = 0L
    private var closed = false
    private val hot = object : LinkedHashMap<Long, LiveWork>(64, .75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<Long, LiveWork>?) = size > 64
    }
    init {
        synchronized(active) {
            check(root.mkdirs() || root.isDirectory)
            cleanupOrphans(root)
            directory = File(root, "session-${UUID.randomUUID()}")
            check(directory.mkdir())
            active.add(directory.absolutePath)
        }
    }
    private fun weight(r: LiveWork): Long = 2L * (r.source.length.toLong() + r.fullSource.length +
        r.translated.length + r.audioText.length + r.context.sumOf { it.length.toLong() } + r.chunks.sumOf { it.length.toLong() })
    private fun cache(r: LiveWork) {
        hot[r.id] = r
        while (hot.isNotEmpty() && hot.values.sumOf(::weight) > 2L * 1024 * 1024) {
            val it = hot.entries.iterator(); it.next(); it.remove()
        }
    }
    @Synchronized fun cachedBytes() = hot.values.sumOf(::weight)
    @Synchronized fun cachedRecords() = hot.size
    @Synchronized fun sizeBytes() = bytes
    @Synchronized fun put(record: LiveWork) {
        check(!closed) { "session closed" }
        val data = encode(record)
        val target = File(directory, "${record.id}.rec")
        val oldSize = target.length()
        val reserve = minOf(1024L * 1024, maxBytes / 10)
        val limit = if (target.exists()) maxBytes else maxBytes - reserve
        if (bytes - oldSize + data.size > limit || freeBytes(directory) < data.size + reserve)
            throw IOException("session storage full")
        val temp = File(directory, "${record.id}.tmp")
        try {
            FileOutputStream(temp).use { it.write(data); it.fd.sync() }
            beforeCommit()
            try { Files.move(temp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) {
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            bytes = bytes - oldSize + data.size
            cache(record)
        } finally { temp.delete() }
    }
    @Synchronized fun get(id: Long): LiveWork? {
        check(!closed) { "session closed" }
        hot[id]?.let { return it }
        val file = File(directory, "$id.rec")
        if (!file.exists()) return null
        if (file.length() > MAX_RECORD + 12) throw IOException("oversized spool record")
        return decode(file.readBytes()).also(::cache)
    }
    @Synchronized fun remove(id: Long) {
        check(!closed)
        val file = File(directory, "$id.rec"); val size = file.length()
        if (file.exists() && !file.delete()) throw IOException("cannot acknowledge spool record")
        bytes -= size; hot.remove(id)
    }
    @Synchronized override fun close() {
        if (closed) return
        closed = true; hot.clear()
        synchronized(active) {
            directory.deleteRecursively(); active.remove(directory.absolutePath)
        }
    }
    private fun encode(r: LiveWork): ByteArray {
        if (weight(r) > MAX_RECORD / 2) throw IOException("oversized subtitle record")
        val buffer = ByteArrayOutputStream()
        DataOutputStream(buffer).use { out ->
            fun str(s: String) { val b = s.toByteArray(Charsets.UTF_8); require(b.size <= MAX_FIELD); out.writeInt(b.size); out.write(b) }
            fun strings(values: List<String>) { require(values.size <= 4096); out.writeInt(values.size); values.forEach(::str) }
            out.writeInt(MAGIC); out.writeLong(r.id); out.writeLong(r.occurrence)
            str(r.source); str(r.fullSource); out.writeBoolean(r.continuation)
            out.writeLong(r.observed); out.writeLong(r.ocrCompleted); str(r.provider); strings(r.context)
            out.writeInt(r.state.ordinal); str(r.translated); out.writeInt(r.attempts); out.writeLong(r.retryAt)
            out.writeInt(r.audioRetries); str(r.audioText); out.writeInt(r.members.size); r.members.forEach(out::writeLong)
            strings(r.chunks); out.writeInt(r.submittedThrough); out.writeInt(r.completedThrough); out.writeInt(r.uncertainThrough); str(r.outcome); out.writeInt(r.failedThrough)
        }
        val data = buffer.toByteArray()
        if (data.size > MAX_RECORD) throw IOException("oversized subtitle record")
        return ByteArrayOutputStream().also { b -> DataOutputStream(b).use {
            it.writeInt(data.size); it.write(data); it.writeLong(CRC32().apply { update(data) }.value)
        } }.toByteArray()
    }
    private fun decode(bytes: ByteArray): LiveWork {
        if (bytes.size < 12) throw IOException("truncated spool record")
        val outer = DataInputStream(ByteArrayInputStream(bytes))
        val size = outer.readInt()
        if (size != bytes.size - 12 || size < 0) throw IOException("invalid spool length")
        val payload = ByteArray(size); outer.readFully(payload)
        if (outer.readLong() != CRC32().apply { update(payload) }.value) throw IOException("spool checksum mismatch")
        val input = DataInputStream(ByteArrayInputStream(payload))
        fun count(): Int = input.readInt().also { if (it !in 0..4096) throw IOException("invalid spool count") }
        fun str(): String { val n = input.readInt(); if (n !in 0..MAX_FIELD || n > input.available()) throw IOException("invalid spool field"); val b = ByteArray(n); input.readFully(b); return b.toString(Charsets.UTF_8) }
        fun strings() = List(count()) { str() }
        if (input.readInt() != MAGIC) throw IOException("invalid spool version")
        val id = input.readLong(); val occurrence = input.readLong(); val source = str(); val full = str()
        val cont = input.readBoolean(); val observed = input.readLong(); val ocr = input.readLong()
        val provider = str(); val context = strings(); val ordinal = input.readInt()
        val state = LiveWorkState.values().getOrNull(ordinal) ?: throw IOException("invalid spool state")
        val translated = str(); val attempts = input.readInt(); val retryAt = input.readLong(); val audioRetries = input.readInt()
        val audioText = str(); val members = List(count()) { input.readLong() }; val chunks = strings()
        val submitted = input.readInt(); val completed = input.readInt(); val uncertain = input.readInt(); val outcome = str(); val failed = input.readInt()
        if (input.available() != 0) throw IOException("spool trailing data")
        return LiveWork(id, occurrence, source, full, cont, observed, ocr, provider, context, state, translated,
            attempts, retryAt, audioRetries, audioText, members, chunks, submitted, completed, uncertain, outcome, failed)
    }
}
