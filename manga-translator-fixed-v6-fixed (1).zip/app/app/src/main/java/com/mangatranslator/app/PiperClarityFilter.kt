package com.mangatranslator.app

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** DC removal and a Butterworth low-pass with an actual -3 dB cutoff.
 * Keeps consonant detail below the selected cutoff without adding presence gain.
 */
internal object PiperClarityFilter {
    fun apply(samples: FloatArray, length: Int, rate: Int, cutoffHz: Float) {
        val n = length.coerceIn(0, samples.size)
        if (n == 0 || rate <= 0) return
        val cutoff = (if (cutoffHz.isFinite()) cutoffHz.toDouble() else 7000.0)
            .coerceIn(1.0, maxOf(1.0, rate * 0.45))
        val omega = 2.0 * PI * cutoff / rate
        val c = cos(omega)
        val alpha = sin(omega) / sqrt(2.0)
        val a0 = 1.0 + alpha
        val b0 = (1.0 - c) / (2.0 * a0)
        val b1 = (1.0 - c) / a0
        val a1 = -2.0 * c / a0
        val a2 = (1.0 - alpha) / a0
        var previousInput = 0.0
        var previousDc = 0.0
        var z1 = 0.0
        var z2 = 0.0
        for (i in 0 until n) {
            val input = samples[i].toDouble()
            val dc = input - previousInput + 0.995 * previousDc
            previousInput = input
            previousDc = dc
            val output = b0 * dc + z1
            z1 = b1 * dc - a1 * output + z2
            z2 = b0 * dc - a2 * output
            samples[i] = output.toFloat()
        }
    }
}
