package com.mangatranslator.app

/** No text, API keys, URLs or audio in the export. Monotonic times only. */
internal class LiveTiming(private val capacity: Int = 2000) {
    data class Event(val segment: Long, val stage: String, val elapsedMs: Long)
    private val events = ArrayDeque<Event>()
    @Synchronized fun mark(id: Long, stage: String, time: Long) {
        events.addLast(Event(id, stage, time))
        while (events.size > capacity) events.removeFirst()
    }
    @Synchronized fun csv(): String {
        val rows = events.toList()
        val summary = ArrayList<Event>()
        val groups = rows.groupBy { it.segment }
        for ((name, pair) in mapOf(
            "ocr" to ("observed" to "ocr_completed"),
            "translation" to ("ocr_confirmed" to "translated"),
            "audio_ready" to ("translated" to "pcm_ready"),
            "total" to ("observed" to "playback_started"))) {
            val values = groups.values.mapNotNull { group ->
                val from = group.firstOrNull { it.stage == pair.first }?.elapsedMs
                val to = group.firstOrNull { it.stage == pair.second }?.elapsedMs
                if (from != null && to != null && to >= from) to - from else null
            }.sorted()
            if (values.isNotEmpty()) for (percent in listOf(50, 95)) {
                val index = ((values.size * percent + 99) / 100 - 1).coerceIn(0, values.lastIndex)
                summary.add(Event(0, "${name}_p${percent}_ms", values[index]))
            }
        }
        return "segment,stage,elapsed_ms\n" + (rows + summary).joinToString("\n") {
            "${it.segment},${it.stage},${it.elapsedMs}"
        }
    }

}

internal object LiveTimingExport {
    @Volatile var active: LiveTiming? = null
    fun report(): String = active?.csv() ?: last
    @Volatile var last: String = "segment,stage,elapsed_ms\n"
}
