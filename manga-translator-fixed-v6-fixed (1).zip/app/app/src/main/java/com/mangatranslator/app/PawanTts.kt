package com.mangatranslator.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

/**
 * خوێندنەوەی کوردی لە ڕێگەی tts.pawan.krd: WebViewـێکی شاراوە، دەق دەخاتە ناو چوارگۆشەکە و دوگمەی خوێندنەوە دادەگرێت.
 * کاربەر یەک جار لە PawanLoginActivity دەچێتە ژوورەوە و cookieـەکان لە CookieManager دەمێننەوە.
 * هەموو فەرمانەکان لە main thread بانگ بکرێن.
 */
object PawanTts {
    const val URL = "https://tts.pawan.krd/"
    private val ui = Handler(Looper.getMainLooper())

    private var web: WebView? = null
    private var pageReady = false
    private var queued: (() -> Unit)? = null
    private var onState: ((Boolean) -> Unit)? = null
    private var onError: ((String) -> Unit)? = null
    private var gen = 0
    private var timeout: Runnable? = null

    /** کاتێک کوکی/چوونەژوورەوە بەسەرچوو (یان Cloudflare پشتڕاستکردنەوە دەوێت) بانگ دەکرێت؛ لەسەر main thread */
    @Volatile var onNeedLogin: (() -> Unit)? = null
    /** کاتێک PawanLoginActivity داخرا بانگ دەکرێت (main thread) */
    @Volatile var onLoginDone: (() -> Unit)? = null

    /** دوای چوونەژوورەوە: WebViewـی شاراوەی کۆن (کە لەوانەیە لەسەر پەڕەی Cloudflare مابێتەوە) دەسڕێتەوە تا بە cookieـی نوێ دووبارە بار بێت. */
    fun loginDone() {
        if (Looper.myLooper() != Looper.getMainLooper()) { ui.post { loginDone() }; return }
        try { web?.destroy() } catch (_: Throwable) {}
        web = null
        pageReady = false
        queued = null
        onLoginDone?.invoke()
    }

    /** ئایا ئینتەرنێتی کاراکراو هەیە */
    fun isOnline(ctx: Context): Boolean = try {
        val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Throwable) { false }

    fun hasCookie(): Boolean = !CookieManager.getInstance().getCookie(URL).isNullOrBlank()

    /** تەنها بۆ ئەوەی کاتی بەکارهێنانی یەکەم لەپێشەوە بار بکرێت. */
    fun warmUp(ctx: Context) { ensureWeb(ctx.applicationContext) }

    private class Bridge {
        @JavascriptInterface fun started() = ui.post { onState?.invoke(true) }
        @JavascriptInterface fun ended() = ui.post { finish() }
        @JavascriptInterface fun failed(m: String) = ui.post { fail(m) }
        /** پەڕەکە چوارگۆشەی دەق/دوگمەی نییە: Cloudflare یان بەسەرچوونی چوونەژوورەوە */
        @JavascriptInterface fun needLogin() = ui.post {
            fail("کۆکی Pawan بەسەرچووە؛ دوگمەی «چوونەژوورەوە» لەسەر شاشە دابگرە")
            onNeedLogin?.invoke()
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun ensureWeb(app: Context): WebView {
        web?.let { return it }
        val w = WebView(app)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        CookieManager.getInstance().setAcceptCookie(true)
        w.addJavascriptInterface(Bridge(), "AndroidTts")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) {
                // هەموو دەنگێک کە ماڵپەڕەکە دەیپەخشێنێت بزانین کەی دەست پێدەکات و کەی تەواو دەبێت
                v.evaluateJavascript(HOOK_JS, null)
                pageReady = true
                queued?.also { queued = null }?.invoke()
            }
        }
        w.loadUrl(URL)
        web = w
        return w
    }

    fun speak(ctx: Context, text: String, onState: (Boolean) -> Unit, onError: (String) -> Unit) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (!hasCookie()) {
            onError("کۆکی Pawan نییە یان بەسەرچووە؛ دوگمەی «چوونەژوورەوە» لەسەر شاشە دابگرە")
            ui.post { onNeedLogin?.invoke() }
            return
        }
        this.onState = onState
        this.onError = onError
        val my = ++gen
        val st = TranslatorSettings(ctx.applicationContext)
        val voice = st.pawanVoice
        val lang = st.pawanLang
        val gain = st.pawanGain / 100.0
        val rate = st.pawanRate / 100.0
        val soft = st.pawanSoft
        val w = ensureWeb(ctx.applicationContext)
        val run = {
            if (gen == my) {
                onState(true)
                w.evaluateJavascript(
                    "window.__pawanSpeak(${JSONObject.quote(t)},${JSONObject.quote(voice)},${JSONObject.quote(lang)},$gain,$rate,$soft)", null
                )
                timeout?.let { ui.removeCallbacks(it) }
                timeout = Runnable { if (gen == my) fail("کاتی خوێندنەوە تەواو بوو") }
                ui.postDelayed(timeout!!, 90_000)
            }
        }
        if (pageReady) run() else queued = run
    }

    fun stop() {
        if (Looper.myLooper() != Looper.getMainLooper()) { ui.post { stop() }; return }
        gen++
        queued = null
        timeout?.let { ui.removeCallbacks(it) }
        // دوگمەی خودی ماڵپەڕەکە لە کاتی خوێندنەوە دەبێتە «وەستاندن»؛ دەیگرین تا ڕاستەقینە بوەستێت
        web?.evaluateJavascript(
            "(function(){clearInterval(window.__pawanIv);" +
                "var b=document.getElementById('speak');" +
                "if(b&&b.hasAttribute('data-busy'))b.click();" +
                "document.querySelectorAll('audio').forEach(function(a){try{a.pause()}catch(e){}});})()", null
        )
        val cb = onState
        onState = null
        cb?.invoke(false)
    }

    private fun finish() {
        timeout?.let { ui.removeCallbacks(it) }
        onState?.invoke(false)
        onState = null
    }

    private fun fail(m: String) {
        timeout?.let { ui.removeCallbacks(it) }
        onState?.invoke(false)
        onState = null
        onError?.invoke(m)
    }

    private const val HOOK_JS = """
(function(){
  if (window.__pawanHooked) return; window.__pawanHooked = true;
  var P = HTMLMediaElement.prototype, origPlay = P.play;
  P.play = function(){
    var a = this;
    // ڕێکخستنی دەنگ: ئاستی دەنگ، تۆن/خێرایی، نەرمکردن (low-pass)
    try {
      var c = window.__pwCfg || {g: 1, r: 1, s: 0};
      a.volume = c.g;
      a.preservesPitch = false; a.webkitPreservesPitch = false; a.mozPreservesPitch = false;
      a.playbackRate = c.r;
      var freq = c.s > 0 ? (12000 - c.s / 100 * 9000) : 22000;
      if (a.__flt) { a.__flt.frequency.value = freq; }
      else if (c.s > 0) {
        var AC = window.AudioContext || window.webkitAudioContext;
        var cx = window.__pwCtx || (window.__pwCtx = new AC());
        var src = cx.createMediaElementSource(a), f = cx.createBiquadFilter();
        f.type = 'lowpass'; f.frequency.value = freq;
        src.connect(f); f.connect(cx.destination);
        a.__flt = f;
        if (cx.resume) cx.resume();
      }
    } catch (e) {}
    if (!a.__h) { a.__h = 1;
      a.addEventListener('ended', function(){ AndroidTts.ended(); });
      a.addEventListener('error', function(){ AndroidTts.failed('دەنگەکە پەخش نەکرا'); });
    }
    AndroidTts.started();
    return origPlay.apply(this, arguments);
  };
  window.__pawanSpeak = function(text, voice, lang, g, r, sf){
    window.__pwCfg = {g: g, r: r, s: sf};
    var t = document.getElementById('text'), b = document.getElementById('speak');
    if (!t || !b) { AndroidTts.needLogin(); return; }
    clearInterval(window.__pawanIv);
    document.querySelectorAll('audio').forEach(function(a){ try{ a.pause(); }catch(e){} });
    var busy = function(){ return b.hasAttribute('data-busy'); };
    // هەڵبژاردنی دەنگ (ئافرەت/پیاو) و زمان، وەک ماڵپەڕەکە
    var pick = function(sel){
      var e = document.querySelector(sel);
      if (e && e.getAttribute('aria-checked') !== 'true') { e.click(); return true; }
      return false;
    };
    var go = function(){
      var changed = pick('#langs [data-lang="' + lang + '"]');
      changed = pick('#voices .voice[data-voice="' + voice + '"]') || changed;
      setTimeout(function(){
        var setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
        setter.call(t, text);
        t.dispatchEvent(new Event('input', {bubbles:true}));
        setTimeout(function(){
          b.click();
          var seen = false, n = 0;
          window.__pawanIv = setInterval(function(){
            n++;
            var playing = false;
            document.querySelectorAll('audio').forEach(function(a){ if (!a.paused && !a.ended) playing = true; });
            if (busy() || playing) { if (!seen) { seen = true; AndroidTts.started(); } }
            else if (seen) { clearInterval(window.__pawanIv); AndroidTts.ended(); }
            else if (n > 50) { clearInterval(window.__pawanIv); AndroidTts.failed('خوێندنەوە دەست پێنەکرد'); }
            if (n > 300) clearInterval(window.__pawanIv);
          }, 300);
        }, 120);
      }, changed ? 250 : 0);
    };
    if (busy()) {
      b.click();
      var w = 0, iv = setInterval(function(){ if (!busy() || ++w > 10) { clearInterval(iv); go(); } }, 200);
    } else go();
  };
})();
"""
}
