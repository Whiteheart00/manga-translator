package com.mangatranslator.app

/** Faster live sampling without overlapping OCR or exceeding Accessibility limits. */
internal object LiveRefresh {
    // Bound recovery time when downsampling misses a change or OCR returns empty.
    fun rescanDue(sinceLastOcrMs: Long) = sinceLastOcrMs >= 450L

    fun captureMs(low: Boolean) = if (low) 100L else 60L
    fun accessibilityMs(low: Boolean) = if (low) 400L else 350L
    fun ocrGapMs(kurdish: Boolean) = if (kurdish) 80L else 100L
    fun forceMs(kurdish: Boolean) = if (kurdish) 120L else 160L
}
