package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.SystemClock
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

/** Live capture -> occurrence ledger -> ordered translation -> continuous offline PCM.
 * Only accepted source suffixes are appended. Audio already playing is immutable.
 * Timing exports contain segment IDs and monotonic events, never subtitle text.
 */
class LiveSubtitle(
    private val ctx: Context,
    private val ocr: OcrEngine,
    private val tts: SoraniTts,
    private val settings: TranslatorSettings,
    private val main: Handler,
    /** null = ژێرنووس نەما (بار بسڕەوە). لەسەر main thread. */
    private val onCaption: (String?) -> Unit,
    private val onError: (String) -> Unit
) {
    // ---------- ڕووبەر و دۆخی گرتن (thread ی گرتنەوە) ----------
    @Volatile private var region = RectF()
    @Volatile private var screenW = 1
    @Volatile private var screenH = 1

    /** ڕووبەر و قەبارەی شاشەی ئێستا (دوای سووڕانەوەی شاشە دەگۆڕێت) بۆ شوێنی نووسینی وەرگێڕدراو */
    class Geom(val region: RectF, val w: Int, val h: Int)
    @Volatile var geom: Geom = Geom(RectF(), 1, 1)
        private set
    /** لەسەر main: شاشە سوڕایەوە و ڕووبەری نوێ دانرا */
    @Volatile var onGeomChanged: (() -> Unit)? = null
    /** ڕووبەری دیاریکراو بۆ هەر ئاراستەیەک (true = لاندسکەیپ)؛ تەنها لە thread ی گرتن */
    private val savedRegions = java.util.concurrent.ConcurrentHashMap<Boolean, RectF>()
    private var lang = "auto"
    @Volatile private var liveOcr = ocr.forkLiveSession()
    private val ocrLease = LiveOcrLease()
    @Volatile private var captureHalted = false
    private var networkCallback: android.net.ConnectivityManager.NetworkCallback? = null
    data class Selection(val region: LiveGeometry.Box, val w: Int, val h: Int,
                         val orientations: Map<Boolean, LiveGeometry.Box> = emptyMap())

    /** Pause preserves only geometry; Resume reads a fresh screen, never old audio. */
    fun snapshotSelection(): Selection {
        val current = geom
        fun box(r: RectF) = LiveGeometry.Box(r.left, r.top, r.right, r.bottom)
        val regions = savedRegions.mapValues { box(it.value) }.toMutableMap()
        regions[current.w > current.h] = box(current.region)
        return Selection(box(current.region), current.w, current.h, regions.toMap())
    }
    /** کلیلی Gemini بۆ ژێرنووسی زیندوو؛ ئەگەر بەکارهێنەر کوژاندبێتییەوە بەتاڵە (هەر ئێستا کاریگەرە، بێ دەستپێکردنەوە) */
    private val key: String get() = if (lang == "ar") settings.liveKey()
        else if (settings.translationProvider == TranslationProvider.GOOGLE) "" else settings.geminiTtsKey

    @Volatile private var running = false
    @Volatile private var ocrBusy = false
    @Volatile private var changedSince = 0L
    @Volatile private var lastOcrAt = 0L
    /** دوایین دێڕی خوێندراو کوردی بوو (وەرگێڕان پێویست نەبوو) ← OCR و دەنگ بە خێراتری */
    @Volatile private var kurdishMode = false
    private var prevSig: IntArray? = null
    private var ocrSig: IntArray? = null

    // واژۆی ڕووبەر بێ دروستکردنی bitmap: لە bitmap ێکی ٣٢×٣٢ ی دووبارەبەکارهاتوو دەکێشرێت (کەمکردنەوەی GC)
    private val sigBmp = Bitmap.createBitmap(SIG_N, SIG_N, Bitmap.Config.ARGB_8888)
    private val sigCanvas = Canvas(sigBmp)
    private val sigPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val sigPx = IntArray(SIG_N * SIG_N)
    private val sigDst = Rect(0, 0, SIG_N, SIG_N)
    private val cropRect = Rect()
    @Volatile private var geometryEpoch = 0
    @Volatile private var inFlightGeometry = 0
    @Volatile private var positionEpoch = 0
    private var previousPosition: Pair<Float, Float>? = null
    private var cropFw = -1
    private var cropFh = -1
    /** سەرەتای پرۆمپت: یەکجار لە start() دروست دەکرێت، نەک بۆ هەر دێڕێک */
    private var promptHead = ""

    // ---------- بەرهەمهێنان ----------
    private val seq = AtomicInteger(0)
    private val ocrGeometry = java.util.concurrent.ConcurrentHashMap<Int, Int>()
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "live-sub").apply { isDaemon = true } }
    private val pool = java.util.concurrent.ThreadPoolExecutor(2, 4, 30, TimeUnit.SECONDS,
        java.util.concurrent.ArrayBlockingQueue<Runnable>(4),
        java.util.concurrent.ThreadFactory { r -> Thread(r, "live-sub-net").apply { isDaemon = true } })
    private val history = ArrayList<String>()       // دێڕە سەرچاوەکانی پێشوو (worker)
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 200
    }

    private var streamStarted = false
    private var liveVoiceKey = ""
    private var liveNeuralVoice = false
    private fun voiceKey() = "${settings.offlineTts}|${settings.pawanTts}|${settings.offlineVoice}|${settings.piperModelVariant}|${tts.canStreamLiveOffline()}"
    private var streamEpoch = 0
    private var lastCaption = ""
    private var captionVisible = false
    fun start(regionPx: RectF, screenWidth: Int, screenHeight: Int,
              savedSelections: Map<Boolean, LiveGeometry.Box> = emptyMap()) {
        region = RectF(regionPx)
        screenW = screenWidth.coerceAtLeast(1)
        screenH = screenHeight.coerceAtLeast(1)
        lang = settings.sourceLang
        liveVoiceKey = voiceKey(); liveNeuralVoice = tts.canStreamLiveOffline()
        savedRegions.clear()
        for ((landscape, box) in savedSelections) {
            savedRegions[landscape] = RectF(box.left, box.top, box.right, box.bottom)
        }
        savedRegions[screenW > screenH] = RectF(region)
        geom = Geom(RectF(region), screenW, screenH)
        promptHead = buildPromptHead()
        try { tts.setLowLatency(true) } catch (_: Throwable) {}
        running = true
        // The first fresh frame is authoritative, even when its text is the
        // same as before Pause. No saved line is shown or queued here.
        if (settings.liveFastGoogle) {
            GoogleTranslator.fast = true
            if (settings.translationProvider.warmGoogle(lang)) {
                try { pool.execute { GoogleTranslator.preconnect() } } catch (_: Throwable) {}
            }
        }
        LiveTimingExport.active = timing
        worker.execute { try { if (running) pipeline } catch (_: Exception) {
            captureHalted = true
            main.post { if (running) onError("شوێنی کاتی ڕیزی دەق ئامادە نەبوو؛ بۆشایی مۆبایل بپشکنە") }
        } }
        try {
            val callback = object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) {
                    if (running && pipelineDelegate.isInitialized()) pipeline.reconnected()
                }
            }
            networkCallback = callback
            (ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager)
                .registerDefaultNetworkCallback(callback)
        } catch (_: Exception) {}
        main.postDelayed(watchdog, WATCHDOG_MS)
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            when (ocrLease.expire(SystemClock.elapsedRealtime())) {
                LiveOcrLease.Expiry.NONE -> {}
                LiveOcrLease.Expiry.RESET -> {
                    val old = liveOcr
                    old.closeLiveSession()
                    liveOcr = ocr.forkLiveSession()
                    ocrGeometry.clear(); ocrSig = null; ocrBusy = false
                    stamp(0, "ocr_session_reset")
                }
                LiveOcrLease.Expiry.HALT -> {
                    captureHalted = true
                    stamp(0, "ocr_halted")
                    onError("دەقناسینەوە وەستا؛ ژێرنووسی زیندوو ڕابگرە و دووبارە دەستی پێبکە")
                }
            }
            main.postDelayed(this, WATCHDOG_MS)
        }
    }

    fun stop() {
        running = false; captureHalted = true; ocrLease.cancel()
        stamp(0, "session_cancelled")
        LiveTimingExport.last = timing.csv()
        if (LiveTimingExport.active === timing) LiveTimingExport.active = null
        main.removeCallbacks(watchdog)
        settleRun?.let { main.removeCallbacks(it) }
        networkCallback?.let { callback -> try {
            (ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager).unregisterNetworkCallback(callback)
        } catch (_: Exception) {} }
        networkCallback = null
        if (pipelineDelegate.isInitialized()) pipeline.close()
        worker.shutdownNow(); pool.shutdownNow()
        liveOcr.closeLiveSession()
        GoogleTranslator.fast = false
        val cleanup = Runnable {
            streamEpoch++; streamStarted = false; captionVisible = false
            try { tts.stop(); tts.speedBoost = 1f; tts.setLowLatency(false); onCaption(null) } catch (_: Exception) {}
        }
        if (android.os.Looper.myLooper() === android.os.Looper.getMainLooper()) cleanup.run() else main.post(cleanup)
    }

    // =====================================================================
    // 1) فرەیم → ڕووبەر → بڕیاری OCR
    // =====================================================================

    /** ڕێگای کۆن (AccessibilityCapturer): کۆپی دەدرێت؛ لێرە recycle دەکرێت. */
    fun onFrame(frame: Bitmap) {
        try { onRawFrame(frame, true) } finally { frame.recycle() }
    }

    /**
     * ڕێگای خێرا (ScreenCapturer.rawFrameListener): هیچ کۆپییەک نییە. `frame` هی گرتنەوەیە — recycle مەکە و مەیهێڵەوە.
     * تەنها واژۆی ٣٢×٣٢ ی ڕووبەرەکە حیساب دەکرێت؛ bitmap ی ڕووبەر تەنها کاتێک دروست دەبێت کە OCR بەڕاستی پێویست بێت.
     */
    fun onRawFrame(frame: Bitmap, isNew: Boolean) {
        if (!running || captureHalted || (pipelineDelegate.isInitialized() && pipeline.captureHalted)) return
        val now = SystemClock.elapsedRealtime()
        // شاشە سوڕایەوە (یوتوب فوڵسکرین): ڕووبەری ئاراستەی نوێ بەکاربهێنە، نەک ڕووبەری پۆرترەیت
        val landscape = frame.width > frame.height
        if (landscape != (screenW > screenH)) adaptOrientation(landscape)

        // فرەیمی دووبارە (شاشە نەگۆڕاوە): ئەگەر هیچ گۆڕانکارییەک چاوەڕێ نییە هیچ مەکە (٠ کار)؛
        // ئەگەر چاوەڕێی ڕاوەستانە، فرەیمی دووبارە خۆی ڕاوەستانە ← واژۆی پێشوو بەکاربهێنە
        val prev = prevSig
        val sig: IntArray
        val settled: Boolean
        if (!isNew && prev != null) {
            if (changedSince == 0L && !LiveRefresh.rescanDue(now - lastOcrAt)) return
            sig = prev
            settled = true
        } else {
            sig = regionSig(frame)
            settled = prev != null && ChangeDetector.distance(sig, prev) < STABLE_THRESHOLD
            prevSig = sig
        }

        val base = ocrSig
        // هیچ گۆڕانکارییەک نییە لە دوایین OCR ← ژێرنووسەکە هەمان ماوەتەوە
        val changed = base == null || ChangeDetector.changedFraction(sig, base) >= CHANGED_FRACTION
        // A coarse signature can miss a short subtitle or an OCR failure.
        // Periodically retry even a static frame, without overlapping OCR.
        val rescan = LiveRefresh.rescanDue(now - lastOcrAt)
        if (!changed && !rescan) { changedSince = 0L; return }
        if (changedSince == 0L) changedSince = now

        // یەکەم OCR دوای دیاریکردنی ڕووبەر یەکسەر دەکرێت؛ دواتر: ڕاوەستاو (ژێرنووس تەواو دەرکەوتووە) یان باگراوندی جووڵاو
        // (ڤیدیۆ) ← بە زۆرەملێ OCR. دەقی کوردی چاوەڕێی کەمتر دەکات (OcrGate)
        if (!OcrGate.shouldRun(base == null, settled || rescan, now - changedSince, now - lastOcrAt, ocrBusy, kurdishMode, fastRefresh = lang != "ar")) return

        val crop = cropRegion(frame) ?: return
        ocrBusy = true
        ocrSig = sig
        lastOcrAt = now
        try { runOcr(crop) } catch (_: Exception) {
            if (!crop.isRecycled) crop.recycle()
            ocrBusy = false; ocrSig = null; ocrLease.cancel()
            stamp(0, "ocr_start_failed")
        }
    }

    /**
     * ڕووبەری ئاراستەی نوێ: ئەوەی پێشتر بۆی دیاری کراوە، یان بارێکی بنەڕەتی لە خوارەوەی ڤیدیۆ ([LiveGeometry.defaultBand]).
     * هەموو دۆخی OCR/ڕاوەستان دەست پێدەکاتەوە بۆ ئەوەی یەکەم OCR یەکسەر بێت ([OcrGate]).
     */
    private fun adaptOrientation(landscape: Boolean) {
        geometryEpoch++
        previousPosition = null
        savedRegions[screenW > screenH] = RectF(region)
        val sz = LiveGeometry.screenFor(landscape, screenW, screenH)
        val saved = savedRegions[landscape]
        val r = saved ?: LiveGeometry.defaultBand(sz.w, sz.h).let { RectF(it.left, it.top, it.right, it.bottom) }
        savedRegions[landscape] = RectF(r)
        region = r
        screenW = sz.w
        screenH = sz.h
        cropFw = -1
        cropFh = -1
        prevSig = null
        ocrSig = null
        changedSince = 0L
        geom = Geom(RectF(r), sz.w, sz.h)
        Log.d(TAG, "orientation → ${if (landscape) "landscape" else "portrait"} ${sz.w}x${sz.h} saved=${saved != null}")
        main.post { if (running) onGeomChanged?.invoke() }
    }

    /** ڕووبەرەکە بە پیکسێلی فرەیم؛ تەنها کاتێک قەبارەی فرەیم بگۆڕێت دووبارە حیساب دەکرێت */
    private fun frameRegion(frame: Bitmap): Rect {
        val fw = frame.width
        val fh = frame.height
        if (fw != cropFw || fh != cropFh) {
            val kx = fw.toFloat() / screenW
            val ky = fh.toFloat() / screenH
            val l = (region.left * kx).toInt().coerceIn(0, fw - 2)
            val t = (region.top * ky).toInt().coerceIn(0, fh - 2)
            cropRect.set(l, t, (region.right * kx).toInt().coerceIn(l + 2, fw), (region.bottom * ky).toInt().coerceIn(t + 2, fh))
            cropFw = fw
            cropFh = fh
        }
        return cropRect
    }

    /** واژۆی ٣٢×٣٢ ی خۆڵەمێشی ی ڕووبەر، بێ bitmap ی نوێ */
    private fun regionSig(frame: Bitmap): IntArray {
        sigCanvas.drawBitmap(frame, frameRegion(frame), sigDst, sigPaint)
        sigBmp.getPixels(sigPx, 0, SIG_N, 0, 0, SIG_N, SIG_N)
        return IntArray(SIG_N * SIG_N) { i ->
            val c = sigPx[i]
            (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
        }
    }

    /** کۆپییەکی سەربەخۆی ڕووبەرەکە (بۆ OCR ی ناو thread ی تر)؛ تەنها کاتی پێویست */
    private fun cropRegion(frame: Bitmap): Bitmap? {
        return try {
            val r = frameRegion(frame)
            val c = Bitmap.createBitmap(frame, r.left, r.top, r.width(), r.height())
            if (c === frame) frame.copy(Bitmap.Config.ARGB_8888, false) else c
        } catch (_: Throwable) {
            null
        }
    }

    /** ڕووبەرەکە (بچووک کراوە بۆ ≤٢٠٠px) لێواری بەهێزی وەک-نووسینی تێدایە؟ لە شکستدا true (دوودڵی = بەردەوامبە). */
    private fun cropHasText(crop: Bitmap): Boolean {
        return try {
            val w = minOf(crop.width, GATE_W).coerceAtLeast(2)
            val h = (crop.height.toFloat() * w / crop.width.coerceAtLeast(1)).toInt().coerceAtLeast(2)
            val sm = if (w == crop.width && h == crop.height) crop else Bitmap.createScaledBitmap(crop, w, h, true)
            val sw = sm.width
            val sh = sm.height
            val px = IntArray(sw * sh)
            sm.getPixels(px, 0, sw, 0, 0, sw, sh)
            if (sm !== crop) sm.recycle()
            val gray = IntArray(px.size) { i ->
                val c = px[i]
                (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            }
            SubtitleGuard.hasTextLikeEdges(gray, sw, sh)
        } catch (_: Throwable) {
            true
        }
    }

    // =====================================================================
    // 2) OCR
    // =====================================================================

    // ---------- دەقی ڕاستەقینە لە Accessibility (بێ OCR) ----------
    private var accFails = 0                     // تەنها لە pool: چەند جار لە دووی یەک دەقی نەدۆزییەوە
    @Volatile private var accSkipUntil = 0L

    /** دەقی ناو ڕووبەر لە Accessibility؛ null = هیچ نییە (یاریی زۆرینە دەقی Accessibility نادەن) */
    private fun accessibilityText(): String? {
        val all = try { ScreenText.collect(ctx, screenW, screenH, lite = true) } catch (_: Throwable) { return null }
        if (all.isEmpty()) return null
        val rg = Rect(region.left.toInt(), region.top.toInt(), region.right.toInt(), region.bottom.toInt())
        val hit = all.filter { b ->
            val i = Rect()
            if (!i.setIntersect(b.rect, rg)) false
            else {
                val ia = i.width().toLong() * i.height()
                val ba = (b.rect.width().toLong() * b.rect.height()).coerceAtLeast(1)
                ia * 2 >= ba          // زۆرینەی نۆدەکە لەناو ڕووبەرەکەیە
            }
        }.filter { TextFilter.worthTranslating(it.text) || TextFilter.isLikelySorani(it.text) }
        if (hit.isEmpty()) return null
        val t = LiveTextOrder.join(hit.map { Blk(it.text, it.rect.left, it.rect.top, it.rect.right, it.rect.bottom) },
            rtl = lang == "ar" || lang == "ckb")
        return t.takeIf { it.length >= 2 }
    }

    private fun runOcr(crop: Bitmap) {
        inFlightGeometry = geometryEpoch
        val id = seq.incrementAndGet()
        if (!ocrLease.begin(id, SystemClock.elapsedRealtime())) { crop.recycle(); return }
        ocrGeometry[id] = geometryEpoch
        val startedAt = SystemClock.elapsedRealtime()
        if (settings.liveAccText && startedAt >= accSkipUntil && MangaAccessibilityService.instance != null) {
            try {
                pool.execute {
                    val t = try { accessibilityText() } catch (_: Throwable) { null }
                    if (t != null) {
                        accFails = 0
                        crop.recycle()
                        submit(id, t, startedAt, alreadyKurdish = false)
                    } else {
                        // ٣ جار لە دووی یەک دەقی نەبوو (یاری) ← ١٠ چرکە Accessibility مەپرسە، OCR ی ئاسایی
                        if (++accFails >= 3) { accFails = 0; accSkipUntil = SystemClock.elapsedRealtime() + 10_000L }
                        if (running) try { runOcrReal(crop, id, startedAt) } catch (_: Exception) {
                            if (!crop.isRecycled) crop.recycle()
                            ocrGeometry.remove(id); ocrSig = null
                            if (ocrLease.finish(id)) ocrBusy = false
                            stamp(0, "ocr_start_failed")
                        } else { crop.recycle(); if (ocrLease.finish(id)) ocrBusy = false }
                    }
                }
            } catch (_: Throwable) {   // دوای stop() ی pool
                crop.recycle()
                ocrGeometry.remove(id); ocrSig = null
                if (ocrLease.finish(id)) ocrBusy = false
            }
            return
        }
        runOcrReal(crop, id, startedAt)
    }

    private fun runOcrReal(crop: Bitmap, id: Int, startedAt: Long) {

        // ڕووبەری بێ هیچ لێوارێکی وەک-نووسین (تەخت/ڕەش/دیمەنی بێ دەق): نە OCR نە Gemini ← هیچ نووسینێکی لەحۆوە دروست نابێت
        if (!cropHasText(crop)) {
            crop.recycle()
            submit(id, "", startedAt, alreadyKurdish = false)
            return
        }

        // عەرەبی + کلیلی Gemini، یان کوردی کاتێک Local Kurdish OCR کوژێندرابێت:
        // وێنە و دەق بە یەک داواکاری دەخوێندرێتەوە؛ دەقی کوردی وەرناگێڕدرێت.
        if ((lang == "ar" || (lang == "ckb" && !settings.localKurdish)) && key.isNotBlank()) {
            try { pool.execute {
                var text = ""
                try {
                    val items = RegionTranslator.run(crop, key, true).sortedBy { it.rect?.top ?: 0 }
                    if (!ocrLease.accepts(id)) return@execute
                    val cw = crop.width
                    val chh = crop.height
                    val kept = wmFilter(items.map {
                        val r = it.rect
                        Blk(it.original.ifBlank { it.kurdish }, r?.left ?: 0, r?.top ?: 0, r?.right ?: cw, r?.bottom ?: chh)
                    }, cw, chh)
                    text = LiveTextOrder.join(kept, rtl = true)
                    val translated = LiveTextOrder.join(items.map {
                        val r = it.rect
                        Blk(it.kurdish, r?.left ?: 0, r?.top ?: 0, r?.right ?: cw, r?.bottom ?: chh)
                    }, rtl = true)
                    if (text.isNotBlank() && translated.isNotBlank()) {
                        if (visionTranslations.size >= 40) visionTranslations.clear()
                        visionTranslations[text] = translated
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "Gemini vision failed: ${t.message}")
                } finally {
                    crop.recycle()
                }
                submit(id, text, startedAt, alreadyKurdish = false)
            } } catch (_: Throwable) {   // دوای stop() ی pool: داوا ڕەتدەکرێتەوە
                crop.recycle()
                ocrGeometry.remove(id); ocrSig = null
                if (ocrLease.finish(id)) ocrBusy = false
            }
            return
        }

        val cw = crop.width
        val chh = crop.height
        liveOcr.recognizeLiveBoxes(crop) { boxes ->
            crop.recycle()
            if (!ocrLease.accepts(id) || !running) return@recognizeLiveBoxes
            // واتەرمارک/نووسینی جێگیر (ناوی کەناڵ، X=SELECT...) لادەبرێت و ناچێتە وەرگێڕان
            val kept = wmFilter(boxes.map { Blk(it.text, it.rect.left, it.rect.top, it.rect.right, it.rect.bottom) }, cw, chh)
            val rtl = lang == "ar" || lang == "ckb" ||
                (lang == "auto" && kept.sumOf { b -> b.text.count { it in '\u0600'..'\u06ff' } } >
                    kept.sumOf { b -> b.text.count { it in 'A'..'Z' || it in 'a'..'z' } })
            val text = LiveTextOrder.join(kept, rtl)
            submit(id, text, startedAt, alreadyKurdish = false)
        }
    }

    // The user's selected region is authoritative. A duration/fuzzy watermark
    // blacklist used to erase valid repeated dialogue and slowly changing lines.
    private fun wmFilter(blocks: List<Blk>, cw: Int, ch: Int): List<Blk> {
        if (blocks.isNotEmpty() && inFlightGeometry == geometryEpoch) {
            val x = (blocks.minOf { it.l } + blocks.maxOf { it.r }) / (2f * cw.coerceAtLeast(1))
            val bottom = blocks.maxOf { it.b }.toFloat() / ch.coerceAtLeast(1)
            val old = previousPosition
            if (old != null && (abs(old.first - x) > 0.4f || abs(old.second - bottom) > 0.25f)) positionEpoch++
            previousPosition = x to bottom
        }
        return blocks
    }

    private fun submit(id: Int, raw: String, startedAt: Long, alreadyKurdish: Boolean) {
        if (!ocrLease.accepts(id)) return
        val capturedGeometry = ocrGeometry.remove(id)
        if (!running || capturedGeometry != geometryEpoch) {
            if (ocrLease.finish(id)) ocrBusy = false
            return
        }
        val position = positionEpoch
        try {
            worker.execute {
                try {
                    if (running && ocrLease.accepts(id) && capturedGeometry == geometryEpoch)
                        handle(raw, startedAt, alreadyKurdish, position)
                } catch (_: Exception) {
                    captureHalted = true
                    main.post { if (running) onError("گرتنی دەقی تازە وەستا بۆ پاراستنی ڕیزی دەق") }
                } finally { if (ocrLease.finish(id)) ocrBusy = false }
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            if (ocrLease.finish(id)) ocrBusy = false
        }
    }

    private val visionTranslations = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val ledger = LiveSubtitleLedger()
    private val timing = LiveTiming()
    private val pipelineDelegate = lazy {
        LiveDurablePipeline(java.io.File(ctx.noBackupFilesDir, "live_subtitle_sessions"),
            clock = { SystemClock.elapsedRealtime() }, translate = ::translateWork,
            online = { PawanTts.isOnline(ctx) }, audioCapacity = if (liveNeuralVoice) 2 else 1,
            onAudio = { unit -> main.post { if (running) playUnit(unit) } },
            onStatus = { message -> if (message.isNotEmpty()) main.post { if (running) {
                captionVisible = false; onCaption(message); onError(message)
            } } }, event = ::stamp, accepted = { record ->
                val cacheKey = "$lang|${record.provider}|${record.source}|${if (record.continuation) record.fullSource else ""}"
                if (cacheKey.length + record.translated.length <= 12000) synchronized(cache) { cache[cacheKey] = record.translated }
            }).also { if (!running) it.close() }
    }
    private val pipeline: LiveDurablePipeline get() = pipelineDelegate.value
    private var settleRun: Runnable? = null
    private fun stamp(id: Long, stage: String) { timing.mark(id, stage, SystemClock.elapsedRealtime()) }

    private fun handle(raw: String, startedAt: Long, alreadyKurdish: Boolean, position: Int) {
        if (!running) return
        val text = NameFilter.strip(TextPrep.prepare(raw), skipNamesList(), settings.skipNamesStrict,
            everywhere = settings.skipNamesEverywhere, followedByMarker = settings.skipNamesMarkedOnly)
        val valid = text.isNotBlank() && SubtitleGuard.looksLikeRealText(text)
        val g = geom
        val band = "$position:${g.w}:${g.h}:${g.region.left.toInt()}:${g.region.top.toInt()}:${g.region.right.toInt()}:${g.region.bottom.toInt()}"
        ledger.observe(if (valid) text else "", SystemClock.elapsedRealtime(), band, startedAt)
            .forEach { processSegment(it, alreadyKurdish) }
        if (!valid && ledger.isAbsent) main.post { if (running) { captionVisible = false; onCaption(null) } }
        if (valid) kurdishMode = lang == "ckb" || alreadyKurdish || TextFilter.isLikelySorani(text)
        settleRun?.let { main.removeCallbacks(it) }
        val r = Runnable {
            try { worker.execute {
                if (running) ledger.settle(SystemClock.elapsedRealtime())?.let { processSegment(it, alreadyKurdish) }
            } } catch (_: java.util.concurrent.RejectedExecutionException) {}
        }
        settleRun = r; main.postDelayed(r, 180)
    }

    private fun processSegment(segment: LiveSubtitleLedger.Segment, alreadyKurdish: Boolean) {
        if (!running || captureHalted) return
        val text = segment.text
        timing.mark(segment.id, "observed", segment.firstSeen)
        timing.mark(segment.id, "ocr_completed", segment.ocrCompleted)
        stamp(segment.id, "ocr_confirmed")
        val direct = lang == "ckb" || ((alreadyKurdish || TextFilter.isLikelySorani(text)) && !TextFilter.hasEnglishWord(text))
        val prepared = visionTranslations[text]?.takeIf { SubtitleGuard.plausibleTranslation(text, it) }
        val output = if (direct) text else prepared.orEmpty()
        val previous = ArrayList(history)
        if (segment.continuation) previous.add("Full current subtitle (context only): ${segment.fullText}")
        val record = LiveWork(segment.id, segment.occurrence, text, segment.fullText,
            segment.continuation, segment.firstSeen, segment.ocrCompleted, settings.translationProvider.id,
            context = previous, state = if (output.isNotEmpty()) LiveWorkState.TRANSLATED else LiveWorkState.QUEUED,
            translated = output)
        if (pipeline.append(record)) {
            ledger.forget(segment.id)
            history.add(segment.fullText); while (history.size > 3) history.removeAt(0)
        } else {
            captureHalted = true
            main.post { if (running) onError("گرتنی دەقی تازە وەستا؛ ڕیزی پێشوو پارێزراوە") }
        }
    }

    private fun translateWork(record: LiveWork): String? {
        val provider = TranslationProvider.fromId(record.provider)
        val requestKeys = if (lang == "ar") settings.liveKey() else settings.geminiTtsKey
        val cacheKey = "$lang|${provider.id}|${record.source}|${if (record.continuation) record.fullSource else ""}"
        return synchronized(cache) { cache[cacheKey] } ?: LiveTranslationRecovery.run(
            active = { running && !Thread.currentThread().isInterrupted },
            primary = { translateHedged(record.source, record.context, provider, requestKeys)
                ?.takeIf { SubtitleGuard.plausibleTranslation(record.source, it) } },
            fallback = {
                val value = if (provider == TranslationProvider.GOOGLE && requestKeys.isNotBlank())
                    geminiLine(record.source, record.context, requestKeys, quotaSensitive = true)
                else if (provider != TranslationProvider.GOOGLE)
                    GoogleTranslator.translateBubble(record.source, lang)?.let(TextPrep::fixSorani)
                else null
                value?.takeIf { SubtitleGuard.plausibleTranslation(record.source, it) }
            }, retry = { stamp(record.id, "translation_retry") })
    }

    /** Gemini (٣ دێڕی پێشوو وەک چوارچێوە) + Google ی دواخراو (٧٠٠ms) ← یەکەم وەڵامی بێگەرد دەبات. */
    private fun translateHedged(
        text: String, prev: List<String>, provider: TranslationProvider, requestKeys: String
    ): String? {
        if (lang != "ar") {
            return TranslationRouter.shared.run(provider, requestKeys,
                gemini = { geminiLine(text, prev, requestKeys, quotaSensitive = true) },
                google = { TextPrep.fixSorani(GoogleTranslator.translateBubble(text, lang).orEmpty()).takeIf { it.isNotBlank() } })
        }
        // Arabic alone retains the original hedged behavior and existing settings.
        val winner = AtomicReference<String?>(null)
        val latch = CountDownLatch(1)
        fun offer(v: String?) {
            if (!v.isNullOrBlank() && winner.compareAndSet(null, v)) latch.countDown()
        }
        val hasKey = requestKeys.isNotBlank()
        if (hasKey) {
            pool.execute { try { offer(geminiLine(text, prev, requestKeys)) } catch (t: Throwable) { Log.w(TAG, "gemini: ${t.message}") } }
        }
        pool.execute {
            try {
                if (hasKey) {
                    // Gemini ی خێرا ئەگەر لە HEDGE_MS دا وەڵامی دایەوە، Google پێویست نییە
                    if (latch.await(HEDGE_MS, TimeUnit.MILLISECONDS)) return@execute
                }
                offer(TextPrep.fixSorani(GoogleTranslator.translateBubble(text, lang) ?: ""))
            } catch (t: Throwable) {
                Log.w(TAG, "google: ${t.message}")
            }
        }
        latch.await(if (settings.liveFastGoogle) FAST_TIMEOUT_MS else TIMEOUT_MS, TimeUnit.MILLISECONDS)
        return winner.get()
    }

    private fun langName(code: String) = when (code) {
        "en" -> "English"; "ar" -> "Arabic"; "ja" -> "Japanese"; "zh" -> "Chinese"; "ko" -> "Korean"; "hi" -> "Hindi"
        else -> "auto-detect"
    }

    private fun buildPromptHead(): String =
        "Translate ONE video/game subtitle line (" + langName(lang) + ") into natural SPOKEN Central Kurdish (Sorani, Arabic script). " +
            "Translate the meaning of the whole line, never word by word; keep the tone; keep it short enough to speak in the original's time; " +
            "use Sorani letters (ی ک ە ێ ۆ ڵ ڕ ڤ); names transliterated; numbers unchanged; silently fix small OCR mistakes. " +
            "Translate ONLY the given line: never invent, complete or continue text, never repeat the previous lines, never explain. " +
            "If the line is not real readable subtitle text (random characters, symbols, interface noise), output exactly " + SubtitleGuard.NONE + ". " +
            "When full current subtitle or a previously translated span is supplied as context, translate ONLY the new Subtitle line span as a continuation; never repeat that earlier span. " +
            "Output ONLY the Kurdish.\n"

    private fun geminiLine(text: String, prev: List<String>, keysRaw: String, quotaSensitive: Boolean = false): String? {
        val sb = StringBuilder(promptHead)
        if (prev.isNotEmpty()) {
            sb.append("Previous lines (context only, do NOT translate):\n")
            for (p in prev) sb.append("- ").append(p).append('\n')
        }
        val hints = try { AmbiguityGlossary.hintsFor(ctx, listOf(text), 5, 360) } catch (_: Throwable) { "" }
        if (hints.isNotBlank()) {
            sb.append("Hints for ambiguous words (use a hint only if its meaning fits this sentence):\n").append(hints).append('\n')
        }
        sb.append("Subtitle line:\n").append(text)
        val prompt = sb.toString()

        fun body(model: String, think: Boolean): String {
            val gen = JSONObject().put("temperature", 0.2).put("maxOutputTokens", 256)
            if (think) gen.put("thinkingConfig", GeminiModels.thinking(model))
            return JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", gen)
                .toString()
        }

        val out = GeminiKeys.withKeys(keysRaw) { k ->
            GeminiModels.call(true, quotaSensitive = quotaSensitive) { m, think -> post(body(m, think), k, m) }
        }
        val t = TextPrep.fixSorani(out).trim().trim('"', '«', '»')
        if (t.contains(SubtitleGuard.NONE, ignoreCase = true)) return SubtitleGuard.NONE   // یەکلاکەرەوەیە: Google چاوەڕێ نەکرێت
        return t.takeIf { it.isNotBlank() }
    }

    private fun post(body: String, apiKey: String, model: String): String {
        if (!running || Thread.currentThread().isInterrupted) throw InterruptedException()
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        var ok = false
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 3_000
            c.readTimeout = 6_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val why = try { JSONObject(resp).getJSONObject("error").getString("message") } catch (_: Exception) { resp }
                throw ApiException(code, "Gemini $code ${why.take(120)}".trim())
            }
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").optJSONArray("parts") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            ok = true
            return sb.toString()
        } finally {
            // دوای وەڵامی تەواو disconnect ناکەین: پەیوەندی TLS دەمێنێتەوە بۆ دێڕی دواتر (≈١٠٠-٣٠٠ms کەمتر)
            if (!ok) c.disconnect()
        }
    }

    // =====================================================================
    // 5) دەنگ: ڕیزبەندی بەبێ دووبارەکردنەوەی خوێندنەوەی تەواوبوو
    // =====================================================================

    private var namesRaw = ""
    private var namesParsed: List<String> = emptyList()
    private fun skipNamesList(): List<String> {
        val raw = settings.skipNames
        if (raw != namesRaw) { namesRaw = raw; namesParsed = NameFilter.parse(raw) }
        return namesParsed
    }

    private fun playUnit(unit: LiveDurablePipeline.AudioUnit) {
        if (voiceKey() != liveVoiceKey) {
            captureHalted = true; stamp(unit.work.id, "voice_configuration_changed")
            onError("ڕێکخستنی دەنگ گۆڕا؛ ژێرنووس ڕابگرە و بەردەوامی بکەوە بۆ بەکارهێنانی")
            return
        }
        val r = unit.work
        val tx = r.audioText.ifEmpty { r.translated }
        lastCaption = (if (r.continuation && captionVisible) "$lastCaption $tx" else tx).takeLast(1500)
        captionVisible = true; onCaption(lastCaption)
        if (liveNeuralVoice) {
            if (!streamStarted) {
                streamStarted = true
                val epoch = ++streamEpoch
                val generation = unit.generation
                tts.speedBoost = 1f
                fun failed(message: String) { main.post {
                    if (running && epoch == streamEpoch) {
                        streamEpoch++; streamStarted = false
                        pipeline.audioFailed(generation); onError(message)
                    }
                } }
                tts.beginStream(true, onState = { on -> if (!on) failed("پەخشی دەنگی زیندوو وەستا") }, onError = ::failed)
            }
            val accepted = tts.feedLive(SpeechMsg(tx, boost = LiveAudioRetry.boost(unit.pendingBehind), live = true,
                onReady = { pipeline.ready(unit) }, onComplete = { pipeline.complete(unit) },
                exactChunks = r.chunks.takeIf { it.isNotEmpty() }, startChunk = unit.startChunk,
                onPlan = { pipeline.plan(unit, it) }, beforeChunk = { pipeline.submitted(unit, it) },
                onChunkStarted = { pipeline.started(unit, it) }, onChunkComplete = { pipeline.chunkDone(unit, it) }))
            if (!accepted) { streamEpoch++; streamStarted = false; pipeline.audioFailed(unit.generation) }
        } else {
            // Non-neural voices retain their engine; the durable queue supplies one utterance at a time.
            pool.execute {
                if (!pipeline.plan(unit, listOf(tx)) || !pipeline.submitted(unit, 0)) return@execute
                main.post { if (running) {
                    pipeline.started(unit, 0)
                    tts.speak(listOf(tx), onState = { on -> if (!on && running) {
                        pipeline.chunkDone(unit, 0); pipeline.complete(unit)
                    } }, onError = { message -> if (running) { pipeline.audioFailed(unit.generation); onError(message) } })
                } }
            }
        }
    }

    companion object {
        private const val TAG = "LiveSubtitle"
        private const val SIG_N = 32
        private const val GATE_W = 200
        private const val CHANGED_FRACTION = 0.03f
        private const val STABLE_THRESHOLD = 4f
        private const val HEDGE_MS = 700L
        private const val TIMEOUT_MS = 3500L
        private const val FAST_TIMEOUT_MS = 2500L
        private const val WATCHDOG_MS = 300L
    }
}
