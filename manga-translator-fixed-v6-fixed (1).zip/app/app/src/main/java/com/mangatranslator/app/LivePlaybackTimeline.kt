package com.mangatranslator.app

/** Callbacks follow played frames, never synthesis or successful write calls. */
internal class LivePlaybackTimeline {
    private val callbacks = ArrayDeque<Pair<Long, () -> Unit>>()
    fun at(frame: Long, callback: (() -> Unit)?) {
        if (callback != null) callbacks.addLast(frame to callback)
    }
    fun advance(played: Long) {
        while (callbacks.isNotEmpty() && played >= callbacks.first().first) {
            callbacks.removeFirst().second.invoke()
        }
    }
    fun cancel() = callbacks.clear()
}
