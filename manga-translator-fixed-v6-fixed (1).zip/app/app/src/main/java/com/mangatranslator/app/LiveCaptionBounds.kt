package com.mangatranslator.app

internal object LiveCaptionBounds {
    fun outside(l: Float, t: Float, r: Float, b: Float, x1: Int, y1: Int, x2: Int, y2: Int): Boolean =
        x2 <= l || x1 >= r || y2 <= t || y1 >= b
}
