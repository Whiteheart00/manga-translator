package com.mangatranslator.app

import kotlin.math.abs

/** Trim only clip-edge silence, never pauses inside a word or sentence. */
internal object LivePcmBoundary {
    fun apply(input: FloatArray, rate: Int, text: String): FloatArray {
        if (input.isEmpty() || rate <= 0) return input
        val peak = input.maxOf { abs(it) }
        if (peak < 0.0001f) return input
        val threshold = maxOf(0.00001f, peak * 0.001f)
        val first = input.indexOfFirst { abs(it) >= threshold }
        val last = input.indexOfLast { abs(it) >= threshold }
        if (first < 0 || last < first) return input
        val trailingMs = when (text.trimEnd().lastOrNull()) {
            ',', '،', ';', '؛', ':' -> 80
            '.', '!', '?', '؟', '。', '！', '？' -> 180
            else -> 0
        }
        val start = (first - rate * 40 / 1000).coerceAtLeast(0)
        val end = (last + 1 + rate * maxOf(40, trailingMs) / 1000).coerceAtMost(input.size)
        val result = input.copyOfRange(start, end)
        val fade = minOf(rate * 5 / 1000, result.size / 2)
        for (i in 0 until fade) {
            val gain = i.toFloat() / fade
            result[i] *= gain
            result[result.lastIndex - i] *= gain
        }
        return result
    }
    // Keep punctuation and do not split numeric separators such as 3.14 / 1,000.
    fun clauses(text: String): List<String> {
        val result = ArrayList<String>()
        var pending = ""
        for (part in text.split(Regex("(?<=[،,؛;:.!?؟])\\s+"))) {
            pending = (pending + " " + part.trim()).trim()
            val words = pending.split(Regex("\\s+")).size
            if (words >= 4 || pending.lastOrNull() in listOf('.', '!', '?', '؟')) {
                if (pending.isNotEmpty()) result.add(pending)
                pending = ""
            }
        }
        if (pending.isNotEmpty()) result.add(pending)
        return result
    }
}
