package com.mangatranslator.app

/** Audio that may have been submitted to a playing device must not restart. */
internal object LiveAudioRetry {
    fun allowed(mayHavePlayed: Boolean, retries: Int) = !mayHavePlayed && retries < 1
    fun boost(pending: Int) = (1f + 0.06f * pending.coerceAtLeast(0)).coerceAtMost(1.25f)
}
