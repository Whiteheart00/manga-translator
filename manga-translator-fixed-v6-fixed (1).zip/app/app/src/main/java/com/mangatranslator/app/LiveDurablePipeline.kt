package com.mangatranslator.app

import java.io.Closeable
import java.io.File
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicBoolean

/** All durable state belongs to one worker. Network workers never commit results. */
internal class LiveDurablePipeline(
    root: File, private val clock: () -> Long,
    private val translate: (LiveWork) -> String?, private val online: () -> Boolean = { true },
    private val audioCapacity: Int = 2,
    private val onAudio: (AudioUnit) -> Unit,
    private val onStatus: (String) -> Unit,
    private val event: (Long, String) -> Unit,
    private val accepted: (LiveWork) -> Unit = {},
    maxBytes: Long = 50L * 1024 * 1024,
    freeBytes: (File) -> Long = { it.usableSpace }
) : Closeable {
    data class AudioUnit(val work: LiveWork, val generation: Int, val pendingBehind: Int = 0) {
        val startChunk: Int get() = maxOf(work.submittedThrough, work.failedThrough) + 1
    }
    private val closed = AtomicBoolean(false)
    private var owner: Thread? = null
    private val worker = ScheduledThreadPoolExecutor(1) { r -> Thread(r, "live-durable").apply { isDaemon = true; owner = this } }.apply {
        setExecuteExistingDelayedTasksAfterShutdownPolicy(false)
        setContinueExistingPeriodicTasksAfterShutdownPolicy(false)
    }
    private val network = ThreadPoolExecutor(2, 2, 0L, TimeUnit.MILLISECONDS, SynchronousQueue<Runnable>(),
        ThreadFactory { r -> Thread(r, "live-request").apply { isDaemon = true } })
    private val store = LiveSessionStore(root, maxBytes, freeBytes)
    private val gate = LiveAttemptGate()
    private data class Attempt(val ticket: LiveAttemptGate.Ticket, val future: Future<*>, val timeout: ScheduledFuture<*>)
    private val attempts = HashMap<Long, Attempt>()
    private val audio = LinkedHashSet<Long>()
    private var generation = 0
    private var lastId = 0L
    private var audioCursor = 1L
    private var scanCursor = 1L
    private var status = ""
    private var networkSaturatedUntil = 0L
    private val translatedContext = object : LinkedHashMap<Long, Pair<Long, String>>(64, .75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<Long, Pair<Long, String>>?) = size > 64
    }
    private fun rememberContext(r: LiveWork) {
        if (r.translated.isNotEmpty() && (translatedContext[r.occurrence]?.first ?: 0) < r.id)
            translatedContext[r.occurrence] = r.id to r.translated.takeLast(600)
    }
    @Volatile var captureHalted = false
        private set
    private val ticker = worker.scheduleWithFixedDelay({ safe { pump() } }, 500, 500, TimeUnit.MILLISECONDS)

    private fun status(message: String) {
        if (captureHalted && message.isEmpty()) return
        if (message != status) { status = message; onStatus(message) }
    }
    private fun safe(block: () -> Unit) {
        if (closed.get()) return
        try { block() } catch (_: Exception) {
            captureHalted = true
            event(0, "storage_halted")
            status("بۆ پاراستنی ڕیزی دەق، گرتنی دەقی تازە وەستا؛ بۆشایی و بیرگە بپشکنە")
        }
    }
    private fun post(block: () -> Unit) {
        if (closed.get()) return
        try { worker.execute { safe(block) } } catch (_: RejectedExecutionException) {}
    }
    /** Capture must await this append before releasing its OCR busy gate. */
    fun append(record: LiveWork): Boolean = call {
        store.put(record); rememberContext(record); lastId = maxOf(lastId, record.id)
        event(record.id, if (record.translated.isEmpty()) "queued" else "translated")
        pump(); true
    }
    fun wake() = post { pump() }
    fun tick() = call { pump(); true }
    private fun call(block: () -> Boolean): Boolean {
        if (closed.get()) return false
        if (Thread.currentThread() === owner) {
            var result = false; safe { result = block() }; return result
        }
        val future = try { worker.submit<Boolean> {
            var result = false; safe { result = block() }; result
        } } catch (_: RejectedExecutionException) { return false }
        return try { future.get(1500, TimeUnit.MILLISECONDS) }
        catch (_: Exception) {
            future.cancel(false)
            captureHalted = true
            post { status("گرتنی دەقی تازە وەستا؛ نووسینی ڕیزی کاتی خاوە") }
            false
        }
    }
    private fun pump() {
        val now = clock()
        // Retry acknowledgements after a transient delete failure without replaying audio.
        for (id in audio.toList()) store.get(id)?.takeIf { it.state in listOf(LiveWorkState.COMPLETE, LiveWorkState.FAILED_AUDIO) }?.let {
            acknowledge(it, it.outcome); audio.remove(id)
        }
        attempts.values.filter { now >= it.ticket.deadline }.toList().forEach { expire(it.ticket) }
        if (online()) {
            // The blocked head has priority; other requests remain bounded to two.
            if (attempts.size < 2) tryTranslation(audioCursor)
            var checked = 0
            while (attempts.size < 2 && checked++ < 64 && lastId >= audioCursor) {
                if (scanCursor < audioCursor || scanCursor > lastId) scanCursor = audioCursor
                tryTranslation(scanCursor++)
                if (checked >= (lastId - audioCursor + 1).coerceAtMost(64)) break
            }
        }
        pumpAudio()
    }
    private fun tryTranslation(id: Long) {
        if (id > lastId || id in attempts || attempts.size >= 2 || clock() < networkSaturatedUntil) return
        val r = store.get(id) ?: return
        if (r.state != LiveWorkState.QUEUED && r.state != LiveWorkState.FAILED_RETRYABLE) return
        if (r.retryAt > clock()) return
        val previous = translatedContext[r.occurrence]?.takeIf { it.first < r.id }?.second
        val context = r.context.filterNot { it.startsWith("Previously translated span:") } +
            listOfNotNull(previous?.let { "Previously translated span: $it" })
        val current = r.copy(state = LiveWorkState.TRANSLATING, attempts = r.attempts + 1, context = context)
        store.put(current)
        val ticket = gate.begin(id, clock())
        try {
            val future = network.submit {
                val result = try { translate(current)?.takeIf { it.isNotBlank() } } catch (_: Exception) { null }
                post { finish(ticket, result) }
            }
            val timeout = worker.schedule({ safe { expire(ticket) } }, 12_000, TimeUnit.MILLISECONDS)
            attempts[id] = Attempt(ticket, future, timeout)
        } catch (_: RejectedExecutionException) {
            gate.expire(ticket)
            networkSaturatedUntil = clock() + 1000
            store.put(r.copy(retryAt = networkSaturatedUntil))
        }
    }
    private fun finish(ticket: LiveAttemptGate.Ticket, result: String?) {
        val a = attempts[ticket.id] ?: return
        if (a.ticket != ticket) return
        attempts.remove(ticket.id); a.timeout.cancel(false)
        val r = store.get(ticket.id) ?: return
        if (!gate.finish(ticket, clock()) || result == null) failTranslation(r)
        else {
            val success = r.copy(state = LiveWorkState.TRANSLATED, translated = result)
            store.put(success); rememberContext(success); accepted(success)
            event(r.id, "translated")
        }
        pump()
    }
    private fun expire(ticket: LiveAttemptGate.Ticket) {
        val a = attempts[ticket.id] ?: return
        if (a.ticket != ticket || !gate.expire(ticket)) return
        attempts.remove(ticket.id); a.future.cancel(true); a.timeout.cancel(false)
        store.get(ticket.id)?.let { failTranslation(it) }
    }
    private fun failTranslation(r: LiveWork) {
        store.put(r.copy(state = LiveWorkState.FAILED_RETRYABLE,
            retryAt = clock() + LiveAttemptGate.retryDelay(r.attempts)))
        event(r.id, "translation_failed_retryable")
    }
    private fun pumpAudio() {
        while (audio.size < audioCapacity && audioCursor <= lastId) {
            var r = store.get(audioCursor)
            if (r == null) { audioCursor++; continue }
            if (r.state !in listOf(LiveWorkState.TRANSLATED, LiveWorkState.AUDIO_QUEUED)) {
                if (r.state == LiveWorkState.FAILED_RETRYABLE || (!online() && clock() - r.observed >= 1000))
                    status("خوێندنەوە چاوەڕێی وەرگێڕانە؛ دەقەکان پارێزراون")
                break
            }
            if (r.members.isEmpty()) {
                val members = mutableListOf(r.id)
                val text = StringBuilder(r.translated)
                var next = r.id + 1
                while (members.size < 64 && next <= lastId) {
                    val b = store.get(next) ?: break
                    if (b.state != LiveWorkState.TRANSLATED || !b.continuation || b.occurrence != r.occurrence ||
                        text.length + b.translated.length > 600) break
                    text.append(' ').append(b.translated); members.add(next++)
                }
                r = r.copy(members = members, audioText = text.toString())
            }
            r = r.copy(state = LiveWorkState.AUDIO_QUEUED)
            store.put(r); audio.add(r.id); audioCursor = r.members.last() + 1
            status("")
            onAudio(AudioUnit(r, generation, (lastId - r.members.last()).coerceIn(0, Int.MAX_VALUE.toLong()).toInt()))
        }
    }
    private fun current(unit: AudioUnit): LiveWork? =
        if (unit.generation == generation && unit.work.id in audio) store.get(unit.work.id) else null

    /** Persist a frozen synthesis layout before generating any chunk. */
    fun plan(unit: AudioUnit, chunks: List<String>) = call {
        val r = current(unit) ?: return@call false
        if (chunks.isEmpty() || (r.chunks.isNotEmpty() && r.chunks != chunks)) return@call false
        store.put(r.copy(chunks = chunks.toList())); true
    }
    fun ready(unit: AudioUnit) = post {
        current(unit)?.let { r ->
            if (r.state == LiveWorkState.AUDIO_QUEUED) store.put(r.copy(state = LiveWorkState.READY))
            event(r.id, "pcm_ready")
        }
    }
    /** Synchronous durability fence before native writes: a late callback cannot cause replay. */
    fun submitted(unit: AudioUnit, chunk: Int) = call {
        val r = current(unit) ?: return@call false
        if (chunk !in r.chunks.indices || chunk != maxOf(r.submittedThrough, r.failedThrough) + 1) return@call false
        store.put(r.copy(submittedThrough = chunk, audioRetries = 0)); event(r.id, "chunk_submitted"); true
    }
    fun started(unit: AudioUnit, chunk: Int) = post {
        current(unit)?.let { r ->
            if (chunk !in r.chunks.indices || chunk > r.submittedThrough) return@let
            if (r.state != LiveWorkState.PLAYING) store.put(r.copy(state = LiveWorkState.PLAYING))
            event(r.id, "playback_started")
        }
    }
    fun chunkDone(unit: AudioUnit, chunk: Int) = post {
        current(unit)?.let { r ->
            if (chunk <= r.submittedThrough && chunk == maxOf(r.completedThrough, r.uncertainThrough, r.failedThrough) + 1)
                store.put(r.copy(completedThrough = chunk))
        }
    }
    fun complete(unit: AudioUnit) = post {
        val r = current(unit) ?: return@post
        if (r.chunks.isEmpty() || r.completedThrough != r.chunks.lastIndex) return@post
        acknowledge(r, if (r.uncertainThrough >= 0 || r.failedThrough >= 0) "audio_complete_with_gap" else "playback_complete"); audio.remove(r.id); pump()
    }
    private fun acknowledge(r: LiveWork, outcome: String) {
        store.put(r.copy(state = if (outcome == "playback_complete") LiveWorkState.COMPLETE else LiveWorkState.FAILED_AUDIO, outcome = outcome))
        val members = r.members.ifEmpty { listOf(r.id) }
        // The parent survives until every child is removed, retaining the group checkpoint.
        for (id in members.filter { it != r.id } + r.id) { event(id, outcome); store.remove(id) }
    }
    fun audioFailed(oldGeneration: Int) = post {
        if (oldGeneration != generation) return@post
        generation++
        val pending = audio.sorted(); audio.clear()
        if (pending.isNotEmpty()) audioCursor = minOf(audioCursor, pending.first())
        for (id in pending) {
            val r = store.get(id) ?: continue
            if (r.submittedThrough > r.completedThrough) event(id, "uncertain_audio_tail")
            val uncertain = if (r.submittedThrough > r.completedThrough)
                maxOf(r.uncertainThrough, r.submittedThrough) else r.uncertainThrough
            val next = maxOf(r.submittedThrough, r.failedThrough) + 1
            when {
                r.chunks.isEmpty() && r.audioRetries >= 1 -> acknowledge(r, "audio_failed")
                r.chunks.isNotEmpty() && next >= r.chunks.size -> acknowledge(r, "audio_failed")
                r.audioRetries >= 1 -> {
                    // The failed, never-submitted chunk is explicit. Later chunks still get their own chance.
                    event(id, "audio_chunk_failed:$next")
                    val advanced = r.copy(state = LiveWorkState.AUDIO_QUEUED, failedThrough = next,
                        audioRetries = 0, uncertainThrough = uncertain)
                    if (next == r.chunks.lastIndex) acknowledge(advanced, "audio_complete_with_gap")
                    else store.put(advanced)
                }
                else -> {
                    store.put(r.copy(state = LiveWorkState.AUDIO_QUEUED, audioRetries = r.audioRetries + 1,
                        uncertainThrough = uncertain))
                    event(id, "audio_retry_tail")
                }
            }
        }
        pump()
    }
    /** Reconnect wakes the failed head immediately, not a new copy of its source. */
    fun reconnected() = post {
        store.get(audioCursor)?.takeIf { it.state == LiveWorkState.FAILED_RETRYABLE }?.let {
            store.put(it.copy(retryAt = 0))
        }
        pump()
    }
    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        ticker.cancel(false)
        worker.execute {
            attempts.values.forEach { it.future.cancel(true); it.timeout.cancel(false) }
            attempts.clear(); gate.cancelAll(); audio.clear(); network.shutdownNow(); store.close()
        }
        worker.shutdown()
    }
    // Test/diagnostic barriers do not expose text in the timing report.
    fun inspect(id: Long): LiveWork? = if (closed.get()) null else worker.submit<LiveWork?> { store.get(id) }.get(2, TimeUnit.SECONDS)
    fun cachedRecords() = worker.submit<Int> { store.cachedRecords() }.get(2, TimeUnit.SECONDS)
}
