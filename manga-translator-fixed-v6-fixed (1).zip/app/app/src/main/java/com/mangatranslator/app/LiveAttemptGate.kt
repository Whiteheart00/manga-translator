package com.mangatranslator.app

/** Clock-injected attempt tickets: late completions never win after timeout/cancel. */
internal class LiveAttemptGate(private val deadlineMs: Long = 12_000) {
    data class Ticket(val id: Long, val serial: Long, val deadline: Long)
    private var serial = 0L
    private val active = HashMap<Long, Ticket>()
    fun begin(id: Long, now: Long) = Ticket(id, ++serial, now + deadlineMs).also { active[id] = it }
    fun finish(ticket: Ticket, now: Long): Boolean {
        if (active[ticket.id] != ticket) return false
        active.remove(ticket.id)
        return now < ticket.deadline
    }
    fun expire(ticket: Ticket): Boolean = if (active[ticket.id] == ticket) { active.remove(ticket.id); true } else false
    fun cancelAll() = active.clear()
    companion object {
        fun retryDelay(failures: Int): Long = when (failures) {
            0, 1 -> 1000; 2 -> 2000; 3 -> 4000; 4 -> 8000; else -> 15000
        }
    }
}
