package com.mangatranslator.app

/** At most one active lease; an expired generation can never unlock its successor. */
internal class LiveOcrLease(private val timeoutMs: Long = 12_000) {
    enum class Expiry { NONE, RESET, HALT }
    private var current: Int? = null
    private var started = 0L
    private var resets = 0
    @Synchronized fun begin(id: Int, now: Long): Boolean {
        if (current != null) return false
        current = id; started = now; return true
    }
    @Synchronized fun accepts(id: Int) = current == id
    @Synchronized fun finish(id: Int): Boolean {
        if (current != id) return false
        current = null; return true
    }
    @Synchronized fun expire(now: Long): Expiry {
        if (current == null || now - started < timeoutMs) return Expiry.NONE
        current = null
        return if (resets++ == 0) Expiry.RESET else Expiry.HALT
    }
    @Synchronized fun cancel() { current = null }
}
