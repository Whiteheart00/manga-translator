package com.mangatranslator.app

/** Group slightly uneven word boxes into lines before ordering words. */
internal object LiveTextOrder {
    fun join(blocks: List<Blk>, rtl: Boolean): String {
        val lines = ArrayList<MutableList<Blk>>()
        for (b in blocks.sortedBy { (it.t + it.b) / 2 }) {
            val center = (b.t + b.b) / 2f
            val line = lines.lastOrNull()
            val first = line?.firstOrNull()
            if (first != null && kotlin.math.abs(center - (first.t + first.b) / 2f) <=
                maxOf(2f, minOf(b.b - b.t, first.b - first.t) * 0.6f)) line.add(b)
            else lines.add(mutableListOf(b))
        }
        return lines.joinToString(" ") { line ->
            val physical = line.sortedBy { it.l }
            fun direction(b: Blk): Boolean? {
                for (c in b.text) when (Character.getDirectionality(c)) {
                    Character.DIRECTIONALITY_LEFT_TO_RIGHT -> return false
                    Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> return true
                    Character.DIRECTIONALITY_EUROPEAN_NUMBER, Character.DIRECTIONALITY_ARABIC_NUMBER -> return false
                }
                return null
            }
            val runs = ArrayList<Pair<Boolean, MutableList<Blk>>>()
            for (b in physical) {
                val d = direction(b) ?: runs.lastOrNull()?.first ?: rtl
                if (runs.lastOrNull()?.first == d) runs.last().second.add(b)
                else runs.add(d to mutableListOf(b))
            }
            (if (rtl) runs.reversed() else runs).joinToString(" ") { (rightToLeft, words) ->
                (if (rightToLeft) words.reversed() else words).joinToString(" ") { it.text.trim() }
            }
        }.trim()
    }
}
