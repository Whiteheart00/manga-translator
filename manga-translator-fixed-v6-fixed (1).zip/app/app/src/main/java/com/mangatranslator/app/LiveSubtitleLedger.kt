package com.mangatranslator.app

/** One visible occurrence, rather than a global history of similar sentences.
 * All calls belong to the live worker. Played audio is immutable.
 */
internal class LiveSubtitleLedger(private val settleMs: Long = 180) {
    // Two or three missed OCR frames are common while a video subtitle is
    // moving. Do not close the occurrence that quickly, or the same visible
    // sentence is emitted again when OCR recovers.
    private val absenceConfirmMs = maxOf(500L, settleMs * 3)
    enum class State { SEEN, CONFIRMED, TRANSLATED, READY, PLAYING, COMPLETE, FAILED }
    data class Segment(val id: Long, val occurrence: Long, val text: String,
                       val fullText: String, val continuation: Boolean, val firstSeen: Long,
                       var state: State = State.CONFIRMED, val ocrCompleted: Long = firstSeen)
    private data class Token(val key: String, val start: Int)
    private val pattern = Regex("[\\p{L}\\p{M}\\p{N}]+(?:['’][\\p{L}\\p{M}\\p{N}]+)*")
    private fun tokens(s: String): List<Token> {
        val result = ArrayList<Token>()
        fun add(start: Int, end: Int) {
            if (end > start) result.add(Token(s.substring(start, end).lowercase().replace('ك', 'ک').replace('ي', 'ی'), start))
        }
        for (match in pattern.findAll(s)) {
            var run = match.range.first
            var i = run
            while (i <= match.range.last) {
                val code = s.codePointAt(i)
                val width = Character.charCount(code)
                val script = Character.UnicodeScript.of(code)
                if (script in listOf(Character.UnicodeScript.HAN, Character.UnicodeScript.HIRAGANA,
                        Character.UnicodeScript.KATAKANA, Character.UnicodeScript.HANGUL)) {
                    add(run, i); add(i, i + width); run = i + width
                }
                i += width
            }
            add(run, match.range.last + 1)
        }
        return result
    }
    private var accepted = emptyList<Token>()
    private var pending = ""
    private var pendingAt = 0L
    private var lastChange = 0L
    private var pendingOcrAt = 0L
    private var absentAt: Long? = null
    var isAbsent: Boolean = false
        private set
    // A shorter prefix can be either one truncated OCR frame or a genuinely
    // new subtitle. Keep the former debounce, but allow the latter through
    // once the same shorter text stays visible for a complete settle window.
    private var truncatedCandidate = ""
    private var truncatedSince = 0L
    private var occurrence = 0L
    private var serial = 0L
    private var band = ""
    val segments = LinkedHashMap<Long, Segment>()
    private fun keys(t: List<Token>) = t.map { it.key }

    fun observe(raw: String, now: Long, regionKey: String = "", observedAt: Long = now): List<Segment> {
        val out = ArrayList<Segment>()
        if (regionKey != band) {
            flush()?.let(out::add)
            accepted = emptyList(); truncatedCandidate = ""; truncatedSince = 0L
            occurrence++; band = regionKey
        }
        val text = raw.trim()
        if (tokens(text).isEmpty()) {
            flush()?.let(out::add)
            truncatedCandidate = ""; truncatedSince = 0L
            val blank = absentAt
            if (blank == null) absentAt = now
            else if (now - blank >= absenceConfirmMs) { accepted = emptyList(); occurrence++; isAbsent = true }
            return out
        }
        absentAt = null
        isAbsent = false
        val incoming = tokens(text)
        val prior = if (pending.isNotEmpty()) tokens(pending) else accepted
        val same = keys(incoming) == keys(prior)
        val growth = prior.isNotEmpty() && incoming.size > prior.size &&
            keys(incoming.take(prior.size)) == keys(prior)
        // Ignore a temporarily truncated OCR prefix before resetting occurrence identity.
        // If the same shorter text remains visible for a full settle window, it is
        // a genuine new subtitle rather than a single OCR frame that lost its tail.
        if (incoming.size < accepted.size && keys(accepted.take(incoming.size)) == keys(incoming)) {
            if (truncatedCandidate != text) {
                truncatedCandidate = text
                truncatedSince = now
                return out
            }
            if (now - truncatedSince < settleMs) return out
            accepted = emptyList()
            occurrence++
            pending = text
            pendingAt = observedAt
            pendingOcrAt = now
            lastChange = now
            truncatedCandidate = ""
            truncatedSince = 0L
            flush()?.let(out::add)
            return out
        }
        truncatedCandidate = ""
        truncatedSince = 0L
        if (!same && !growth) {
            flush()?.let(out::add)
            // Exact suffix/prefix only; do not erase genuinely changed short lines.
            if (overlap(accepted, incoming) == 0) { accepted = emptyList(); occurrence++ }
        }
        if (keys(incoming) == keys(accepted)) return out
        if (pending.isEmpty()) pendingAt = observedAt
        if (!same || pending.isEmpty()) { lastChange = now; pendingOcrAt = now }
        pending = text
        val complete = text.lastOrNull() in listOf('.', '!', '?', '؟', '。', '！', '？')
        if (complete || now - lastChange >= settleMs) flush()?.let(out::add)
        return out
    }
    fun settle(now: Long): Segment? = if (pending.isNotEmpty() && now - lastChange >= settleMs) flush() else null
    fun reset() {
        pending = ""; accepted = emptyList(); absentAt = null; isAbsent = false
        truncatedCandidate = ""; truncatedSince = 0L; occurrence++
    }
    @Synchronized fun failUnfinishedAudio(): List<Long> = segments.values
        .filter { it.state in listOf(State.TRANSLATED, State.READY, State.PLAYING) }
        .map { it.state = State.FAILED; it.id }
    @Synchronized fun state(id: Long, value: State) {
        segments[id]?.let { if (it.state !in listOf(State.COMPLETE, State.FAILED) && value.ordinal >= it.state.ordinal) it.state = value }
    }
    @Synchronized fun forget(id: Long) { segments.remove(id) }
    @Synchronized private fun remember(s: Segment) {
        segments[s.id] = s
        // Bound completed diagnostics, never discard pending work.
        val old = segments.values.filter { it.state == State.COMPLETE }.take((segments.size - 200).coerceAtLeast(0))
        old.forEach { segments.remove(it.id) }
    }
    private fun flush(): Segment? {
        if (pending.isEmpty()) return null
        val full = pending; pending = ""
        val incoming = tokens(full)
        val used = overlap(accepted, incoming)
        val text = if (used >= incoming.size) "" else full.substring(incoming[used].start).trim()
        accepted = incoming
        if (text.isEmpty()) return null
        return Segment(++serial, occurrence, text, full, used > 0, pendingAt, ocrCompleted = pendingOcrAt).also(::remember)
    }
    private fun overlap(old: List<Token>, new: List<Token>): Int {
        for (n in minOf(old.size, new.size) downTo 1) {
            if (keys(old.takeLast(n)) == keys(new.take(n))) return n
        }
        return 0
    }
}
