package com.mangatranslator.app

/**
 * دەقی سۆرانی ← دەقێکی ئینگلیزیی ڕوون، کە دەنگی ئینگلیزیی ئۆفلاینی ناو مۆبایل بە نزیکترین دەنگ بۆ کوردی
 * بیخوێنێتەوە. تەنها بۆ خوێندنەوەیە، نەک نووسینی ڕەسمیی کوردی.
 *
 * ڕێساکان (هەموو بە شێوازی نووسینی ئینگلیزی، تا دەنگە ئینگلیزییەکە هەڵە نەخوێنێتەوە):
 *   ا = ah  ە = eh  ێ = ay  ۆ = oh  وو/و = oo  ی = ee  (y/w ئەگەر لە نێوان دەنگدارەکان بێت)
 *   چ = ch  ش = sh  ژ = zh  خ = kh  غ = gh  ج = j  ڕ = r  ڵ = l  ق = k  ڤ = v
 *   ئەو = ow ، ئاو = ow ، ەی = ay ، دەنگی کورتی «i» ی نەنووسراو لە کۆمەڵە پیتی بێدەنگ دەخرێتە ناو وشە
 */
object KurdishVoiceText {

    const val EN = 0
    const val PIPER = 4 // مۆدێلی نیورالی کوردی (Piper/ONNX) — دەقی سۆرانی بێ گۆڕین؛ بڕوانە PiperTts

    fun convert(text: String, mode: Int): String = when (mode) {
        PIPER -> text
        else -> toEnglish(text)
    }

    private val vowelLetters = setOf('ا', 'ە', 'ێ', 'ۆ', 'ی', 'و', 'ؤ')

    private val enCons = mapOf(
        'ب' to "b", 'پ' to "p", 'ت' to "t", 'ج' to "j", 'چ' to "ch",
        'ح' to "h", 'خ' to "kh", 'د' to "d", 'ر' to "r", 'ڕ' to "r",
        'ز' to "z", 'ژ' to "zh", 'س' to "s", 'ش' to "sh", 'غ' to "gh",
        'ف' to "f", 'ڤ' to "v", 'ق' to "k", 'ک' to "k", 'گ' to "g",
        'ل' to "l", 'ڵ' to "l", 'م' to "m", 'ن' to "n", 'ه' to "h",
        'ھ' to "h", 'ث' to "s", 'ذ' to "z", 'ص' to "s", 'ض' to "z",
        'ط' to "t", 'ظ' to "z", 'ك' to "k", 'ڪ' to "k", 'ع' to ""
    )

    private val digits = mapOf(
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9',
        '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
        '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9'
    )

    private val punct = mapOf('،' to ",", '؟' to "?", '؛' to ";", '۔' to ".", '«' to "\"", '»' to "\"")

    private fun isArabicLetter(c: Char) = c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F'

    /** وشە باوەکان کە ڕێساکە بە باشی ناینووسێت؛ ڕاستەوخۆ بە شێوەی ڕوون دەنووسرێن. */
    private val common = mapOf(
        "ئەو" to "ow", "ئاو" to "ow", "ئەم" to "ehm", "ئەمە" to "ehmeh", "ئەوە" to "ehweh",
        "ئەوان" to "ehwahn", "ئێمە" to "aymeh", "ئێوە" to "aywe", "من" to "min", "تۆ" to "toh",
        "ئێستا" to "aystah", "ئەمڕۆ" to "ehmroh", "سڵاو" to "slow", "سوپاس" to "soopahs",
        "بۆ" to "boh", "بە" to "beh", "لە" to "leh", "کە" to "keh", "وە" to "weh", "و" to "oo",
        "نا" to "nah", "نەخێر" to "nehkhayr", "بەڵێ" to "behlay", "باشە" to "bahsheh",
        "چی" to "chee", "چۆن" to "chohn", "کێ" to "kay", "کوێ" to "kway", "کەی" to "kay",
        "زۆر" to "zohr", "هەموو" to "hehmoo", "هیچ" to "heech",
        "هاوڕێ" to "hahwray", "ئاوات" to "ahwaht", "هەناسە" to "hehnahseh", "گیان" to "gyahn",
        "دڵخۆش" to "dilkhohsh", "هاوسەر" to "hahwsehr", "ژوور" to "zhoor", "ئازا" to "ahzah"
    )

    fun toEnglish(text: String): String {
        val sb = StringBuilder()
        var i = 0
        val n = text.length
        while (i < n) {
            val c = text[i]
            if (!isArabicLetter(c) || c in punct || c in digits) {
                sb.append(digits[c] ?: punct[c] ?: c)
                i++
                continue
            }
            var j = i
            while (j < n && isArabicLetter(text[j]) && text[j] !in punct && text[j] !in digits) j++
            sb.append(englishWord(text.substring(i, j)))
            i = j
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private class Tok(val s: String, val vowel: Boolean)

    private fun englishWord(raw: String): String {
        val w = raw.filter { it !in '\u064B'..'\u065F' && it != 'ـ' && it != '\u200c' && it != '\u200d' }
            .replace('ك', 'ک').replace('ي', 'ی').replace('ى', 'ی').replace('ة', 'ە')
        common[w]?.let { return it }
        val toks = ArrayList<Tok>()
        var i = 0
        while (i < w.length) {
            val c = w[i]
            val next = w.getOrNull(i + 1)
            val prev = w.getOrNull(i - 1)
            val nextNext = w.getOrNull(i + 2)
            when {
                c == 'و' && next == 'و' -> { toks.add(Tok("oo", true)); i += 2; continue }
                // ەو / او لە کۆتای وشە: دووپیت (diphthong) = ow
                (c == 'ە' || c == 'ا') && next == 'و' && nextNext == null -> {
                    toks.add(Tok("ow", true)); i += 2; continue
                }
                // ەی: ay (کەی = kay)
                c == 'ە' && next == 'ی' && (nextNext == null || nextNext !in vowelLetters) -> {
                    toks.add(Tok("ay", true)); i += 2; continue
                }
                c == 'و' -> {
                    val nextIsVowel = next != null && next in vowelLetters
                    val afterVowel = prev != null && prev in setOf('ا', 'ە', 'ێ', 'ۆ')
                    if (nextIsVowel || afterVowel) toks.add(Tok("w", false)) else toks.add(Tok("oo", true))
                }
                c == 'ی' -> {
                    val nextIsVowel = next != null && next in vowelLetters && next != 'ی'
                    if (i == 0 || nextIsVowel) toks.add(Tok("y", false)) else toks.add(Tok("ee", true))
                }
                c == 'ێ' -> toks.add(Tok("ay", true))
                c == 'ە' -> toks.add(Tok("eh", true))
                c == 'ۆ' || c == 'ؤ' -> toks.add(Tok("oh", true))
                c == 'ا' -> toks.add(Tok("ah", true))
                c == 'ئ' || c == 'ء' -> { }
                else -> {
                    val s = enCons[c]
                    if (!s.isNullOrEmpty()) toks.add(Tok(s, false))
                }
            }
            i++
        }
        // دەنگی کورتی «i» کە سۆرانی ناینووسێت: bra → bira ، سێ بێدەنگ لە ڕیز → i لە ناوەڕاست
        val o = StringBuilder()
        var run = 0
        for ((idx, t) in toks.withIndex()) {
            if (!t.vowel) {
                run++
                if ((run == 2 && idx == 1) || run == 3) {
                    o.append('i')
                    run = 1
                }
            } else run = 0
            o.append(t.s)
        }
        return o.toString()
    }
}
