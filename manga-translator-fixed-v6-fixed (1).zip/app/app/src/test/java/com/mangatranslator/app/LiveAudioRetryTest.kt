package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test
class LiveAudioRetryTest {
    @Test fun retriesQueuedAudioOnceButNeverPartlyPlayedAudio() {
        assertTrue(LiveAudioRetry.allowed(false, 0))
        assertFalse(LiveAudioRetry.allowed(false, 1))
        assertFalse(LiveAudioRetry.allowed(true, 0))
    }
    @Test fun backlogSpeedIsBoundedAndReturnsToNormal() {
        assertEquals(1f, LiveAudioRetry.boost(0), 0f)
        assertTrue(LiveAudioRetry.boost(2) > 1f)
        assertEquals(1.25f, LiveAudioRetry.boost(100), 0f)
        assertEquals(1f, LiveAudioRetry.boost(-1), 0f)
    }
}
