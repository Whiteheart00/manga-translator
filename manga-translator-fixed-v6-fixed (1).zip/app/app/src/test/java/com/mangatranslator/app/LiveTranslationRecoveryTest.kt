package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
class LiveTranslationRecoveryTest {
    @Test fun retriesBeforeFallbackAndNeverCachesBlankSuccess() {
        var primary = 0; var fallback = 0; var retry = 0
        val result = LiveTranslationRecovery.run({ true }, {
            primary++; if (primary == 1) throw IOException() else " "
        }, { fallback++; "وەرگێڕان" }, { retry++ })
        assertEquals("وەرگێڕان", result)
        assertEquals(2, primary); assertEquals(1, fallback); assertEquals(1, retry)
    }
    @Test fun firstSuccessDoesNotInvokeAnotherProvider() {
        assertEquals("ok", LiveTranslationRecovery.run({ true }, { "ok" }, { fail("fallback"); null }))
    }
    @Test fun cancellationDoesNotRetryOrFallback() {
        var active = true; var attempts = 0
        assertNull(LiveTranslationRecovery.run({ active }, { attempts++; active = false; null }, { fail("fallback"); null }))
        assertEquals(1, attempts)
    }
    @Test fun totalFailureRemainsFailure() {
        assertNull(LiveTranslationRecovery.run({ true }, { null }, { throw IOException() }))
    }
}
