package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test

class LiveRefreshTest {
    @Test fun staticSubtitleRetriesAfterMissedOcrWithoutBusyLoop() {
        assertFalse(LiveRefresh.rescanDue(449))
        assertTrue(LiveRefresh.rescanDue(450))
        assertTrue(LiveRefresh.rescanDue(2000))
        assertFalse(OcrGate.shouldRun(false, true, 700, 700, true, false, fastRefresh = true))
        assertTrue(OcrGate.shouldRun(false, true, 0, 700, false, false, fastRefresh = true))
    }

    @Test fun changedSubtitleCanRunEarlierOnMovingBackground() {
        assertFalse(OcrGate.shouldRun(false, false, 159, 200, false, false, fastRefresh = true))
        assertTrue(OcrGate.shouldRun(false, false, 160, 200, false, false, fastRefresh = true))
        assertFalse(OcrGate.shouldRun(false, true, 200, 99, false, false, fastRefresh = true))
        assertTrue(OcrGate.shouldRun(false, true, 200, 100, false, false, fastRefresh = true))
        assertFalse(OcrGate.shouldRun(false, true, 200, 200, true, false, fastRefresh = true))
        assertEquals(60L, LiveRefresh.captureMs(false))
        assertEquals(100L, LiveRefresh.captureMs(true))
    }
    @Test fun nonArabicLiveCaptureUsesShorterIntervals() {
        assertTrue(LiveRefresh.captureMs(false) < 150)
        assertTrue(LiveRefresh.captureMs(true) < 220)
    }
    @Test fun accessibilityNeverExceedsItsScreenshotRateLimit() {
        assertTrue(LiveRefresh.accessibilityMs(false) >= 333)
        assertTrue(LiveRefresh.accessibilityMs(true) >= 333)
        assertTrue(LiveRefresh.accessibilityMs(false) < 400)
        assertTrue(LiveRefresh.accessibilityMs(true) < 550)
    }
    @Test fun liveRefreshAllowsEarlierOcrButNeverConcurrentOcr() {
        assertTrue(OcrGate.shouldRun(false, true, 0, 120, false, false, fastRefresh = true))
        assertFalse(OcrGate.shouldRun(false, true, 0, 120, false, false))
        assertFalse(OcrGate.shouldRun(true, true, 1000, 1000, true, false, fastRefresh = true))
        assertTrue(OcrGate.shouldRun(false, false, 250, 300, false, false, fastRefresh = true))
        assertFalse(OcrGate.shouldRun(false, false, 250, 300, false, false))
    }
    @Test fun unchangedArabicOcrStillUsesItsExistingThresholds() {
        assertEquals(450L, OcrGate.forceMs(false))
        assertEquals(220L, OcrGate.gapMs(false))
        assertFalse(OcrGate.shouldRun(false, false, 300, 300, false, false))
    }
}
