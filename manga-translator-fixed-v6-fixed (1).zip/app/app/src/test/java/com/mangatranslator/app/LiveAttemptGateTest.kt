package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test
class LiveAttemptGateTest {
    @Test fun lateAndCancelledResultsCannotWin() {
        val g = LiveAttemptGate()
        val old = g.begin(1, 0); assertFalse(g.finish(old, 12000))
        val fresh = g.begin(1, 13000)
        assertFalse(g.finish(old, 13001)); assertTrue(g.finish(fresh, 13001))
        assertFalse(g.finish(fresh, 13002))
        val cancelled = g.begin(2, 14000); g.cancelAll(); assertFalse(g.finish(cancelled, 14001))
    }
    @Test fun expiryCannotExpireANewerAttempt() {
        val g = LiveAttemptGate(); val a = g.begin(1, 0); val b = g.begin(1, 1)
        assertFalse(g.expire(a)); assertTrue(g.finish(b, 2))
    }
    @Test fun backoffNeverExceedsFifteenSeconds() {
        assertEquals(listOf(1000L, 2000L, 4000L, 8000L, 15000L, 15000L),
            (1..6).map { LiveAttemptGate.retryDelay(it) })
    }
}
