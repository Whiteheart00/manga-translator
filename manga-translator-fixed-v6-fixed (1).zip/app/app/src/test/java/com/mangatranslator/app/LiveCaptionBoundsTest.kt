package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test
class LiveCaptionBoundsTest {
    @Test fun fullScreenSelectionCannotCaptureItsOwnCaption() {
        assertFalse(LiveCaptionBounds.outside(0f, 0f, 1080f, 1920f, 0, 0, 1080, 32))
        assertFalse(LiveCaptionBounds.outside(0f, 0f, 1080f, 1920f, 0, 1888, 1080, 1920))
    }
    @Test fun captionsAboveBelowOrAtTheEdgeDoNotCoverSource() {
        assertTrue(LiveCaptionBounds.outside(0f, 200f, 1080f, 400f, 0, 100, 1080, 200))
        assertTrue(LiveCaptionBounds.outside(0f, 200f, 1080f, 400f, 0, 400, 1080, 500))
        assertFalse(LiveCaptionBounds.outside(0f, 200f, 1080f, 400f, 0, 399, 1080, 500))
    }
}
