package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test
class LiveTimingTest {
    @Test fun exportsDurationsAndPercentilesWithoutSubtitleText() {
        val t = LiveTiming()
        for (i in 1L..20L) {
            t.mark(i, "observed", 1000)
            t.mark(i, "playback_started", 1000 + i * 10)
        }
        val report = t.csv()
        assertTrue(report.contains("0,total_p50_ms,100"))
        assertTrue(report.contains("0,total_p95_ms,190"))
    }
    @Test fun retainsBoundedEventsAndDoesNotInventMissingTimings() {
        val t = LiveTiming(2)
        t.mark(1, "observed", 0); t.mark(1, "translated", 50); t.mark(1, "audio_failed", 100)
        assertFalse(t.csv().contains("observed"))
        assertFalse(t.csv().contains("total_p"))
    }
}
