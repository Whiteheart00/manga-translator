package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files
import java.util.concurrent.*
import java.util.concurrent.atomic.*

class LiveDurablePipelineTest {
    private fun record(id: Long, translated: String = "", cont: Boolean = false) = LiveWork(
        id, 1, "source $id", "source $id", cont, 0, 0, "google",
        state = if (translated.isEmpty()) LiveWorkState.QUEUED else LiveWorkState.TRANSLATED, translated = translated)
    private fun await(condition: () -> Boolean) {
        val end = System.nanoTime() + TimeUnit.SECONDS.toNanos(3)
        while (!condition() && System.nanoTime() < end) Thread.sleep(5)
        assertTrue(condition())
    }
    @Test fun failedTranslationHoldsLaterAudioThenReconnectReleasesInOrder() {
        val root = Files.createTempDirectory("live-pipe").toFile()
        val now = AtomicLong(); val recover = AtomicBoolean(false)
        val audio = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val p = LiveDurablePipeline(root, now::get, { if (recover.get()) "translated" else null },
            onAudio = { audio.add(it) }, onStatus = {}, event = { _, _ -> })
        try {
            assertTrue(p.append(record(1))); assertTrue(p.append(record(2, "second")))
            await { p.inspect(1)?.state == LiveWorkState.FAILED_RETRYABLE }
            assertNull(audio.poll()); recover.set(true); p.reconnected()
            assertEquals(1L, audio.poll(3, TimeUnit.SECONDS)?.work?.id)
            assertEquals(2L, audio.poll(3, TimeUnit.SECONDS)?.work?.id)
        } finally { p.close() }
    }
    @Test fun timeoutRejectsInterruptIgnoringLateResponse() {
        val root = Files.createTempDirectory("live-pipe").toFile(); val now = AtomicLong()
        val firstStarted = CountDownLatch(1); val release = CountDownLatch(1); val calls = AtomicInteger()
        val audio = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val p = LiveDurablePipeline(root, now::get, {
            if (calls.incrementAndGet() == 1) {
                firstStarted.countDown()
                while (release.count > 0) try { release.await() } catch (_: InterruptedException) {}
                "late old result"
            } else "new result"
        }, onAudio = { audio.add(it) }, onStatus = {}, event = { _, _ -> })
        try {
            p.append(record(1)); assertTrue(firstStarted.await(2, TimeUnit.SECONDS))
            now.set(12000); p.tick()
            assertEquals(LiveWorkState.FAILED_RETRYABLE, p.inspect(1)?.state)
            now.set(13000); p.reconnected()
            assertEquals("new result", audio.poll(3, TimeUnit.SECONDS)?.work?.translated)
            release.countDown(); p.tick()
            assertEquals("new result", p.inspect(1)?.translated)
            assertNull(audio.poll())
        } finally { release.countDown(); p.close() }
    }
    @Test fun chunkRecoveryResumesOnlyTheUnsubmittedTailAndIgnoresOldCallbacks() {
        val root = Files.createTempDirectory("live-pipe").toFile()
        val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val p = LiveDurablePipeline(root, { 0 }, { null }, onAudio = { q.add(it) }, onStatus = {}, event = { _, _ -> })
        try {
            p.append(record(1, "whole utterance")); val a = q.poll(2, TimeUnit.SECONDS)!!
            assertTrue(p.plan(a, listOf("A", "B", "C")))
            assertTrue(p.submitted(a, 0)); p.chunkDone(a, 0); p.audioFailed(a.generation)
            val retry = q.poll(2, TimeUnit.SECONDS)!!
            assertEquals(1, retry.startChunk); assertEquals(listOf("A", "B", "C"), retry.work.chunks)
            assertFalse(p.submitted(a, 1)); p.complete(a)
            assertTrue(p.submitted(retry, 1)); p.chunkDone(retry, 1)
            assertTrue(p.submitted(retry, 2)); p.chunkDone(retry, 2); p.complete(retry)
            await { p.inspect(1) == null }
        } finally { p.close() }
    }
    @Test fun completedCallbacksAreIdempotentAndCannotReplayNativeAudio() {
        val root = Files.createTempDirectory("live-pipe").toFile(); val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val p = LiveDurablePipeline(root, { 0 }, { null }, onAudio = { q.add(it) }, onStatus = {}, event = { _, _ -> })
        try {
            p.append(record(1, "first")); val a = q.poll(2, TimeUnit.SECONDS)!!
            p.plan(a, listOf("first")); p.submitted(a, 0); p.chunkDone(a, 0); p.complete(a); p.complete(a)
            p.started(a, 0); p.ready(a); p.tick()
            assertNull(p.inspect(1)); assertNull(q.poll())
        } finally { p.close() }
    }
    @Test fun pendingContinuationsMergeBeforeSynthesisButPlayingAudioIsFrozen() {
        val root = Files.createTempDirectory("live-pipe").toFile(); val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val p = LiveDurablePipeline(root, { 0 }, { null }, audioCapacity = 1,
            onAudio = { q.add(it) }, onStatus = {}, event = { _, _ -> })
        try {
            p.append(record(1, "A")); val a = q.poll(2, TimeUnit.SECONDS)!!
            p.append(record(2, "B", true)); p.append(record(3, "C", true))
            assertEquals("A", a.work.audioText)
            p.plan(a, listOf("A")); p.submitted(a, 0); p.chunkDone(a, 0); p.complete(a)
            val merged = q.poll(2, TimeUnit.SECONDS)!!
            assertEquals("B C", merged.work.audioText); assertEquals(listOf(2L, 3L), merged.work.members)
            p.plan(merged, listOf("B C")); p.submitted(merged, 0); p.chunkDone(merged, 0); p.complete(merged)
            await { p.inspect(2) == null && p.inspect(3) == null }
        } finally { p.close() }
    }
    @Test fun diskSpillKeepsHotMemoryBoundedAndLowSpaceHaltsOnlyCapture() {
        val root = Files.createTempDirectory("live-pipe").toFile(); val free = AtomicLong(Long.MAX_VALUE)
        val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val p = LiveDurablePipeline(root, { 0 }, { null }, online = { false }, freeBytes = { free.get() },
            onAudio = { q.add(it) }, onStatus = {}, event = { _, _ -> })
        try {
            repeat(150) { assertTrue(p.append(record(it + 1L))) }
            assertTrue(p.cachedRecords() <= 64); assertNotNull(p.inspect(1)); assertNotNull(p.inspect(150))
            free.set(0); assertFalse(p.append(record(151))); assertTrue(p.captureHalted)
            assertNotNull(p.inspect(1)); assertNull(q.poll())
        } finally { p.close() }
    }
    @Test fun partialChunkGapIsReportedWithoutReplayingEarlierChunks() {
        val root = Files.createTempDirectory("live-pipe").toFile()
        val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val outcomes = ConcurrentLinkedQueue<String>()
        val p = LiveDurablePipeline(root, { 0 }, { null }, audioCapacity = 1,
            onAudio = { q.add(it) }, onStatus = {}, event = { _, e -> outcomes.add(e) })
        try {
            p.append(record(1, "three chunks")); val first = q.poll(2, TimeUnit.SECONDS)!!
            p.plan(first, listOf("one", "two", "three")); p.submitted(first, 0)
            p.chunkDone(first, 0); p.submitted(first, 1) // may have partly played
            p.audioFailed(first.generation)
            val resumed = q.poll(2, TimeUnit.SECONDS)!!
            assertEquals(2, resumed.startChunk)
            p.chunkDone(first, 1); p.complete(first) // stale callbacks cannot acknowledge the new run
            assertNotNull(p.inspect(1))
            p.plan(resumed, resumed.work.chunks); p.submitted(resumed, 2)
            p.chunkDone(resumed, 2); p.complete(resumed)
            await { p.inspect(1) == null }
            assertTrue(outcomes.contains("uncertain_audio_tail"))
            assertTrue(outcomes.contains("audio_complete_with_gap"))
            assertFalse(outcomes.contains("playback_complete"))
        } finally { p.close() }
    }
    @Test fun outOfOrderChunkCallbacksCannotClaimCompletion() {
        val root = Files.createTempDirectory("live-pipe").toFile()
        val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val p = LiveDurablePipeline(root, { 0 }, { null }, audioCapacity = 1,
            onAudio = { q.add(it) }, onStatus = {}, event = { _, _ -> })
        try {
            p.append(record(1, "two chunks")); val unit = q.poll(2, TimeUnit.SECONDS)!!
            p.plan(unit, listOf("one", "two")); p.submitted(unit, 0); p.submitted(unit, 1)
            p.chunkDone(unit, 1); p.complete(unit)
            assertNotNull(p.inspect(1))
            p.chunkDone(unit, 0); p.chunkDone(unit, 1); p.complete(unit)
            await { p.inspect(1) == null }
        } finally { p.close() }
    }
    @Test fun normalTranslationDoesNotShowAnErrorAndOnlyAcceptedResultsEnterCache() {
        val root = Files.createTempDirectory("live-pipe").toFile()
        val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val statuses = ConcurrentLinkedQueue<String>(); val cached = ConcurrentLinkedQueue<String>()
        val p = LiveDurablePipeline(root, { 0 }, { "ok" },
            onAudio = { q.add(it) }, onStatus = { statuses.add(it) }, event = { _, _ -> },
            accepted = { cached.add(it.translated) })
        try {
            p.append(record(1)); assertNotNull(q.poll(3, TimeUnit.SECONDS))
            assertTrue(statuses.none { it.isNotEmpty() }); assertEquals(listOf("ok"), cached.toList())
        } finally { p.close() }
    }
    @Test fun cleanCompletedChunkDoesNotBecomeAnUncertainGapOnRecovery() {
        val root = Files.createTempDirectory("live-pipe").toFile(); val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val outcomes = ConcurrentLinkedQueue<String>()
        val p = LiveDurablePipeline(root, { 0 }, { null }, onAudio = { q.add(it) }, onStatus = {}, event = { _, stage -> outcomes.add(stage) })
        try {
            p.append(record(1, "A B")); val a = q.poll(2, TimeUnit.SECONDS)!!
            p.plan(a, listOf("A", "B")); p.submitted(a, 0); p.chunkDone(a, 0); p.inspect(1)
            p.audioFailed(a.generation); val b = q.poll(2, TimeUnit.SECONDS)!!
            assertEquals(-1, b.work.uncertainThrough); assertEquals(1, b.startChunk)
            p.plan(b, b.work.chunks); p.submitted(b, 1); p.chunkDone(b, 1); p.complete(b)
            await { p.inspect(1) == null }
            assertTrue(outcomes.contains("playback_complete")); assertFalse(outcomes.contains("audio_complete_with_gap"))
        } finally { p.close() }
    }
    @Test fun aRepeatedlyFailingChunkDoesNotDiscardLaterUnsubmittedChunks() {
        val root = Files.createTempDirectory("live-pipe").toFile(); val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val outcomes = ConcurrentLinkedQueue<String>()
        val p = LiveDurablePipeline(root, { 0 }, { null }, onAudio = { q.add(it) }, onStatus = {}, event = { _, stage -> outcomes.add(stage) })
        try {
            p.append(record(1, "A B")); val a = q.poll(2, TimeUnit.SECONDS)!!
            p.plan(a, listOf("A", "B")); p.audioFailed(a.generation)
            val retry = q.poll(2, TimeUnit.SECONDS)!!; assertEquals(0, retry.startChunk)
            p.audioFailed(retry.generation)
            val tail = q.poll(2, TimeUnit.SECONDS)!!; assertEquals(1, tail.startChunk)
            p.plan(tail, tail.work.chunks); p.submitted(tail, 1); p.chunkDone(tail, 1); p.complete(tail)
            await { p.inspect(1) == null }
            assertTrue(outcomes.contains("audio_chunk_failed:0")); assertTrue(outcomes.contains("audio_complete_with_gap"))
        } finally { p.close() }
    }
    @Test fun stopErasesPrivateSpoolAndRejectsLateTranslation() {
        val root = Files.createTempDirectory("live-pipe").toFile(); val q = LinkedBlockingQueue<LiveDurablePipeline.AudioUnit>()
        val started = CountDownLatch(1); val release = CountDownLatch(1)
        val p = LiveDurablePipeline(root, { 0 }, {
            started.countDown(); try { release.await() } catch (_: InterruptedException) {}; "late"
        }, onAudio = { q.add(it) }, onStatus = {}, event = { _, _ -> })
        p.append(record(1)); assertTrue(started.await(2, TimeUnit.SECONDS)); p.close(); release.countDown()
        await { root.listFiles().isNullOrEmpty() }; assertNull(q.poll()); root.delete()
    }
}
