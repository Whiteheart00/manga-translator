package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test
class LiveOcrLeaseTest {
    @Test fun oldCallbackCannotUnlockNewCapture() {
        val l = LiveOcrLease(); assertTrue(l.begin(1, 0)); assertFalse(l.begin(2, 1))
        assertEquals(LiveOcrLease.Expiry.RESET, l.expire(12000))
        assertTrue(l.begin(2, 12001)); assertFalse(l.finish(1)); assertTrue(l.accepts(2))
        assertTrue(l.finish(2)); assertFalse(l.finish(2))
    }
    @Test fun repeatedMissingCallbacksHaltInsteadOfLeakingSessions() {
        val l = LiveOcrLease(); l.begin(1, 0); l.expire(12000); l.begin(2, 13000)
        assertEquals(LiveOcrLease.Expiry.NONE, l.expire(24999))
        assertEquals(LiveOcrLease.Expiry.HALT, l.expire(25000))
        assertFalse(l.accepts(2)); l.cancel()
    }
}
