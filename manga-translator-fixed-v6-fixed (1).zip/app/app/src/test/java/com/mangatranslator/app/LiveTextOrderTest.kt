package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test
class LiveTextOrderTest {
    @Test fun embeddedEnglishAndNumbersKeepTheirOwnDirection() {
        val boxes = listOf(Blk("world", 25, 10, 45, 30), Blk("Hello", 0, 10, 23, 30),
            Blk("هاوڕێ", 100, 10, 140, 30), Blk("١٢٣", 60, 10, 90, 30))
        assertEquals("هاوڕێ Hello world ١٢٣", LiveTextOrder.join(boxes, true))
    }

    @Test fun soraniWordsReadFromRightToLeftWithinEachLine() {
        val boxes = listOf(Blk("هاوڕێ", 0, 9, 40, 29), Blk("سڵاو", 50, 10, 90, 30),
            Blk("دووەم", 20, 50, 70, 70))
        assertEquals("سڵاو هاوڕێ دووەم", LiveTextOrder.join(boxes, true))
    }
    @Test fun unevenEnglishWordTopsDoNotShuffleReadingOrder() {
        assertEquals("Hello world", LiveTextOrder.join(listOf(
            Blk("world", 50, 9, 90, 29), Blk("Hello", 0, 11, 40, 31)), false))
    }
}
