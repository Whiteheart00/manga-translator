package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test

class LiveSubtitlePipelineTest {
    @Test fun thousandsOfRollingAndDuplicateFramesKeepEveryNewTokenExactlyOnce() {
        val ledger = LiveSubtitleLedger()
        val result = ArrayList<String>()
        for (i in 0 until 3000) {
            val frame = ((i - 2).coerceAtLeast(0)..i).joinToString(" ") { "word$it" } + "."
            result += ledger.observe(frame, i * 1000L).map { it.text }
            assertTrue(ledger.observe(frame, i * 1000L + 100).isEmpty())
            ledger.segments.keys.toList().forEach(ledger::forget)
        }
        assertEquals((0 until 3000).map { "word$it" }, result.joinToString(" ").replace(".", "").split(' '))
    }

    @Test fun cumulativeAndRollingFramesProduceEveryNewWordOnce() {
        val l = LiveSubtitleLedger()
        val result = mutableListOf<String>()
        for ((i, frame) in listOf("one two.", "one two three.", "two three four.", "three four five.").withIndex()) {
            result += l.observe(frame, i * 100L).map { it.text }
        }
        assertEquals(listOf("one two.", "three.", "four.", "five."), result)
    }
    @Test fun returningDialogueAfterAnUnrelatedLineIsANewOccurrence() {
        val l = LiveSubtitleLedger()
        val first = l.observe("Come here.", 0).single()
        l.observe("What happened?", 100)
        val repeated = l.observe("Come here.", 200).single()
        assertEquals("Come here.", repeated.text)
        assertNotEquals(first.occurrence, repeated.occurrence)
    }
    @Test fun aConfirmedBlankAllowsSameDialogueAgain() {
        val l = LiveSubtitleLedger()
        l.observe("Yes.", 0); l.observe("", 10); l.observe("", 600)
        assertEquals("Yes.", l.observe("Yes.", 650).single().text)
    }
    @Test fun newGeometryDoesNotShareDuplicateMemory() {
        val l = LiveSubtitleLedger()
        val first = l.observe("Hello.", 0, "top").single()
        val moved = l.observe("Hello.", 100, "bottom").single()
        assertNotEquals(first.occurrence, moved.occurrence)
    }
    @Test fun pendingWorkIsNeverEvictedAsCompletedWork() {
        val l = LiveSubtitleLedger()
        repeat(240) { l.observe("Sentence $it.", it * 100L) }
        assertEquals(240, l.segments.size)
        val failed = l.failUnfinishedAudio()
        assertTrue(failed.isEmpty()) // still confirmed, not yet submitted to audio
        assertTrue(l.segments.values.all { it.state == LiveSubtitleLedger.State.CONFIRMED })
    }
}
