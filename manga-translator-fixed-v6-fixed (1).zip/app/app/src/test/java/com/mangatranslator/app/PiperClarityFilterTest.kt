package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.*

class PiperClarityFilterTest {
    private val rate = 22050
    private fun gain(hz: Double, cutoff: Float = 7000f): Double {
        val x = FloatArray(rate) { (0.1 * sin(2 * PI * hz * it / rate)).toFloat() }
        PiperClarityFilter.apply(x, x.size, rate, cutoff)
        return sqrt(x.drop(2000).sumOf { it.toDouble() * it } / (x.size - 2000)) / (0.1 / sqrt(2.0))
    }
    @Test fun preservesConsonantBandBelowCutoff() {
        assertTrue(gain(4000.0) > 0.97)
        assertTrue(gain(6000.0) > 0.85)
    }
    @Test fun cutoffMatchesSelectedFrequencyAndSuppressesHiss() {
        assertEquals(1 / sqrt(2.0), gain(7000.0), 0.015)
        assertTrue(gain(10000.0) < 0.1)
        assertTrue(gain(6000.0, 4000f) < gain(6000.0, 7000f))
    }
    @Test fun removesDcAndLeavesEndPauseUntouched() {
        val x = FloatArray(rate + 200) { if (it < rate) 0.2f else 0f }
        PiperClarityFilter.apply(x, rate, rate, 7000f)
        assertTrue(x.sliceArray(20000 until rate).all { abs(it) < 0.00001f })
        assertTrue(x.drop(rate).all { it == 0f })
        assertTrue(x.all { it.isFinite() })
    }
    @Test fun silenceAndSmallBuffersAreSafe() {
        val x = FloatArray(10)
        PiperClarityFilter.apply(x, 10, rate, 7000f)
        assertArrayEquals(FloatArray(10), x, 0f)
        PiperClarityFilter.apply(FloatArray(0), 0, rate, 7000f)
        val impulse = floatArrayOf(1f)
        PiperClarityFilter.apply(impulse, 1, rate, 7000f)
        assertTrue(impulse[0].isFinite())
    }
}
