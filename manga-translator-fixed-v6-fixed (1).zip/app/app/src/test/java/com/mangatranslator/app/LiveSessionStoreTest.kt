package com.mangatranslator.app

import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files
import java.io.File
import java.io.IOException

class LiveSessionStoreTest {
    private fun record(id: Long) = LiveWork(id, 1, "سڵاو $id", "سڵاو $id", false, 0, 10, "google")
    @Test fun spillsWithoutGrowingHotMemoryAndKeepsEveryRecord() {
        val root = Files.createTempDirectory("live-store").toFile()
        LiveSessionStore(root).use { store ->
            repeat(250) { store.put(record(it + 1L)) }
            assertTrue(store.cachedRecords() <= 64)
            repeat(250) { assertEquals(record(it + 1L), store.get(it + 1L)) }
            assertTrue(store.cachedRecords() <= 64)
        }
        assertTrue(root.listFiles().isNullOrEmpty()); root.delete()
    }
    @Test fun failedAtomicReplacementPreservesOriginalRecord() {
        val root = Files.createTempDirectory("live-store").toFile(); var fail = false
        LiveSessionStore(root, beforeCommit = { if (fail) throw IOException("injected") }).use { s ->
            s.put(record(1)); fail = true
            try { s.put(record(1).copy(translated = "changed")); fail("expected failure") } catch (_: IOException) {}
            assertEquals(record(1), s.get(1))
            assertFalse(File(s.directory, "1.tmp").exists())
        }; root.delete()
    }
    @Test fun quotaAndLowSpaceDoNotEraseEarlierRecords() {
        val root = Files.createTempDirectory("live-store").toFile(); var free = Long.MAX_VALUE
        LiveSessionStore(root, maxBytes = 1000, freeBytes = { free }).use { s ->
            s.put(record(1)); val size = s.sizeBytes(); free = 0
            try { s.put(record(2)); fail("low space") } catch (_: IOException) {}
            assertEquals(size, s.sizeBytes()); assertEquals(record(1), s.get(1))
            free = Long.MAX_VALUE
            try { s.put(record(2).copy(source = "x".repeat(1100))); fail("quota") } catch (_: IOException) {}
            assertEquals(record(1), s.get(1))
        }; root.delete()
    }
    @Test fun corruptedRecordFailsClosedAfterCacheEviction() {
        val root = Files.createTempDirectory("live-store").toFile()
        LiveSessionStore(root).use { s ->
            repeat(70) { s.put(record(it + 1L)) }
            val file = File(s.directory, "1.rec"); val bytes = file.readBytes()
            bytes[20] = (bytes[20].toInt() xor 1).toByte(); file.writeBytes(bytes)
            try { s.get(1); fail("checksum") } catch (_: IOException) {}
        }; root.delete()
    }
    @Test fun largeBacklogsAreBoundedByBytesAsWellAsRecordCount() {
        val root = Files.createTempDirectory("live-store").toFile()
        LiveSessionStore(root).use { s ->
            repeat(50) { s.put(record(it + 1L).copy(source = "word".repeat(15000))) }
            assertTrue(s.cachedRecords() <= 64); assertTrue(s.cachedBytes() <= 2L * 1024 * 1024)
            assertEquals(60000, s.get(1)?.source?.length)
            try { s.put(record(100).copy(source = "x".repeat(300000))); fail("oversized") } catch (_: IOException) {}
            assertNotNull(s.get(1))
        }; root.delete()
    }
    @Test fun startupRemovesOrphansButNotAnActiveSession() {
        val root = Files.createTempDirectory("live-store").toFile()
        val orphan = File(root, "session-abandoned").apply { mkdir(); File(this, "1.tmp").writeText("partial") }
        LiveSessionStore(root).use { first ->
            first.put(record(1)); assertFalse(orphan.exists())
            LiveSessionStore(root).use { second ->
                assertTrue(first.directory.exists()); assertNotEquals(first.directory, second.directory)
            }
            assertEquals(record(1), first.get(1))
        }; root.delete()
    }
}
