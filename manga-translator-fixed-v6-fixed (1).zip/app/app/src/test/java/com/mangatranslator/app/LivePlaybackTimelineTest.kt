package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test

class LivePlaybackTimelineTest {
    @Test fun appendedAudioStartsOnlyAfterPreviousFramesAndNeverRepeats() {
        val t = LivePlaybackTimeline(); val calls = mutableListOf<String>()
        t.at(1) { calls.add("A start") }; t.at(100) { calls.add("A done") }
        t.at(101) { calls.add("B start") }; t.at(200) { calls.add("B done") }
        t.advance(50); assertEquals(listOf("A start"), calls)
        t.advance(100); assertEquals(listOf("A start", "A done"), calls)
        t.advance(200); t.advance(200)
        assertEquals(listOf("A start", "A done", "B start", "B done"), calls)
    }
    @Test fun cancellationCannotCompleteQueuedAudio() {
        val t = LivePlaybackTimeline(); var complete = false
        t.at(100) { complete = true }; t.cancel(); t.advance(200)
        assertFalse(complete)
    }
}
