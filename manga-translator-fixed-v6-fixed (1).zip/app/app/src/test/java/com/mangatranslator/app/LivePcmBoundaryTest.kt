package com.mangatranslator.app
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.*
class LivePcmBoundaryTest {
    @Test fun weakConsonantTailIsRetainedAndCommaFragmentsAreGrouped() {
        val input = FloatArray(1000) { when (it) { in 100..499 -> 0.3f; in 500..649 -> 0.001f; else -> 0f } }
        val out = LivePcmBoundary.apply(input, 1000, "word,")
        assertTrue(out.count { it == 0.001f } >= 145)
        assertEquals(listOf("one, two, three, four,", "five"), LivePcmBoundary.clauses("one, two, three, four, five"))
    }

    @Test fun limitsOnlyClipEdgesAndKeepsInternalPauses() {
        val rate = 1000
        val input = FloatArray(1500) { if (it in 200..399 || it in 650..849) 0.3f else 0f }
        val comma = LivePcmBoundary.apply(input, rate, "word,")
        val period = LivePcmBoundary.apply(input, rate, "word.")
        val continuation = LivePcmBoundary.apply(input, rate, "word")
        assertEquals(770, comma.size)
        assertEquals(870, period.size)
        assertEquals(730, continuation.size)
        assertTrue(comma.sliceArray(240..489).all { it == 0f })
        assertTrue(comma.all { it.isFinite() && abs(it) <= 0.3f })
    }
    @Test fun preservesPunctuationAndNumericSeparators() {
        assertEquals(listOf("Rate 3.14, count 1,000.", "Next!"), LivePcmBoundary.clauses("Rate 3.14, count 1,000. Next!"))
    }
    @Test fun emptyAndSilentClipsRemainSafe() {
        assertEquals(0, LivePcmBoundary.apply(FloatArray(0), 22050, ".").size)
        assertArrayEquals(FloatArray(10), LivePcmBoundary.apply(FloatArray(10), 22050, ","), 0f)
    }
}
