# Live subtitle reliability update

- Recheck the selected region every 700 ms when idle even if the coarse image signature is unchanged. This retries empty OCR and detects small subtitle changes. OCR remains serialized by the existing busy gate.
- Preserve the pending change time when OCR finishes so a change arriving during recognition does not incur another full settling interval.
- Replace the busy overlay text with a compact animated icon and exclude it from accessibility. This removes the app status label from screenshot OCR and screen reading.

Validation: LiveRefreshTest compiled and run separately using Kotlin 2.1 and JUnit 4.13.2. Android APK/device tests were not run: this workspace has no Android SDK or Gradle installation. Check short subtitles, moving backgrounds, Arabic network OCR, and full-screen reading on a device. Periodic retries may increase OCR/network work while live mode is active.
