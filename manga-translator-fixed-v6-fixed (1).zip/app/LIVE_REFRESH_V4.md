Live refresh v4

MediaProjection live sampling: 90 -> 60 ms, low-memory device 140 -> 100 ms. Local OCR minimum gap: 120 -> 100 ms, direct Kurdish 100 -> 80 ms. Moving-background force threshold: 250 -> 160 ms, Kurdish 180 -> 120 ms. Recovery scan: 700 -> 450 ms. Accessibility low-device sampling: 450 -> 400 ms; normal 350 ms stays within screenshot rate limits. Busy OCR gate and Arabic legacy thresholds retained.

Validation: 6 LiveRefreshTest JUnit tests pass, including changed/settled/busy boundary checks. No Android build or device/video latency test. These are sampling thresholds, not total audio latency. More frequent capture/OCR can increase CPU and battery use. Includes prior fixes.
