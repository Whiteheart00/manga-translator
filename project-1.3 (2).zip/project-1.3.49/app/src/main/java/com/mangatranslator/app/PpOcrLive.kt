package com.mangatranslator.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.SystemClock
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Fast, local PP-OCR path used only by LiveSubtitle.
 * The existing ML Kit/Tesseract/Gemini paths remain unchanged for normal region OCR.
 */
internal object PpOcrLive {
    private const val DET_SIZE = 640
    private const val REC_H = 48
    private const val REC_W = 320
    private const val DET_THRESHOLD = 0.30f
    private const val MIN_ROW_PIXELS = 3
    private const val MIN_TEXT_CHARS = 1
    private const val DET_MODEL = "ppocr_det_fp16.tflite"
    private const val REC_MODEL = "ppocr_rec_fp16.tflite"
    private const val DICT = "ppocrv5_dict.txt"

    private val lock = Any()
    @Volatile private var loaded = false
    private var detector: Interpreter? = null
    private var recognizer: Interpreter? = null
    private var dictionary: Array<String> = emptyArray()

    private data class Fit(val bitmap: Bitmap, val scale: Float, val left: Float, val top: Float)
    private data class Line(val left: Int, val top: Int, val right: Int, val bottom: Int)

    fun warmUp(ctx: Context) {
        synchronized(lock) {
            if (!ensureLoaded(ctx)) return
            // Allocate tensors now, before the first live frame arrives.
            detector?.allocateTensors()
            recognizer?.allocateTensors()
        }
    }

    fun release() {
        synchronized(lock) {
            try { detector?.close() } catch (_: Throwable) {}
            try { recognizer?.close() } catch (_: Throwable) {}
            detector = null
            recognizer = null
            dictionary = emptyArray()
            loaded = false
        }
    }

    fun recognize(ctx: Context, source: Bitmap): List<TextBox> {
        synchronized(lock) {
            if (!ensureLoaded(ctx)) return emptyList()
            val det = detector ?: return emptyList()
            val rec = recognizer ?: return emptyList()
            val t0 = SystemClock.elapsedRealtime()
            val fit = letterbox(source, DET_SIZE, DET_SIZE)
            val detInput = floatInput(fit.bitmap, DET_SIZE, DET_SIZE)
            val detOut = Array(1) { Array(1) { Array(DET_SIZE) { FloatArray(DET_SIZE) } } }
            try {
                det.run(detInput, detOut)
            } finally {
                fit.bitmap.recycle()
            }
            val lines = rowLines(detOut[0][0], fit, source.width, source.height)
            if (lines.isEmpty()) return emptyList()

            val result = ArrayList<TextBox>(lines.size)
            for (line in lines) {
                if (line.right - line.left < 3 || line.bottom - line.top < 3) continue
                val crop = try {
                    Bitmap.createBitmap(source, line.left, line.top,
                        line.right - line.left, line.bottom - line.top)
                } catch (_: Throwable) { continue }
                try {
                    val text = recognizeLine(rec, crop)
                    if (text.first.length >= MIN_TEXT_CHARS) {
                        result += TextBox(Rect(line.left, line.top, line.right, line.bottom), text.first)
                    }
                } finally { crop.recycle() }
            }
            LogPerf.mark("ppocr-live ${source.width}x${source.height} → ${result.size} line(s), ${SystemClock.elapsedRealtime() - t0}ms")
            return result
        }
    }

    private fun ensureLoaded(ctx: Context): Boolean {
        if (loaded && detector != null && recognizer != null && dictionary.isNotEmpty()) return true
        return try {
            val options = Interpreter.Options().setNumThreads(2)
            detector = Interpreter(assetBuffer(ctx, DET_MODEL), options)
            recognizer = Interpreter(assetBuffer(ctx, REC_MODEL), options)
            dictionary = ctx.assets.open(DICT).bufferedReader(Charsets.UTF_8).use { it.readLines() }.toTypedArray()
            loaded = dictionary.isNotEmpty()
            loaded
        } catch (_: Throwable) {
            release()
            false
        }
    }

    private fun assetBuffer(ctx: Context, name: String): ByteBuffer {
        ctx.assets.openFd(name).use { afd ->
            java.io.FileInputStream(afd.fileDescriptor).channel.use { channel ->
                return channel.map(java.nio.channels.FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.declaredLength)
                    .order(ByteOrder.nativeOrder())
            }
        }
    }

    private fun letterbox(src: Bitmap, width: Int, height: Int): Fit {
        val scale = min(width.toFloat() / src.width, height.toFloat() / src.height)
        val w = max(1, (src.width * scale).toInt())
        val h = max(1, (src.height * scale).toInt())
        val out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        Canvas(out).apply {
            drawColor(Color.WHITE)
            drawBitmap(src, null, Rect(((width - w) / 2), ((height - h) / 2),
                ((width - w) / 2) + w, ((height - h) / 2) + h), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        return Fit(out, scale, (width - w) / 2f, (height - h) / 2f)
    }

    /** NCHW float input used by the exported PP-OCR models. */
    private fun floatInput(bitmap: Bitmap, width: Int, height: Int): ByteBuffer {
        val px = IntArray(width * height)
        bitmap.getPixels(px, 0, width, 0, 0, width, height)
        val b = ByteBuffer.allocateDirect(width * height * 3 * 4).order(ByteOrder.nativeOrder())
        for (c in 0..2) for (y in 0 until height) for (x in 0 until width) {
            val v = px[y * width + x]
            val raw = when (c) { 0 -> v shr 16; 1 -> v shr 8; else -> v } and 255
            b.putFloat((raw / 255f - 0.5f) / 0.5f)
        }
        b.rewind()
        return b
    }

    /** Fast subtitle-oriented DB postprocess: horizontal connected bands from the probability map. */
    private fun rowLines(map: Array<FloatArray>, fit: Fit, originalW: Int, originalH: Int): List<Line> {
        val bands = ArrayList<IntArray>()
        var start = -1
        var last = -2
        for (y in map.indices) {
            var count = 0
            var left = DET_SIZE
            var right = -1
            for (x in map[y].indices) if (map[y][x] >= DET_THRESHOLD) {
                count++; left = min(left, x); right = max(right, x)
            }
            val active = count >= MIN_ROW_PIXELS && right >= left
            if (active) {
                if (start < 0) start = y
                last = y
            } else if (start >= 0 && y - last > 2) {
                bands += intArrayOf(start, last + 1)
                start = -1
            }
        }
        if (start >= 0) bands += intArrayOf(start, last + 1)

        return bands.mapNotNull { band ->
            var left = DET_SIZE
            var right = -1
            for (y in band[0] until band[1]) for (x in map[y].indices) if (map[y][x] >= DET_THRESHOLD) {
                left = min(left, x); right = max(right, x)
            }
            if (right < left) return@mapNotNull null
            val padX = maxOf(3, ((right - left) * 0.04f).toInt())
            val padY = maxOf(3, ((band[1] - band[0]) * 0.12f).toInt())
            val x0 = floor((left.toFloat() - padX.toFloat() - fit.left) / fit.scale)
                .toInt().coerceIn(0, originalW - 1)
            val y0 = floor((band[0].toFloat() - padY.toFloat() - fit.top) / fit.scale)
                .toInt().coerceIn(0, originalH - 1)
            val x1 = ceil((right.toFloat() + 1f + padX.toFloat() - fit.left) / fit.scale)
                .toInt().coerceIn(x0 + 1, originalW)
            val y1 = ceil((band[1].toFloat() + padY.toFloat() - fit.top) / fit.scale)
                .toInt().coerceIn(y0 + 1, originalH)
            Line(x0, y0, x1, y1)
        }.sortedWith(compareBy({ it.top }, { it.left }))
    }

    private fun recognizeLine(interpreter: Interpreter, src: Bitmap): Pair<String, Float> {
        val fit = letterbox(src, REC_W, REC_H)
        val input = floatInput(fit.bitmap, REC_W, REC_H)
        fit.bitmap.recycle()
        val out = Array(1) { Array(40) { FloatArray(18385) } }
        interpreter.run(input, out)
        val text = StringBuilder()
        var previous = -1
        var confidence = 0f
        var count = 0
        for (t in out[0].indices) {
            var best = 0
            var score = out[0][t][0]
            for (i in 1 until out[0][t].size) if (out[0][t][i] > score) {
                score = out[0][t][i]; best = i
            }
            if (best != 0 && best != previous && best - 1 in dictionary.indices) {
                text.append(dictionary[best - 1])
                confidence += score
                count++
            }
            previous = best
        }
        return text.toString().replace(Regex("\\s+"), " ").trim() to
            if (count == 0) 0f else confidence / count
    }

    private object LogPerf {
        fun mark(message: String) { android.util.Log.d("PpOcrLive", message) }
    }
}
