# 1.3.45 — خێراکردنی خوێندنەوە (Piper)

هۆکار (لە کۆدەوە، نەپێوراو لەسەر مۆبایل): `prefetch` لەسەر thread ی `THREAD_PRIORITY_BACKGROUND` کار دەکرد و `synthesisGate` ی دەگرت.
ئەگەر ڕستەی ئێستا پێویستی بە هەمان gate بوایە، چاوەڕێی ئەو thread ە دەکرد کە CPU ی کەم وەردەگرێت (priority inversion)، بۆیە دەنگ دواکەوت.

گۆڕانکاری:
- prefetch ئێستا `THREAD_PRIORITY_DEFAULT` ـە.
- thread ی دروستکردنی خوێندنەوە `THREAD_PRIORITY_DISPLAY` ـە (کەمێک لە ئاسایی بەرزتر، هێشتا لە ئاستی audio ی خێرا کەمتر).
