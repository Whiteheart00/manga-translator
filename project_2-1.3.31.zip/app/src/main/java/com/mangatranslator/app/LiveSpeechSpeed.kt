package com.mangatranslator.app

/**
 * Length-aware speed for the live subtitle speech queue only.
 * The returned value is a multiplier over the user's configured speech speed.
 */
internal object LiveSpeechSpeed {
    fun boost(text: String, queueBoost: Float = 1f, baseSpeed: Float = 1f): Float {
        val base = baseSpeed.coerceIn(0.5f, 2f)
        val ceiling = maxOf(1.5f, base).coerceAtMost(2f)
        val clean = text.trim()
        if (clean.isEmpty()) return (maxOf(base, base * queueBoost).coerceAtMost(ceiling) / base)

        val words = clean.split(Regex("\\s+")).count { it.isNotBlank() }
        val lengthBoost = when {
            words >= 12 -> 1.5f
            words >= 8 -> 1.35f
            words >= 6 -> 1.25f
            else -> 1f
        }
        // Exact live-subtitle rule: under six words always keeps the user's
        // selected speed; queue backlog must not override that rule.
        val target = (base * lengthBoost).coerceAtMost(ceiling)
        return (target / base).coerceAtLeast(1f)
    }
}
