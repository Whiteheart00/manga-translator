package com.mangatranslator.app

/**
 * ئازادکردنی ئەنجامەکان بە ڕیزی ژمارەکانیان (فەنکشنی پاک، بێ Android، تاقیکراو).
 *
 * وەرگێڕانی ڕستەکان پارالێل دەڕۆن، بەڵام نووسین/دەنگ دەبێت بە ڕیزی دەرکەوتن بێت. کێشە: ئەگەر یەک وەرگێڕان
 * بەستراو بێت (تۆڕی خاو، timeout)، هەموو ڕستە ئامادەکانی دوای ئەو چاوەڕێ دەمێنن و دەنگ دەست پێناکات (head-of-line blocking).
 *
 *  - [put] ئەنجامێک دەخاتە ناو و ئەوانەی دەتوانرێت ئازاد بکرێن بە ڕیز دەگەڕێنێتەوە.
 *  - [hasGap] ئەنجامی ئامادە لە پشت ژمارەیەکی ونبووە.
 *  - [skipGap] ژمارە ونبووەکە دەپەڕێنێت بۆ ئەوەی ئەوانی پشتی ئازاد بکرێن (دوای timeout).
 *  - ئەنجامی ژمارەیەکی پەڕێنراو کاتێک درەنگ هات، ڕاستەوخۆ دەگەڕێتەوە ([put] بە order < next): هیچ ڕستەیەک ونناکرێت.
 */
class OrderedRelease<T : Any> {
    private val ready = HashMap<Int, T>()
    private var next = 0

    fun put(order: Int, value: T): List<T> {
        if (order < next) return listOf(value)      // درەنگ هات دوای پەڕاندنی: ونناکرێت
        ready[order] = value
        return drain()
    }

    fun hasGap(): Boolean = ready.isNotEmpty() && !ready.containsKey(next)

    fun skipGap(): List<T> {
        if (!hasGap()) return emptyList()
        next++
        return drain()
    }

    fun nextOrder(): Int = next
    fun clear() { ready.clear() }

    private fun drain(): List<T> {
        val out = ArrayList<T>()
        while (true) {
            val v = ready.remove(next) ?: break
            out.add(v)
            next++
        }
        return out
    }
}
