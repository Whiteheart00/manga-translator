package com.mangatranslator.app

/** Faster live sampling without overlapping OCR or exceeding Accessibility limits. */
internal object LiveRefresh {
    fun captureMs(low: Boolean) = if (low) 110L else 70L
    // Accessibility screenshots are rate-limited by Android, but the normal
    // path can safely ask again sooner than the old 350ms interval.
    fun accessibilityMs(low: Boolean) = if (low) 450L else 340L
    // Keep one OCR at a time, but sample a changed subtitle sooner so the
    // next line can enter translation while the current line is spoken.
    fun ocrGapMs(kurdish: Boolean) = if (kurdish) 60L else 70L
    fun forceMs(kurdish: Boolean) = if (kurdish) 70L else 100L
}
