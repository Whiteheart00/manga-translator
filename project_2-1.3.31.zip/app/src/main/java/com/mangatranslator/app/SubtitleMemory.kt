package com.mangatranslator.app

import android.content.Context
import android.util.Log
import java.io.File
import kotlin.math.max

/**
 * «فەرهەنگی ژێرنووس» (CC): فایلێکی txt کە ڕستەی سەرچاوە (ئینگلیزی...) و وەرگێڕانی کوردییەکەی تێدایە.
 * ژێرنووسی زیندوو پێش Google/Gemini لێرە دەگەڕێت؛ ئەگەر ڕستەکە لێرە بوو، یەکسەر (بێ ئینتەرنێت) دەنووسرێت و دەخوێنرێتەوە.
 *
 * شێوازە پشتگیریکراوەکانی فایلەکە (خۆکار دەناسرێتەوە، ڕیزبەندییەکەی گرنگ نییە: ئینگلیزی/کوردی ئەمدیو یان ئەودیو):
 *   1) لە یەک دێڕدا: `english | کوردی`  یان  tab  یان  =>  ->  =  — – -  ;
 *   2) دوو دێڕی لەدوای یەک: دێڕی ئینگلیزی ئینجا دێڕی کوردی (یان پێچەوانە)
 *   3) بلۆکی SRT/VTT: ژمارە، کات (-->) ڕەت دەکرێنەوە؛ دێڕی خاڵی بلۆکەکان جیا دەکاتەوە
 * دێڕی `#` یان `//` تێبینییە.
 *
 * بەرنامەیەکی پاک (بێ Android جگە لە load) تا لە JVM تاقی بکرێت.
 */
object SubtitleMemory {
    private const val TAG = "SubtitleMemory"
    const val FILE_NAME = "subtitle_memory.txt"
    private const val MIN_KEY = 3
    private const val FUZZY_MIN_LEN = 12
    private const val FUZZY_RATIO = 0.08          // تا ٨٪ هەڵەی OCR
    private const val MAX_ENTRIES = 50_000

    class Entry(val source: String, val kurdish: String)

    @Volatile private var exact: Map<String, String> = emptyMap()
    @Volatile private var byLen: Map<Int, List<Pair<String, String>>> = emptyMap()
    @Volatile private var loadedStamp = -1L

    val size: Int get() = exact.size

    // ---------- پۆلێنکردن ----------
    private fun isArabicLetter(c: Char) = c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    /** true = دێڕێک کە بەزۆری پیتی عەرەبی/کوردییە */
    internal fun isKurdishScript(s: String): Boolean {
        var ar = 0; var other = 0
        for (c in s) if (c.isLetter()) { if (isArabicLetter(c)) ar++ else other++ }
        return ar > 0 && ar > other
    }

    internal fun hasLetters(s: String) = s.any { it.isLetter() }

    /** کلیلی بەراوردکردن: تەنها پیت و ژمارە، پیتی بچووک (OCR ی بۆشایی/خاڵبەندی ناشێوێنێت) */
    fun key(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) if (ch.isLetterOrDigit()) sb.append(ch.lowercaseChar())
        return sb.toString().take(300)
    }

    // ---------- خوێندنەوە ----------
    private val TAGS = Regex("<[^>]{1,20}>|\\{\\\\[^}]*\\}")
    private val TIME = Regex("-->")
    private val INDEX = Regex("^\\d{1,6}$")
    private val DELIMS = listOf("\t", " | ", "|", " => ", "=>", " -> ", "->", " — ", " – ", " = ", " - ", " ; ", ";")

    private fun clean(line: String): String =
        line.replace("\uFEFF", "").replace(TAGS, "").trim()

    /** دێڕێک بە جیاکەرەوە: (سەرچاوە، کوردی) یان null */
    internal fun splitPair(line: String): Entry? {
        for (d in DELIMS) {
            var from = 0
            while (true) {
                val i = line.indexOf(d, from)
                if (i < 0) break
                val l = line.substring(0, i).trim()
                val r = line.substring(i + d.length).trim()
                if (l.isNotEmpty() && r.isNotEmpty() && hasLetters(l) && hasLetters(r)) {
                    val lk = isKurdishScript(l); val rk = isKurdishScript(r)
                    if (!lk && rk) return Entry(l, r)
                    if (lk && !rk) return Entry(r, l)
                }
                from = i + d.length
            }
        }
        return null
    }

    /** دێڕێک کە بێ جیاکەرەوە، سەرەتای ئینگلیزییە و پاشان کوردی («Please subscribe. تکایە بەشداری بکە.») */
    internal fun splitByScript(line: String): Entry? {
        val toks = line.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val firstK = toks.indexOfFirst { t -> t.any { it.isLetter() } && isKurdishScript(t) }
        if (firstK < 2 || toks.size - firstK < 2) return null
        val left = toks.subList(0, firstK).joinToString(" ")
        val right = toks.subList(firstK, toks.size).joinToString(" ")
        // لای کوردی دەکرێت ناوی لاتینی تێدابێت («...لە Enjoy English Talks»)، بۆیە بە ژمارەی وشەی کوردی دەپشکنین نەک پیت
        val kTokens = toks.subList(firstK, toks.size).count { t -> t.any { it.isLetter() } && isKurdishScript(t) }
        if (!hasLetters(left) || isKurdishScript(left) || kTokens < 2) return null
        return Entry(left, right)
    }

    /** ڕستەکان: لە . ! ? ؟ ی بەدوای بۆشاییدا دەبڕدرێت (بێ lookbehind، گونجاو بۆ Android) */
    internal fun sentences(t: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for ((i, ch) in t.withIndex()) {
            sb.append(ch)
            if ((ch == '.' || ch == '!' || ch == '?' || ch == '\u061F') && (i + 1 == t.length || t[i + 1].isWhitespace())) {
                val x = sb.toString().trim(); if (x.isNotEmpty()) out.add(x); sb.setLength(0)
            }
        }
        val rest = sb.toString().trim(); if (rest.isNotEmpty()) out.add(rest)
        return out
    }

    /** بلۆکێکی چەند ڕستەیی کە ئینگلیزی و کوردییەکەی هەمان ژمارەی ڕستەیان هەیە، بە ڕستە بە ڕستەش دەخرێتە فەرهەنگەوە */
    internal fun expand(entries: List<Entry>): List<Entry> {
        val extra = ArrayList<Entry>()
        for (e in entries) {
            val a = sentences(e.source); val b = sentences(e.kurdish)
            if (a.size >= 2 && a.size == b.size) for (i in a.indices) add(extra, a[i], b[i])
        }
        return extra
    }

    fun parse(lines: Sequence<String>): List<Entry> {
        val out = ArrayList<Entry>()
        // بلۆکێک (تا دێڕی خاڵی): دێڕەکانی هەمان پیت پێکەوە دەلکێنرێن، پاشان دوو بە دوو جووت دەکرێن
        val runs = ArrayList<Pair<Boolean, StringBuilder>>()   // (کوردییە؟، دەق)

        fun flush() {
            var i = 0
            while (i + 1 < runs.size) {
                val a = runs[i]; val b = runs[i + 1]
                if (a.first != b.first) {
                    val src = if (!a.first) a.second else b.second
                    val ku = if (a.first) a.second else b.second
                    add(out, src.toString().trim(), ku.toString().trim())
                    i += 2
                } else i += 1        // دوو بەشی هاوشێوە: یەکەمیان فڕێدەدرێت
            }
            runs.clear()
        }

        for (raw in lines) {
            val line = clean(raw)
            if (line.isEmpty()) { flush(); continue }
            if (line.startsWith("#") || line.startsWith("//") || line.startsWith("WEBVTT")) continue
            if (TIME.containsMatchIn(line) || INDEX.matches(line)) continue
            val pair = splitPair(line)
            if (pair != null) { flush(); add(out, pair.source, pair.kurdish); continue }
            if (!hasLetters(line)) continue
            val mixed = splitByScript(line)
            if (mixed != null && runs.isEmpty()) { add(out, mixed.source, mixed.kurdish); continue }
            val k = isKurdishScript(line)
            val last = runs.lastOrNull()
            if (last != null && last.first == k) last.second.append(' ').append(line)
            else runs.add(k to StringBuilder(line))
            if (out.size >= MAX_ENTRIES) break
        }
        flush()
        return out
    }

    private fun add(out: MutableList<Entry>, src: String, ku: String) {
        if (key(src).length >= MIN_KEY && ku.isNotBlank()) out.add(Entry(src, ku))
    }

    /** ئینتێریی نوێ دادەنێت (دوای parse). */
    fun install(base: List<Entry>) {
        // ڕستە بە ڕستە زیاد دەکرێت پێش بلۆکە تەواوەکان، بۆ ئەوەی بلۆکی تەواو (ئەگەر هەبوو) بەسەریاندا سەربکەوێت
        val entries = expand(base) + base
        val ex = HashMap<String, String>(entries.size * 2)
        val bl = HashMap<Int, MutableList<Pair<String, String>>>()
        for (e in entries) {
            val k = key(e.source)
            if (k.length < MIN_KEY) continue
            ex[k] = e.kurdish
            if (k.length >= FUZZY_MIN_LEN) bl.getOrPut(k.length) { ArrayList() }.add(k to e.kurdish)
        }
        exact = ex
        byLen = bl
    }

    // ---------- گەڕان ----------
    /** وەرگێڕانی ئامادە بۆ [text] یان null. exact ی خێرا، پاشان گەڕانی نزیک (بۆ هەڵەی بچووکی OCR). */
    fun lookup(text: String): String? {
        val ex = exact
        if (ex.isEmpty()) return null
        val k = key(text)
        if (k.length < MIN_KEY) return null
        ex[k]?.let { return it }
        if (k.length < FUZZY_MIN_LEN) return null
        val maxD = max(1, (k.length * FUZZY_RATIO).toInt())
        var best: String? = null
        var bestD = Int.MAX_VALUE
        val bl = byLen
        for (len in (k.length - maxD)..(k.length + maxD)) {
            val list = bl[len] ?: continue
            for ((ck, ku) in list) {
                val d = boundedLev(k, ck, maxD)
                if (d < bestD) { bestD = d; best = ku; if (d == 0) return ku }
            }
        }
        return if (bestD <= maxD) best else null
    }

    /** Levenshtein بە سنووری [limit]؛ ئەگەر لە سنوور تێپەڕی limit+1 */
    internal fun boundedLev(a: String, b: String, limit: Int): Int {
        if (kotlin.math.abs(a.length - b.length) > limit) return limit + 1
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
                if (cur[j] < rowMin) rowMin = cur[j]
            }
            if (rowMin > limit) return limit + 1
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    // ---------- فایل ----------
    fun file(ctx: Context) = File(ctx.filesDir, FILE_NAME)

    /** فایلەکە (ئەگەر هەبوو و گۆڕابوو) دەخوێنێتەوە؛ لەسەر thread ی پاشبنەما بانگ بکرێت. دەگەڕێنێتەوە ژمارەی ڕستەکان. */
    @Synchronized
    fun ensureLoaded(ctx: Context): Int {
        val f = file(ctx)
        if (!f.exists()) { exact = emptyMap(); byLen = emptyMap(); loadedStamp = -1L; return 0 }
        val stamp = f.lastModified() xor f.length()
        if (stamp == loadedStamp) return exact.size
        return try {
            val entries = f.bufferedReader(Charsets.UTF_8).useLines { parse(it) }
            install(entries)
            loadedStamp = stamp
            Log.d(TAG, "loaded ${exact.size} subtitle pairs")
            exact.size
        } catch (t: Throwable) {
            Log.w(TAG, "load failed: ${t.message}")
            0
        }
    }

    /** فایلی هەڵبژێردراو دەگوازێتەوە بۆ ناو ئەپ و دەیخوێنێتەوە. ژمارەی جووتەکان دەگەڕێنێتەوە (٠ = هیچ نەدۆزرایەوە). */
    fun importStream(ctx: Context, input: java.io.InputStream): Int {
        val tmp = File(ctx.filesDir, "$FILE_NAME.tmp")
        input.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
        val entries = try { tmp.bufferedReader(Charsets.UTF_8).useLines { parse(it) } } catch (t: Throwable) { emptyList() }
        if (entries.isEmpty()) { tmp.delete(); return 0 }
        val f = file(ctx)
        f.delete()
        tmp.renameTo(f)
        loadedStamp = -1L
        return ensureLoaded(ctx)
    }

    fun clear(ctx: Context) {
        file(ctx).delete()
        exact = emptyMap(); byLen = emptyMap(); loadedStamp = -1L
    }
}
