package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Test

class LiveSpeechSpeedTest {
    @Test fun shortLineStaysAtNormalSpeed() {
        assertEquals(1f, LiveSpeechSpeed.boost("سڵاو هاوڕێ."), 0.001f)
    }

    @Test fun mediumLineGetsAModerateBoost() {
        val text = (1..14).joinToString(" ") { "وشە$it" }
        assertEquals(1.5f, LiveSpeechSpeed.boost(text), 0.001f)
    }

    @Test fun longLineCapsAtOnePointFive() {
        val text = (1..35).joinToString(" ") { "وشە$it" }
        assertEquals(1.5f, LiveSpeechSpeed.boost(text), 0.001f)
    }

    @Test fun sixWordsAreOnePointTwoFive() {
        assertEquals(1.25f, LiveSpeechSpeed.boost("یەک دوو سێ چوار پێنج شەش", 1.5f), 0.001f)
    }

    @Test fun eightWordsAreOnePointThreeFive() {
        val text = "Hello everyone and welcome back to Enjoy English Talks"
        assertEquals(1.35f, LiveSpeechSpeed.boost(text), 0.001f)
    }

    @Test fun fiveWordsKeepTheUsersSelectedSpeed() {
        assertEquals(1f, LiveSpeechSpeed.boost("یەک دوو سێ چوار پێنج", 1.5f), 0.001f)
        assertEquals(1.25f, LiveSpeechSpeed.boost("یەک دوو سێ چوار پێنج", baseSpeed = 1.25f), 0.001f)
    }

    @Test fun shortLineNeverLowersOnePointFiveUserSpeed() {
        assertEquals(1f, LiveSpeechSpeed.boost("یەک دوو", baseSpeed = 1.5f), 0.001f)
    }

    @Test fun longLineTargetsOnePointFiveEvenWhenUserSelectedOnePointTwoFive() {
        val text = (1..35).joinToString(" ") { "وشە$it" }
        assertEquals(1.2f, LiveSpeechSpeed.boost(text, baseSpeed = 1.25f), 0.001f)
    }
}
