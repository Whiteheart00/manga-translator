package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SubtitleMemoryTest {
    private fun load(text: String) = SubtitleMemory.install(SubtitleMemory.parse(text.lineSequence()))

    @Test fun delimiterLinesEitherOrder() {
        load("Hello, how are you? | سڵاو، چۆنی؟\nباشم - I'm fine\nDon't go! => مەڕۆ!")
        assertEquals("سڵاو، چۆنی؟", SubtitleMemory.lookup("hello how are you"))
        assertEquals("باشم", SubtitleMemory.lookup("I'm fine"))
        assertEquals("مەڕۆ!", SubtitleMemory.lookup("DON'T GO"))
    }

    @Test fun twoLinePairs() {
        load("Where are you going?\nتۆ بۆ کوێ دەچیت؟\nI will wait here.\nمن لێرە چاوەڕێ دەکەم.")
        assertEquals("تۆ بۆ کوێ دەچیت؟", SubtitleMemory.lookup("Where are you going"))
        assertEquals("من لێرە چاوەڕێ دەکەم.", SubtitleMemory.lookup("I will wait here"))
    }

    @Test fun srtBlocksWithMultilineText() {
        load(
            "1\n00:00:01,000 --> 00:00:03,000\n<i>This place looks like</i>\nsome kind of palace.\nئەم شوێنە وەک\nکۆشکێک دەچێت.\n\n" +
                "2\n00:00:04,000 --> 00:00:05,000\nWho are you?\nتۆ کێیت؟\n"
        )
        assertEquals("ئەم شوێنە وەک کۆشکێک دەچێت.", SubtitleMemory.lookup("This place looks like some kind of palace."))
        assertEquals("تۆ کێیت؟", SubtitleMemory.lookup("who are you"))
    }

    @Test fun englishDashInsideTextIsNotASplit() {
        load("Well - maybe later | باشە - لەوانەیە دواتر")
        assertEquals("باشە - لەوانەیە دواتر", SubtitleMemory.lookup("Well - maybe later"))
    }

    @Test fun fuzzyToleratesSmallOcrErrors() {
        load("I was sitting at home a second ago | چرکەیەک لەمەوبەر لە ماڵەوە دانیشتبووم")
        assertEquals(
            "چرکەیەک لەمەوبەر لە ماڵەوە دانیشتبووم",
            SubtitleMemory.lookup("I was sitting at horne a second ago")
        )
        assertNull(SubtitleMemory.lookup("This place looks like some kind of European palace"))
    }

    @Test fun shortTextsNeedExactMatch() {
        load("Yes | بەڵێ\nNo way! | نەخێر!")
        assertEquals("بەڵێ", SubtitleMemory.lookup("yes"))
        assertNull(SubtitleMemory.lookup("yet"))
    }

    @Test fun commentsAndGarbageIgnored() {
        load("# تێبینی\n// note\nWEBVTT\n123\n----\nplain english only line")
        assertEquals(0, SubtitleMemory.size)
    }

    @Test fun sentenceLevelLookupFromMultiSentenceBlock() {
        load("00:00:09 --> 00:00:11\nHello everyone. I'm Jake.\nسڵاو هەمووان. من جەیکم.\n")
        assertEquals("من جەیکم.", SubtitleMemory.lookup("I'm Jake."))
        assertEquals("سڵاو هەمووان.", SubtitleMemory.lookup("Hello everyone."))
        assertEquals("سڵاو هەمووان. من جەیکم.", SubtitleMemory.lookup("Hello everyone. I'm Jake."))
    }

    @Test fun sameLineWithoutDelimiter() {
        load("Please subscribe to our channel. تکایە بەشداری بکە لە کەناڵەکەمان.\n")
        assertEquals("تکایە بەشداری بکە لە کەناڵەکەمان.", SubtitleMemory.lookup("please subscribe to our channel"))
    }
}
