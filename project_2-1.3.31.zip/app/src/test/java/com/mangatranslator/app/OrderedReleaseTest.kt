package com.mangatranslator.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OrderedReleaseTest {

    @Test fun inOrderItemsAreReleasedImmediately() {
        val r = OrderedRelease<String>()
        assertEquals(listOf("a"), r.put(0, "a"))
        assertEquals(listOf("b"), r.put(1, "b"))
    }

    @Test fun outOfOrderItemsWaitForTheMissingOne() {
        val r = OrderedRelease<String>()
        assertEquals(emptyList<String>(), r.put(1, "b"))
        assertEquals(emptyList<String>(), r.put(2, "c"))
        assertTrue(r.hasGap())
        assertEquals(listOf("a", "b", "c"), r.put(0, "a"))
        assertFalse(r.hasGap())
    }

    @Test fun stuckItemDoesNotBlockLaterOnesForever() {
        val r = OrderedRelease<String>()
        assertEquals(emptyList<String>(), r.put(1, "later"))     // ٠ بەستراوە
        assertTrue(r.hasGap())
        assertEquals(listOf("later"), r.skipGap())               // دوای timeout: ٠ دەپەڕێنرێت
        assertFalse(r.hasGap())
    }

    @Test fun skippedItemIsNotLostWhenItArrivesLate() {
        val r = OrderedRelease<String>()
        r.put(1, "later")
        r.skipGap()
        assertEquals(listOf("late-zero"), r.put(0, "late-zero")) // درەنگ هات: هێشتا دەنووسرێت و دەخوێنرێتەوە
    }

    @Test fun everyItemIsReleasedExactlyOnce() {
        val r = OrderedRelease<Int>()
        val out = ArrayList<Int>()
        // ڕیزبەندی تێکەڵ + یەک ونبوو کە دواتر دێت
        for (o in listOf(3, 1, 4, 2)) out.addAll(r.put(o, o))
        out.addAll(r.skipGap())          // ٠ ونە ← ١..٤ ئازاد دەبن
        out.addAll(r.put(0, 0))          // ٠ درەنگ
        assertEquals(listOf(1, 2, 3, 4, 0), out)
        assertEquals(5, out.toSet().size)
    }

    @Test fun skipGapWithoutGapDoesNothing() {
        val r = OrderedRelease<String>()
        assertEquals(emptyList<String>(), r.skipGap())
        r.put(0, "a")
        assertEquals(emptyList<String>(), r.skipGap())
        assertEquals(1, r.nextOrder())
    }

    @Test fun multipleGapsAreSkippedOneAtATime() {
        val r = OrderedRelease<String>()
        r.put(2, "c")                       // ٠ و ١ هەردووکیان ونن
        assertTrue(r.hasGap())
        assertEquals(emptyList<String>(), r.skipGap())   // ٠ پەڕێنرا، ١ هێشتا ونە
        assertTrue(r.hasGap())
        assertEquals(listOf("c"), r.skipGap())           // ١ پەڕێنرا ← ٢ ئازاد بوو
        assertFalse(r.hasGap())
    }
}
