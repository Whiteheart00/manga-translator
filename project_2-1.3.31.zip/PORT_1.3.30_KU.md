# 1.3.30 — بردنی چاکسازییەکانی 1.3.45 بۆ ئەم وەشانە

لەسەر بنەمای 1.3.29؛ واژۆی کلیلی `manga` (GitHub Secrets) وەک خۆی ماوە.

بردنە ناو: 
- خێراکردنی خوێندنەوەی Piper (priority ی prefetch/synthesis).
- ژێرنووسی زیندوو: LiveRefresh، SETTLE_MS 450/160، خێرایی زیرەکی دەنگ (LiveSpeechSpeed)، SpeechQueue بێ خاڵی زیادە، ڕاگرتنی typing window، Accessibility تەنها لە ڕووبەرەکە، نەخوێندنەوەی دووبارەی دێڕی پێشوو دوای Play.
- OCR ی کوردی: KurdishOcrText (پاککردنەوەی هێما/بۆشایی)، KurdishVocab.mapWords، LocalKurdishOcr، فلتەری UiNoise ـی «دەخوێنرێتەوە/دەخوێندرێتەوە».
- دەنگ: VoiceShaper (گڕ و نەرمی)، Low-pass تا 1000Hz، slider ـەکان لە ڕێکخستنی دەنگ.
- نوێ: OCR ی کوردیی ناوخۆیی لە دەستپێکی ژێرنووسی زیندوو پێشوەختە بار دەکرێت.

نەبردرا: ڕێکخستنی دیاریکردنی checkbox، گۆڕانکارییەکانی Dictation/OverlayService/GeminiModels ی 1.3.45.
بیلد و تاقیکردنەوە لەسەر مۆبایل نەکراوە.
