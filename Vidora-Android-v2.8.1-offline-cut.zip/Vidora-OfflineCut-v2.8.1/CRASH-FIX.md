# Download-close investigation, 1.9.1

## Reproduced defect

The user's original ZIP already contained this expression in DownloadService.cleanMediaTitle:

`(?U)(?:\s*[#＃][\p{L}\p{N}_]+)+\s*$`

Android's Pattern delegates matching to ICU and does not support Java's inline U flag. The exact original expression failed in the native ICU test with error 66305; the equivalent expression without (?U) compiled successfully. Explicit Unicode categories already express the required letter/number matching.

The failure path matters: youtubedl-android 0.18.1 invokes the application's progress callback inside StreamProcessExtractor, which is its own Thread. That reader catches IOException, not runtime exceptions thrown by the callback. The try/catch surrounding YoutubeDL.execute() runs on a different thread and cannot catch that exception. A Destination/Merging output line reaches title cleanup, so an uncaught PatternSyntaxException can terminate the app after metadata extraction begins.

This is a confirmed code defect and a reproduced Android-engine incompatibility, consistent with the report that downloading failed before the redesign. Without the affected phone's crash log, it is not proof that this is its only failure.

## Changes

MediaTitle removes (?U) and retains explicit Unicode classes. ProgressCallback.safely contains recoverable exceptions on the reader thread and separately contains failures of its reporter. Foreground startup happens before preference/broadcast work. Notification update failures and native linkage initialization failures are recorded instead of escaping the callback/task.

DownloadDiagnostics keeps a bounded app-private report, redacts URLs, and offers an explicit copy action in About. Its uncaught-exception reporter preserves the platform crash handler; it does not pretend a fatal error recovered. No automatic upload is added.

## Evidence and references

- User ZIP: Vidora-v1.7/app/src/main/java/com/kurd/videodownloader/DownloadService.kt, cleanMediaTitle.
- Android Pattern source: https://android.googlesource.com/platform/libcore/+/refs/heads/android14-release/ojluni/src/main/java/java/util/regex/Pattern.java (UNICODE_CHARACTER_CLASS documentation and ICU compile implementation).
- Actual dependency source: https://repo.maven.apache.org/maven2/io/github/junkfood02/youtubedl-android/library/0.18.1/library-0.18.1-sources.jar (StreamProcessExtractor.run/processOutputLine and YoutubeDL.executeImpl).

`python3 tools/check-android-title-regex.py` reproduces the old ICU rejection and compiles all shipped title/redaction patterns. This check requires native ICU on the Linux test host. Host JVM/Robolectric regex behavior alone does not reproduce Android's rejection of (?U), which explains why an ordinary desktop build/test pass was insufficient.

## Verification limits

14 JVM/Robolectric tests passed, including callback exception isolation and real service Destination-line title capture. The native UI bridge harness passed. Debug APK builds and verifies its signature. No physical-phone execution, live video download or Android logcat from the reported device has been available. If failure persists, use About's Copy Error Report to identify the actual next failure rather than assuming it has the same cause.
