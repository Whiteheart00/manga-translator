# پڕۆژەکە بکە Private — هەنگاوی پێویستی GitHub

لەو workspace ـەوە دەستگەیشتن بە هەژماری GitHub ـت نەبوو؛ بۆیە repository ـەکەت هێشتا لێرەوە Private نەکراوە. Workflow ـی 2.6 لە repository ـی Public build ڕادەگرێت.

1. repository ـەکە لە GitHub بکەرەوە → **Settings → General → Danger Zone → Change repository visibility → Make private**. ئەمە پێش بارکردنی کۆدی نوێ بکە.
2. لە **Settings → Collaborators / Manage access** تەنها کەسانی متمانەپێکراو بهێڵەوە. بۆ هەژمارەکەت 2FA چالاک بکە و هەنگاوەکانی پاراستنی branch دانێ.
3. لە **Settings → Secrets and variables → Actions** هەمان چوار secret ـی signing ـی پێشوو بهێڵەوە: VIDORA_KEYSTORE_BASE64، VIDORA_STORE_PASSWORD، VIDORA_KEY_ALIAS، VIDORA_KEY_PASSWORD. کلیلێکی نوێ دروست مەکە بۆ update؛ applicationId مەگۆڕە.
4. `.github/workflows/build.yml` بە workflow ـی نوێ بگۆڕە. تەنها یەک ZIP ـی پڕۆژە لە ڕیشە بهێڵەوە، یان فایلەکانی ZIP ـەکە دەربهێنە و ZIP ـە کۆنەکان لابەرە. Workflow ZIP ـە تاکەکە لەبری کۆدی کۆنی ڕیشە هەڵدەبژێرێت.
5. Actions → Build Vidora 2.6 → Run workflow. لە ئەنجامی سەرکەوتوو Vidora-Update-APK دابەزێنە. تەنها APK بە بەکارهێنەرەکان بدە؛ source، keystore، secrets و mapping.txt مەبڵاوکەرەوە.

Private Actions artifacts تەنها بۆ کەسانی دەستگەیشتووی repository ـەن. ئەگەر داگرتنی گشتیی APK دەوێت، فایلە واژۆکراوەکە بە جیا لە شوێنی بڵاوکردنەوەی binary دابنێ، بۆ نموونە repository ـێکی جیا بۆ APK تەنها. کۆدی سەرچاوە لەوێ مەخە.

Private کردن کۆپییە پێشووترە گشتییەکان/clone ـەکان ناسڕێتەوە. ئەگەر signing key یان secret پێشتر بڵاوکرابێتەوە، Private کردن بە تەنها چارەسەر نییە؛ پێویستە ئەو secret ـە بە تایبەتی هەڵبسەنگێندرێت. واژۆی ئەپ بەبێ پلانی update مەگۆڕە.
