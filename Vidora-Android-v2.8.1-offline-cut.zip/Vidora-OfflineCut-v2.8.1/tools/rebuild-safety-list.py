#!/usr/bin/env python3
"""Rebuild compact domain hashes from the bundled MIT-licensed source snapshots."""
from pathlib import Path
import gzip, hashlib, struct
root=Path(__file__).resolve().parents[1]
for category in ('adult','gambling'):
    domains=set()
    with gzip.open(root/'tools/blocklist-sources'/f'{category}.hosts.gz','rt') as source:
        for line in source:
            fields=line.split('#',1)[0].split()
            if len(fields)>1 and fields[0] in ('0.0.0.0','127.0.0.1'):
                domains.update(name.lower().rstrip('.') for name in fields[1:] if '.' in name and name not in ('localhost.localdomain','local'))
    hashes=sorted({struct.unpack('>q',hashlib.sha256(name.encode()).digest()[:8])[0] for name in domains})
    target=root/'app/src/main/assets/safety'/f'{category}.bin'
    target.write_bytes(b''.join(struct.pack('>q',value) for value in hashes))
    print(category,len(domains),hashlib.sha256(target.read_bytes()).hexdigest())
