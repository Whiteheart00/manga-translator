#!/usr/bin/env python3
"""Compile the production patterns in ICU, matching Android's regex engine.
Requires an installed ICU shared library on the Linux build/test machine.
The retired Java-only (?U) probe must fail, while every shipped title pattern passes.
"""
import ctypes
import ctypes.util
import json
import re
from pathlib import Path

root=Path(__file__).resolve().parents[1]
name=ctypes.util.find_library('icui18n')
if not name:raise SystemExit('Install ICU on the test machine to run this native regex regression check.')
lib=ctypes.CDLL(name)
match=re.search(r'\.so\.(\d+)',name)
suffix='_'+match.group(1) if match else ''
compile_regex=getattr(lib,'uregex_open'+suffix)
compile_regex.argtypes=[ctypes.POINTER(ctypes.c_uint16),ctypes.c_int32,ctypes.c_uint32,ctypes.c_void_p,ctypes.POINTER(ctypes.c_int32)]
compile_regex.restype=ctypes.c_void_p
close_regex=getattr(lib,'uregex_close'+suffix);close_regex.argtypes=[ctypes.c_void_p]
def status(pattern):
    data=pattern.encode('utf-16-le');chars=(ctypes.c_uint16*(len(data)//2)).from_buffer_copy(data)
    error=ctypes.c_int32(0);compiled=compile_regex(chars,len(chars),0,None,ctypes.byref(error))
    if compiled:close_regex(compiled)
    return error.value
old=r'(?U)(?:\s*[#＃][\p{L}\p{N}_]+)+\s*$'
assert status(old)>0,'The test requires an ICU version that reproduces Android\'s unsupported inline flag.'
source='\n'.join((root/'app/src/main/java/com/kurd/videodownloader'/name).read_text() for name in ['MediaTitle.kt','DownloadDiagnostics.kt'])
patterns=[json.loads('"'+value+'"') for value in re.findall(r'Regex\("((?:\\.|[^"\\])*)"\)',source)]
assert len(patterns)==4
for pattern in patterns:assert status(pattern)==0,pattern
print('PASS: original (?U) crash reproduced in ICU; all 4 shipped title/diagnostic patterns compile successfully.')
