#!/usr/bin/env python3
"""Host FFmpeg smoke test of argv exported from the production Kotlin helper.
This does not run Android's ARM binaries or verify Android playback/storage.
Run :app:testDebugUnitTest first; requires ffmpeg/ffprobe on PATH.
"""
from pathlib import Path
import json,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
args=json.loads((root/'app/build/tested-conversion-arguments.json').read_text())
def run(argv):subprocess.run(argv,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def probe(path):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
with tempfile.TemporaryDirectory(prefix='vidora-conversion-')as temp:
    folder=Path(temp);source=folder/'sample movie.mp4';audio=folder/'out audio.mp3';poster=folder/'poster.jpg';video=folder/'out video.mp4'
    run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc=size=160x90:rate=10','-f','lavfi','-i','sine=frequency=440:sample_rate=44100','-t','2','-c:v','libx264','-pix_fmt','yuv420p','-threads','1','-c:a','aac',str(source)])
    run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=0x064b62:s=720x1280','-frames:v','1','-threads','1',str(poster)])
    for mode,input_file,output_file in [('audio',source,audio),('video',audio,video)]:
        replace={'INPUT':str(input_file),'OUTPUT':str(output_file),'POSTER':str(poster)}
        run(['ffmpeg']+[replace.get(value,value) for value in args[mode]])
        info=probe(output_file);types=[s['codec_type'] for s in info['streams']]
        assert types==['audio'] if mode=='audio' else set(types)=={'audio','video'}
        assert 1.8<float(info['format']['duration'])<4.0
        if mode=='video':
            stream=next(s for s in info['streams'] if s['codec_type']=='video');assert (stream['width'],stream['height'])==(720,1280)
        print('PASS',mode,types,info['format']['duration'])
