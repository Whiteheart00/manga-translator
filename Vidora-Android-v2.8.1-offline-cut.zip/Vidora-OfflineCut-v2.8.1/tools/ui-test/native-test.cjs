const {parseHTML}=require('linkedom');const fs=require('fs'),vm=require('vm'),assert=require('assert');
const base=process.env.VIDORA_UI_ROOT||require('path').resolve(__dirname,'../../app/src/main/assets/ui')+'/';
const {window,document}=parseHTML(fs.readFileSync(base+'index.html','utf8'));window.innerHeight=740;
Object.defineProperty(document.querySelector('.viewport'),'clientWidth',{value:360});
for(const dialog of document.querySelectorAll('dialog')){dialog.showModal=function(){this.open=true};dialog.close=function(){this.open=false;this.dispatchEvent(new window.Event('close'))};}
for(const el of document.querySelectorAll('input'))el.focus=()=>{};
Object.defineProperty(window.HTMLSelectElement.prototype,'value',{configurable:true,get(){return (this.querySelector('option[selected]')||this.querySelector('option'))?.getAttribute('value')||''},set(value){for(const option of this.querySelectorAll('option')){if(option.getAttribute('value')===value)option.setAttribute('selected','');else option.removeAttribute('selected')}}});
const calls=[];window.VidoraNative=Object.fromEntries(['ready','configure','requestDownload','updateEngine','cancel','paste','openDownloads','openFile','favorite','removeHistory','renameFile','copyDiagnostics','inspect','playPreview','requestConversion','deleteFile'].map(name=>[name,(...args)=>calls.push({name,args})]));
window.VidoraNative.bootstrap=()=>JSON.stringify({palette:'amber',mode:'light'});
window.VidoraNative.validateSource=url=>JSON.stringify({allowed:!/(^|\.)hentaicity\.com$/.test(new URL(url).hostname)&&new URL(url).hostname!=='bet365.com',message:'blocked by safety policy'});
const timeouts=[];const cache=new Map();const context=vm.createContext({window,document,URL,console,localStorage:{getItem:k=>cache.get(k)||null,setItem:(k,v)=>cache.set(k,v)},setTimeout:fn=>{timeouts.push(fn);return timeouts.length},clearTimeout:()=>{},setInterval:()=>{throw Error('Native UI must never simulate progress')},clearInterval:()=>{},MutationObserver:class{observe(){}}});
vm.runInContext(fs.readFileSync(base+'bootstrap.js','utf8'),context);assert.equal(document.documentElement.dataset.palette,'amber');assert.equal(document.documentElement.dataset.mode,'light');vm.runInContext(fs.readFileSync(base+'app.js','utf8'),context);assert.equal(document.documentElement.dataset.palette,'amber');assert.equal(document.documentElement.dataset.mode,'light');vm.runInContext(fs.readFileSync(base+'clip.js','utf8'),context);vm.runInContext(fs.readFileSync(base+'native.js','utf8'),context);
const q=s=>document.querySelector(s),click=s=>q(s).dispatchEvent(new window.Event('click'));
function assertQualityLabels(){for(const button of document.querySelectorAll('.quality')){assert.equal(button.textContent,button.dataset.quality,'Each quality label must appear exactly once');assert.equal(button.querySelector('.skin').textContent,'','Image layers must not contain labels');assert.equal(button.querySelectorAll('.skin .tint-viewport img').length,1,'Tint image must remain intact')}}
assertQualityLabels();
for(let repeat=0;repeat<3;repeat++){click('[data-format="MP3"]');assertQualityLabels();assert.equal(q('[data-quality="128k"] .quality-text').textContent,'128k');click('[data-quality="192k"]');assertQualityLabels();click('[data-format="MP4"]');assertQualityLabels();click('[data-quality="720p"]');assertQualityLabels();click('[data-quality="1080p"]');assertQualityLabels()}
click('[data-format="MP3"]');click('[data-quality="320k"]');click('[data-format="MP4"]');assertQualityLabels();

const initial={running:false,progress:0,status:'idle',action:'idle',message:'Ready',format:'MP4',quality:'1080p',url:'',title:'',settings:{format:'MP4',videoQuality:'1080p',audioQuality:'320k',folder:'Downloads/VideoDownloader',wifi:false,notifications:true,mode:'light',palette:'amber'},history:[],engineVersion:'—'};
window.vidoraReceive(initial);assert.equal(document.documentElement.dataset.palette,'amber');assert.equal(q('#percentage').textContent,'0%');assert.equal(q('#url').value,'');assert.equal(document.documentElement.dataset.mode,'light');
click('#history');assert.equal(document.querySelectorAll('.file-row').length,0);click('.sub-nav [data-route="home"]');
click('#paste');assert.equal(calls.at(-1).name,'paste');window.vidoraSetUrl('https://youtu.be/example');click('#download');assert.equal(calls.at(-1).name,'requestDownload');assert.equal(JSON.parse(calls.at(-1).args[0]).quality,'1080p');assert.equal(q('#percentage').textContent,'0%');
window.vidoraReceive({...initial,running:true,status:'running',action:'download',progress:37,url:'https://youtu.be/example',title:'A real video'});assert.equal(q('#percentage').textContent,'37%');assert.equal(q('#file-title').textContent,'A real video');click('#download');assert.equal(calls.at(-1).name,'cancel');
const item={id:'file-1',title:'A real video',name:'A real video.mp4',host:'youtube.com',format:'MP4',quality:'1080p',size:'10.24 MB',url:'https://youtu.be/example',time:'2026.11.15',favorite:false};
window.vidoraReceive({...initial,action:'download',status:'success',progress:100,history:[item],url:item.url,title:item.title});click('#history');assert.equal(document.querySelectorAll('.file-row').length,1);click('[data-star="file-1"]');assert.equal(calls.at(-1).name,'favorite');click('[data-file-id="file-1"]');click('.file-hero + .file-properties + button');assert.equal(calls.at(-1).name,'openFile');
click('#file-rename');q('#file-name-input').value='Renamed';click('.dialog-action');assert.equal(calls.at(-1).name,'renameFile');
click('#file-remove');assert.equal(calls.at(-1).name,'removeHistory');assert.equal(calls.at(-1).args[1],true);click('.undo-button');assert.equal(calls.at(-1).args[1],false);
click('.sub-nav [data-route="engine"]');click('#engine-check');assert.equal(calls.at(-1).name,'updateEngine');window.vidoraReceive({...initial,action:'update',running:true,status:'running',progress:0,message:'Checking'});assert.equal(q('#engine-percent').textContent,'0%');click('#engine-check');assert.equal(calls.at(-1).name,'cancel');
window.vidoraReceive({...initial,action:'update',status:'success',progress:100,message:'Updated',engineVersion:'2026.11.15'});assert.equal(q('#native-engine-version').textContent,'2026.11.15');assert(window.vidoraBack());assert(q('#workspace').hidden);assert.equal(window.vidoraBack(),false);
if(base.includes('Multisite')||base.includes('Stability')){
 for(const [url,name] of [['https://pin.it/abc','Pinterest'],['https://pinterest.com/pin/123','Pinterest'],['https://www.snapchat.com/spotlight/ABC','Snapchat'],['https://redd.it/abc','Reddit'],['https://dai.ly/abc','Dailymotion'],['https://soundcloud.com/artist/track','SoundCloud']]){q('#url').value=url;q('#url').dispatchEvent(new window.Event('input'));assert.equal(q('#site-name').textContent,name);assert(q('#source-icon [data-platform]'))}
 assert.equal(q('[data-format="MP3"]').getAttribute('aria-pressed'),'true');
 click('[data-format="MP4"]');click('#download');assert.equal(JSON.parse(calls.at(-1).args[0]).format,'MP3');
 click('#info');assert.equal(document.querySelectorAll('.platform-gallery [data-platform]').length,11);
}
if(base.includes('Stability')){click('#copy-diagnostics');assert.equal(calls.at(-1).name,'copyDiagnostics')}
console.log('PASS: Native-only UI, no fake progress/history, clipboard bridge, real snapshot updates, download/cancel, file open/rename/favorite/remove/undo, engine bridge, native back and preferences.');

window.vidoraReceive(initial);window.vidoraSetUrl('https://youtu.be/preview');
window.vidoraPreview({requestId:9999,url:'https://youtu.be/preview',status:'ready',title:'stale',token:'bad',playable:true});assert.equal(window.nativePreview,null,'stale callbacks must be ignored');

timeouts.at(-1)();const probe=calls.at(-1);assert.equal(probe.name,'inspect');const request=JSON.parse(probe.args[0]);
window.vidoraPreview({...request,status:'ready',title:'Actual extracted title',duration:125,token:'preview-token',playable:true,thumbnail:'https://appassets.androidplatform.net/preview/test.jpg'});
assert.equal(q('#file-title').textContent,'Actual extracted title');assert(q('#file-details').textContent.includes('2:05'));click('#thumbnail');assert.equal(calls.at(-1).name,'playPreview');assert.equal(calls.at(-1).args[0],'preview-token');
window.vidoraReceive({...initial,history:[{...item,mime:'video/mp4'}]});click('#history');click('[data-file-id="file-1"]');click('#file-convert');assert.equal(calls.at(-1).name,'requestConversion');assert.equal(calls.at(-1).args[1],'MP3');
const audioItem={...item,id:'audio-1',format:'MP3',mime:'audio/mpeg'};window.vidoraReceive({...initial,history:[audioItem]});click('#history');click('[data-file-id="audio-1"]');click('#file-convert');assert.equal(calls.at(-1).args[1],'MP4');
window.vidoraSetUrl('https://www.hentaicity.com/click/1-1/video/example');assert.equal(window.nativePreview,null);assert(q('#status-text').textContent.includes('blocked by safety policy'));assert(q('#download').disabled);assert.equal(q('#valid').textContent,'×');const downloadsBefore=calls.filter(c=>c.name==='requestDownload').length;click('#download');assert.equal(calls.filter(c=>c.name==='requestDownload').length,downloadsBefore);window.vidoraSetUrl('https://youtu.be/allowed');assert(!q('#download').disabled);assert.equal(q('#valid').textContent,'✓');
console.log('PASS: debounced preview, stale response guard, real cover/title/duration, in-app playback bridge, both conversion actions, blocked preview.');

assert(q('.brand h1').textContent==='ڤیدۆرا');assert(!fs.readFileSync(base+'app.js','utf8').includes('فیدۆرا'));console.log('PASS: screenshot domain blocked immediately, no download request, allowed-link reset, corrected brand.');

for(const [url,name,id] of [['https://drive.google.com/file/d/abc/view','Google Drive','drive'],['https://cdn.discordapp.com/attachments/123/video.mp4','Discord','discord'],['https://t.me/example/1','Telegram','telegram'],['https://pin.it/abc','Pinterest','pinterest'],['https://www.snapchat.com/spotlight/abc','Snapchat','snapchat']]){
 window.vidoraSetUrl(url);assert.equal(q('#site-name').textContent,name);const mark=q('#source-icon [data-platform="'+id+'"]');assert(mark);assert(mark.querySelector('img').getAttribute('src').includes('furry-sources-extra.png'));
}
click('#info');assert.equal(document.querySelectorAll('.platform-gallery [data-platform]').length,14);console.log('PASS: all five reference-based source icons and safe host labels.');

window.vidoraReceive({...initial,history:[item]});click('#history');click('[data-delete-file="file-1"]');assert(q('#details').open);assert(q('.delete-file-preview').textContent.includes(item.title));const beforeDelete=calls.filter(c=>c.name==='deleteFile').length;assert.equal(beforeDelete,0);click('#delete-file-confirm');assert.equal(calls.at(-1).name,'deleteFile');assert.equal(calls.at(-1).args[0],'file-1');assert(q('#delete-file-confirm').disabled);
window.vidoraFileDeleted({id:'file-1',status:'error',message:'Permission denied'});assert(!q('#delete-file-confirm').disabled);assert.equal(document.querySelectorAll('.file-row').length,1,'Failure must keep the file row');
click('#delete-file-confirm');window.vidoraFileDeleted({id:'file-1',status:'deleted',message:'Deleted'});assert(!q('#details').open);assert.equal(document.querySelectorAll('.file-row').length,0);console.log('PASS: destructive deletion requires confirmation; failure keeps row and retry; success removes row.');

window.vidoraNewSession();assert.equal(q('#url').value,'');assert.equal(window.nativePreview,null);assert.equal(q('#percentage').textContent,'0%');assert(!q('#toast').classList.contains('visible'));console.log('PASS: selected native theme is applied before app initialization; a new idle session clears URL, preview, progress and stale toast.');

window.vidoraReceive({...initial,running:true,action:'download',phase:'preparing',status:'running',progress:0});assert(q('.progress-card').classList.contains('is-preparing'));assert.equal(q('.track').getAttribute('aria-valuenow'),null);
window.vidoraReceive({...initial,running:true,action:'download',phase:'downloading',status:'running',progress:12});assert(!q('.progress-card').classList.contains('is-preparing'));assert.equal(q('.track').getAttribute('aria-valuenow'),'12');assert.equal(q('#percentage').textContent,'12%');
const coverItem={...item,id:'cover-2'};window.vidoraReceive({...initial,history:[coverItem]});click('#history');click('[data-filter="all"]');let cover=q('[data-real-cover]');assert(cover.src.includes('/thumbnails/'+coverItem.id+'.jpg'));assert(!cover.src.includes('thumbnail.svg'));cover.dispatchEvent(new window.Event('load'));assert(!cover.closest('.media-preview').classList.contains('is-loading'));click('[data-file-id="cover-2"]');cover=q('.file-visual [data-real-cover]');assert(cover.src.includes('/thumbnails/'+coverItem.id+'.jpg'));console.log('PASS: preparation loader switches to actual percentages; list/details request actual local covers and stop their shimmer on load.');

window.vidoraReceive({...initial,running:false,status:'idle'});window.vidoraSetUrl('https://youtu.be/long-clip');
// Native preview hook drives the range; no client-supplied duration is sent to Android.
window.vidoraClipSource({url:'https://youtu.be/long-clip',token:'clip-token',duration:7200,durationMs:7200000,clipAllowed:true},'https://youtu.be/long-clip');
click('#clip-part');assert(q('#clip-dialog').open);assert.equal(q('#clip-source-end').textContent,'02:00:00');assert.equal(q('#clip-start-time').value,'00:00:00');
const rangeKey=new window.Event('keydown');rangeKey.key='ArrowRight';q('#clip-start-range').dispatchEvent(rangeKey);assert.equal(Number(q('#clip-start-range').value),1000);
click('[data-clip-preset="last"]');assert.equal(q('#clip-start-time').value,'01:50:00');assert.equal(q('#clip-length').textContent,'00:10:00');click('#clip-apply');click('#download');let clipJob=JSON.parse(calls.at(-1).args[0]);assert.deepEqual(clipJob.clip,{token:'clip-token',startMs:6600000,endMs:7200000});assert.equal(q('#clip-choice-note').textContent,'01:50:00 — 02:00:00');
click('#clip-part');q('#clip-start-range').value=7199999;q('#clip-start-range').dispatchEvent(new window.Event('input'));assert.equal(Number(q('#clip-start-range').value),7199000,'Handles cannot cross');
q('#clip-start-time').value='00:10:00';q('#clip-end-time').value='00:09:00';q('#clip-end-time').dispatchEvent(new window.Event('change'));assert(q('#clip-apply').disabled);assert(!q('#clip-error').hidden);
q('#clip-start-time').value='۰۰:۱۰:۰۰';q('#clip-end-time').value='00:20:00';q('#clip-end-time').dispatchEvent(new window.Event('change'));assert(!q('#clip-apply').disabled);click('#clip-apply');click('[data-format="MP3"]');click('#download');clipJob=JSON.parse(calls.at(-1).args[0]);assert.equal(clipJob.format,'MP3');assert.equal(clipJob.clip.startMs,600000);assert.equal(clipJob.clip.endMs,1200000);
window.vidoraSetUrl('https://youtu.be/another-clip');assert.equal(q('#clip-all').getAttribute('aria-pressed'),'true');click('#download');assert(!JSON.parse(calls.at(-1).args[0]).clip);
window.vidoraClipSource({token:'live',durationMs:7200000,clipAllowed:false},'https://youtu.be/another-clip');click('#clip-part');assert(q('#clip-editor').hidden);assert(q('#clip-apply').disabled);q('#clip-dialog').close();
console.log('PASS: whole/segment choice, real source length, hour-format endpoints, last-ten preset, noncrossing handles, invalid times, Persian digits, MP3 payload, stale URL reset and live rejection.');
