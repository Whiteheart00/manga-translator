const {parseHTML}=require('linkedom'),fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const base=path.resolve(__dirname,'../../app/src/main/assets/player');const {window,document}=parseHTML(fs.readFileSync(base+'/index.html','utf8'));
const calls=[];window.VidoraPlayerNative=Object.fromEntries(['ready','open','play','pause','seek','speed','volume','audioMode','layout','aspect','fullscreen','back','pickMedia','pickSubtitle','capture','filters','download','cancelDownload','saveSettings','captions','cut','cancelCut'].map(name=>[name,(...args)=>calls.push({name,args})]));
window.VidoraPlayerNative.settings=()=> JSON.stringify({ccEnabled:true,volume:0,theme:'gold'});
Object.defineProperty(window.HTMLSelectElement.prototype,'options',{get(){return Array.from(this.querySelectorAll('option'))}});
Object.defineProperty(window.HTMLSelectElement.prototype,'value',{get(){return this.getAttribute('value')||''},set(v){this.setAttribute('value',v)}});
let timerNow=0,timerId=0;const timers=new Map();
function later(fn,delay=0){const id=++timerId;timers.set(id,{fn,at:timerNow+delay});return id;}
function advance(ms){timerNow+=ms;for(const [id,timer]of [...timers])if(timer.at<=timerNow){timers.delete(id);timer.fn();}}
const cache=new Map();const context=vm.createContext({window,document,URL,Event:window.Event,console,localStorage:{getItem:k=>cache.get(k)||null,setItem:(k,v)=>cache.set(k,v)},navigator:{},performance:{now:()=>1000},location:{origin:'https://appassets.androidplatform.net'},setTimeout:later,clearTimeout:id=>timers.delete(id),setInterval:()=>1,clearInterval:()=>{},requestAnimationFrame:()=>1,cancelAnimationFrame:()=>{},ResizeObserver:class{constructor(fn){this.fn=fn}observe(){this.fn()}},screen:{}});
vm.runInContext(fs.readFileSync(base+'/bootstrap.js','utf8'),context);assert.equal(document.documentElement.dataset.theme,'gold');vm.runInContext(fs.readFileSync(base+'/native-player.js','utf8'),context);vm.runInContext(fs.readFileSync(base+'/player.js','utf8'),context);vm.runInContext(fs.readFileSync(base+'/cut.js','utf8'),context);
const $=id=>document.getElementById(id);const click=id=>$(id).dispatchEvent(new window.Event('click'));
assert.equal(calls.at(-1).name,'ready');assert.equal($('ccSwitch').getAttribute('aria-checked'),'false');assert.equal($('volumeSlider').value,85);assert(calls.some(c=>c.name==='captions'&&c.args[0]===false));assert(!calls.some(c=>c.name==='open'),'No demos or fake playback');
window.nativePlaylist([{id:'record:video',title:'Mountains.mp4',isAudio:false},{id:'record:music',title:'Song.mp3',isAudio:true}],0);
assert(calls.some(c=>c.name==='open'&&c.args[0]==='record:video'));assert(calls.some(c=>c.name==='play'));assert.equal($('headerTitle').textContent,'Mountains.mp4');
window.nativePlayerSnapshot({id:'record:video',duration:120,currentTime:25,paused:false,ended:false,buffer:35,videoWidth:1280,videoHeight:720,readyState:4,embedded:'',error:null});
window.nativePlayerSnapshot({id:'record:video',duration:120,currentTime:25,paused:false,buffer:35,embedded:'Embedded caption',videoHeight:720});assert.equal($('subtitleContent').textContent,'');click('ccToggleBtn');assert(calls.some(c=>c.name==='captions'&&c.args[0]===true));assert.equal($('subtitleContent').textContent,'Embedded caption');click('ccToggleBtn');assert.equal($('subtitleContent').textContent,'');assert.equal($('currentTime').textContent,'00:25');assert.equal($('durationToggle').textContent,'02:00');assert($('mediaFormat').textContent.includes('720p'));
click('forwardBtn');assert(calls.some(c=>c.name==='seek'&&c.args[0]===35));click('playBtn');assert.equal(calls.at(-1).name,'pause');
window.VidoraPlayer.setSpeed(1.5);assert(calls.some(c=>c.name==='speed'&&c.args[0]===1.5));
click('fullscreenBtn');assert.equal(calls.at(-1).name,'fullscreen');click('openFilesQuick');assert.equal(calls.at(-1).name,'pickMedia');click('loadSubtitleBtn');assert.equal(calls.at(-1).name,'pickSubtitle');click('screenshotBtn');assert.equal(calls.at(-1).name,'capture');
click('nextBtn');assert(calls.some(c=>c.name==='open'&&c.args[0]==='record:music'));assert($('app').classList.contains('audio-mode'));assert.equal($('musicTitle').textContent,'Song.mp3');
assert(window.loadSubtitleText('1\n00:00:01,000 --> 00:00:05,000\nسڵاو'));
window.nativeSuspend();assert(document.body.classList.contains('native-suspended'));assert.equal(calls.at(-1).name,'pause');window.nativeResume();assert(!document.body.classList.contains('native-suspended'));
assert(!fs.readFileSync(base+'/player.js','utf8').includes('const DEMO_'));console.log('PASS: supplied player design uses native playback/seek/speed/fullscreen/capture/file/subtitle bridges, real timing, music mode, no demo, and suspend/resume cleanup.');

window.nativePlayerSnapshot({id:'preview:token',duration:60,currentTime:10,paused:false,canDownload:true,saved:false,downloadRunning:false,downloadCurrent:false});assert(!$('playerDownloadBtn').disabled);click('playerDownloadBtn');assert($('downloadSheet').classList.contains('open'));click('startPlayerDownload');assert.equal(calls.at(-1).name,'download');assert.equal(calls.at(-1).args[0],'preview:token');assert.equal(calls.at(-1).args[1],'MP4');
window.nativePlayerSnapshot({id:'preview:token',duration:60,currentTime:12,paused:false,canDownload:true,downloadRunning:true,downloadCurrent:true,downloadProgress:37,downloadMessage:'Downloading'});assert.equal($('playerDownloadPercent').textContent,'37%');assert(!$('cancelPlayerDownload').hidden);click('cancelPlayerDownload');assert.equal(calls.at(-1).name,'cancelDownload');
window.nativePlayerSnapshot({id:'record:saved',duration:60,currentTime:12,paused:true,canDownload:false,saved:true,downloadRunning:false});assert($('playerDownloadBtn').disabled);console.log('PASS: in-player download sheet, actual job progress/cancel, and saved-file disabled state.');

window.nativePlayerSnapshot({id:'preview:audio',duration:60,currentTime:5,paused:false,canDownload:true,audioOnly:true,downloadRunning:false,downloadCurrent:false});click('playerDownloadBtn');assert(document.querySelector('[data-download-mode="MP4"]').disabled);click('startPlayerDownload');assert.equal(calls.at(-1).args[1],'MP3');console.log('PASS: audio-only playback defaults to MP3 and disables video download.');

window.nativePlayerSnapshot({id:'preview:audio',duration:60,currentTime:5,paused:false,loading:true,readyState:0,canDownload:true,audioOnly:true,downloadRunning:true,downloadCurrent:true,downloadPhase:'preparing',downloadProgress:0});assert(!$('playerLoading').hidden);assert($('playerDownloadPercent').classList.contains('download-preparing'));
window.nativePlayerSnapshot({id:'preview:audio',duration:60,currentTime:6,paused:false,loading:false,readyState:4,canDownload:true,audioOnly:true,downloadRunning:true,downloadCurrent:true,downloadPhase:'downloading',downloadProgress:18});assert($('playerLoading').hidden);assert(!$('playerDownloadPercent').classList.contains('download-preparing'));assert.equal($('playerDownloadPercent').textContent,'18%');
window.nativePlayerSnapshot({id:'preview:audio',duration:60,currentTime:6,paused:true,loading:true,error:{code:3}});assert($('playerLoading').hidden);console.log('PASS: player opens/buffers with loader, hides it on readiness/error, and download preparation changes to real percentage.');

// Real elapsed timers expose the former 3.5-second disappearance regression.
document.querySelector('#downloadSheet .sheet-close').dispatchEvent(new window.Event('click'));
window.nativePlaylist([{id:'record:video2',title:'Film.mp4',isAudio:false}],0);
window.nativePlayerSnapshot({id:'record:video2',duration:120,currentTime:25,paused:false,ended:false,buffer:35,videoWidth:1280,videoHeight:720,readyState:4,embedded:'',error:null});
advance(30000);assert(!$('app').classList.contains('controls-hidden'),'Playing controls stay visible after 30 seconds');
$('playerStage').getBoundingClientRect=()=>({left:0,top:0,width:900,height:500});
const tap=()=>{for(const type of ['pointerdown','pointerup']){const event=new window.Event(type);Object.assign(event,{clientX:450,clientY:250,pointerId:1,button:0});$('gestureSurface').dispatchEvent(event);}};
tap();assert($('app').classList.contains('controls-hidden'),'Deliberate centre tap hides controls');
tap();assert(!$('app').classList.contains('controls-hidden'),'Next centre tap restores controls');
click('forwardBtn');advance(30000);assert(!$('app').classList.contains('controls-hidden'),'Seeking never starts an auto-hide timer');
console.log('PASS: controls stay visible during playback and seeking; deliberate centre taps hide and restore them.');

// The native fullscreen flag, not browser Fullscreen API state, owns Android's layout.
window.nativeFullscreenState(true);assert($('app').classList.contains('is-fullscreen'));assert.equal($('screenModeIcon').getAttribute('href'),'#i-exit-full');assert.equal($('screenModeBtn').getAttribute('aria-pressed'),'true');assert($('screenModeBtn').getAttribute('aria-label').includes('ئاسایی'));
click('screenModeBtn');assert.equal(calls.at(-1).name,'fullscreen');
window.nativeFullscreenState(false);assert(!$('app').classList.contains('is-fullscreen'));assert.equal($('screenModeIcon').getAttribute('href'),'#i-full');
tap();assert($('app').classList.contains('controls-hidden'));window.nativePlayerSnapshot({id:'record:video2',duration:120,currentTime:30,paused:false,ended:false,fullscreen:false});assert($('app').classList.contains('controls-hidden'),'Periodic native snapshots must not undo deliberate hiding');tap();
window.nativePlaylist([{id:'record:loop-a',title:'A.mp4',isAudio:false},{id:'record:loop-b',title:'B.mp4',isAudio:false}],0);
window.nativePlayerSnapshot({id:'record:loop-a',duration:10,currentTime:9,paused:false,ended:false});
click('videoRepeatBtn');assert.equal($('videoRepeatBtn').getAttribute('aria-pressed'),'true');assert.equal($('repeatLabel').textContent,'1');assert(!$('videoRepeatBadge').hidden);assert(JSON.parse(calls.filter(c=>c.name==='saveSettings').at(-1).args[0]).repeatMode==='one');
for(let loop=0;loop<2;loop++){
 const before=calls.length;window.nativePlayerSnapshot({id:'record:loop-a',duration:10,currentTime:10,paused:false,ended:true});
 const recent=calls.slice(before);assert(recent.some(c=>c.name==='seek'&&c.args[0]===0));assert(recent.some(c=>c.name==='play'));assert(!recent.some(c=>c.name==='open'),'Repeat one must not advance to the next item');
 window.nativePlayerSnapshot({id:'record:loop-a',duration:10,currentTime:0,paused:false,ended:false});
}
click('repeatBtn');assert($('videoRepeatBadge').hidden);assert($('videoRepeatText').textContent.includes('هەموو'));
window.nativePlayerSnapshot({id:'record:loop-a',duration:10,currentTime:10,paused:false,ended:true});assert(calls.some(c=>c.name==='open'&&c.args[0]==='record:loop-b'));
click('videoRepeatBtn');assert.equal($('repeatBtn').getAttribute('aria-pressed'),'false');assert.equal($('videoRepeatBtn').getAttribute('aria-pressed'),'false');
console.log('PASS: visible native fullscreen enter/exit state; repeat one replays twice without advancing, shared music/video state, all/off and saved preference.');

window.nativePlayerSnapshot({id:'record:loop-b',duration:10,currentTime:2,paused:false,ended:false});click('abLoopBtn');window.nativePlayerSnapshot({id:'record:loop-b',duration:10,currentTime:5,paused:false,ended:false});click('abLoopBtn');assert($('abLoopBtn').classList.contains('active'));
click('videoRepeatBtn');assert(!$('abLoopBtn').classList.contains('active'),'Whole-file repeat clears a prior A-B segment');assert(!$('videoRepeatBadge').hidden);
click('abLoopBtn');assert.equal($('videoRepeatBtn').getAttribute('aria-pressed'),'false','Starting an A-B segment switches off whole-file repeat');
console.log('PASS: selecting whole-file repeat and A-B segment repeat are mutually exclusive.');

const cutId='record:aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
window.nativePlaylist([{id:cutId,title:'Original.mp4',isAudio:false}],0);
window.nativePlayerSnapshot({id:cutId,saved:true,canCut:true,duration:120,cutDurationMs:120000,currentTime:15,paused:false,ended:false,downloadRunning:false,taskAction:'idle'});assert(!$('playerCutBtn').disabled);
click('playerCutBtn');assert($('cutSheet').classList.contains('open'));assert.equal(calls.at(-1).name,'pause');assert.equal($('localCutAxisEnd').textContent,'00:02:00');
$('localCutStartTime').value='00:00:10';$('localCutEndTime').value='00:00:30';$('localCutEndTime').dispatchEvent(new window.Event('change'));assert(!$('saveCutBtn').disabled);click('saveCutBtn');assert.equal(calls.at(-1).name,'cut');assert.deepEqual(calls.at(-1).args,[cutId,10000,30000]);assert($('saveCutBtn').disabled);
window.nativePlayerSnapshot({id:cutId,saved:true,canCut:true,duration:120,cutDurationMs:120000,currentTime:15,paused:true,ended:false,downloadRunning:true,downloadProgress:40,downloadStatus:'running',downloadPhase:'processing',downloadMessage:'Cutting',taskAction:'cut',taskRecordId:cutId.slice(7)});
assert.equal($('cutPercent').textContent,'40%');assert(!$('cancelCutBtn').hidden);click('cancelCutBtn');assert.equal(calls.at(-1).name,'cancelCut');assert.equal(calls.at(-1).args[0],cutId);
window.nativePlayerSnapshot({id:cutId,saved:true,canCut:true,duration:120,cutDurationMs:120000,currentTime:15,paused:true,downloadRunning:false,downloadProgress:100,downloadStatus:'success',downloadMessage:'New file saved; original kept',taskAction:'cut',taskRecordId:cutId.slice(7)});assert.equal($('cutPercent').textContent,'100%');assert($('cutStatus').textContent.includes('original kept'));assert.equal($('headerTitle').textContent,'Original.mp4');
$('localCutStartTime').value='00:00:40';$('localCutEndTime').value='00:00:20';$('localCutEndTime').dispatchEvent(new window.Event('change'));assert($('saveCutBtn').disabled);assert(!$('cutError').hidden);
window.nativePlayerSnapshot({id:'preview:online',saved:false,canCut:false,duration:120,currentTime:0,paused:true,downloadRunning:false,taskAction:'idle'});assert($('playerCutBtn').disabled);assert(!$('cutSheet').classList.contains('open'));
window.nativePlaylist([{id:'record:audio-cut',title:'Original.mp3',isAudio:true}],0);window.nativePlayerSnapshot({id:'record:audio-cut',saved:true,canCut:true,duration:60,cutDurationMs:60000,currentTime:5,paused:true,downloadRunning:false,taskAction:'idle'});click('playerCutBtn');assert.equal($('localCutStartTime').value,'00:00:00');click('localCutMarkStart');assert.equal($('localCutStartTime').value,'00:00:05');click('saveCutBtn');assert.equal(calls.at(-1).name,'cut');assert.equal(calls.at(-1).args[0],'record:audio-cut');
console.log('PASS: downloaded-only Cut sheet for video/music, native save-new request, actual progress/cancel/completion, invalid times and track-change reset; original stays selected.');
