"""No-network tests against the actual yt-dlp transport plugin."""
import importlib.util
import pathlib
import sys
sys.dont_write_bytecode = True
import unittest
from unittest.mock import patch
from yt_dlp import YoutubeDL
from yt_dlp.utils import YoutubeDLError
from yt_dlp.networking._urllib import RedirectHandler
from yt_dlp.networking._requests import RequestsSession
from urllib.request import Request

path = pathlib.Path(__file__).resolve().parents[2] / 'app/src/main/assets/security/vidora_transport.py'
spec = importlib.util.spec_from_file_location('vidora_transport_test', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class TransportTest(unittest.TestCase):
    def test_policy_rejects_cleartext_credentials_and_empty_host(self):
        for url in ('http://example.org/video', 'https://user:secret@example.org/video', 'file:///tmp/video', 'https:///video'):
            with self.subTest(url=url), self.assertRaises(YoutubeDLError):
                module.require_https(url)
        module.require_https('https://example.org/video?token=sample')

    def test_top_level_https_and_redirects_are_checked_before_transport(self):
        with YoutubeDL({'quiet': True}) as ydl:
            sentinel = object()
            with patch.object(ydl, 'urlopen', return_value=sentinel) as send, patch.object(RedirectHandler, 'redirect_request', return_value=sentinel) as redirect, patch.object(RequestsSession, 'send', return_value=sentinel) as requests_send:
                # Patches are restored after construction, including module-installed wrappers.
                module.VidoraTransportPP(ydl)
                self.assertTrue(set(ydl._request_director.handlers).issubset({'Urllib', 'Requests'}))
                self.assertIs(ydl.urlopen('https://example.org/movie'), sentinel)
                self.assertEqual(send.call_count, 1)
                with self.assertRaises(YoutubeDLError):
                    ydl.urlopen('http://example.org/movie')
                self.assertEqual(send.call_count, 1)
                handler = RedirectHandler()
                args = (Request('https://example.org/start'), None, 302, 'redirect', {})
                with self.assertRaises(YoutubeDLError):
                    handler.redirect_request(*args, 'http://example.org/end')
                redirect.assert_not_called()
                self.assertIs(handler.redirect_request(*args, 'https://example.org/end'), sentinel)
                fake = type('Prepared', (), {'url': 'http://example.org/end'})()
                with self.assertRaises(YoutubeDLError):
                    RequestsSession.send(object(), fake)
                requests_send.assert_not_called()
                fake.url = 'https://example.org/end'
                self.assertIs(RequestsSession.send(object(), fake), sentinel)

if __name__ == '__main__':
    unittest.main()
