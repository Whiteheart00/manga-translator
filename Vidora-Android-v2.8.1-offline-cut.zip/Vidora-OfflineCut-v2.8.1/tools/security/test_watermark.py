"""No-network regression of clean-rendition preference before yt-dlp format selection."""
import sys
sys.dont_write_bytecode=True
import importlib.util
from pathlib import Path
import unittest
from yt_dlp import YoutubeDL
from yt_dlp.postprocessor.common import PostProcessor
p=Path(__file__).resolve().parents[2]/'app/src/main/assets/security/vidora_transport.py'
spec=importlib.util.spec_from_file_location('vidora_watermark',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

class WatermarkTest(unittest.TestCase):
    def processed(self,formats):
        with YoutubeDL({'quiet':True,'skip_download':True,'format':'best'}) as ydl:
            # run is independent of transport constructor; transport itself has separate tests.
            pp=object.__new__(module.VidoraTransportPP)
            PostProcessor.__init__(pp,ydl);ydl.add_post_processor(pp,when='pre_process')
            return ydl.process_ie_result({'id':'synthetic','title':'test','formats':formats},download=False)
    def fmt(self,id,height,**extra):return dict(format_id=id,url=f'https://example.org/{id}.mp4',ext='mp4',vcodec='h264',acodec='aac',height=height,**extra)
    def test_actual_selection_prefers_clean_over_higher_resolution_watermarked(self):
        result=self.processed([self.fmt('clean',720,is_watermarked=False),self.fmt('watermarked',1080,is_watermarked=True)])
        self.assertEqual(result['format_id'],'clean');self.assertEqual(result['vidora_watermark_status'],'declared_clean')
    def test_unknown_is_never_claimed_clean_and_explicit_watermark_is_avoided(self):
        result=self.processed([self.fmt('unknown',720),self.fmt('marked',1080,format_note='watermarked')])
        self.assertEqual(result['format_id'],'unknown');self.assertEqual(result['vidora_watermark_status'],'unknown')
    def test_only_marked_source_is_reported_honestly(self):
        result=self.processed([self.fmt('only',720,is_watermarked=True)])
        self.assertEqual(result['vidora_watermark_status'],'marked')
    def test_notes_and_audio_preserved(self):
        self.assertFalse(module.VidoraTransportPP.watermark({'format_note':'without watermark'}))
        self.assertFalse(module.VidoraTransportPP.watermark({'format_note':'unwatermarked'}))
        pp=object.__new__(module.VidoraTransportPP);PostProcessor.__init__(pp)
        audio={'format_id':'audio','vcodec':'none','url':'https://example.org/audio.m4a'}
        _,result=pp.run({'formats':[self.fmt('clean',720,is_watermarked=False),self.fmt('marked',1080,is_watermarked=True),audio]})
        self.assertIn(audio,result['formats'])

if __name__=='__main__':unittest.main()
