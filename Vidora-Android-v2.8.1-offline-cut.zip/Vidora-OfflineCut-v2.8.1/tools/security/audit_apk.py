"""Audit an already built release APK. Requires Android SDK build-tools; no keys read."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

def signing_certificate(output):
    """Accept legacy and scheme-prefixed apksigner output; never match public-key hashes."""
    certificates = set(value.lower() for value in re.findall(
        r'^(?:Signer #\d+|V\d+(?:\.\d+)? Signer(?: #\d+)?):? certificate SHA-256 digest: ([0-9a-fA-F]{64})\s*$',
        output, re.M))
    counts = re.findall(r'^Number of signers: (\d+)\s*$', output, re.M)
    assert len(certificates) == 1 and all(int(n) == 1 for n in counts), 'Expected exactly one APK signing certificate'
    return certificates.pop()

parser = argparse.ArgumentParser()
parser.add_argument('apk', type=Path)
parser.add_argument('--project', type=Path, default=Path('.'))
args = parser.parse_args()
sdk = Path(os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT') or '')
versions = sorted((sdk / 'build-tools').glob('*'), key=lambda p: tuple(int(x) if x.isdigit() else 0 for x in p.name.split('.')))
assert versions, 'Android SDK build-tools unavailable'
bin_dir = versions[-1]
def run(tool, *arguments):
    return subprocess.check_output([str(bin_dir / tool), *map(str, arguments)], stderr=subprocess.STDOUT, text=True)
certs = run('apksigner', 'verify', '--verbose', '--print-certs', args.apk)
certificate = signing_certificate(certs)
build_config = args.project / 'app/build/generated/source/buildConfig/release/com/kurd/videodownloader/BuildConfig.java'
source = build_config.read_text()
def constant(name):
    value = re.search(r'\b' + name + r'\s*=\s*"([0-9a-f]{64})"', source)
    assert value, f'Missing release constant: {name}'
    return value.group(1)
assert constant('TRUSTED_CERT_SHA256') == certificate, 'Signer differs from expected release certificate'
with zipfile.ZipFile(args.apk) as archive:
    names = archive.namelist()
    dex = b''.join(archive.read(n) for n in names if re.fullmatch(r'classes\d*\.dex', n))
    manifest_bytes = archive.read('assets/security/asset-hashes.json')
    assert hashlib.sha256(manifest_bytes).hexdigest() == constant('ASSET_MANIFEST_SHA256'), 'Asset manifest pin mismatch'
    entries = json.loads(manifest_bytes)
    for name, digest in entries.items():
        assert '..' not in name and not name.startswith('/'), 'Unsafe asset name'
        assert hashlib.sha256(archive.read('assets/' + name)).hexdigest() == digest, 'Asset mismatch: ' + name
    # AGP generates binary runtime profiles after source asset hashing.
    packaged = set(n[7:] for n in names if n.startswith('assets/') and not n.endswith('/'))
    profiles = {'dexopt/baseline.prof', 'dexopt/baseline.profm'}
    assert packaged - profiles == set(entries) | {'security/asset-hashes.json'}, 'Unaccounted assets'
    for pin in ('TRUSTED_CERT_SHA256', 'ASSET_MANIFEST_SHA256'):
        assert constant(pin).encode() in dex, f'Release DEX missing {pin}'
    for n in names:
        assert not n.lower().endswith(('.jks', '.keystore', '.p12', '.pem', '.key')), 'Private credential file packaged'
manifest = run('aapt', 'dump', 'xmltree', args.apk, 'AndroidManifest.xml')
for field in ('debuggable', 'allowBackup', 'usesCleartextTraffic'):
    assert not re.search(r'android:' + field + r'.*=\(type 0x12\)0xffffffff', manifest), f'Unsafe manifest flag: {field}'
permissions = run('aapt', 'dump', 'permissions', args.apk)
for forbidden in ('ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'READ_PHONE_STATE', 'READ_PHONE_NUMBERS', 'READ_CONTACTS', 'AD_ID', 'ACCESS_BACKGROUND_LOCATION'):
    assert forbidden not in permissions, f'Unnecessary personal-data permission: {forbidden}'
mapping = args.project / 'app/build/outputs/mapping/release/mapping.txt'
mapping_text = mapping.read_text()
renamed = re.findall(r'^com\.kurd\.videodownloader\.[^ :]+ -> ([^ :]+):', mapping_text, re.M)
assert renamed and any(not name.startswith('com.kurd.videodownloader.') for name in renamed), 'App code was not obfuscated'
assert 'useTestKey' not in mapping_text, 'Debug crypto override survived release shrinking'
bridge_count = 0
for activity, bridge in [('MainActivity', 'NativeApi'), ('PlayerActivity', 'Controls')]:
    source = (args.project / f'app/src/main/java/com/kurd/videodownloader/{activity}.kt').read_text()
    expected = set(re.findall(r'@(?:android\.webkit\.)?JavascriptInterface\s+fun\s+(\w+)\(', source))
    assert expected, 'Bridge annotation discovery failed'
    header = f'com.kurd.videodownloader.{activity}${bridge} -> '
    sections = re.split(r'(?m)(?=^[^ #\s].* -> .*:$)', mapping_text)
    section = next((s for s in sections if s.startswith(header)), '')
    assert section, 'Missing native bridge class'
    for name in expected:
        assert re.search(r'\b' + name + r'\([^\n]*\)[^\n]* -> ' + name + r'$', section, re.M), 'Bridge method removed/renamed: ' + name
    bridge_count += len(expected)
print(f'PASS: signed release, expected public certificate, {len(entries)} asset hashes, pinned manifest, R8, {bridge_count} bridge methods preserved, no debug key override, backup/cleartext disabled, no location/phone/contact/ad-ID permissions.')
