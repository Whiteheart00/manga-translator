"""Exercise the audit's pure parser without running its APK command-line entrypoint."""
import ast
from pathlib import Path
import re
import unittest
source = ast.parse(Path(__file__).with_name('audit_apk.py').read_text())
function = next(node for node in source.body if isinstance(node, ast.FunctionDef) and node.name == 'signing_certificate')
namespace = {'re': re}
exec(compile(ast.Module(body=[function], type_ignores=[]), 'audit_apk.py', 'exec'), namespace)
certificate = namespace['signing_certificate']

class SignerParserTest(unittest.TestCase):
    digest = '0ab020a90cfa3d5871c04f253ab7539f233d570208d6ba35a2768fdfd1754dfc'
    def test_legacy_output(self):
        self.assertEqual(certificate('Number of signers: 1\nSigner #1 certificate SHA-256 digest: '+self.digest+'\n'), self.digest)
    def test_reported_v2_output(self):
        self.assertEqual(certificate('Verifies\nVerified using v2 scheme (APK Signature Scheme v2): true\nNumber of signers: 1\nV2 Signer: certificate SHA-256 digest: '+self.digest+'\nV2 Signer: public key SHA-256 digest: '+'64'*32+'\n'), self.digest)
    def test_same_certificate_in_multiple_schemes(self):
        output='\n'.join(f'{prefix} certificate SHA-256 digest: {self.digest.upper()}' for prefix in ('Signer #1', 'V2 Signer:', 'V3 Signer:', 'V3.1 Signer:'))
        self.assertEqual(certificate(output), self.digest)
    def test_missing_certificate_or_conflicting_signers_rejected(self):
        for output in ('', 'V2 Signer: public key SHA-256 digest: '+self.digest, 'V2 Signer: certificate SHA-1 digest: '+self.digest,
                       'Number of signers: 2\nSigner #1 certificate SHA-256 digest: '+self.digest,
                       'Signer #1 certificate SHA-256 digest: '+self.digest+'\nSigner #2 certificate SHA-256 digest: '+'ab'*32):
            with self.subTest(output=output), self.assertRaises(AssertionError): certificate(output)

if __name__ == '__main__': unittest.main()
