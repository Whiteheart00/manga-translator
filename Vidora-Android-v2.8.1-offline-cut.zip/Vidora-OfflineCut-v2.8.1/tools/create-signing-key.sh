#!/usr/bin/env bash
# One-time private-key creation on the user's own device (e.g. Termux).
# Never share or upload the private keystore. Do NOT regenerate on every release.
set -euo pipefail
umask 077

if ! command -v keytool >/dev/null 2>&1; then
  echo 'keytool is required. In Termux: pkg install openjdk-17 coreutils -y'
  exit 1
fi
if ! command -v base64 >/dev/null 2>&1; then
  echo 'base64 is required. In Termux: pkg install coreutils -y'
  exit 1
fi

keydir="$HOME/vidora-signing"
keystore="$keydir/vidora-release.jks"
mkdir -p "$keydir"
chmod 700 "$keydir"

if [[ -f "$keystore" ]]; then
  echo "Existing key found: $keystore"
  echo 'Good: the existing key will NOT be overwritten.'
else
  echo 'Creating a PRIVATE, PERMANENT signing key.'
  echo 'Enter and remember a strong keystore password when prompted.'
  keytool -genkeypair \
    -keystore "$keystore" \
    -storetype PKCS12 \
    -alias vidora \
    -keyalg RSA \
    -keysize 3072 \
    -validity 12000 \
    -dname 'CN=Vidora Android App, OU=App Signing, O=Vidora'
  chmod 600 "$keystore"
fi

printf '\n*** IMPORTANT: KEEP THIS FILE PRIVATE AND BACK IT UP ***\n%s\n' "$keystore"
echo 'GitHub secrets to create under Settings > Secrets and variables > Actions:'
echo '  VIDORA_KEYSTORE_BASE64 : copy the base64 text printed below (ONE line)'
echo '  VIDORA_STORE_PASSWORD  : the password you entered above'
echo '  VIDORA_KEY_ALIAS       : vidora'
echo '  VIDORA_KEY_PASSWORD    : the SAME password (PKCS12)'
echo
echo '== BEGIN PRIVATE KEYSTORE BASE64 (DO NOT COMMIT OR SHARE) =='
base64 -w 0 "$keystore"
printf '\n== END PRIVATE KEYSTORE BASE64 ==\n'
echo 'Keep a secure backup of the original .jks file and its password.'
