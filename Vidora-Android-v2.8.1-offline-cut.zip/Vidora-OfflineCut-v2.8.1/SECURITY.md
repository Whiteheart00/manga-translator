# Vidora 2.6 security and privacy

This is an offline-first Android client with direct connections to user-selected media sources. There is no new account, licensing/activation server, advertising ID collection, location permission, analytics SDK, or automatic diagnostic upload. The source website/CDN and network operators can still observe connection IP addresses. HTTPS protects transport content; this app is not a VPN or anonymity service.

## Private app data

History, saved source links, playback positions, settings, update integrity state, and player preferences use AES-256-GCM with a per-install Android Keystore key. Every value has a fresh random IV and authenticates its store/key context. Private preview metadata and structural diagnostic reports are encrypted as well. The key is not shipped in the APK; release builds remove the test-only crypto override. Hardware backing depends on the device and is not guaranteed.

Existing preference values are copied, committed, decrypted and authenticated before the old plaintext preferences are cleared. Process admission also removes expired-process preview caches and app-owned job staging left by older versions, without touching saved public media. A completed migration never re-imports injected legacy preferences. Backup and device-transfer rules exclude app data. If the key is lost or authentication fails, the app refuses to silently load untrusted state and preserves the files. Uninstalling loses app-private history/settings. Keep the same application ID and permanent signing key to update in place.

Public downloaded videos/music remain in Android Downloads, as requested. They are readable by their owner and other applications with Android-authorized access. File names, covers, and media metadata can reveal information. Job staging is in app-private internal cache, cleaned after each job; temporary cleartext job metadata is required by yt-dlp. This is not an encrypted media vault, secure deletion system, or root-proof protection. A compromised OS or code running inside the app process may access decrypted data. Ciphertext rollback is not prevented by a remote monotonic service.

## APK authenticity and ownership

Release builds use R8 shrinking/obfuscation and resource shrinking. At startup, native code verifies the installed APK signing certificate against the public certificate hash derived from the supplied signing keystore. It also verifies a pinned manifest and hashes of packaged HTML, JavaScript, safety lists, Python policy, fonts and other assets before admitting the UI/download service. Debug builds intentionally skip certificate/assets enforcement for development; distribute signed release builds only.

Android APK signatures and these checks make accidental modification and basic repackaging detectable. They cannot make a distributed client impossible to copy, reverse engineer, patch or re-sign. An attacker who rewrites native checks can bypass client-side enforcement. An unchanged legitimate APK can be copied and run, intentionally: there is no activation system. Certificate pinning here identifies the app signer; it is not third-party website TLS certificate pinning. Existing public repository clones cannot be recalled.

## Network and executable updates

Native source URLs require HTTPS without embedded URL credentials. WebView serves bundled UI only, with existing network/file restrictions. Media3 disallows cross-protocol redirects. The yt-dlp policy checks top-level requests plus urllib/requests redirects and disables handlers whose native redirects cannot be checked. Plain HTTP sources and curl/impersonation-only transports are unsupported; some sites can consequently fail rather than weaken the policy. This is defense in depth, not a sandbox around every extractor, FFmpeg process, third-party library or upstream script.

The updater accepts the official stable yt-dlp GitHub release only, with a bounded download and SHA-256 verification against the exact `yt-dlp` entry in official `SHA2-256SUMS`. Redirects must remain HTTPS on explicit GitHub delivery hosts. Installation uses AtomicFile and an encrypted recovery journal. A previously unverified cached engine is reset to the APK-bundled engine; a changed verified engine is rejected. Failed/cancelled downloads do not replace the old engine. GitHub release checksums share the official upstream TLS/account trust and are not an independent offline signature. The bundled engine and optional official YouTube EJS component remain upstream software trust dependencies.

No source credentials, IP address, location, phone model, raw exception messages or source URL are written to the app's diagnostics. Reports contain only app/API versions, local time, fixed event names, exception type and own-code stack locations. Manual report export is user-initiated; third-party libraries and the Android OS may maintain their own logs. Normal site requests can include necessary headers/cookies from extractors.

## Distribution and repository

The supplied workflow requires a private source repository, uses read-only GitHub token permissions, disables persisted checkout credentials, pins Actions to immutable commit SHAs, requires the existing signing secrets, and runs tests plus a signed-APK audit before upload. The signing key is temporarily restored outside source and removed at job end. APK artifacts are separate from source and mapping files. CI dependencies and upstream releases still require routine maintenance.

Follow PRIVATE-REPOSITORY.md before pushing source. No remote GitHub visibility or collaborator setting was changed in this workspace. Keep signing keys/passwords and R8 mapping files private. Do not rotate an existing signing key merely to install this update. Do not apply ownership restrictions to third-party open-source code or trademarks; their original licenses remain applicable.

## Before release to users

Read BUILD-VERIFICATION.txt for actual checks and limitations. On a physical device test upgrade from the previous signed APK, history/settings migration, preview and download from several allowed sources, blocked domains, both media modes, file deletion, task removal and an authentic minified release startup. Separately re-sign a disposable APK and confirm the native integrity screen rejects it; never replace production signing credentials for this test. Test encrypted-storage failure on a disposable installation, not real user data. No physical-device run was available during this implementation.
