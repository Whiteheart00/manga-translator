# v2.2 media UI and lifecycle

The uploaded index_1_.html was split into packaged player/index.html, player.css and player.js. Native-player.js exposes a media-element facade; controls invoke only a narrow JavaScript bridge. A native Media3 ExoPlayer/TextureView sits beneath the transparent HTML stage. JavaScript receives real duration/position/buffer/decoder state and never gets remote media headers. The WebView has no network, file or content access; source IDs are checked against app-owned queue entries or URIs explicitly granted through the Android picker.

Original demo video/audio/subtitle tracks were removed. Controls, gestures, sheets and visual design remain. Background playback and PiP are deliberately disabled. Imported subtitles are capped at 1 MiB and sanitized as text by the supplied parser. Existing embedded subtitle cues are passed to the HTML caption renderer. Native screenshot capture saves an actual TextureView frame; no HTML canvas masquerades as a native decoded frame.

OnPause pauses audio/video and suspends HTML timers/visuals. OnStop removes polling callbacks, detaches and releases ExoPlayer and shuts down file I/O workers. Returning prepares the selected item paused. A new user selection can explicitly start playback. The prior MediaSessionService and its mediaPlayback/wake-lock permissions were removed. Thus no notification playback service survives the screen.

A shared visibility coordinator called explicitly by both activities pauses WebView timers when the last activity stops and cancels non-download maintenance/conversion tasks. Input-preview cancellation disconnects native HTTP and cancels the Python process; the preview worker's idle thread times out. DownloadService alone may continue when Home/backgrounded. Its onTaskRemoved cancels jobs and removes the notification, suppressing completion/progress notifications after task removal.

Android owns process caching and reclaimed RAM. This implementation does not forcibly kill the app process or promise zero physical RAM/battery use; resources and continuing background work are the practical controls.

Phone validation still needed: native video alignment beneath the HTML in portrait/landscape, imported local files/subtitles, screenshot, Home/back/screen lock pause, return without autoplay, download continuation on Home and cancellation on recents swipe. Some codecs/streams are device-dependent. Domains/metadata are not complete content classification.

## v2.3 playback download / physical deletion

Playback previews export a whitelist of selected formats and headers to a private cached info file; unselected renditions, output filenames, requested_downloads and arbitrary extractor fields are not copied. Only native preview tokens matching the source/current player are accepted. The download service rechecks source/age/DRM safety, copies the snapshot into its own job directory, then invokes yt-dlp with --load-info-json and no original page URL argument. Normal page extraction is left unchanged. MP3 chooses the captured audio rendition when separate tracks are available. Successful output follows the same MediaStore/history path and background-download lifecycle as normal downloads.

File deletion is scoped to an existing native record. MediaStore requires a concrete numeric Downloads item URI. Legacy files must resolve inside public Downloads and use this app's provider; directory/path escapes fail. The history/bookmark is removed only after deletion or confirmed absence. Security failures can request the OS's recoverable deletion permission; cancellation keeps history. The UI distinguishes permanent deletion from hide/undo, never offers an undo for a physically deleted file, and keeps rows on failure.

Host live fallback validation: a public clip snapshot exported by the production Kotlin capture helper was downloaded successfully with its webpage URL set to an unavailable domain. It yielded the exact 6,570,639-byte H.264/AAC clip, 62.415011s, without page extraction. This is host-engine verification, not a physical Android player/permission test.
