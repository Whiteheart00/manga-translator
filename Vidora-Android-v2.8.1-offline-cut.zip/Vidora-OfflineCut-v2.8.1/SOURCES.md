# Downloader references and validation scope

Primary references consulted on 2026-11-15:

- https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md
- https://github.com/yt-dlp/yt-dlp/blob/master/README.md#format-selection
- https://github.com/yt-dlp/yt-dlp/blob/master/README.md#filtering-formats
- https://github.com/yt-dlp/yt-dlp/blob/master/yt_dlp/extractor/tiktok.py
- https://github.com/yt-dlp/yt-dlp/blob/master/yt_dlp/extractor/pinterest.py
- https://github.com/yt-dlp/yt-dlp/blob/master/yt_dlp/extractor/snapchat.py

Actual production selectors were exported by MediaRequestPolicyTest, then evaluated by yt-dlp 2026.10.26 against ten synthetic format fixtures. These check parser validity, clean-vs-watermarked selection, unknown metadata, silent video, muxed/separate formats, and a real resolution cap. The same engine lists the requested extractor families (1,754 extractor classes in the inspected package); this count is not a count of live-tested working sites.

Short links first receive native redirect preflight, followed by yt-dlp extraction. Site recognition supplies labels and special audio/TikTok policy. v2.0 also applies the bundled adult/gambling source filter; ordinary unlisted domains remain supported. TikTok metadata filtering does not inspect burned-in video pixels and cannot guarantee every source lacks embedded branding.

Public Instagram Stories may still require authentication. This build does not import cookies, sign in, remove DRM, or use third-party downloader APIs. Live extraction success depends on site changes, account requirements, region and the installed engine version.

No end-to-end download of live social-media content or physical-device verification has been performed in this environment.

## v2.0 primary references / licenses

- https://github.com/StevenBlack/hosts — MIT license; category-only porn/gambling snapshots fetched 2026-11-15. The complete compressed source snapshots, upstream MIT license, and reproducible SHA-256-prefix generator are in tools/blocklist-sources/ and tools/rebuild-safety-list.py. At runtime, sorted signed 64-bit hashes provide bounded-memory suffix matching (76,811 / 6,744 domains).
- https://developer.android.com/media/media3/exoplayer — Media3 ExoPlayer 1.5.1, HLS/DASH/UI artifacts.
- https://developer.android.com/develop/background-work/services/fgs/service-types#media-processing — Android 15 media-processing foreground type for local conversion; dataSync fallback on older versions.
- Bundled youtubedl-android FFmpeg 0.18.1 source inspected to match native binary and library extraction paths. ARM64 binary/package inspected for libx264/libmp3lame; no ARM binary was executed on this Linux host.

Safety limits: native checks cover input/HEAD redirects, extracted metadata and preview stream/segment endpoints. yt-dlp performs its own additional network requests; they are not all intercepted. Mixed-content sites without age/category metadata can contain unclassified content. A 100% content block is not claimed. No login/cookies/DRM bypass was added.

## v2.1 playback and build selection

Historical v2.1 used MediaSessionService/MediaController for background playback (removed in v2.2): https://developer.android.com/media/media3/session/background-playback . Native controls use PlayerView; PiP checks Android API/device support. The legacy launcher aliases are retained for migration but cannot switch with the palette. The workflow selection script was executed in a synthetic repository containing both old root source and a new ZIP; it selected the ZIP. A multiple-ZIP fixture was rejected. The screenshot's exact domain/path pattern is tested through the real native bridge and direct service gate without making a network request or fetching adult media.

## v2.2 sources

Player visual/interaction source: user-uploaded index_1_.html. Embedded media and demo captions are excluded from the Android integration. The integrated HTML remains offline; only native decoder/network/storage/pickers perform privileged work.

Brand font: https://github.com/google/fonts/tree/main/ofl/notonaskharabic — Noto Naskh Arabic variable font and OFL license included in ui/assets/fonts/. No font outline was edited. The brand string is U+06A4 U+06CC U+062F U+06C6 U+0631 U+0627.

Android lifecycle resources: https://developer.android.com/reference/android/app/Service#onTaskRemoved(android.content.Intent) and https://developer.android.com/media/media3/exoplayer . Task-removal and device-specific memory reclamation still require real-device validation.

## v2.2.1 icon artwork

User-provided furry Google Drive, Discord, Pinterest, Telegram and Snapchat references were adapted into an equally spaced transparent sprite with the image-generation tool. The reference screenshot text/labels were excluded. No runtime asset generation or extra network fetch is used; the sprite is bundled locally. UI recognition only, with no new extractor/authentication claims.

## v2.2.2 Snapchat investigation — 2026-11-16

- User-reported https://www.snapchat.com/t/m8zQHs6q resolved to a public /@username/snapId Story page. Public __NEXT_DATA__ contained a seven-entry story.snapList and unrelated Spotlight recommendations. The requested snap's media URL ends with opaque .IRZXSOY, while its HTTP body has an MP4 ftyp isom signature and Content-Type video/mp4.
- Official upstream Snapchat extractor consulted: https://github.com/yt-dlp/yt-dlp/blob/master/yt_dlp/extractor/snapchat.py . It currently matches /spotlight/<id>, not the shared profile Story path. The dedicated bridge resolver selects exact requested Story metadata instead of the generic extractor's page recommendations.
- yt-dlp --load-info-json uses a temporary app-generated info file after origin/signature checks; no allow-unsafe-ext compatibility flag or global extension-guard disabling is used. Non-Snapchat requests retain the existing extractor behavior.
- Production Kotlin parser output was exported from the saved live public page and loaded into host yt-dlp 2026.10.26 using the actual production selector. Full requested clip downloaded, exact ID matched, ffprobe confirmed 62.415011s H.264 480x852 + AAC, 6,570,639 bytes. _UnsafeExtensionError remained enabled and still rejected raw IRZXSOY. Test media/signed CDN URLs and live page snapshots are not included in the project ZIP.
- No physical Android device download/playback verification has been performed. Source availability and Snapchat page schema can change; private/expired or non-video Stories fail with an explanatory message.

## v2.3 references / validation

- https://developer.android.com/training/data-storage/shared/media#remove-item — direct app-owned MediaStore deletion and user-consent recovery via RecoverableSecurityException (API29) / createDeleteRequest (API30+).
- https://github.com/yt-dlp/yt-dlp/blob/master/README.md — --load-info-json and format selection. Actual playback snapshot is created only from native extractor results; no JavaScript URLs or output paths are trusted.
- Host yt-dlp 2026.10.26 downloaded the public playback clip from the native capture output even with an unavailable webpage URL: 6,570,639 bytes; ffprobe 62.415011s video+audio. Live URLs/media are not bundled.
- Native tests cover selected-format snapshots, unsafe fields discarded, restricted source/DRM denial, stream-token bridge, actual legacy byte deletion, path/collection denial, modern provider failure retention and exact-target deletion. DOM tests cover consent/error/retry/removal and player download/progress/cancel/audio-only state. Physical Android scoped-storage permission dialogs and real player-to-download flow remain unverified.


## Security implementation references (2.4)
- Android Keystore: https://developer.android.com/privacy-and-security/keystore
- Cryptography recommendations: https://developer.android.com/privacy-and-security/cryptography
- Android signing: https://developer.android.com/studio/publish/app-signing
- R8: https://developer.android.com/topic/performance/app-optimization/enable-app-optimization
- Backup/device-transfer rules: https://developer.android.com/identity/data/autobackup
- Official yt-dlp releases/checksums: https://github.com/yt-dlp/yt-dlp/releases
- GitHub Actions hardening: https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions
- Repository visibility: https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/managing-repository-settings/setting-repository-visibility


## Snapchat public metadata regression (2.4.1)
- Snapchat's current public Spotlight HTML exposes schema.org VideoObject JSON-LD with an exact page URL, contentUrl, thumbnail, duration and family-friendly metadata.
- Schema: https://schema.org/VideoObject
- Upstream extractor being replaced for these pages: https://github.com/yt-dlp/yt-dlp/blob/master/yt_dlp/extractor/snapchat.py
- The three user-reported pages were fetched and tested locally. Raw HTML, public comments, signed CDN URLs and media are deliberately excluded from the source ZIP. Synthetic regression cases are included; optional local fixture input is VIDORA_SPOTLIGHT_FIXTURES.


## Playback/session maintenance (2.5)
- Media3 audio attributes: https://developer.android.com/reference/androidx/media3/common/AudioAttributes
- Track selection: https://developer.android.com/media/media3/exoplayer/track-selection
- Decoder fallback: https://developer.android.com/reference/androidx/media3/exoplayer/DefaultRenderersFactory
- Notification cancellation: https://developer.android.com/develop/ui/views/notifications/build-notification
- yt-dlp pre-processors run before final format selection; the trusted bundled policy prefers source-declared clean renditions without pixel edits. Unknown metadata is not a watermark-free guarantee.


## Snapchat original rendition verification (2.5.1)
The known public .1034.IRZXSOY rendition was tested for the same sc-cdn.net object exposed as .27.IRZXSOY in all three supplied public Spotlight pages. No object identifiers were scanned and no credentials, login, cookie or DRM bypass was used. Both streams are fetched through existing HTTPS/CDN guards. Bounded ISO BMFF movie headers (moov/mvhd/trak/tkhd/mdia/hdlr) validate duration, aspect and audio before selection. Unsupported/unavailable/mismatching variants retain the validated sharing source. Native tests use synthetic headers plus optional local fixtures. Frames/downloads/audio were independently checked on the host; this is not a guarantee for every Snapchat object or creator-burned overlay.


## Video covers/loading (2.6)
- Android MediaMetadataRetriever: https://developer.android.com/reference/android/media/MediaMetadataRetriever
- Media3 Player.Listener first-frame/buffering events: https://developer.android.com/reference/androidx/media3/common/Player.Listener
- WebViewClient.shouldInterceptRequest executes off the UI thread: https://developer.android.com/reference/android/webkit/WebViewClient
- Covers are generated locally from authoritative published download records, JPEG metadata is stripped by re-encoding, and cache is private/rebuildable. Existing public Downloads are not modified.

## Startup animation (2.7)

`app/src/main/assets/startup/loading.gif` is the unchanged animation supplied by the app owner in `loading.zip` (580×580, 45 frames, 1.35-second loop). It is bundled offline, included in the release asset integrity manifest, and shown in an isolated, script-free local WebView as of2.7.2; no external animation library or network request is added.
