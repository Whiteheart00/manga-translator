> v2.4: Make the source repository private first (PRIVATE-REPOSITORY.md). Reuse existing signing secrets; do not create a replacement key for an installed app. SECURITY.md and BUILD-VERIFICATION.txt describe the new checks and actual validation.

# ڤیدۆرا v1.7 — نوێکردنەوە بەبێ سڕینەوەی ئەپ

## هۆکاری کێشەی وەشانی پێشوو

GitHub Actions پێشتر `assembleDebug` بەکاردەهێنا. لە GitHub-hosted runner ـە نوێیەکاندا debug keystore زۆرجار هەر Run ـێک تازە دروست دەبێت. Android ناتوانێت APK ـی بە واژۆی جیاواز وەک Update دابمەزرێنێت.

## چارەسەری v1.7

- `applicationId = com.kurd.videodownloader` هەر ئەوەی پێشووە؛ **ناگۆڕدرێت**.
- `.github/workflows/build.yml` ئێستا `assembleRelease` ـی واژۆکراو دروست دەکات، نەک Debug.
- یەک کلیلی هەمیشەیی لە GitHub Actions Secrets دەپارێزرێت و بۆ هەموو Build ـەکانی داهاتوو دووبارە بەکاردێت.
- `versionCode` لە GitHub Actions خۆکارانە زیاد دەبێت (`100000 + github.run_number`).
- ڕەنگە شەشگانه، دۆخی Light/Dark، DownloadService، MP4/MP3، yt-dlp و MediaStore وەک v1.6 ماونەتەوە.

## تەنها جارێک: کلیل لە Termux دروست بکە

1. لە Termux: `pkg install openjdk-17 coreutils -y`
2. فایلی `tools/create-signing-key.sh` لە پڕۆژەکە بە Termux جێبەجێ بکە: `bash tools/create-signing-key.sh` (لە فۆڵدەری پڕۆژەدا).
3. وشەی نهێنییەکی بەهێز هەڵبژێرە؛ بۆ هەموو Build ـەکانی داهاتوو پێویستە.
4. لە GitHub Repository ـەکەت بچۆ: **Settings → Secrets and variables → Actions → New repository secret**.
5. ئەم چوار Secret ـە دروست بکە:

| Secret name | Value |
| --- | --- |
| `VIDORA_KEYSTORE_BASE64` | هەموو دەقی base64 ـی دەرچووی سکریپتەکە، بە یەک هێڵ |
| `VIDORA_STORE_PASSWORD` | ئەو وشەی نهێنییەی بۆ keystore دانات |
| `VIDORA_KEY_ALIAS` | `vidora` |
| `VIDORA_KEY_PASSWORD` | هەمان وشەی نهێنی (لەو سکریپتەدا PKCS12 بەکارهاتووە) |

**زۆر گرنگ:** `~/vidora-signing/vidora-release.jks` بە شێوەیەکی پارێزراو هەڵبگرە و backup بکە. کلیلەکە، وشەی نهێنی و دەقی base64 هەرگیز لە Repository ـی گشتی، issue، screenshot، chat، یان ZIP ـەکە دانەنێ. ئەگەر کلیلەکە ون بکەیت، نوێکردنەوەی ئەپە دامەزراوەکان بە هەمان واژۆ ئەستەم دەبێت.

## هەر جارێک APK ـی نوێ دروست دەکەیت

1. ZIP ـی کۆن لە GitHub بسڕەوە؛ **تەنها یەک ZIP** لە root ـی Repository بمێنێتەوە، یان فایلەکانی پڕۆژە لە root ـدا بن.
2. فایلی `.github/workflows/build.yml` ـی نوێ **بە جیا** لە GitHub ـدا لە هەمان شوێن دابنێ/جێگرەوە. GitHub workflow لەناو ZIP ناناسێت.
3. `Vidora-v1.7.zip` upload بکە.
4. GitHub → **Actions → Build Android APK (Stable Signing) → Run workflow**.
5. Artifact ـی `Vidora-Update-APK` دابگرە و `Vidora-Update.apk` لەسەر مۆبایل بکەرەوە بۆ Update.
6. لە Build ـی داهاتوو هەمان Secrets و همان applicationId بەکاربهێنە.

## یەکەم جار ـی گواستنەوە لە Debug بۆ Release

ئەگەر APK ـی v1.6 وەک Debug بە کلیلی کۆنی GitHub واژۆ کراوە، ئەم signing key ـەی نوێ جیاوازە. **ناتوانرێت بەڵێن بدرێت کە v1.7 لەسەر ئەو وەشانە دامەزرێت.** Android ئاساییشی خۆی پارێزێت. ئەگەر کلیلە ڕەسەنەکە بەردەست بێت، دەتوانرێت هەمان بۆ v1.7 بەکاربهێنرێت؛ ئەگەر نەبوو، یەکەم گواستنەوە ڕەنگە پێویستی بە uninstall هەبێت. ئەو uninstall ـە ڕێکخستنە ناوخۆییەکان دەسڕێتەوە، بەڵام فایلەکانی `Downloads/VideoDownloader` بە شێوەی ئاسایی دەمێننەوە. **دوای ئەو گواستنەوەیە**، هەمان keystore بۆ هەموو وەشانەکانی داهاتوو بهێڵەوە و نوێکردنەوە بەبێ سڕینەوە دەکرێت.

## تاقیکردنەوە

پڕۆژەکە و فایلەکانی build/Gradle بە پشکنینی ئاستی فایل و syntax تاقی دەکرێنەوە. تا `assembleRelease` لە GitHub سەرکەوتوو نەبێت، APK ـی واژۆکراوی تاقیکراو نییە. هیچ کلیلێکی تایبەتی لەم ZIP ـەدا نییە.

## References

- https://developer.android.com/google/play/app-updates
- https://developer.android.com/studio/publish/app-signing
- https://developer.android.com/build/building-cmdline
