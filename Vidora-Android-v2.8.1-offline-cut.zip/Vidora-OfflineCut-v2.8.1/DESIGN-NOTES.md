# Vidora 2.2 architecture

Home/history/settings retain the approved offline hybrid glass UI. The player uses the user's supplied HTML controls with a native Media3 decoder beneath a transparent WebView stage. Native/HTML state is synchronized through a restricted bridge. Headers remain native; network/file/content loads and navigation in the player WebView are blocked.

Brand text uses U+06A4 and a dedicated OFL-licensed Noto Naskh Arabic font; the previous heavy display font made the initial shape hard to distinguish. Launcher aliases only migrate existing installs onto one fixed icon. Theme selection never switches launcher components.

Player lifetime is scoped to its activity. Home/background/Back pauses and releases the decoder, polling and I/O workers; JS timers/visuals are suspended. Download preparation/download/publication may continue in the foreground download service while UI is hidden. Non-download jobs are cancelled when no UI is visible. Task removal cancels the download service and suppresses its final/progress notifications.

Media is published through MediaStore or the scoped legacy Downloads/FileProvider path. History is app-owned published metadata; removal hides a record without deleting its file. Local player imports use only explicit Android picker grants; they do not add invented history entries. Signing/application ID remain unchanged.

Safety is enforced before preview and download in native code as well as in visible UI. A single project ZIP has priority over stale root source in the GitHub workflow. No site publishing, third-party downloader API, credentials/cookies/DRM bypass, or process-caching claims were introduced.
