# 2.8.1 — 2026-11-17

- Player Cut sheet for downloaded audio/video records with dual handles, HH:MM:SS fields, current-position markers, real progress and cancellation.
- Read only the authoritative owned local source, copy to private staging, revalidate duration, and re-encode/publish a NEW file and history entry. Original bytes/history/bookmark remain intact. No network download is needed.
- MediaStore uses a new row; legacy publication now atomically claims a new filename so existing files cannot be truncated on collisions.
- Cut uses the existing media-processing foreground service and cancels when all app screens are hidden or the task is removed. Source deletion is blocked while cut/convert is active. Existing Home segment download and all prior features retained.

# 2.8 — 2026-11-17

- Home whole/segment selector with LTR dual handles, HH:MM:SS fields, actual duration and first/last/middle ten-minute presets. Native source changes reset old selections; live/unknown duration cannot be clipped.
- Segment times use trusted native metadata/token/source binding and are revalidated by the service. Integer millisecond bounds and minimum1second duration enforced.
- Download through the existing secure path, then local FFmpeg accurate re-encode to MP4/MP3. Only completed clip is published; originals stay in private staging and are cleaned up. Existing cancel/task removal kills clipping too. Clips can use full-source bandwidth; this limitation is shown in the selector.
- Network/cut progress derives from actual callbacks across two stages; selected times recorded in history and filename. Existing player/fullscreen/repeat/startup/Snapchat/security retained.

# 2.7.3 — 2026-11-17

- Expose video repeat in the quick-actions row, including landscape: off -> same file(1) -> all -> off, synchronised with music repeat and saved in player settings.
- Add a topbar fullscreen enter/exit control, synced to native fullscreen state rather than the browser Fullscreen API. Exit restores portrait when fullscreen was entered from portrait; back arrow exits fullscreen before closing the player.
- Periodic native snapshots do not override deliberate control hiding. Sleep timer priority retained; whole-file repeat and A-B segment selection are mutually exclusive.

# 2.7.2 — 2026-11-17

- Replace the plain native GIF with the supplied HTML loading design: cover GIF/zoom, dark gradients, frosted panel, cyan ring, pulsing Kurdish title, moving indeterminate strip and hint.
- Serve only the two protected local startup assets in a script-free isolated WebView. Unload its document in background and destroy it on reveal/error. No global WebView timer pause or fake progress.
- Keep the existing main snapshot/visual readiness, real failure actions, and all Snapchat2.7.1/player fixes. Reduced-motion mode also disables the animated GIF background; short landscape screens keep the panel centred.

# 2.7.1 — 2026-11-16

- Snapchat original-rendition selection accepts one-letter CDN storage shards instead of only d/z. Reported links use y and i and previously fell back to marked sharing renditions.
- Exact same CDN object and known .1034 rendition only; HTTPS/host, MP4, duration, audio, aspect and fallback checks retained.
- Two actual reported clips verified against their public original renditions; creator captions/overlays remain intact. All2.7 startup/player features preserved.

# 2.7 — 2026-11-16

- Supplied GIF shown in a native startup cover until settings, the real initial snapshot and WebView visual readiness; no fixed animation delay. Pauses in background and releases after reveal/destroy.
- Startup deadline or main-document failure shows native retry/close controls. Security admission failure remains visible and blocks app initialization.
- Player controls remain visible until a deliberate centre tap. Seek, playback and sheet interaction never schedule auto-hide; music controls stay visible.
- All 2.6 preview/download loading, covers and earlier security/source/playback behavior retained.

# 2.6 — Actual file previews and loading states

- Backfill private, bounded real video-frame covers for existing/new downloaded records. Local MediaStore/FileProvider records only; no remote thumbnail fetch while browsing history.
- Use covers in the file list/details and completed-download Home card, with loading/failure fallbacks and deletion cleanup.
- Player glass loading overlay follows native buffering/readiness/first rendered video frame and clears on errors.
- Native preparation phase drives indeterminate Home/player download spinners before real byte progress; actual SDK percentages restore the normal counter/bar. No simulated progress.
- Reduced-motion and background animation pause support; all 2.5.1 behavior and security retained.

# 2.5.1 — Public Snapchat original rendition

- Prefer the known public original rendition of the same Snapchat CDN object over its sharing rendition, with bounded MP4 movie metadata validation before changing sources.
- Require matching duration/aspect and retain audio; reject invalid/unavailable candidates and preserve validated sharing fallback. HTTPS/CDN, exact Spotlight identity, gating, cancellation and extension safety remain.
- Use actual original width/height/duration and surface original-rendition provenance in preview. No cropping, blurring or invented pixels.
- Verified all three reported clips: platform sharing logo absent in inspected original frames; H.264/AAC and matching durations. Creator-authored overlays can remain; original resolution can differ.
- Retain all 2.5 session, audio, caption, theme and security fixes.

# 2.5 — Playback and session behavior

- Idle Home re-entry clears terminal job state, stale preview/input/toast and completion notification without deleting media/history or stopping active downloads.
- Explicit media/movie audio, media volume keys, decoder fallback, selected audio in both video/music modes and volume restoration across decoder recreation. Fresh players recover from persisted zero-volume/mute state; system volume and routes remain user-controlled.
- Captions start off in native selection, JS options and initial HTML; explicit CC/import enables them for the current player.
- Saved Home/player themes bootstrap synchronously before styles/first UI initialization.
- Prefer source-declared clean video renditions across extractors and preserve separate audio; report unknown/only-marked sources honestly. No baked-in logo removal.
- Retain Snapchat Spotlight exact-ID extraction, source safety, encryption, signer/assets checks and the corrected legacy/V2 apksigner output parser.

# 2.4.1 CI audit compatibility correction

- Accept both legacy Signer #1 and newer V2 Signer certificate output from apksigner. Preserve signature verification, single-certificate checks and expected-certificate pin comparison. Four parser regressions and both full audit paths passed.
- No change to Android runtime, version, application ID or permanent signing secrets.

# 2.4.1 — Snapchat Spotlight preview/play/download fix

- Parse public JSON-LD VideoObject metadata on Snapchat's new App Router pages, where __NEXT_DATA__ no longer exists.
- Route direct, creator-prefixed and /t/ Spotlight shares through the same native extraction used by preview and download.
- Match exact Spotlight identity; reject unrelated recommendations, conflicting metadata, adult/gated/image sources and untrusted CDN URLs. Verify MP4 bytes before exporting an explicit extension.
- Retain legacy Spotlight/Story parsers and all 2.4 privacy/signing protections.
- Regression fixtures cover all three reported links; actual host downloads verified H.264/AAC with ffprobe.

# 2.4 — Security and privacy

- Keystore-backed AES-GCM private preferences, safe legacy migration, encrypted preview metadata and structural diagnostics.
- Signed-release certificate and packaged asset checks; R8/resource shrinking; debug-only crypto test override eliminated from release.
- HTTPS source/transport policy, checked redirects, official stable engine update SHA-256 validation and atomic recovery.
- Backup/device-transfer exclusions; internal job staging; no tracking or location/phone/contact permissions added.
- Private-source workflow, pinned Actions, existing permanent signing identity, release APK audit, private-repository instructions.
- Public Downloads, existing media controls, blocklists, foreground playback lifecycle, player downloading and confirmed file deletion preserved.

# v2.3 — Download from playback and delete actual files

- Added a glass in-player download sheet with video/MP3 selection, real progress and cancellation. Audio-only sources default to MP3. Local/saved files are distinguished from online previews.
- Capture only the selected playback formats/headers in a private temporary info file. Download from the player uses that snapshot through --load-info-json instead of repeating page extraction/redirects/updates; source/age/DRM and extension protections remain active. This can recover a download when page extraction failed but the public playback stream is usable.
- Added actual file deletion from history rows and file details, with filename/size confirmation, pending/error/retry states and Android permission recovery where required. Keep hide/undo as a distinct non-destructive action.
- Delete only app-owned history records, concrete MediaStore Downloads items or canonical legacy Downloads files. Keep history on errors, remove bookmarks after confirmed success, and block deletion during conversion. Collection/path escapes are rejected.
- Preserve the 2.2.2 Snapchat fix, source icons, fixed launcher and foreground-only playback/task cleanup.

# v2.2.2 — Snapchat public Story shares

- Fixed shared Snapchat /t links resolving to /@username/snapId. The generic extractor could infer the opaque IRZXSOY CDN suffix as a file extension and/or select unrelated profile recommendations.
- Parse only the exact requested snap from public story.snapList. Reject missing/expired/image/age-gated content; never substitute a profile, first snap or Spotlight recommendation.
- Verify Snapchat CDN HTTPS origin and MP4 ftyp/brand bytes before creating a temporary yt-dlp load-info JSON with ext=mp4. Global unsafe-extension checks remain enabled.
- Use the same resolver for metadata preview and actual MP4/MP3 downloads. Known Spotlight URLs continue through the official extractor, with @user/spotlight aliases normalized.
- Preserve cancellation/connection tracking, temporary file cleanup, domain safety, player/lifecycle behavior and signing identity. Workflow refuses projects missing the Snapchat fix.

# v2.2.1 — Additional source icon artwork

- Added reference-based plush icon artwork for Google Drive, Discord, Pinterest, Telegram and Snapchat, used in link recognition, history origin labels and the About gallery.
- Added UI-only host labels for Drive/Discord/Telegram. No extractor, authentication, redirect policy, background behavior or safety enforcement changed. An icon does not guarantee download support; private/authenticated content remains unsupported.

# v2.2 — Supplied player design, foreground-only playback, task cleanup

- Applied the supplied HTML player design over a native TextureView/ExoPlayer with restricted media-ID bridge and real position/state; removed all embedded demo media/captions.
- Added Android picker integration for local media/subtitle files, native screenshot capture, embedded cue forwarding, and native fit/filter controls behind the reference UI.
- Clarified VEH with a separate Noto Naskh Arabic brand font (U+06A4, OFL license).
- Removed the playback foreground service, background playback, PiP and wake-lock permission. Pause/release player and suspend visuals/timers when leaving the screen.
- Keep only real downloads running while the app is hidden; cancel non-download jobs. Swipe away the task cancels download work and notifications. Preview connections are cancellable and idle workers expire.
- Corrected light-mode system-bar background contrast.

# v2.1 — Fixed brand/icon, full native playback controls, visible safety gate

- Corrected every Kurdish brand spelling to ڤیدۆرا; the launcher uses one fixed icon independent of the in-app palette, with migration of old enabled aliases.
- Replaced activity-owned playback with a MediaSessionService/MediaController architecture for music playback across backgrounding and screen lock, notification controls, queues, resume positions and sleep timer.
- Added native video/music controls described in MEDIA-FEATURES.md, including fullscreen/PiP, embedded audio/subtitle selection, speed, repeat/shuffle, zoom, volume and brightness.
- Added synchronous fail-closed source validation before preview, a visible blocked state, and an independent first-operation gate in DownloadService. Regression tests cover the exact domain/path pattern shown by the user through both the bridge and service, without fetching its content.
- Fixed GitHub workflow project selection: a single new ZIP takes priority over old root files; ambiguous archives or old safety-less source fail. Run native tests before signed release assembly. Expose the actual app version on Home so it cannot be confused with the yt-dlp version.

# v2.0 — Media preview, playback, conversion and safety

- Added a debounced native metadata/thumbnail preview, with stale callback rejection and bounded temporary cache.
- Added an internal Media3 player for extracted streams and app-owned downloaded media, including separate audio/video sources.
- Added cancellable foreground FFmpeg conversions: video to MP3 and audio to a 720×1280 Vidora still-poster MP4. Original files remain intact; output is published to Downloads/history.
- Added bundled adult/gambling domain hashes with parent-domain matching, redirect preflight and age/category metadata checks. Sources, license and reproducible list generator are included. This is a best-effort domain/metadata filter, not complete content classification or an extractor network firewall.
- Suppressed launcher-alias switching when opening internal playback to avoid interfering with the activity transition.
- Retained v1.9.1 callback crash fix, private diagnostics, signing workflow and application ID.

# v1.9.1 — Android title/progress crash fix

- Removed unsupported Java-only inline (?U) from title cleanup; explicit Unicode letter/number classes are retained.
- Precompiled Android-compatible title patterns and added regression cases for Kurdish, Arabic, hashtags and filenames.
- Guarded progress callbacks on yt-dlp's separate reader thread, including diagnostic-reporting failures.
- Enter foreground before status broadcasts/preference writes to reduce startup deadline exposure.
- Protect notification updates from recoverable platform exceptions; report native LinkageError as a task failure.
- Added bounded app-private diagnostics with URL redaction and an explicit copy action in About. Uncaught exceptions are still forwarded to Android's default handler.
- Existing layout, quality-label fix, multisite format policy and release signing setup retained.

# v1.9 — Broader public media support

- Added recognition and native routing for Pinterest/pin.it, Snapchat Spotlight, Reddit, Vimeo, Dailymotion and SoundCloud; arbitrary domains still reach yt-dlp.
- Automatically selects MP3 for SoundCloud, including short links.
- Added a format policy supporting unknown heights, silent video and non-MP4 fallbacks.
- TikTok candidates explicitly marked watermarked/unplayable are excluded in every selector branch. No pixel-level watermark removal or protected-content bypass is attempted.
- Publishes every completed media output of a post instead of discarding all but one file.
- Added extractor retries, clearer format/login messages, platform help and policy tests.
- Retained the quality-label fix, approved UI, signing setup and package ID.

# v1.8 — Approved hybrid Android interface

- Bundled approved HTML screens, day/night themes and furry platform icons.
- Connected native download/cancel/update/clipboard/share actions and real progress.
- Added native file history, open/rename/favorite and reversible history removal.
- Connected Wi-Fi preference, completion notifications and a safe Downloads subfolder.
- Added offline asset loading, navigation restrictions and scoped legacy FileProvider.
- Kept package identity, native yt-dlp/FFmpeg libraries and permanent release signing workflow.
- Added Gradle wrapper and integration checks.

# Native Liquid Glass UI refresh

- Rebuilt the main screen around the supplied screenshot proportions.
- Added beveled translucent glass controls and the transparent liquid sculpture.
- Retained video/audio downloading, quality selection, paste, cancel, engine update, storage, permissions, share intents and launcher palette behavior.
- Added distinct sun/moon controls and native palette selection.
- Replaced gallery references to missing screenshot resources with native swatches.
- Progress remains service-driven, without fake completion values or file sizes.
- Existing release signing configuration and package identity retained.

## Vidora v1.7

- Stable release signing via secure GitHub Actions repository secrets.
- Release APK output, not throwaway debug APK, for long-term install-in-place upgrades.
- Auto-increment Android `versionCode` on every new GitHub workflow run.
- Keep original application ID `com.kurd.videodownloader`.
- Preserve six visual themes and colors, light/dark, download service, yt-dlp functionality from v1.6.
- Add Termux signing setup helper and update migration documentation.

## Notification refresh
- Show a cleaned media filename/title when yt-dlp reports its destination.
- Trim excessive trailing hashtags and long IDs from the notification title.
- Show compact download percentage and an indeterminate bar during preparation.
- Remove the progress bar on completion or failure, and display a concise final status.
- Preserve existing stable release signing workflow, themes, and downloader behavior.
