# Ownership and third-party components

Keep the app owner's private signing key, unpublished app-specific source, artwork rights and distribution settings under the owner's control. This implementation adds no license server, account restriction, DRM, ownership registration or legal guarantee of exclusivity. The repository owner must decide the applicable license for their own original work.

Android, yt-dlp/youtubedl-android, FFmpeg, Media3, AndroidX, Jackson, fonts, icons, blocklists, and all other third-party components retain their respective licenses, notices and trademark rights. APK/source obfuscation and private hosting do not remove attribution or source-distribution obligations that may apply. Do not represent third-party code as exclusively owned by Vidora.
