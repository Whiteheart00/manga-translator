import java.security.KeyStore
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The release signing key is supplied by GitHub Actions secrets.
// Never place the keystore or passwords inside this repository/ZIP.
val vidoraKeystorePath = System.getenv("VIDORA_KEYSTORE_PATH")
val vidoraStorePassword = System.getenv("VIDORA_STORE_PASSWORD")
val vidoraKeyAlias = System.getenv("VIDORA_KEY_ALIAS")
val vidoraKeyPassword = System.getenv("VIDORA_KEY_PASSWORD")
val stableSigningConfigured = listOf(
    vidoraKeystorePath, vidoraStorePassword, vidoraKeyAlias, vidoraKeyPassword
).all { !it.isNullOrBlank() }

fun digest(bytes:ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it.toInt() and 255)}
val certificatePin = if(stableSigningConfigured){
    val keyFile=file(vidoraKeystorePath!!)
    val store=KeyStore.getInstance(if(keyFile.extension.equals("p12",true))"PKCS12" else "JKS")
    keyFile.inputStream().use{store.load(it,vidoraStorePassword!!.toCharArray())}
    digest(store.getCertificate(vidoraKeyAlias!!).encoded)
}else ""
val protectedAssets=fileTree("src/main/assets"){
    // Python host tests must never add bytecode to the Android integrity manifest.
    exclude("**/__pycache__/**","**/*.pyc","**/.*","**/.*/**")
}.files.sortedBy{it.relativeTo(file("src/main/assets")).invariantSeparatorsPath}
val assetManifest=groovy.json.JsonOutput.toJson(protectedAssets.associate{it.relativeTo(file("src/main/assets")).invariantSeparatorsPath to digest(it.readBytes())})
val generatedSecurityAssets=layout.buildDirectory.dir("generated/securityAssets")
val generateIntegrityAssets=tasks.register("generateIntegrityAssets"){
    inputs.files(protectedAssets);outputs.dir(generatedSecurityAssets)
    doLast{val out=generatedSecurityAssets.get().file("security/asset-hashes.json").asFile;out.parentFile.mkdirs();out.writeText(assetManifest)}
}
tasks.matching{it.name=="preBuild"}.configureEach{dependsOn(generateIntegrityAssets)}
gradle.taskGraph.whenReady{
    if(allTasks.any{it.project==project && (it.name=="validateSigningRelease"||it.name=="packageRelease")}&&!stableSigningConfigured)
        throw GradleException("Release requires the permanent signing secrets. Debug signing is never a release fallback.")
}

android {
    buildFeatures { buildConfig = true }
    sourceSets.getByName("main").assets.srcDir(generatedSecurityAssets)
    namespace = "com.kurd.videodownloader"
    compileSdk = 35

    defaultConfig {
        // Never change the applicationId of an installed app when publishing updates.
        applicationId = "com.kurd.videodownloader"
        buildConfigField("String","TRUSTED_CERT_SHA256","\"$certificatePin\"")
        buildConfigField("String","ASSET_MANIFEST_SHA256","\"${digest(assetManifest.toByteArray(Charsets.UTF_8))}\"")
        minSdk = 24
        targetSdk = 35
        // Locally defaults to 8, above v1.6 (=7). In GitHub Actions, the workflow
        // supplies a monotonically increasing number for each new run.
        versionCode = System.getenv("VIDORA_VERSION_CODE")?.toIntOrNull() ?: 28
        versionName = System.getenv("VIDORA_VERSION_NAME") ?: "2.8.1"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    signingConfigs {
        if (stableSigningConfigured) {
            create("vidoraStable") {
                storeFile = file(vidoraKeystorePath!!)
                storePassword = vidoraStorePassword
                keyAlias = vidoraKeyAlias
                keyPassword = vidoraKeyPassword
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro")
            // CI fails if signing secrets are absent; it does NOT fall back
            // to a freshly generated debug keystore.
            if (stableSigningConfigured) {
                signingConfig = signingConfigs.getByName("vidoraStable")
            }
        }
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.webkit:webkit:1.12.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("com.google.android.material:material:1.12.0")
    val downloaderVersion = "0.18.1"
    implementation("io.github.junkfood02.youtubedl-android:library:$downloaderVersion")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$downloaderVersion")
}
