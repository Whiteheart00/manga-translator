package com.kurd.videodownloader

import android.content.Context
import android.net.Uri
import android.os.Looper
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class MediaFeaturesTest {
    private val c:Context get()=RuntimeEnvironment.getApplication()
    @Before fun clear(){CryptoTest.setup();DownloadState.running=false;DownloadState.action="idle";c.securePreferences("vidora_file_history",0).edit().clear().commit();shadowOf(RuntimeEnvironment.getApplication()).grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)}
    private fun blocked(block:()->Unit){try{block();fail("Expected safety rejection")}catch(_:SafetyException){}}
    @Test fun blocklistsCoverRootsSubdomainsCaseAndTrailingDots(){
        for(domain in listOf("pornhub.com","bet365.com","hentaicity.com"))for(host in listOf(domain,"www.$domain","deep.media.$domain",domain.uppercase()+"."))blocked{SourceSafety.check(c,"https://$host/watch")}
        for(url in listOf("https://youtube.com/watch?v=123","https://pin.it/abc","https://bet365.com.example.org/video","https://vimeo.com/123"))SourceSafety.check(c,url)
    }
    @Test fun malformedCredentialsAndIpUrlsCannotSkipDomainChecking(){
        for(url in listOf("file:///sdcard/movie.mp4","https://pornhub.com@youtube.com/watch","https://127.0.0.1/video","https://[::1]/","https://2130706433/","https://localhost/video"))blocked{SourceSafety.check(c,url)}
    }
    @Test fun metadataRejectsAgeRestrictedAndCategorizedMedia(){
        blocked{SourceSafety.metadata(c,JSONObject("{\"age_limit\":18}"))}
        blocked{SourceSafety.metadata(c,JSONObject("{\"categories\":[\"Casino\"]}"))}
        blocked{SourceSafety.metadata(c,JSONObject("{\"webpage_url\":\"https://bet365.com/video\"}"))}
        SourceSafety.metadata(c,JSONObject("{\"age_limit\":0,\"categories\":[\"Music\"],\"webpage_url\":\"https://youtube.com/watch?v=x\"}"))
        SourceSafety.metadata(c,JSONObject("{}"))
    }
    @Test fun openingAHistoryRecordUsesTheInternalPlayer(){
        val row=NativeHistory.add(c,PublishedMedia("movie.mp4",Uri.parse("content://media/external/downloads/5"),"video/mp4",1024),"https://youtu.be/example","720p")
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup();val activity=controller.get()
        activity.NativeApi().openFile(row.getString("id"));shadowOf(Looper.getMainLooper()).idle()
        val intent=shadowOf(activity).nextStartedActivity
        assertEquals(PlayerActivity::class.java.name,intent.component!!.className);assertEquals(row.getString("id"),intent.getStringExtra("recordId"))
        controller.pause().stop().destroy()
    }
    @Test fun conversionBridgeChecksDirectionAndStartsTheService(){
        val row=NativeHistory.add(c,PublishedMedia("song.mp3",Uri.parse("content://media/external/downloads/6"),"audio/mpeg",1024),"https://soundcloud.com/artist/song","320k")
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup();val api=controller.get().NativeApi()
        api.requestConversion(row.getString("id"),"MP3");shadowOf(Looper.getMainLooper()).idle();assertFalse(DownloadState.running)
        api.requestConversion(row.getString("id"),"MP4");shadowOf(Looper.getMainLooper()).idle();assertTrue(DownloadState.running)
        val intent=shadowOf(RuntimeEnvironment.getApplication()).nextStartedService
        assertEquals(DownloadService.ACTION_CONVERT,intent.action);assertEquals("MP4",intent.getStringExtra(DownloadService.EXTRA_TARGET));assertEquals(row.getString("id"),intent.getStringExtra(DownloadService.EXTRA_FILE_ID))
        DownloadState.running=false;controller.pause().stop().destroy()
    }
    @Test fun screenshotDomainIsRejectedByBothValidationAndDownloadBridge(){
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup();val api=controller.get().NativeApi()
        val url="https://www.hentaicity.com/click/1-1/video/example"
        val result=JSONObject(api.validateSource(url));assertFalse(result.getBoolean("allowed"));assertTrue(result.getString("message").contains("18+"))
        assertTrue(JSONObject(api.validateSource("https://youtu.be/example")).getBoolean("allowed"))
        api.requestDownload(JSONObject().put("url",url).put("format","MP4").toString());shadowOf(Looper.getMainLooper()).idle()
        assertFalse(DownloadState.running);assertNull(shadowOf(RuntimeEnvironment.getApplication()).nextStartedService)
        // The service's direct entry must also reject before checking the network or starting yt-dlp.
        val service=Robolectric.buildService(DownloadService::class.java).create()
        val download=DownloadService::class.java.getDeclaredMethod("doDownload",String::class.java,Boolean::class.javaPrimitiveType,Int::class.javaPrimitiveType).apply{isAccessible=true}
        try{download.invoke(service.get(),url,false,1080);fail("Known blocked domain reached downloader")}catch(error:java.lang.reflect.InvocationTargetException){assertTrue(error.cause is SafetyException)}
        service.destroy();controller.pause().stop().destroy()
    }
    @Test fun blockedDownloadNeverStartsAService(){
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup()
        controller.get().NativeApi().requestDownload("{\"url\":\"https://bet365.com/video\",\"format\":\"MP4\"}")
        shadowOf(Looper.getMainLooper()).idle();assertFalse(DownloadState.running)
        controller.pause().stop().destroy()
    }
    @Test fun ffmpegArgumentsKeepPathsAsLiteralArgumentsAndUseAStillPoster(){
        val path="/private/name with spaces $(anything).mp4"
        val audio=LocalConversion.arguments(path,"/private/out.mp3",null)
        assertEquals(path,audio[audio.indexOf("-i")+1]);assertTrue(audio.contains("-vn"));assertTrue(audio.contains("libmp3lame"));assertFalse(audio.contains("-loop"))
        val video=LocalConversion.arguments("/private/in.mp3","/private/out.mp4","/private/poster.jpg")
        assertTrue(video.contains("-shortest"));assertTrue(video.contains("libx264"));assertTrue(video.contains("yuv420p"));assertEquals(2,video.count{it=="-i"})
        val arguments=JSONObject().put("audio",org.json.JSONArray(LocalConversion.arguments("INPUT","OUTPUT",null)))
            .put("video",org.json.JSONArray(LocalConversion.arguments("INPUT","OUTPUT","POSTER")))
        java.io.File("build/tested-conversion-arguments.json").apply{parentFile.mkdirs();writeText(arguments.toString())}
    }
}
