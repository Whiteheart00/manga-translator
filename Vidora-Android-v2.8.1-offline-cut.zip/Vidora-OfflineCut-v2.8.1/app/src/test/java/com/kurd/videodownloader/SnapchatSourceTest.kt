package com.kurd.videodownloader

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class SnapchatSourceTest {
    @org.junit.Before fun cryptoSetup(){CryptoTest.setup()}

    private val id="requested_snap_123"
    private val url="https://www.snapchat.com/@person/$id"
    private fun snap(key:String,type:Int=1,media:String="https://cf-st.sc-cdn.net/d/opaque.1034.IRZXSOY?mo=sample")=JSONObject().put("snapId",JSONObject().put("value",key)).put("snapMediaType",type)
        .put("snapUrls",JSONObject().put("mediaUrl",media).put("mediaPreviewUrl",JSONObject().put("value","https://cf-st.sc-cdn.net/d/thumb.256.IRZXSOY")))
    private fun root()=JSONObject().put("query",JSONObject().put("snapId",id)).put("props",JSONObject().put("pageProps",JSONObject()
        .put("story",JSONObject().put("snapList",JSONArray().put(snap("unrelated_first_123")).put(snap(id))))
        .put("spotlightHighlights",JSONArray().put(JSONObject().put("story",JSONObject().put("snapList",JSONArray().put(snap("recommendation_123"))))))))
    private fun html(json:JSONObject)="<script nonce='example' id='__NEXT_DATA__' type='application/json'>${json}</script>"
    private fun props(root:JSONObject)=root.getJSONObject("props").getJSONObject("pageProps")
    private fun rejected(action:()->Unit){try{action();fail("Source should be rejected")}catch(_:IOException){}}
    @Test fun selectsExactRequestedStoryInsteadOfFirstSnapOrRecommendations(){
        val info=SnapchatSource.parse(html(root()),url)
        assertEquals(id,info.getString("id"));assertEquals("mp4",info.getString("ext"));assertTrue(info.getString("url").contains("IRZXSOY"))
        assertEquals(url,info.getString("webpage_url"));assertFalse(info.has("entries"))
        File("build/tested-snapchat-story.info.json").apply{parentFile.mkdirs();writeText(info.toString())}
    }
    @Test fun refusesMissingExpiredImageAndGatedContent(){
        val missing=root();props(missing).getJSONObject("story").put("snapList",JSONArray().put(snap("another_snap_123")))
        rejected{SnapchatSource.parse(html(missing),url)}
        val expired=root();props(expired).put("showSnapExpiredToast",true);rejected{SnapchatSource.parse(html(expired),url)}
        val image=root();props(image).getJSONObject("story").put("snapList",JSONArray().put(snap(id,0)));rejected{SnapchatSource.parse(html(image),url)}
        val gated=root();props(gated).put("userProfile",JSONObject().put("publicProfileInfo",JSONObject().put("audienceGateSettings",JSONObject().put("minAge",18))))
        rejected{SnapchatSource.parse(html(gated),url)}
    }
    @Test fun refusesUntrustedCdnAndMismatchedIds(){
        val altered=root();props(altered).getJSONObject("story").put("snapList",JSONArray().put(snap(id,1,"https://sc-cdn.net.attacker.example/movie.mp4")))
        rejected{SnapchatSource.parse(html(altered),url)}
        rejected{SnapchatSource.parse(html(root()),"https://www.snapchat.com/@person/different_snap_123")}
        val profile=root().put("query",JSONObject());rejected{SnapchatSource.parse(html(profile),"https://www.snapchat.com/@person")}
    }
    @Test fun mp4SignatureIsRequiredAndImagesAreNotRelabeled(){
        val mp4=byteArrayOf(0,0,0,32)+"ftypisom".toByteArray()+byteArrayOf(0,0,2,0)
        SnapchatSource.requireMp4(mp4)
        rejected{SnapchatSource.requireMp4(byteArrayOf(0xff.toByte(),0xd8.toByte(),0xff.toByte(),0xe0.toByte()))}
        rejected{SnapchatSource.requireMp4(byteArrayOf(0,0,0,24)+"ftypheic".toByteArray()+byteArrayOf(0,0,0,0))}
    }
    @Test fun canonicalizesOnlySnapchatSpotlightPaths(){
        assertEquals("https://www.snapchat.com/spotlight/abcdef123",SnapchatSource.canonical("https://www.snapchat.com/@person/spotlight/abcdef123"))
        assertEquals(url,SnapchatSource.canonical(url))
        val other="https://example.com/@person/spotlight/abcdef123";assertEquals(other,SnapchatSource.canonical(other))
    }
    @Test fun exportedLiveSnapshotWhenProvidedUsesTheProductionParser(){
        val file=System.getenv("VIDORA_SNAPCHAT_HTML_FIXTURE")?.let(::File)?:return
        val text=file.readText();val json=JSONObject(Regex("<script[^>]*id=\"__NEXT_DATA__\"[^>]*>(.*?)</script>",RegexOption.DOT_MATCHES_ALL).find(text)!!.groupValues[1])
        val target=json.getJSONObject("query").getString("snapId")
        val info=SnapchatSource.parse(text,json.getJSONObject("props").getString("currentUrl").substringBefore('?'))
        assertEquals(target,info.getString("id"));File("build/tested-snapchat-live.info.json").writeText(info.toString())
    }
}
