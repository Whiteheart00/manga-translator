package com.kurd.videodownloader

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class PlayerFeaturesTest {
    private val c:Context get()=RuntimeEnvironment.getApplication()
    @Before fun clear(){CryptoTest.setup();for(name in listOf("vidora_file_history","player_positions"))c.securePreferences(name,0).edit().clear().commit();DownloadState.running=false}
    private fun add(name:String,mime:String,url:String="https://youtu.be/example")=NativeHistory.add(c,PublishedMedia(name,Uri.parse("content://media/external/downloads/"+name.hashCode()),mime,1234),url,"Best")
    @Test fun queueKeepsMusicAndVideoSeparateAndSkipsBlockedSources(){
        val song=add("song.mp3","audio/mpeg");val second=add("second.mp3","audio/mpeg");add("video.mp4","video/mp4");add("blocked.mp3","audio/mpeg","https://www.hentaicity.com/click/1-1/video/example")
        val (items,index)=PlaybackQueue.records(c,song.getString("id"));assertEquals(2,items.size);assertEquals("record:"+song.getString("id"),items[index].mediaId)
        assertTrue(items.all{it.mediaMetadata.artist=="ڤیدۆرا"});assertTrue(items.any{it.mediaId=="record:"+second.getString("id")})
        NativeHistory.change(c,second.getString("id")){it.put("hidden",true)};assertEquals(1,PlaybackQueue.records(c,song.getString("id")).first.size)
    }
    @Test fun resumeBookmarksPersistForDownloadedFilesButNotExpiringPreviews(){
        PlaybackQueue.savePosition(c,"record:abc",12345);assertEquals(12345L,PlaybackQueue.position(c,"record:abc"))
        PlaybackQueue.savePosition(c,"preview:abc",999);assertEquals(0L,PlaybackQueue.position(c,"preview:abc"))
        PlaybackQueue.savePosition(c,"record:abc",-5);assertEquals(0L,PlaybackQueue.position(c,"record:abc"))
    }
    @Test fun fixedLauncherMigratesOldAliasesAndPaletteChangesCannotSwitchIt(){
        val pm=c.packageManager
        pm.setComponentEnabledSetting(ComponentName(c,c.packageName+".LauncherPalette4"),PackageManager.COMPONENT_ENABLED_STATE_ENABLED,PackageManager.DONT_KILL_APP)
        val screen=Robolectric.buildActivity(MainActivity::class.java).setup()
        screen.get().NativeApi().configure(JSONObject().put("palette","gold").toString())
        for(i in 0..7)assertEquals(if(i==0)PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,pm.getComponentEnabledSetting(ComponentName(c,c.packageName+".LauncherPalette$i")))
        screen.pause().stop().destroy()
    }
    @Test fun leavingPlayerReleasesDecoderAndCancelsPolling(){
        val screen=Robolectric.buildActivity(PlayerActivity::class.java).setup();val activity=screen.get()
        val field=PlayerActivity::class.java.getDeclaredField("player").apply{isAccessible=true}
        assertNotNull(field.get(activity));screen.pause().stop();assertNull(field.get(activity));screen.destroy()
    }
    @Test fun onlyDownloadWorkMayContinueWhenTheLastScreenStops(){
        val service=Robolectric.buildService(DownloadService::class.java).create()
        val screen=Robolectric.buildActivity(MainActivity::class.java).setup()
        DownloadState.action="download";DownloadState.running=true
        screen.pause().stop();assertFalse(org.robolectric.Shadows.shadowOf(service.get()).isStoppedBySelf)
        screen.restart().start().resume();DownloadState.action="convert";DownloadState.running=true
        screen.pause().stop();assertTrue("Hidden conversion service must stop",org.robolectric.Shadows.shadowOf(service.get()).isStoppedBySelf)
        DownloadState.running=false;screen.destroy();service.destroy()
    }
    @Test fun swipingTaskCancelsTheDownloadAndRemovesForegroundWork(){
        val service=Robolectric.buildService(DownloadService::class.java).create()
        service.get().onTaskRemoved(null)
        val cancelled=DownloadService::class.java.getDeclaredField("cancelled").apply{isAccessible=true}.get(service.get())as java.util.concurrent.atomic.AtomicBoolean
        assertTrue(cancelled.get());assertTrue(org.robolectric.Shadows.shadowOf(service.get()).isStoppedBySelf)
        service.destroy()
    }
}
