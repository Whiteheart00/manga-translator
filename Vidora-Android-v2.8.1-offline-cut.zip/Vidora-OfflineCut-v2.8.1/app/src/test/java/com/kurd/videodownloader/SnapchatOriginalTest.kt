package com.kurd.videodownloader

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.nio.ByteBuffer

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class SnapchatOriginalTest {
    private val media="https://bolt-gcdn.sc-cdn.net/z/asset_123.27.IRZXSOY?mo=sharing&uc=46"
    private fun atom(name:String,data:ByteArray)=ByteBuffer.allocate(8+data.size).putInt(8+data.size).put(name.toByteArray()).put(data).array()
    private fun movie(width:Int=540,height:Int=960,ms:Int=15000,audio:Boolean=true):ByteArray{
        fun track(type:String):ByteArray{
            val tkhd=ByteArray(84);ByteBuffer.wrap(tkhd,76,8).putInt(width shl 16).putInt(height shl 16)
            return atom("trak",atom("tkhd",tkhd)+atom("mdia",atom("hdlr",ByteArray(8)+type.toByteArray())))
        }
        val mvhd=ByteBuffer.allocate(20).putInt(0).putInt(0).putInt(0).putInt(1000).putInt(ms).array()
        return atom("ftyp","isom".toByteArray()+ByteArray(4))+atom("moov",atom("mvhd",mvhd)+track("vide")+(if(audio)track("soun")else ByteArray(0)))
    }
    private fun info()=JSONObject().put("extractor_key","VidoraSnapchatSpotlight").put("id","exact_snap_123").put("url",media).put("width",540).put("height",960).put("webpage_url","https://www.snapchat.com/spotlight/exact_snap_123")
    @Test fun candidatePreservesExactCdnObjectAndUsesOnlyKnownHttpsVariant(){
        assertEquals("https://bolt-gcdn.sc-cdn.net/z/asset_123.1034.IRZXSOY",SnapchatOriginal.candidate(media))
        for(shard in listOf("d","z","y","i"))assertEquals("https://bolt-gcdn.sc-cdn.net/$shard/asset_123.1034.IRZXSOY",SnapchatOriginal.candidate(media.replace("/z/","/$shard/")))
        for(url in listOf("https://cf-st.sc-cdn.net/shard/id.27.IRZXSOY","https://cf-st.sc-cdn.net/y/other/id.27.IRZXSOY","https://cf-st.sc-cdn.net/y/id.28.IRZXSOY","http://cf-st.sc-cdn.net/z/id.27.IRZXSOY","https://sc-cdn.net.attacker.example/z/id.27.IRZXSOY","https://user@cf-st.sc-cdn.net/z/id.27.IRZXSOY","https://cf-st.sc-cdn.net/z/id.1034.IRZXSOY","https://cf-st.sc-cdn.net/unrelated.mp4"))assertNull(SnapchatOriginal.candidate(url))
    }
    @Test fun validatesSameDurationAudioAspectAndUpdatesActualRenditionMetadata(){
        val source=info();var calls=0
        val selected=SnapchatOriginal.prefer(source,movie()){url->calls++;assertEquals(SnapchatOriginal.candidate(media),url);movie(480,852)}
        assertEquals(1,calls);assertTrue(selected.getBoolean("vidora_original_rendition"));assertEquals(480,selected.getInt("width"));assertEquals(852,selected.getInt("height"));assertEquals(15.0,selected.getDouble("duration"),.001)
        assertEquals("exact_snap_123",selected.getString("id"));assertEquals(source.getString("webpage_url"),selected.getString("webpage_url"));assertEquals(media,source.getString("url"))
    }
    @Test fun refusesTruncationDifferentClipShapeMissingAudioAndMalformedVideo(){
        val source=info()
        for(header in listOf(movie(ms=35000),movie(audio=false),movie(width=960,height=540),movie().copyOf(35),"not an MP4".toByteArray())){
            assertSame(source,SnapchatOriginal.prefer(source,movie()){header})
        }
        assertNull(SnapchatOriginal.movie(ByteArray(128)))
        assertNull(SnapchatOriginal.movie(movie().also{ByteBuffer.wrap(it,16,4).putInt(Int.MAX_VALUE)}))
    }
    @Test fun unrelatedStoriesOrIncompleteMovieHeadersNeverProbeGuessedSources(){
        val source=info();assertSame(source,SnapchatOriginal.prefer(source.put("extractor_key","VidoraSnapchatStory"),movie()){error("unexpected probe")})
        val spotlight=info();assertSame(spotlight,SnapchatOriginal.prefer(spotlight,movie().copyOf(20)){error("unexpected probe")})
    }
    @Test fun allThreeReportedMoviesUseValidatedProductionOriginalSelectionWhenProvided(){
        val shared=System.getenv("VIDORA_SPOTLIGHT_FIXTURES")?.let(::File)?:return
        val original=System.getenv("VIDORA_ORIGINAL_FIXTURES")?.let(::File)?:return
        for(i in 0..2){
            val page=File(shared,"$i.url").readText();val source=SnapchatSource.parse(File(shared,"$i.html").readText(),page)
            val sharing=File(shared,"download-$i.mp4").inputStream().use{it.readNBytes(SnapchatOriginal.PROBE_BYTES)}
            val candidate=File(original,"$i.mp4").inputStream().use{it.readNBytes(SnapchatOriginal.PROBE_BYTES)}
            val selected=SnapchatOriginal.prefer(source,sharing){url->assertEquals(File(original,"$i.variant-url").readText(),url);candidate}
            assertTrue(selected.optBoolean("vidora_original_rendition"));assertEquals(480,selected.getInt("width"));assertEquals(852,selected.getInt("height"))
            File("build/original-snap-$i.info.json").apply{parentFile.mkdirs();writeText(selected.toString())}
        }
    }
    @Test fun reportedDiscoverLinksUseTheExactValidatedOriginalAcrossStorageShardsWhenProvided(){
        val fixtures=System.getenv("VIDORA_DISCOVER_FIXTURES")?.let(::File)?:return
        for(i in 0..1){
            val source=SnapchatSource.parse(File(fixtures,"$i.html").readText(),File(fixtures,"$i.url").readText())
            val shared=File(fixtures,"$i-shared.mp4").inputStream().use{it.readNBytes(SnapchatOriginal.PROBE_BYTES)}
            val original=File(fixtures,"$i-original.mp4").inputStream().use{it.readNBytes(SnapchatOriginal.PROBE_BYTES)}
            val selected=SnapchatOriginal.prefer(source,shared){url->assertEquals(File(fixtures,"$i.variant-url").readText(),url);original}
            assertTrue(selected.optBoolean("vidora_original_rendition"))
            assertEquals(source.getString("id"),selected.getString("id"))
            assertEquals(source.getString("webpage_url"),selected.getString("webpage_url"))
            // Second clip has tkhd display width 479.4 (coded frame width is 480).
            assertEquals(if(i==0)480 else 479,selected.getInt("width"));assertEquals(if(i==0)852 else 846,selected.getInt("height"))
            assertTrue(SnapchatOriginal.movie(original)!!.audio)
            assertEquals(SnapchatOriginal.movie(shared)!!.duration,selected.getDouble("duration"),.01)
        }
    }
}
