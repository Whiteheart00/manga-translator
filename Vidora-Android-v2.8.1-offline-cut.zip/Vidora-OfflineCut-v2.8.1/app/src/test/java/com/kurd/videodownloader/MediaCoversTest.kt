package com.kurd.videodownloader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowMediaMetadataRetriever

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class MediaCoversTest {
    private val c:Context get()=RuntimeEnvironment.getApplication()
    @Before fun setup(){CryptoTest.setup()}
    private fun record(uri:Uri=Uri.parse("content://media/external/downloads/734"))=NativeHistory.add(c,PublishedMedia("actual.mp4",uri,"video/mp4",123),"https://example.org/video","Best")
    @Test fun existingLocalRecordGeneratesRealJpegThenReusesIt(){
        val uri=Uri.parse("content://media/external/downloads/734");val item=record(uri)
        val frame=Bitmap.createBitmap(640,360,Bitmap.Config.ARGB_8888).apply{eraseColor(Color.RED)}
        ShadowMediaMetadataRetriever.addFrame(c,uri,1_000_000,frame)
        val file=MediaCovers.load(c,item.getString("id"));assertNotNull(file);val bitmap=BitmapFactory.decodeFile(file!!.absolutePath)
        assertNotNull(bitmap);assertTrue(bitmap.width<=384&&bitmap.height<=384);assertTrue(Color.red(bitmap.getPixel(0,0))>200)
        assertEquals(file,MediaCovers.load(c,item.getString("id")));assertEquals(1,NativeHistory.list(c).length())
    }
    @Test fun noRemoteOrCollectionUriCanBeUsedToGenerateACover(){
        for(uri in listOf("https://example.org/private.mp4","content://media/external/downloads","content://media/external/images/42","content://untrusted.provider/video/1")){
            val item=record(Uri.parse(uri));assertNull(MediaCovers.load(c,item.getString("id")))
        }
        assertNull(MediaCovers.load(c,"../../private-file"));assertNull(MediaCovers.load(c,"00000000-0000-0000-0000-000000000000"))
    }
    @Test fun deletingHistoryAlsoDeletesPrivateCoverCache(){
        val uri=Uri.parse("content://media/external/downloads/734");val item=record(uri)
        ShadowMediaMetadataRetriever.addFrame(c,uri,1_000_000,Bitmap.createBitmap(64,64,Bitmap.Config.ARGB_8888))
        val file=MediaCovers.load(c,item.getString("id"))!!;NativeHistory.forget(c,item.getString("id"));assertFalse(file.exists());assertNull(MediaCovers.load(c,item.getString("id")))
    }
}
