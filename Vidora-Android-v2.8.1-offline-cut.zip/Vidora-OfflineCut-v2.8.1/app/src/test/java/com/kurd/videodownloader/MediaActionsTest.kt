package com.kurd.videodownloader

import android.content.Context
import android.net.Uri
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class MediaActionsTest {
    private val c:Context get()=RuntimeEnvironment.getApplication()
    @Before fun clear(){CryptoTest.setup();DownloadState.running=false;c.securePreferences("vidora_file_history",0).edit().clear().commit()}
    private fun info():JSONObject=JSONObject().put("id","video123").put("title","Actual rendition").put("age_limit",0)
        .put("formats",JSONArray().put(JSONObject().put("url","https://cdn.example.org/unselected.mp4")))
        .put("requested_formats",JSONArray()
            .put(JSONObject().put("url","https://cdn.example.org/selected.mp4").put("ext","mp4").put("format_id","video720").put("width",1280).put("height",720).put("vcodec","avc1").put("acodec","none").put("_filename","/outside/evil.mp4"))
            .put(JSONObject().put("url","https://cdn.example.org/audio.m4a").put("ext","m4a").put("format_id","audio").put("vcodec","none").put("acodec","mp4a")))
    @Test fun capturesOnlyPlayingFormatsAndCannotReuseExtractedOutputPaths(){
        val captured=PlaybackDownload.capture(c,info(),"https://example.org/watch")
        val formats=captured.getJSONArray("formats");assertEquals(2,formats.length());assertEquals("video720",formats.getJSONObject(0).getString("format_id"))
        assertFalse(captured.toString().contains("unselected"));assertFalse(captured.toString().contains("_filename"));assertFalse(captured.toString().contains("/outside/"))
        val file=File(c.cacheDir,"preview-action.info.json").apply{SecretFiles.write(this,captured.toString())}
        val media=PreviewMedia("token","https://example.org/watch","Actual rendition",60,emptyList(),null,downloadInfo=file)
        val work=File(c.cacheDir,"playback-action-work").apply{mkdirs()}
        val request=PlaybackDownload.request(c,media,work)
        assertTrue(request.hasOption("--load-info-json"));assertFalse(request.buildCommand().contains(media.source));assertFalse(request.buildCommand().any{it.contains("allow-unsafe-ext")})
        File("build/tested-playback-download.info.json").apply{parentFile.mkdirs();writeText(captured.toString())}
    }
    @Test fun playbackExportKeepsAgeAndDomainAndDrmGates(){
        for(value in listOf(info().put("age_limit",18),info().put("has_drm",true))){try{PlaybackDownload.capture(c,value,"https://example.org/watch");fail("Restricted content exported")}catch(_:java.io.IOException){}}
        try{PlaybackDownload.capture(c,info(),"https://www.hentaicity.com/video");fail("Blocked source exported")}catch(_:SafetyException){}
        try{PlaybackDownload.media(c,"missing-token","https://example.org/watch");fail("Expired token accepted")}catch(_:java.io.IOException){}
    }
    @Test @Config(sdk=[28]) fun deletingPublishedLegacyFileRemovesBytesHistoryAndBookmark(){
        @Suppress("DEPRECATION") val folder=File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VidoraDeletionTest").apply{mkdirs()}
        val file=File(folder,"owned.mp4").apply{writeBytes(byteArrayOf(1,2,3,4))}
        val record=NativeHistory.add(c,PublishedMedia(file.name,Uri.parse("content://${c.packageName}.files/downloads/owned.mp4"),"video/mp4",file.length(),file.path),"https://example.org/watch","720p")
        val id=record.getString("id");PlaybackQueue.savePosition(c,"record:$id",1200)
        NativeFiles.delete(c,id);assertFalse(file.exists());assertNull(NativeHistory.find(c,id));assertEquals(0L,PlaybackQueue.position(c,"record:$id"))
    }
    @Test @Config(sdk=[28]) fun unsafePathAndActiveConversionKeepOriginalFileAndHistory(){
        val file=File(c.filesDir,"must-not-delete.mp4").apply{writeText("original")}
        val record=NativeHistory.add(c,PublishedMedia(file.name,Uri.parse("content://${c.packageName}.files/unsafe"),"video/mp4",file.length(),file.path),"https://example.org/watch","720p")
        val id=record.getString("id")
        try{NativeFiles.delete(c,id);fail("Outside Downloads deleted")}catch(_:IllegalArgumentException){}
        assertTrue(file.exists());assertNotNull(NativeHistory.find(c,id))
        DownloadState.running=true;DownloadState.action="convert"
        try{NativeFiles.delete(c,id);fail("Active conversion source deleted")}catch(_:java.io.IOException){}
        DownloadState.running=false;assertTrue(file.exists());assertNotNull(NativeHistory.find(c,id));file.delete()
    }
    @Test fun collectionUriCannotDeleteMultipleFiles(){
        val record=NativeHistory.add(c,PublishedMedia("bad.mp4",Uri.parse("content://media/external_primary/downloads"),"video/mp4",12),"https://example.org/watch","720p")
        try{NativeFiles.delete(c,record.getString("id"));fail("Collection URI accepted")}catch(_:IllegalArgumentException){}
        assertNotNull(NativeHistory.find(c,record.getString("id")))
    }
    @Test fun playerBridgeStartsDownloadWithTheValidatedPreviewToken(){
        org.robolectric.Shadows.shadowOf(RuntimeEnvironment.getApplication()).grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)
        val source="https://example.org/watch";val token="stream-download-test"
        val file=File(c.cacheDir,"player-bridge.info.json").apply{SecretFiles.write(this,PlaybackDownload.capture(c,info(),source).toString())}
        val media=PreviewMedia(token,source,"Actual rendition",60,emptyList(),null,downloadInfo=file)
        MediaProbe::class.java.getDeclaredMethod("remember",PreviewMedia::class.java).apply{isAccessible=true}.invoke(MediaProbe,media)
        val intent=android.content.Intent(c,PlayerActivity::class.java).putExtra("previewToken",token)
        val screen=org.robolectric.Robolectric.buildActivity(PlayerActivity::class.java,intent).setup()
        screen.get().Controls().download("preview:wrong","MP4");assertFalse(DownloadState.running)
        screen.get().Controls().download("preview:$token","MP4")
        org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        val started=org.robolectric.Shadows.shadowOf(RuntimeEnvironment.getApplication()).nextStartedService
        assertEquals(DownloadService.ACTION_START,started.action);assertEquals(token,started.getStringExtra(DownloadService.EXTRA_PREVIEW_TOKEN));assertEquals(source,started.getStringExtra(DownloadService.EXTRA_URL))
        DownloadState.running=false;screen.pause().stop().destroy()
    }
    @Test fun exportLivePlaybackFixtureWhenProvided(){
        val input=System.getenv("VIDORA_PLAYBACK_INFO_FIXTURE")?.let(::File)?:return
        val capture=PlaybackDownload.capture(c,JSONObject(input.readText()),"https://unavailable.example.org/watch")
        File("build/tested-playback-live.info.json").apply{parentFile.mkdirs();writeText(capture.toString())}
    }

    @Test fun modernDeletionKeepsHistoryOnDenialAndTargetsOnlyTheOwnedItem(){
        val provider=object:android.content.ContentProvider(){
            var denied=true;var removed:android.net.Uri?=null
            override fun onCreate()=true
            override fun getType(uri:android.net.Uri)="video/mp4"
            override fun query(uri:android.net.Uri,projection:Array<out String>?,selection:String?,args:Array<out String>?,order:String?)=android.database.MatrixCursor(arrayOf("_id"))
            override fun insert(uri:android.net.Uri,values:android.content.ContentValues?):android.net.Uri?=null
            override fun update(uri:android.net.Uri,values:android.content.ContentValues?,selection:String?,args:Array<out String>?)=0
            override fun delete(uri:android.net.Uri,selection:String?,args:Array<out String>?):Int{if(denied)throw SecurityException("permission required");removed=uri;return 1}
        }
        provider.attachInfo(c,android.content.pm.ProviderInfo().apply{authority="media"})
        org.robolectric.shadows.ShadowContentResolver.registerProviderInternal("media",provider)
        val uri=Uri.parse("content://media/external_primary/downloads/23")
        val row=NativeHistory.add(c,PublishedMedia("owned.mp4",uri,"video/mp4",123),"https://example.org/watch","720p")
        val other=NativeHistory.add(c,PublishedMedia("keep.mp4",Uri.parse("content://media/external_primary/downloads/24"),"video/mp4",123),"https://example.org/other","720p")
        try{NativeFiles.delete(c,row.getString("id"));fail("Denied deletion succeeded")}catch(_:SecurityException){}
        assertNotNull(NativeHistory.find(c,row.getString("id")))
        provider.denied=false;NativeFiles.delete(c,row.getString("id"));assertEquals(uri,provider.removed)
        assertNull(NativeHistory.find(c,row.getString("id")));assertNotNull(NativeHistory.find(c,other.getString("id")))
    }

}
