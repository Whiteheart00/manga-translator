package com.kurd.videodownloader

import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class DownloadCrashRegressionTest {
    @org.junit.Before fun cryptoSetup(){CryptoTest.setup()}

    @Test fun destinationCallbackUpdatesTheRealServiceTitle(){
        val controller=Robolectric.buildService(DownloadService::class.java).create()
        val service=controller.get()
        val method=DownloadService::class.java.getDeclaredMethod("captureDownloadTitle",String::class.java).apply{isAccessible=true}
        method.invoke(service,"[download] Destination: /data/local/ڤیدیۆی جوان #کوردستان [abc123].mp4")
        assertEquals("ڤیدیۆی جوان",DownloadState.title)
        controller.destroy()
    }
    @Test fun diagnosticsAreBoundedAndDoNotExposeSignedUrls(){
        val context=RuntimeEnvironment.getApplication()
        DownloadDiagnostics.record(context,"test",IllegalStateException("https://media.example/private?token=SECRET"))
        val text=DownloadDiagnostics.report(context)
        assertFalse(text.contains("token=SECRET"))
        assertTrue(text.contains("Android"));assertTrue(text.contains("test"))
    }
}
