package com.kurd.videodownloader

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import android.util.Base64
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class SecurityTest {
    private val c get()=RuntimeEnvironment.getApplication()
    @Before fun setup(){CryptoTest.setup()}
    @Test fun legacyDataMigratesWithTypesAndNoPlaintextCopy(){
        val name="security-migration-test"
        c.getSharedPreferences(name,0).edit().putString("url","https://private.example/user-token-unique").putBoolean("enabled",true).putLong("position",1234567890123).putInt("count",12).putFloat("ratio",.5f).putStringSet("tags",setOf("one","two")).commit()
        val store=c.securePreferences(name)
        assertEquals("https://private.example/user-token-unique",store.getString("url",null));assertTrue(store.getBoolean("enabled",false))
        assertEquals(1234567890123L,store.getLong("position",0));assertEquals(12,store.getInt("count",0));assertEquals(.5f,store.getFloat("ratio",0f));assertEquals(setOf("one","two"),store.getStringSet("tags",null))
        assertTrue(c.getSharedPreferences(name,0).all.isEmpty())
        val raw=c.getSharedPreferences(name+".secure-v1",0).all.toString();assertFalse(raw.contains("private.example"));assertFalse(raw.contains("user-token-unique"))
        store.edit().clear().commit();assertTrue(store.all.isEmpty())
    }
    @Test fun ciphertextAuthenticatesContextAndRejectsTampering(){
        val one=PrivateCipher.seal("sensitive","history/items");val two=PrivateCipher.seal("sensitive","history/items")
        assertNotEquals(one,two);assertEquals("sensitive",PrivateCipher.open(one,"history/items"))
        try{PrivateCipher.open(one,"other/items");fail("AAD substitution accepted")}catch(_:Exception){}
        val data=Base64.decode(one.substringAfter(':'),Base64.NO_WRAP);data[data.lastIndex]=(data.last().toInt()xor 1).toByte()
        try{PrivateCipher.open("vgcm1:"+Base64.encodeToString(data,Base64.NO_WRAP),"history/items");fail("Tampered ciphertext accepted")}catch(_:Exception){}
    }
    @Test fun migratedStoreNeverImportsInjectedPlaintext(){
        val store=c.securePreferences("security-injection");store.edit().putString("value","trusted").commit()
        c.getSharedPreferences("security-injection",0).edit().putString("value","untrusted injected value").commit()
        assertEquals("trusted",c.securePreferences("security-injection").getString("value",null));assertTrue(c.getSharedPreferences("security-injection",0).all.isEmpty())
    }
    @Test fun snapshotAndDiagnosticsContainNoPlainPersonalData(){
        val file=File(c.cacheDir,"encrypted-meta.info.json");SecretFiles.write(file,"https://private.example/?token=secret")
        assertFalse(file.readText().contains("private.example"));assertEquals("https://private.example/?token=secret",SecretFiles.read(file))
        DownloadDiagnostics.record(c,"test",java.io.IOException("IP 192.168.1.11 location 33.123 model PERSONAL_MODEL Cookie secret /data/user/0/private"))
        val report=DownloadDiagnostics.report(c)
        for(secret in listOf("192.168.1.11","33.123","PERSONAL_MODEL","Cookie","/data/user/0"))assertFalse(report.contains(secret))
        assertFalse(File(c.filesDir,"download-diagnostics.txt").readText().contains("IOException"))
    }
    @Test fun certificateAndAssetChecksRejectResigningAndChanges(){
        val original="original-certificate".toByteArray();val pin=SecurityGate.sha(original)
        assertTrue(SecurityGate.trustedSigner(listOf(original),pin));assertFalse(SecurityGate.trustedSigner(listOf("other".toByteArray()),pin));assertFalse(SecurityGate.trustedSigner(listOf(original,original),pin))
        SecurityGate.requireDigest("asset".toByteArray(),SecurityGate.sha("asset".toByteArray()))
        try{SecurityGate.requireDigest("modified".toByteArray(),SecurityGate.sha("asset".toByteArray()));fail("Modified asset accepted")}catch(_:IllegalStateException){}
    }
    @Test fun updatesRequireExactOfficialHttpsHostsAndChecksumEntry(){
        assertTrue(VerifiedEngineUpdater.allowed("https://github.com/yt-dlp/yt-dlp/releases/download/tag/yt-dlp"))
        for(url in listOf("http://github.com/file","https://github.com.attacker.example/file","https://user@github.com/file"))assertFalse(VerifiedEngineUpdater.allowed(url))
        val hash="ab".repeat(32);assertEquals(hash,VerifiedEngineUpdater.checksum("$hash  yt-dlp\n"))
        try{VerifiedEngineUpdater.checksum("$hash  yt-dlp.exe");fail("Wrong update asset accepted")}catch(_:java.io.IOException){}
        try{SourceSafety.check(c,"http://example.org/movie.mp4");fail("Cleartext media accepted")}catch(_:SafetyException){}
    }
    @Test fun engineRecoveryAuthenticatesPendingInstallAndDetectsLaterChanges(){
        val lib=com.yausername.youtubedl_android.YoutubeDL
        val target=File(c.noBackupFilesDir,"${lib.baseName}/${lib.ytdlpDirName}/${lib.ytdlpBin}")
        target.parentFile!!.mkdirs();target.writeText("verified update fixture")
        val digest=SecurityGate.sha(target.readBytes());val prefs=c.securePreferences("engine_updates")
        prefs.edit().clear().putString("pending_digest",digest).putString("pending_version","test-release").commit()
        VerifiedEngineUpdater.ensure(c)
        assertEquals(digest,prefs.getString("verified_digest",null));assertEquals("test-release",prefs.getString("version",null));assertFalse(prefs.contains("pending_digest"))
        target.writeText("modified engine")
        try{VerifiedEngineUpdater.ensure(c);fail("Modified engine accepted")}catch(_:IllegalStateException){}
    }
    @Test fun cancelledUpdatePreservesVerifiedEngineWithoutNetwork(){
        val lib=com.yausername.youtubedl_android.YoutubeDL
        val target=File(c.noBackupFilesDir,"${lib.baseName}/${lib.ytdlpDirName}/${lib.ytdlpBin}")
        target.parentFile!!.mkdirs();target.writeText("original verified engine")
        val prefs=c.securePreferences("engine_updates");prefs.edit().clear().putString("verified_digest",SecurityGate.sha(target.readBytes())).commit()
        try{VerifiedEngineUpdater.update(c,{true},{fail("Cancelled update opened network")});fail("Cancellation ignored")}catch(_:java.io.IOException){}
        assertEquals("original verified engine",target.readText())
    }
    @Test fun admissionClearsLegacyTemporaryMetadataButKeepsSavedFiles(){
        val preview=File(c.cacheDir,"previews/old.info.json");preview.parentFile!!.mkdirs();preview.writeText("old source URL")
        val downloads=c.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)!!
        val job=File(downloads,"job_123_456");job.mkdirs();File(job,"source.info.json").writeText("old staging URL")
        val saved=File(downloads,"saved-user-file.mp4");saved.writeText("saved media")
        PrivateCacheCleanup.run(c)
        assertFalse(preview.exists());assertFalse(job.exists());assertEquals("saved media",saved.readText())
    }
    @Test fun unknownLegacyEngineResetsToBundledWithoutDelayingVerifiedUpdate(){
        val lib=com.yausername.youtubedl_android.YoutubeDL
        val target=File(c.noBackupFilesDir,"${lib.baseName}/${lib.ytdlpDirName}/${lib.ytdlpBin}")
        target.parentFile!!.mkdirs();target.writeText("unverified old cached script")
        val prefs=c.securePreferences("engine_updates");prefs.edit().clear().putLong("last_successful_check",System.currentTimeMillis()).commit()
        VerifiedEngineUpdater.ensure(c)
        val bundled=c.resources.openRawResource(com.yausername.youtubedl_android.R.raw.ytdlp).use{it.readBytes()}
        assertArrayEquals(bundled,target.readBytes());assertEquals(SecurityGate.sha(bundled),prefs.getString("verified_digest",null))
        assertEquals("bundled",prefs.getString("version",null));assertFalse(prefs.contains("last_successful_check"))
    }
}
