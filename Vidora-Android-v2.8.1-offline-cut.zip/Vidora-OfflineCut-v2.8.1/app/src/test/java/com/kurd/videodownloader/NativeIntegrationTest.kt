package com.kurd.videodownloader

import android.Manifest
import android.content.Context
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.JavascriptInterface
import org.robolectric.RuntimeEnvironment
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import android.os.Looper

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class NativeIntegrationTest {
    private val context:Context get()=RuntimeEnvironment.getApplication()
    @Before fun clear(){CryptoTest.setup();
        for(name in listOf("vidora_native_settings","vidora_file_history","native_runtime","vidora_permissions"))context.securePreferences(name,Context.MODE_PRIVATE).edit().clear().commit()
        DownloadState.action="idle";DownloadState.status="idle";DownloadState.running=false;DownloadState.progress=0
        DownloadState.url="";DownloadState.title="";DownloadState.message="ئامادەیە بۆ دابەزاندن"
        shadowOf(RuntimeEnvironment.getApplication()).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
    }
    @Test fun settingsValidateTheDownloadFolderAndKeepPreferences(){
        AppSettings.save(context,JSONObject().put("folder","Downloads/../private").put("wifi",true).put("format","MP3").put("audioQuality","192k"))
        assertEquals("VideoDownloader",AppSettings.folder(context));assertTrue(AppSettings.wifiOnly(context))
        AppSettings.save(context,JSONObject().put("folder","Downloads/MyVideos").put("mode","light"))
        assertEquals("MyVideos",AppSettings.folder(context));assertEquals("MP3",AppSettings.json(context).getString("format"))
        assertEquals("192k",AppSettings.json(context).getString("audioQuality"))
    }
    @Test fun historyUsesPublishedMetadataAndRemovalIsReversible(){
        val media=PublishedMedia("Mountains.mp4",Uri.parse("content://media/external/downloads/42"),"video/mp4",2048)
        val row=NativeHistory.add(context,media,"https://youtu.be/example","1080p");val id=row.getString("id")
        assertEquals(2048,NativeHistory.list(context).getJSONObject(0).getInt("bytes"))
        NativeHistory.change(context,id){it.put("favorite",true);it.put("hidden",true)}
        assertEquals(0,NativeHistory.list(context).length());assertTrue(NativeHistory.find(context,id)!!.getBoolean("favorite"))
        NativeHistory.change(context,id){it.put("hidden",false)};assertEquals(1,NativeHistory.list(context).length())
    }
    @Test fun localWebViewIsIsolatedAndBridgeStartsTheNativeService(){
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup();val activity=controller.get();val web=activity.browser
        assertFalse(web.settings.allowFileAccess);assertFalse(web.settings.allowContentAccess);assertTrue(web.settings.blockNetworkLoads)
        assertTrue(web.settings.javaScriptEnabled)
        val client=web.webViewClient
        assertTrue(client.shouldOverrideUrlLoading(web,Request("https://example.com/")))
        assertTrue(client.shouldOverrideUrlLoading(web,Request("file:///sdcard/test.html")))
        assertFalse(client.shouldOverrideUrlLoading(web,Request("https://appassets.androidplatform.net/assets/ui/index.html")))
        val api=activity.NativeApi();api.requestDownload("{\"url\":\"file:///private\"}");shadowOf(Looper.getMainLooper()).idle()
        assertFalse(DownloadState.running)
        api.requestDownload("{\"url\":\"https://youtu.be/example\",\"format\":\"MP4\",\"quality\":\"720p\"}")
        shadowOf(Looper.getMainLooper()).idle()
        assertTrue(DownloadState.running)
        val started=shadowOf(RuntimeEnvironment.getApplication()).nextStartedService
        assertEquals(DownloadService.ACTION_START,started.action);assertEquals(720,started.getIntExtra(DownloadService.EXTRA_QUALITY,0))
        assertNotNull(MainActivity.NativeApi::class.java.getMethod("requestDownload",String::class.java).getAnnotation(JavascriptInterface::class.java))
        DownloadState.running=false;controller.pause().stop().destroy()
    }
    @Test @Config(sdk=[28]) fun legacyStoragePublishesAReadableContentUriInTheChosenFolder(){
        org.robolectric.shadows.ShadowEnvironment.setExternalStoragePublicDirectory(android.os.Environment.getExternalStorageDirectory().toPath())
        AppSettings.save(context,JSONObject().put("folder","Downloads/NativeUiTest"))
        val source=java.io.File(context.cacheDir,"test-video.mp4").apply{writeBytes(byteArrayOf(1,2,3,4,5))}
        val media=StoragePublisher.publish(context,source,false){false}
        assertEquals("content",media.uri.scheme);assertEquals(5L,media.bytes)
        val published=java.io.File(media.path!!)
        assertEquals("NativeUiTest",published.parentFile!!.name);assertArrayEquals(source.readBytes(),published.readBytes())
        published.delete();source.delete()
    }
    @Test fun failureNeverReportsACompletedDownload(){
        DownloadState.progress=41;DownloadState.status="running"
        val controller=Robolectric.buildService(DownloadService::class.java).create()
        controller.get().onStartCommand(android.content.Intent(context,DownloadService::class.java).apply{action=DownloadService.ACTION_START},0,1)
        assertEquals("error",DownloadState.status);assertEquals(41,DownloadState.progress);assertFalse(DownloadState.running)
        controller.destroy()
    }
    private class Request(private val address:String):WebResourceRequest {
        override fun getUrl()=Uri.parse(address)
        override fun isForMainFrame()=true
        override fun isRedirect()=false
        override fun hasGesture()=true
        override fun getMethod()="GET"
        override fun getRequestHeaders()=emptyMap<String,String>()
    }
}
