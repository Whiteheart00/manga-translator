package com.kurd.videodownloader

import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class LocalCutTest {
    private val c:Context get()=RuntimeEnvironment.getApplication()
    private fun clearProviderCache(){
        (FileProvider::class.java.getDeclaredField("sCache").apply{isAccessible=true}.get(null) as MutableMap<*,*>).clear()
    }
    @After fun cleanup(){clearProviderCache()}
    @Before fun setup(){clearProviderCache();org.robolectric.shadows.ShadowEnvironment.setExternalStoragePublicDirectory(Environment.getExternalStorageDirectory().toPath());CryptoTest.setup();DownloadState.running=false;DownloadState.action="idle";c.securePreferences("vidora_file_history",0).edit().clear().commit();AppSettings.save(c,JSONObject().put("folder","Downloads/LocalCutTests"))}
    private fun original(audio:Boolean=false):Pair<File,JSONObject>{
        @Suppress("DEPRECATION") val root=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val file=File(root,"LocalCutTests/Original.${if(audio)"mp3" else "mp4"}").apply{parentFile!!.mkdirs();writeText("ORIGINAL unchanged media")}
        val uri=FileProvider.getUriForFile(c,c.packageName+".files",file)
        val row=NativeHistory.add(c,PublishedMedia(file.name,uri,if(audio)"audio/mpeg" else "video/mp4",file.length(),file.path),"https://example.org/original","Best")
        org.robolectric.Shadows.shadowOf(c.contentResolver).registerInputStream(uri,ByteArrayInputStream(file.readBytes()))
        return file to row
    }
    private fun rejected(block:()->Unit){try{block();fail("Unsafe cut accepted")}catch(_:IllegalArgumentException){}catch(_:IOException){}}
    @Test fun savingVideoOrAudioCreatesAnotherFileAndRecordWithoutChangingOriginalOrBookmark(){
        for(audio in listOf(false,true)){
            val (file,row)=original(audio);val id=row.getString("id");val before=file.readBytes();PlaybackQueue.savePosition(c,"record:$id",2000)
            val result=LocalCut.run(c,id,1000,4000,{false},{},{},durationOf={input->assertArrayEquals(before,input.readBytes());10000},render={input,clip,isAudio->
                assertEquals(audio,isAudio);assertEquals(1000L,clip.startMs);assertEquals(4000L,clip.endMs);assertNotEquals(file.canonicalPath,input.canonicalPath)
                File(input.parentFile,"New clip.${if(audio)"mp3" else "mp4"}").apply{writeText("SELECTED NEW MEDIA")}
            })
            val saved=LocalCut.remember(c,id,result)
            assertNotEquals(id,saved.getString("id"));assertNotEquals(row.getString("uri"),saved.getString("uri"));assertArrayEquals(before,file.readBytes())
            assertEquals(row.toString(),NativeHistory.find(c,id).toString());assertEquals(2000L,PlaybackQueue.position(c,"record:$id"))
            assertEquals(id,saved.getString("sourceRecordId"));assertEquals(if(audio)"MP3" else "MP4",saved.getString("format"));assertEquals("SELECTED NEW MEDIA",File(result.media.path!!).readText())
        }
    }
    @Test fun cancelledFailedAndOutOfBoundsCutsKeepTheOriginalAndCleanPrivateCopies(){
        for(kind in listOf("cancel","failure","bounds")){
            val (file,row)=original();val before=file.readBytes();val id=row.getString("id")
            rejected{LocalCut.run(c,id,1000,if(kind=="bounds")20000 else 4000,{kind=="cancel"},{},{},durationOf={10000},render={_,_,_->throw IOException("codec failed")})}
            assertArrayEquals(before,file.readBytes());assertNotNull(NativeHistory.find(c,id))
            assertTrue(File(c.cacheDir,"local-cuts").listFiles().orEmpty().isEmpty())
        }
    }
    @Test fun rejectRemoteForeignAndMismatchedLocalRecords(){
        val (file,row)=original()
        for(uri in listOf("https://example.org/video.mp4","content://untrusted.provider/downloads/1","content://${c.packageName}.files/wrong/source.mp4","content://media/external/images/1","content://media/external/downloads/1?query=yes")){
            NativeHistory.change(c,row.getString("id")){it.put("uri",uri)};rejected{LocalCut.source(c,row.getString("id"))}
        }
        val outside=File(c.filesDir,"private.mp4").apply{writeText("private")}
        NativeHistory.change(c,row.getString("id")){it.put("uri","content://${c.packageName}.files/other/private.mp4").put("path",outside.path)}
        rejected{LocalCut.source(c,row.getString("id"))};assertEquals("private",outside.readText());assertTrue(file.exists())
        rejected{LocalCut.source(c,"../../private")}
    }
    @Test fun existingPublicFilenameIsNeverTruncatedByPublishingANewCut(){
        val (original,_)=original();val old=original.readBytes()
        val staged=File(c.cacheDir,original.name).apply{writeText("new clip")}
        val result=StoragePublisher.publish(c,staged,false){false}
        assertNotEquals(original.canonicalPath,File(result.path!!).canonicalPath);assertArrayEquals(old,original.readBytes());assertEquals("new clip",File(result.path).readText())
    }
    @Test fun rejectNonIntegerOrCrossedRangesAndProtectSourceDeletionWhileCutting(){
        for((start,end)in listOf(Double.NaN to 1000.0,0.5 to 2000.0,3000.0 to 2000.0,0.0 to 10001.0))rejected{LocalCut.times(start,end,10000)}
        val (file,row)=original();DownloadState.running=true;DownloadState.action="cut"
        rejected{NativeFiles.delete(c,row.getString("id"))};assertTrue(file.exists());assertNotNull(NativeHistory.find(c,row.getString("id")));DownloadState.running=false
    }
    @Test fun smallDecoderEndpointDifferenceUsesTheActualLocalEnd(){
        val (file,row)=original();val id=row.getString("id")
        val result=LocalCut.run(c,id,9000,10000,{false},{},{},durationOf={9999},render={input,clip,_->
            assertEquals(9999L,clip.endMs);assertEquals(1000L,clip.lengthMs)
            File(input.parentFile,"tail.mp4").apply{writeText("new tail")}
        })
        val saved=LocalCut.remember(c,id,result);assertEquals(9999L,saved.getLong("clipEndMs"));assertEquals("ORIGINAL unchanged media",file.readText())
    }
    @Test @Config(sdk=[34]) fun leavingAllScreensCancelsCutWork(){
        val service=org.robolectric.Robolectric.buildService(DownloadService::class.java).create()
        val screen=org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        DownloadState.action="cut";DownloadState.running=true
        screen.pause().stop()
        assertTrue(org.robolectric.Shadows.shadowOf(service.get()).isStoppedBySelf)
        val cancelled=DownloadService::class.java.getDeclaredField("cancelled").apply{isAccessible=true}.get(service.get()) as java.util.concurrent.atomic.AtomicBoolean
        assertTrue(cancelled.get());DownloadState.running=false;screen.destroy();service.destroy()
    }
}
