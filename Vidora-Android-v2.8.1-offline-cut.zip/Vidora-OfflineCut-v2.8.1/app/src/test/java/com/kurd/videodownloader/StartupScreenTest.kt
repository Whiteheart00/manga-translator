package com.kurd.videodownloader

import android.net.Uri
import android.webkit.WebResourceRequest
import org.robolectric.RuntimeEnvironment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import org.robolectric.annotation.Implements
import org.robolectric.annotation.Implementation
import org.robolectric.shadows.ShadowWebView
import android.widget.Button
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],shadows=[StartupScreenTest.VisualWebView::class])
class StartupScreenTest {
    @Implements(WebView::class)
    class VisualWebView:ShadowWebView(){
        var pendingVisual:WebView.VisualStateCallback?=null
        @Implementation fun postVisualStateCallback(id:Long,callback:WebView.VisualStateCallback){pendingVisual=callback}
    }
    @Before fun setup(){
        CryptoTest.setup();DownloadState.running=false
        // Android grants this merged AndroidX signature permission to its own app;
        // Robolectric's API-28 package manager needs the grant supplied explicitly.
        shadowOf(org.robolectric.RuntimeEnvironment.getApplication()).grantPermissions("com.kurd.videodownloader.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION")
    }
    private fun views(view:View):List<View> = listOf(view)+if(view is ViewGroup)(0 until view.childCount).flatMap{views(view.getChildAt(it))}else emptyList()
    @Test fun coverWaitsForAppliedSnapshotAndVisualReadiness(){
        val screen=Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity=screen.get();val web=activity.browser
        val root=activity.findViewById<View>(android.R.id.content)
        val shadow=shadowOf(web) as VisualWebView
        val loaded="https://appassets.androidplatform.net/assets/ui/index.html"
        web.webViewClient.onPageFinished(web,loaded)
        assertTrue(shadow.lastEvaluatedJavascript.contains("window.vidoraReceive"))
        shadow.lastEvaluatedJavascriptCallback.onReceiveValue("false")
        assertNull(shadow.pendingVisual)
        web.webViewClient.onPageFinished(web,loaded)
        shadow.lastEvaluatedJavascriptCallback.onReceiveValue("true")
        assertNotNull(shadow.pendingVisual)
        assertEquals(1,views(root).filterIsInstance<StartupScreen>().size)
        shadow.pendingVisual!!.onComplete(1)
        assertTrue(views(root).filterIsInstance<StartupScreen>().isEmpty())
        assertEquals(View.IMPORTANT_FOR_ACCESSIBILITY_AUTO,web.importantForAccessibility)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(21))
        assertTrue(views(root).filterIsInstance<StartupScreen>().isEmpty())
        screen.pause().stop().destroy()
    }
    @Test fun startupCoversUnreadyPageAndExposesRealLoadFailure(){
        val screen=Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity=screen.get()
        val root=activity.findViewById<View>(android.R.id.content)
        val cover=views(root).filterIsInstance<StartupScreen>().single()
        assertTrue(cover.isClickable)
        assertTrue(activity.assets.open("startup/loading.gif").use{String(it.readNBytes(6))}.startsWith("GIF"))
        // A failed/missing JS application must not silently reveal an unfinished UI or spin forever.
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(21))
        assertTrue(views(cover).filterIsInstance<TextView>().any{it.text.contains("ئامادە نەبوو")})
        val close=views(cover).filterIsInstance<Button>().single{it.text=="داخستن"}
        close.performClick();assertTrue(activity.isFinishing)
        screen.pause().stop().destroy()
    }
    @Test fun backgroundTimeDoesNotConsumeTheStartupDeadline(){
        val screen=Robolectric.buildActivity(MainActivity::class.java).setup()
        val cover=views(screen.get().findViewById(android.R.id.content)).filterIsInstance<StartupScreen>().single()
        screen.pause().stop()
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(30))
        assertTrue(views(cover).filterIsInstance<Button>().isEmpty())
        screen.restart().start().resume()
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(21))
        assertTrue(views(cover).filterIsInstance<Button>().any{it.text=="دووبارە هەوڵدانەوە"})
        screen.pause().stop().destroy()
    }
    @Test fun isolatedHtmlLoaderStopsInBackgroundAndDestroysAfterReveal(){
        val cover=StartupScreen(RuntimeEnvironment.getApplication())
        val loader=views(cover).filterIsInstance<WebView>().single()
        val shadow=shadowOf(loader)
        val page="https://appassets.androidplatform.net/assets/startup/loading.html"
        assertEquals(page,shadow.lastLoadedUrl)
        assertFalse(loader.settings.javaScriptEnabled);assertFalse(loader.settings.domStorageEnabled)
        assertFalse(loader.settings.allowFileAccess);assertFalse(loader.settings.allowContentAccess)
        assertTrue(loader.settings.blockNetworkLoads)
        assertNull(shadow.getJavascriptInterface("VidoraNative"))
        fun request(url:String)=object:WebResourceRequest{
            override fun getUrl()=Uri.parse(url)
            override fun isForMainFrame()=true
            override fun isRedirect()=false
            override fun hasGesture()=false
            override fun getMethod()="GET"
            override fun getRequestHeaders()=emptyMap<String,String>()
        }
        val client=loader.webViewClient
        assertFalse(client.shouldOverrideUrlLoading(loader,request(page)))
        val html=client.shouldInterceptRequest(loader,request(page))!!.data.bufferedReader().use{it.readText()}
        assertTrue(html.contains("چاوەڕێ بکە..."));assertTrue(html.contains("loading.gif"));assertTrue(html.contains("Content-Security-Policy"))
        for(url in listOf("https://example.org/", "file:///sdcard/media.mp4", "https://appassets.androidplatform.net/assets/ui/index.html")){
            assertTrue(client.shouldOverrideUrlLoading(loader,request(url)))
            assertEquals(0,client.shouldInterceptRequest(loader,request(url))!!.data.readBytes().size)
        }
        cover.running(false);assertEquals("about:blank",shadow.lastLoadedUrl);assertTrue(shadow.wasOnPauseCalled())
        cover.running(true);assertEquals(page,shadow.lastLoadedUrl);assertTrue(shadow.wasOnResumeCalled())
        cover.release();assertTrue(shadow.wasDestroyCalled());assertEquals(0,cover.childCount)
        cover.running(true);cover.release();assertEquals(0,cover.childCount)
    }
}
