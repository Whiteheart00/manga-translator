package com.kurd.videodownloader
internal object CryptoTest {
    fun setup(){PrivateCipher.useTestKey(javax.crypto.spec.SecretKeySpec(ByteArray(32){(it+1).toByte()},"AES"))}
}
