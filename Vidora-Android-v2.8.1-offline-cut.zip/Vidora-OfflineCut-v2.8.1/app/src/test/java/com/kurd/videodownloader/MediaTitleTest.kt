package com.kurd.videodownloader

import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.PatternSyntaxException

class MediaTitleTest {
    @Test fun unicodeTitleAndTrailingHashtagsAreHandledWithoutJavaOnlyFlags(){
        assertEquals("چیا جوانە",MediaTitle.clean("/tmp/چیا جوانە #کوردستان #nature [abc123].mp4"))
        assertEquals("منظر جميل",MediaTitle.clean("/tmp/منظر جميل ＃طبيعة [abcd1234].webm"))
        assertEquals("A #tag in the middle",MediaTitle.clean("A #tag in the middle [abc123].mp4"))
        assertEquals("Movie",MediaTitle.clean("C:\\temp\\Movie [abc123].mp4"))
        assertEquals(85,MediaTitle.clean("x".repeat(200)+".mp4").length)
    }
    @Test fun readerThreadCallbackCannotLeakItsExceptionPastTheGuard(){
        val after=AtomicBoolean(false);val escaped=AtomicBoolean(false);val errors=AtomicInteger(0)
        val reader=Thread {
            ProgressCallback.safely({errors.incrementAndGet()}){throw PatternSyntaxException("ICU rejected inline flag","(?U)",2)}
            after.set(true)
        }
        reader.uncaughtExceptionHandler=Thread.UncaughtExceptionHandler{_,_->escaped.set(true)}
        reader.start();reader.join(2000)
        assertFalse(reader.isAlive);assertTrue(after.get());assertFalse(escaped.get());assertEquals(1,errors.get())
    }
    @Test fun aDiagnosticReporterFailureDoesNotCrashTheReaderEither(){
        ProgressCallback.safely({throw IllegalStateException("disk full")}){throw IllegalArgumentException("bad progress update")}
    }
}
