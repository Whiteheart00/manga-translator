package com.kurd.videodownloader

import android.content.Context
import android.media.AudioManager
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class PlaybackBehaviorTest {
    private val c:Context get()=RuntimeEnvironment.getApplication()
    @Before fun setup(){CryptoTest.setup();DownloadState.running=false;DownloadSession.enterHome(c)}
    @Test fun homeDropsOldTerminalStateAndPersistedResultButKeepsHistory(){
        val item=NativeHistory.add(c,PublishedMedia("saved.mp4",Uri.parse("content://media/external/downloads/52"),"video/mp4",123),"https://example.org/video","Best")
        DownloadState.action="download";DownloadState.status="error";DownloadState.url="https://example.org/old";DownloadState.progress=37;DownloadState.title="old"
        c.securePreferences("native_runtime").edit().putString("url","https://example.org/old").commit()
        c.securePreferences("download_state").edit().putString("last_result","old error").commit()
        DownloadSession.enterHome(c)
        assertEquals("idle",DownloadState.action);assertEquals("",DownloadState.url);assertEquals(0,DownloadState.progress)
        assertTrue(c.securePreferences("native_runtime").all.isEmpty());assertTrue(c.securePreferences("download_state").all.isEmpty())
        assertNotNull(NativeHistory.find(c,item.getString("id")))
    }
    @Test fun reopeningDuringRealDownloadPreservesProgress(){
        DownloadState.running=true;DownloadState.action="download";DownloadState.url="https://example.org/current";DownloadState.progress=54
        DownloadSession.enterHome(c)
        assertTrue(DownloadState.running);assertEquals(54,DownloadState.progress);assertEquals("https://example.org/current",DownloadState.url)
        DownloadState.running=false
    }
    private fun decoder(screen:PlayerActivity)=PlayerActivity::class.java.getDeclaredField("player").apply{isAccessible=true}.get(screen)as ExoPlayer
    @Test fun videoHasMediaAudioWithoutHeadphoneModeAndSubtitlesStartOff(){
        c.securePreferences("player_ui_options").edit().putString("options",JSONObject().put("volume",0).put("ccEnabled",true).toString()).commit()
        val controller=Robolectric.buildActivity(PlayerActivity::class.java).setup();val activity=controller.get();val p=decoder(activity)
        assertEquals(AudioManager.STREAM_MUSIC,activity.volumeControlStream);assertEquals(C.USAGE_MEDIA,p.audioAttributes.usage);assertEquals(.85f,p.volume,0.001f)
        assertFalse(p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_AUDIO));assertTrue(p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT))
        activity.Controls().captions(true);assertFalse(p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT))
        activity.Controls().audioMode(true);assertTrue(p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_VIDEO));assertFalse(p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_AUDIO))
        activity.Controls().audioMode(false);assertFalse(p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_VIDEO));assertEquals(.85f,p.volume,0.001f)
        activity.Controls().volume(.4);controller.pause().stop();controller.restart().start().resume();assertEquals(.4f,decoder(activity).volume,0.001f)
        controller.pause().stop().destroy()
    }
    @Test fun bootstrapReadsSelectedThemeSynchronously(){
        AppSettings.save(c,JSONObject().put("mode","light").put("palette","amber"))
        val controller=Robolectric.buildActivity(MainActivity::class.java).setup();val value=JSONObject(controller.get().NativeApi().bootstrap())
        assertEquals("amber",value.getString("palette"));assertEquals("light",value.getString("mode"));assertEquals("#fffaf0",AppSettings.background(c))
        controller.pause().stop().destroy()
    }
    @Test fun fullscreenCanReturnToPortraitWithoutClosingOrReplacingDecoder(){
        val controller=Robolectric.buildActivity(PlayerActivity::class.java).setup()
        val activity=controller.get();val p=decoder(activity)
        activity.Controls().ready()
        activity.Controls().fullscreen()
        assertEquals(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE,activity.requestedOrientation)
        assertTrue(org.robolectric.Shadows.shadowOf(activity.browser).lastEvaluatedJavascript.contains("nativePlayerSnapshot"))
        assertTrue(org.robolectric.Shadows.shadowOf(activity.browser).lastEvaluatedJavascript.contains("\"fullscreen\":true"))
        // The visible back arrow must leave fullscreen first, not close playback.
        activity.Controls().back()
        assertFalse(activity.isFinishing)
        assertEquals(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT,activity.requestedOrientation)
        assertSame(p,decoder(activity))
        assertTrue(org.robolectric.Shadows.shadowOf(activity.browser).lastEvaluatedJavascript.contains("\"fullscreen\":false"))
        controller.pause().stop().destroy()
    }
}
