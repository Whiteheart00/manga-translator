package com.kurd.videodownloader

import org.junit.Assert.*
import org.junit.Test
import java.io.File

class MediaRequestPolicyTest {
    @Test fun recognizesRequestedServicesAndShortLinks(){
        val urls=mapOf("pinterest" to listOf("https://pinterest.com/pin/123/","https://pin.it/abc","https://uk.pinterest.com/pin/123"),
            "tiktok" to listOf("https://vm.tiktok.com/abc","https://www.tiktok.com/@a/video/123"),
            "instagram" to listOf("https://instagram.com/reel/ABC/","https://www.instagram.com/stories/name/123/"),
            "facebook" to listOf("https://fb.watch/abc/"),"x" to listOf("https://twitter.com/user/status/123"),
            "snapchat" to listOf("https://www.snapchat.com/spotlight/ABC"),"reddit" to listOf("https://redd.it/abc"),
            "vimeo" to listOf("https://vimeo.com/123"),"dailymotion" to listOf("https://dai.ly/abc"),"soundcloud" to listOf("https://on.soundcloud.com/abc"))
        for((id,links)in urls)for(url in links)assertEquals(url,id,MediaRequestPolicy.identify(url)?.id)
        assertNull(MediaRequestPolicy.identify("https://tiktok.com.example.net/video/123"))
        assertNull(MediaRequestPolicy.identify("https://notpinterest.com/pin/123"))
    }
    @Test fun soundcloudUsesTheAudioPipeline(){
        assertTrue(MediaRequestPolicy.identify("https://soundcloud.com/artist/track")!!.audioOnly)
        assertFalse(MediaRequestPolicy.identify("https://youtube.com/watch?v=x")!!.audioOnly)
    }
    @Test fun videoRequestsKeepUnknownHeightSilentAndUnwatermarkedCandidates(){
        val generic=MediaRequestPolicy.videoSelector("https://pin.it/abc",1080)
        assertTrue(generic.contains("[height<=?1080]"));assertTrue(generic.endsWith("bv*[height<=?1080]"))
        val tiktok=MediaRequestPolicy.videoSelector("https://vm.tiktok.com/abc",720)
        for(branch in tiktok.split('/'))assertTrue(branch.contains("[format_note!*=?watermarked]"))
        assertFalse(MediaRequestPolicy.videoSelector("https://example.org/video",0).contains("watermarked"))
    }
    @Test fun exportProductionSelectorsForYtDlpFixtureChecks(){
        val values=mapOf("generic1080" to MediaRequestPolicy.videoSelector("https://pin.it/abc",1080),
            "tiktok1080" to MediaRequestPolicy.videoSelector("https://vm.tiktok.com/abc",1080),
            "tiktokBest" to MediaRequestPolicy.videoSelector("https://www.tiktok.com/@a/video/123",0))
        File("build/tested-media-selectors.tsv").apply{parentFile.mkdirs();writeText(values.entries.joinToString("\n"){it.key+"\t"+it.value})}
    }
}
