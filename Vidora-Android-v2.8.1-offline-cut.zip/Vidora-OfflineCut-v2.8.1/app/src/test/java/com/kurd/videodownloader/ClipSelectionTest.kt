package com.kurd.videodownloader

import android.content.Context
import android.content.Intent
import android.Manifest
import org.json.JSONObject
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RuntimeEnvironment
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class ClipSelectionTest {
    private val c:Context get()=RuntimeEnvironment.getApplication()
    private val url="https://youtu.be/clip-test"
    private val token="clip-metadata-token"
    @Suppress("UNCHECKED_CAST") private fun cache()=MediaProbe::class.java.getDeclaredField("previews").apply{isAccessible=true}.get(MediaProbe) as MutableMap<String,PreviewMedia>
    @Before fun setup(){CryptoTest.setup();cache().clear();DownloadState.running=false;shadowOf(RuntimeEnvironment.getApplication()).grantPermissions(Manifest.permission.POST_NOTIFICATIONS);cache()[token]=PreviewMedia(token,url,"Long source",7200,emptyList(),null)}
    private fun payload(start:Long=0,end:Long=600000)=JSONObject().put("url",url).put("format","MP4").put("quality","720p").put("clip",JSONObject().put("token",token).put("startMs",start).put("endMs",end))
    private fun rejects(block:()->Unit){try{block();fail("Expected invalid selection to reject")}catch(_:IllegalArgumentException){}catch(_:java.io.IOException){}}
    @Test fun selectionsBindNativeDurationSourceAndRoundTripThroughServiceIntent(){
        assertNull(ClipSelection.fromJson(JSONObject(),url))
        val clip=ClipSelection.fromJson(payload(6_600_000,7_200_000),url)!!
        assertEquals(600000L,clip.lengthMs);assertEquals(7_200_000L,clip.sourceDurationMs)
        val intent=Intent();ClipSelection.put(intent,clip);assertEquals(clip,ClipSelection.fromIntent(intent,url))
        assertNull(ClipSelection.fromIntent(Intent(),url))
        rejects{ClipSelection.fromJson(payload(),"https://youtu.be/another")}
        rejects{ClipSelection.fromJson(payload().apply{getJSONObject("clip").put("token","missing")},url)}
    }
    @Test fun invalidAndUntrustedTimesNeverBecomeWholeFileDownloads(){
        for((start,end) in listOf(-1L to 1000L,1000L to 1000L,2000L to 1000L,0L to 999L,0L to 7_200_001L,Long.MAX_VALUE to Long.MIN_VALUE))rejects{ClipSelection.fromJson(payload(start,end),url)}
        for(value in listOf("1000",1.25)){
            rejects{ClipSelection.fromJson(payload().apply{getJSONObject("clip").put("startMs",value)},url)}
        }
        rejects{ClipSelection.fromJson(JSONObject().put("clip","invalid"),url)}
        rejects{ClipSelection.fromIntent(Intent().putExtra("clip_start_ms",0L),url)}
        cache()[token]=cache()[token]!!.copy(clipAllowed=false);rejects{ClipSelection.fromJson(payload(),url)}
        cache()[token]=cache()[token]!!.copy(clipAllowed=true,created=System.currentTimeMillis()-31*60*1000);rejects{ClipSelection.fromJson(payload(),url)}
    }
    @Test fun mainBridgeForwardsOnlyTheValidatedSegmentToNativeService(){
        val screen=Robolectric.buildActivity(MainActivity::class.java).setup();val api=screen.get().NativeApi()
        api.requestDownload(payload(10000,70000).toString())
        assertTrue(DownloadState.running)
        val intent=shadowOf(RuntimeEnvironment.getApplication()).nextStartedService
        assertEquals(DownloadService.ACTION_START,intent.action)
        assertEquals(10000L,ClipSelection.fromIntent(intent,url)!!.startMs)
        DownloadState.running=false;screen.pause().stop().destroy()
    }
    @Test fun productionFfmpegArgumentsAreLocalOnlyPreciseAndUseCorrectOutputCodec(){
        val video=MediaClipper.arguments("{input}","{output}",2000,5000,false,0)
        val audio=MediaClipper.arguments("{input}","{output}",2000,5000,true,192)
        assertEquals("2.000",video[video.indexOf("-ss")+1]);assertEquals("3.000",video[video.indexOf("-t")+1])
        assertEquals("file,pipe",video[video.indexOf("-protocol_whitelist")+1]);assertTrue(video.contains("libx264"));assertFalse(video.contains("copy"))
        assertTrue(audio.contains("libmp3lame"));assertTrue(audio.contains("192k"));assertFalse(audio.contains("libx264"))
        assertEquals("01-01-01",MediaClipper.clock(3_661_000))
        File("build/clip-qa-args.json").apply{parentFile.mkdirs();writeText(JSONObject().put("video",JSONArray(video)).put("audio",JSONArray(audio)).toString())}
    }
}
