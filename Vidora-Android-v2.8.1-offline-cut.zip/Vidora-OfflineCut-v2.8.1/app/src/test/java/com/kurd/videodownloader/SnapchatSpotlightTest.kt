package com.kurd.videodownloader

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class SnapchatSpotlightTest {
    private val id="spotlight_requested_123"
    private val page="https://www.snapchat.com/@person/spotlight/$id"
    private fun video(key:String=id)=JSONObject().put("@type","VideoObject").put("url","https://www.snapchat.com/@person/spotlight/$key")
        .put("mainEntityOfPage",JSONObject().put("@id","https://www.snapchat.com/@person/spotlight/$key"))
        .put("embedUrl","https://www.snapchat.com/spotlight/$key/embed").put("name","Exact Spotlight").put("contentUrl","https://bolt-gcdn.sc-cdn.net/z/exact.IRZXSOY?mo=sample&uc=46")
        .put("thumbnailUrl","https://cf-st.sc-cdn.net/d/cover.IRZXSOY").put("isFamilyFriendly",true).put("encodingFormat","video/mp4").put("duration","PT1M2.5S").put("width",540).put("height",960)
    private fun html(vararg items:JSONObject)=items.joinToString(""){"<script nonce='n' type='application/ld+json'>$it</script>"}+"<script>self.__next_f.push([1,\"untrusted script text\"])</script>"
    private fun reject(block:()->Unit){try{block();fail("Unsafe or unrelated media accepted")}catch(_:IOException){}}
    @Test fun newAppRouterPageSelectsExactVideoWithoutNextData(){
        val info=SnapchatSource.parse(html(video("recommendation_123"),video()),page)
        assertEquals(id,info.getString("id"));assertEquals("mp4",info.getString("ext"));assertEquals(62.5,info.getDouble("duration"),0.001)
        assertEquals(540,info.getInt("width"));assertEquals(page,info.getString("webpage_url"));assertEquals("VidoraSnapchatSpotlight",info.getString("extractor"))
        assertTrue(info.getString("url").contains("&uc=46"))
    }
    @Test fun neverUsesRecommendedVideoProfileOrWrongIdentity(){
        reject{SnapchatSource.parse(html(video("recommendation_123")),page)}
        reject{SnapchatSource.parse(html(video()),"https://www.snapchat.com/@person")}
        reject{SnapchatSource.parse(html(video()),"https://attacker.example/spotlight/$id")}
        reject{SnapchatSource.parse(html(video().put("mainEntityOfPage",JSONObject().put("@id","https://www.snapchat.com/spotlight/wrong_id_123"))),page)}
        reject{SnapchatSource.parse(html(video().put("embedUrl","https://www.snapchat.com/spotlight/wrong_id_123/embed")),page)}
    }
    @Test fun rejectsAdultGatedImageCleartextAndLookalikeCdn(){
        for(change in listOf(video().put("isFamilyFriendly",false),video().put("age_limit",18),video().put("contentRating","18+"),video().put("requiresSubscription",true),video().put("isAccessibleForFree",false),video().put("audienceGateSettings",JSONObject().put("minAge",18)),video().put("encodingFormat","image/jpeg"),video().put("contentUrl","http://cf-st.sc-cdn.net/video.mp4"),video().put("contentUrl","https://sc-cdn.net.attacker.example/video.mp4"),video().put("contentUrl","https://user@cf-st.sc-cdn.net/video.mp4"))){reject{SnapchatSource.parse(html(change),page)}}
    }
    @Test fun supportsJsonLdGraphArrayAndRejectsConflictingExactSources(){
        val graph=JSONObject().put("@graph",JSONArray().put(video("recommendation_123")).put(video().put("thumbnailUrl",JSONArray().put("https://cf-st.sc-cdn.net/thumb"))))
        val info=SnapchatSource.parse(html(graph),page);assertEquals(id,info.getString("id"));assertEquals("https://cf-st.sc-cdn.net/thumb",info.getString("thumbnail"))
        reject{SnapchatSource.parse(html(video(),video().put("contentUrl","https://cf-st.sc-cdn.net/different")),page)}
    }
    @Test fun oldSpotlightPagesStillSelectTheExactStoryId(){
        fun item(key:String)=JSONObject().put("story",JSONObject().put("storyId",JSONObject().put("value",key))).put("metadata",JSONObject().put("videoMetadata",video(key).put("durationMs",4250)))
        val root=JSONObject().put("props",JSONObject().put("pageProps",JSONObject().put("spotlightFeed",JSONObject().put("spotlightStories",JSONArray().put(item("recommendation_123")).put(item(id))))))
        val info=SnapchatSource.parse("<script id='__NEXT_DATA__'>$root</script>",page)
        assertEquals(id,info.getString("id"));assertEquals(4.25,info.getDouble("duration"),0.001)
    }
    @Test fun publicSpotlightPathsAreStrictlyIdentified(){
        assertEquals(id,SnapchatSpotlight.id(page));assertEquals(id,SnapchatSpotlight.id("https://snapchat.com/spotlight/$id?share_id=test"))
        for(link in listOf("http://www.snapchat.com/spotlight/$id","https://snapchat.com.attacker.example/spotlight/$id","https://www.snapchat.com/@person","https://www.snapchat.com/spotlight/short","https://user@www.snapchat.com/spotlight/$id"))assertNull(SnapchatSpotlight.id(link))
    }
    @Test fun originalExplicitIdRemainsBoundAcrossHeadAndGetRedirects(){
        SnapchatSpotlight.verifyRedirect("https://www.snapchat.com/spotlight/$id",page)
        SnapchatSpotlight.verifyRedirect("https://snapchat.com/t/short-share",page)
        reject{SnapchatSpotlight.verifyRedirect(page,"https://www.snapchat.com/spotlight/different_id_123")}
        reject{SnapchatSpotlight.verifyRedirect(page,"https://www.snapchat.com/@person")}
        assertEquals("full-id_with-dashes_123",SnapchatSpotlight.id("https://www.snapchat.com/spotlight/full-id_with-dashes_123"))
    }
    @Test fun exportsAllReportedLivePagesThroughTheProductionParserWhenProvided(){
        val dir=System.getenv("VIDORA_SPOTLIGHT_FIXTURES")?.let(::File)?:return
        for(i in 0..2){
            val page=File(dir,"$i.url").readText();val info=SnapchatSource.parse(File(dir,"$i.html").readText(),page)
            assertEquals(SnapchatSpotlight.id(page),info.getString("id"));assertTrue(info.getDouble("duration")>0);assertEquals("mp4",info.getString("ext"))
            File("build/reported-spotlight-$i.info.json").apply{parentFile.mkdirs();writeText(info.toString())}
            val header=File(dir,"$i.header");if(header.isFile)SnapchatSource.requireMp4(header.readBytes())
            val playback=PlaybackDownload.capture(org.robolectric.RuntimeEnvironment.getApplication(),info,page)
            assertEquals(info.getString("url"),playback.getJSONArray("formats").getJSONObject(0).getString("url"))
            File("build/reported-spotlight-$i.playback.info.json").writeText(playback.toString())
        }
    }
}
