'use strict';
(function(){
 const q=id=>document.getElementById(id);let context={},editingId='',range=null,invalid=false,starting=false;
 const duration=()=>Number(context.cutDurationMs??Number(context.duration)*1000)||0;
 const own=()=>context.taskAction==='cut'&&context.taskRecordId===String(context.id||'').replace(/^record:/,'');
 const busy=()=>!!context.downloadRunning||!!context.cutPending||starting;
 const clock=ms=>{const s=Math.floor(ms/1000);return String(Math.floor(s/3600)).padStart(2,'0')+':'+String(Math.floor(s/60)%60).padStart(2,'0')+':'+String(s%60).padStart(2,'0')};
 function parse(text){const s=String(text).trim().replace(/[٠-٩۰-۹]/g,c=>String(c.charCodeAt(0)-(c>='۰'?1776:1632)));if(!/^\d+(?::\d{1,2}){0,2}$/.test(s))return null;const p=s.split(':').map(Number);if(p.length>1&&p.at(-1)>59||p.length===3&&p[1]>59)return null;const v=p.reduce((a,b)=>a*60+b,0)*1000;return Number.isSafeInteger(v)?v:null;}
 function error(text){invalid=!!text;q('cutError').hidden=!text;q('cutError').textContent=text;}
 function render(){
  const working=own()&&!!context.downloadRunning,ready=!!context.canCut;
  q('playerCutBtn').disabled=(!ready&&!working)||busy()&&!working;
  q('playerCutBtn').title=ready?'بڕین و پاشەکەوتکردنی فایلێکی نوێ':'تەنها بۆ ڤیدیۆ و دەنگە دابەزێنراوەکان';
  q('localCutEditor').disabled=busy()||!ready||!range;
  q('saveCutBtn').disabled=busy()||!ready||!range||invalid||editingId!==context.id;
  q('cancelCutBtn').hidden=!working;
  const preparing=working&&(context.downloadProgress||0)<=0;
  q('cutPercent').classList.toggle('download-preparing',preparing);
  q('cutPercent').textContent=preparing?'':own()?String(context.downloadProgress||0)+'%':'';
  q('cutProgressFill').style.width=(own()?Math.max(0,Math.min(100,context.downloadProgress||0)):0)+'%';
  if(preparing)q('cutProgressTrack').removeAttribute('aria-valuenow');else q('cutProgressTrack').setAttribute('aria-valuenow',String(own()?context.downloadProgress||0:0));
  q('cutProgressTrack').setAttribute('aria-busy',String(working));
  q('cutStatus').textContent=own()?context.downloadMessage||'ئامادەکردنی پارچەی نوێ...':context.downloadRunning?'کردارێکی تر بەردەوامە':'سەرەتا و کۆتایی دیاری بکە';
  if(!range||duration()<1000)return;
  const length=duration();
  for(const id of ['localCutStartRange','localCutEndRange']){q(id).max=length;q(id).step=1;}
  q('localCutStartRange').value=range.startMs;q('localCutEndRange').value=range.endMs;
  q('localCutStartRange').setAttribute('aria-valuetext',clock(range.startMs));q('localCutEndRange').setAttribute('aria-valuetext',clock(range.endMs));
  q('localCutAxisEnd').textContent=clock(length);q('localCutDuration').textContent=clock(range.endMs-range.startMs);
  q('localCutFill').style.left=(range.startMs/length*100)+'%';q('localCutFill').style.right=(100-range.endMs/length*100)+'%';
  if(!invalid){q('localCutStartTime').value=clock(range.startMs);q('localCutEndTime').value=clock(range.endMs);for(const id of ['localCutStartTime','localCutEndTime'])q(id).removeAttribute('aria-invalid');}
 }
 window.nativeCutContext=value=>{
  if(editingId&&value.id!==editingId){editingId='';range=null;error('');if(q('cutSheet').classList.contains('open'))window.VidoraPlayer.closePanel();}
  context=value;starting=false;
  if(range&&duration()>0){range.endMs=Math.min(range.endMs,duration());range.startMs=Math.min(range.startMs,range.endMs-1000)}
  render();
 };
 q('playerCutBtn').addEventListener('click',()=>{
  if(!context.canCut&&!(own()&&context.downloadRunning))return;
  if(editingId!==context.id||!range){editingId=context.id;range={startMs:0,endMs:duration()};}
  error('');q('cutSheet').querySelector('.sheet-scroll').scrollTop=0;q('cutFileTitle').textContent=q('headerTitle').textContent;window.VidoraPlayer.pause();render();window.VidoraPlayer.showCut();
 });
 for(const which of ['Start','End']){
  const input=q('localCut'+which+'Range');
  input.addEventListener('input',()=>{
   if(!range||busy())return;error('');let value=Number(input.value);value=value>=duration()-500?duration():Math.round(value/1000)*1000;
   if(which==='Start')range.startMs=Math.max(0,Math.min(value,range.endMs-1000));else range.endMs=Math.min(duration(),Math.max(value,range.startMs+1000));render();
  });
  input.addEventListener('keydown',event=>{
   if(!range||busy())return;const d={ArrowRight:1000,ArrowUp:1000,ArrowLeft:-1000,ArrowDown:-1000,PageUp:60000,PageDown:-60000}[event.key];
   if(d===undefined&&!['Home','End'].includes(event.key))return;event.preventDefault();input.value=event.key==='Home'?0:event.key==='End'?duration():Number(input.value)+d;input.dispatchEvent(new window.Event('input'));
  });
 }
 function times(){
  if(!range||busy())return;const start=parse(q('localCutStartTime').value),end=parse(q('localCutEndTime').value);
  const actualEnd=end===Math.floor(duration()/1000)*1000&&q('localCutEndRange').value==duration()?duration():end;
  if(start===null||end===null||start<0||actualEnd>duration()||actualEnd-start<1000){error('کاتەکان وەک 00:01:30 بنووسە؛ کۆتایی دوای سەرەتا و لانیکەم یەک چرکە بێت.');for(const id of ['localCutStartTime','localCutEndTime'])q(id).setAttribute('aria-invalid','true');}
  else{error('');range={startMs:start,endMs:actualEnd};}render();
 }
 for(const id of ['localCutStartTime','localCutEndTime'])q(id).addEventListener('change',times);
 q('localCutMarkStart').addEventListener('click',()=>{if(!range||busy())return;error('');range.startMs=Math.max(0,Math.min(Math.round((context.currentTime||0)*1000),range.endMs-1000));render()});
 q('localCutMarkEnd').addEventListener('click',()=>{if(!range||busy())return;error('');range.endMs=Math.min(duration(),Math.max(Math.round((context.currentTime||0)*1000),range.startMs+1000));render()});
 q('saveCutBtn').addEventListener('click',()=>{
  if(busy()||!range||invalid||editingId!==context.id||!context.canCut)return;
  starting=true;render();window.VidoraPlayerNative.cut(editingId,range.startMs,range.endMs);
 });
 q('cancelCutBtn').addEventListener('click',()=>{if(own()&&context.downloadRunning)window.VidoraPlayerNative.cancelCut(context.id)});
 render();
})();
