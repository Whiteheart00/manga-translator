'use strict';
window.nativeMedia=function(video){
 const value={src:'',duration:0,currentTime:0,paused:true,ended:false,seeking:false,volume:.85,muted:false,playbackRate:1,videoWidth:0,videoHeight:0,readyState:0,error:null,buffer:0};
 const bridge=window.VidoraPlayerNative;
 for(const key of ['src','duration','currentTime','paused','ended','seeking','volume','muted','playbackRate','videoWidth','videoHeight','readyState','error'])Object.defineProperty(video,key,{configurable:true,get:()=>value[key],set:v=>{
  value[key]=v;
  if(key==='src'&&v){window.nativeLoadingState?.(true);bridge.open(String(v));}
  if(key==='currentTime')bridge.seek(Number(v)||0);
  if(key==='playbackRate')bridge.speed(Number(v)||1);
  if(key==='volume'||key==='muted')bridge.volume(value.muted?0:value.volume);
 }});
 Object.defineProperty(video,'buffered',{get:()=>({length:value.buffer>0?1:0,start:()=>0,end:()=>value.buffer})});
 video.play=()=>{bridge.play();return Promise.resolve()};video.pause=()=>bridge.pause();video.load=()=>{};
 const event=name=>video.dispatchEvent(new Event(name));
 let lastId='';let lastDuration=0;
 window.nativePlayerSnapshot=next=>{
  if(typeof next.fullscreen==='boolean')window.nativeFullscreenState?.(next.fullscreen);
  window.nativeLoadingState?.(!next.error&&(typeof next.loading==='boolean'?next.loading:next.readyState<3&&!!value.src));window.nativeDownloadContext?.(next);window.nativeCutContext?.(next);window.nativeEmbeddedText=next.embedded||'';const oldPaused=value.paused,oldEnded=value.ended;
  Object.assign(value,next);
  if(lastId!==next.id||lastDuration!==value.duration){lastId=next.id;lastDuration=value.duration;event('loadedmetadata');event('durationchange')}
  if(oldPaused!==value.paused)event(value.paused?'pause':'play');
  event('timeupdate');event('progress');
  if(value.ended&&!oldEnded)event('ended');
  if(next.error)event('error');
 };
 function layout(){const r=document.getElementById('playerStage').getBoundingClientRect();bridge.layout(r.left,r.top,r.width,r.height)}
 window.addEventListener('resize',layout);new ResizeObserver(layout).observe(document.getElementById('playerStage'));
 document.addEventListener('visibilitychange',()=>{if(document.hidden)bridge.pause()});
 return video;
};
