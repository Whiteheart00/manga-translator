'use strict';
(function(){try{const settings=JSON.parse(window.VidoraPlayerNative.settings());document.documentElement.dataset.theme=['obsidian','gold','light'].includes(settings.theme)?settings.theme:'obsidian';}catch{document.documentElement.dataset.theme='obsidian';}})();
