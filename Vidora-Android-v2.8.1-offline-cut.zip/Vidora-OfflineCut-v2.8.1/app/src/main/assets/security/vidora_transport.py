"""Vidora TLS policy for yt-dlp requests and redirects; no telemetry."""
from urllib.parse import urlsplit
import re
from yt_dlp.postprocessor.common import PostProcessor
from yt_dlp.utils import YoutubeDLError

def require_https(url):
    parsed = urlsplit(url)
    if parsed.scheme.lower() != 'https' or not parsed.hostname or parsed.username is not None or parsed.password is not None:
        raise YoutubeDLError('Vidora requires HTTPS without URL credentials')

class VidoraTransportPP(PostProcessor):
    def __init__(self, downloader=None, **kwargs):
        super().__init__(downloader)
        from yt_dlp.networking._urllib import RedirectHandler
        old_redirect = RedirectHandler.redirect_request
        def redirect(handler, req, fp, code, msg, headers, newurl):
            require_https(newurl)
            return old_redirect(handler, req, fp, code, msg, headers, newurl)
        RedirectHandler.redirect_request = redirect
        try:
            from yt_dlp.networking._requests import RequestsSession
            old_send = RequestsSession.send
            def send(session, request, **options):
                require_https(request.url)  # Includes every recursive redirect send.
                return old_send(session, request, **options)
            RequestsSession.send = send
        except ImportError:
            pass
        # Do not fall back to handlers whose native redirect paths bypass these checks.
        director = downloader._request_director
        for name in list(director.handlers):
            if name not in ('Urllib', 'Requests'):
                director.handlers.pop(name).close()
        if not director.handlers:
            raise YoutubeDLError('No supported secure transport available')
        original = downloader.urlopen
        def https_only(request):
            url = request if isinstance(request, str) else getattr(request, 'url', getattr(request, 'full_url', ''))
            require_https(url)
            return original(request)
        downloader.urlopen = https_only

    @staticmethod
    def watermark(format):
        for key in ('is_watermarked', 'watermarked', 'watermark'):
            value = format.get(key)
            if isinstance(value, bool):
                return value
        note = str(format.get('format_note') or '').lower().replace('_', ' ')
        if re.search(r'\b(?:no|without) watermark\b|\bunwatermarked\b', note):
            return False
        if re.search(r'\bwatermark(?:ed)?\b', note):
            return True
        return None

    def run(self, information):
        formats = information.get('formats')
        if isinstance(formats, list):
            videos = [f for f in formats if f.get('vcodec') != 'none']
            clean = [f for f in videos if self.watermark(f) is False]
            unmarked = [f for f in videos if self.watermark(f) is not True]
            candidates = clean or unmarked
            if candidates:
                information['formats'] = [f for f in formats if f.get('vcodec') == 'none' or f in candidates]
                information['vidora_watermark_status'] = 'declared_clean' if clean else 'unknown'
            else:
                information['vidora_watermark_status'] = 'marked' if videos else 'unknown'
        else:
            status = self.watermark(information)
            information['vidora_watermark_status'] = 'declared_clean' if status is False else 'marked' if status is True else 'unknown'
        return [], information
