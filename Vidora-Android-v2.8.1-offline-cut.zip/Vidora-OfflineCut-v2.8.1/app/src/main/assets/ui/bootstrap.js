'use strict';
(function(){
 const root=document.documentElement;
 try{
  const native=window.VidoraNative;
  const initial=native?JSON.parse(native.bootstrap()):{palette:localStorage.getItem('vidora-hybrid-palette'),mode:localStorage.getItem('vidora-hybrid-mode')};
  window.vidoraInitialSettings=initial||{};
  if(['rainbow','ocean','silver','gold','amber'].includes(initial.palette))root.dataset.palette=initial.palette;
  if(['dark','light'].includes(initial.mode))root.dataset.mode=initial.mode;
  if(native)root.classList.add('native-app');
 }catch{window.vidoraInitialSettings={};}
})();
