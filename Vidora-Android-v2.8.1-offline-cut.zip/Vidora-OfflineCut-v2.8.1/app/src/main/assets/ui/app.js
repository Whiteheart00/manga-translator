'use strict';
const nativeApp=typeof window.VidoraNative!=='undefined';
const $=selector=>document.querySelector(selector);
const $$=selector=>[...document.querySelectorAll(selector)];
const root=document.documentElement;
const sheet={width:1122,height:1402,rects:{menu:[88,28,103,103],theme:[864,40,192,81],url:[67,214,985,145],splashTop:[0,125,1122,96],splashBottom:[0,342,1122,47],footer:[0,1315,1122,87],site:[80,390,470,77],paste:[622,391,423,77],formatBar:[79,526,966,82],formatOn:[84,532,491,69],formatOff:[576,533,463,68],best:[80,666,227,78],qualityOff:[322,667,231,76],qualityOn:[815,666,230,78],download:[78,768,967,120],card:[68,907,986,183],downloads:[77,1111,469,108],update:[574,1111,471,108],status:[77,1241,970,75]}};
function skin(element,name){
 const rect=sheet.rects[name];if(!rect)return;
 element.dataset.skin=name;
 if(element.dataset.rendered===name)return;
 const [x,y,w,h]=rect;
 element.replaceChildren();
 for(const tint of [false,true]){
  const img=document.createElement('img');img.src='assets/interface-art.png';img.alt='';img.draggable=false;img.setAttribute('aria-hidden','true');
  
  Object.assign(img.style,{width:`${sheet.width/w*100}%`,height:`${sheet.height/h*100}%`,left:`${-x/w*100}%`,top:`${-y/h*100}%`});
  if(tint){const viewport=document.createElement('span');viewport.className='tint-viewport';viewport.append(img);element.append(viewport)}else element.append(img);
 }
 element.dataset.rendered=name;
}
$$('[data-skin]').forEach(el=>skin(el,el.dataset.skin));
function fit(){root.style.setProperty('--scale',$('.viewport').clientWidth/720)}
fit();window.addEventListener('resize',fit);
if('ResizeObserver' in window)new ResizeObserver(fit).observe($('.viewport'));
if(nativeApp){try{localStorage.removeItem('vidora-ui-prefs')}catch{}}
const saved={get(key,fallback){try{if(nativeApp)return fallback;return localStorage.getItem(key)||fallback}catch{return fallback}},set(key,value){try{if(!nativeApp)localStorage.setItem(key,value)}catch{}}};
const palettes=['rainbow','ocean','silver','gold','amber'];
const state={format:'MP4',videoQuality:'1080p',audioQuality:'320k',percent:0,running:false,timer:null,entries:[]};
let toastTimer;
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),3600)}
function setPalette(palette){
 if(!palettes.includes(palette))return;
 root.dataset.palette=palette;
 $$('[data-palette]').filter(el=>el!==root).forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.palette===palette)));
 saved.set('vidora-hybrid-palette',palette);window.vidoraConfigureNative?.();
}
function setMode(mode){
 if(!['dark','light'].includes(mode))return;
 root.dataset.mode=mode;
 $$('.theme-button').forEach(el=>{const active=el.dataset.mode===mode;el.classList.toggle('selected',active);el.setAttribute('aria-pressed',String(active))});
 saved.set('vidora-hybrid-mode',mode);window.vidoraConfigureNative?.();
 $('meta[name="theme-color"]').content=mode==='dark'?'#061525':'#e4edf6';
}
setPalette(window.vidoraInitialSettings?.palette||saved.get('vidora-hybrid-palette','rainbow'));
setMode(window.vidoraInitialSettings?.mode||saved.get('vidora-hybrid-mode','dark')); 
$$('.theme-button').forEach(button=>button.addEventListener('click',()=>setMode(button.dataset.mode)));
$$('.palette-grid button').forEach(button=>button.addEventListener('click',()=>{setPalette(button.dataset.palette);$('#settings').close()}));
function openDialog(dialog){if(!dialog.open)dialog.showModal()}
$('#menu').addEventListener('click',()=>openScreen('settings'));
$('#settings').addEventListener('close',()=>$('#menu').setAttribute('aria-expanded','false'));
$$('.close-dialog').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
$$('dialog').forEach(dialog=>dialog.addEventListener('click',event=>{if(event.target===dialog){const rect=dialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)dialog.close()}}));
function details(title,text){$('#dialog-title').textContent=title;$('#dialog-content').replaceChildren();const p=document.createElement('p');p.textContent=text;$('#dialog-content').append(p);openDialog($('#details'))}
function readUrl(){try{const url=new URL($('#url').value.trim());return ['https:','http:'].includes(url.protocol)&&url.hostname.includes('.')?url:null}catch{return null}}
const socialPlatforms=[
 {id:'youtube',name:'YouTube',slot:0,domains:['youtube.com','youtu.be'],example:'https://youtu.be/HVVJUy2JfC4'},
 {id:'facebook',name:'Facebook',slot:1,domains:['facebook.com','fb.watch','fb.com'],example:'https://www.facebook.com/watch/?v=preview'},
 {id:'instagram',name:'Instagram',slot:2,domains:['instagram.com'],example:'https://www.instagram.com/reel/preview/'},
 {id:'tiktok',name:'TikTok',slot:3,domains:['tiktok.com'],example:'https://www.tiktok.com/@preview/video/123456'},
 {id:'x',name:'X',slot:4,domains:['x.com','twitter.com','t.co'],example:'https://x.com/preview/status/123456'},
 {id:'pinterest',name:'Pinterest',artSlot:2,mark:'P',color:'#e60023',domains:['pinterest.com','pinterest.co.uk','pinterest.fr','pinterest.de','pinterest.ca','pinterest.com.au','pin.it']},
 {id:'snapchat',name:'Snapchat',artSlot:4,mark:'ghost',color:'#fffc00',domains:['snapchat.com']},
 {id:'drive',name:'Google Drive',artSlot:0,domains:['drive.google.com','docs.google.com']},
 {id:'discord',name:'Discord',artSlot:1,domains:['discord.com','discordapp.com','discord.gg']},
 {id:'telegram',name:'Telegram',artSlot:3,domains:['t.me','telegram.me']},
 {id:'reddit',name:'Reddit',mark:'reddit',color:'#ff4500',domains:['reddit.com','redd.it']},
 {id:'vimeo',name:'Vimeo',mark:'v',color:'#149ed5',domains:['vimeo.com']},
 {id:'dailymotion',name:'Dailymotion',mark:'d',color:'#182233',domains:['dailymotion.com','dai.ly']},
 {id:'soundcloud',name:'SoundCloud',mark:'cloud',color:'#f77622',domains:['soundcloud.com','snd.sc'],audioOnly:true}
];
function platformFor(value){
 let host=String(value||'').trim().toLowerCase();
 try{if(host.includes('://'))host=new URL(host).hostname}catch{return null}
 host=host.replace(/^www\./,'');
 return socialPlatforms.find(platform=>platform.domains.some(domain=>host===domain||host.endsWith('.'+domain)))||null;
}
function platformHTML(value,extra=''){
 const platform=platformFor(value);
 if(!platform)return '<span class="platform-mark generic-platform '+extra+'" aria-hidden="true">↗</span>';
 if(platform.artSlot!==undefined){
  const offset=[-4,-3,0,3,5][platform.artSlot];
  return `<span class="platform-mark platform-furry-extra ${extra}" data-platform="${platform.id}" role="img" aria-label="${platform.name}"><img src="assets/furry-sources-extra.png" alt="" draggable="false" style="left:${-platform.artSlot*100+offset}%"></span>`;
 }
 if(platform.slot===undefined){
  const symbols={ghost:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 9V7a4 4 0 0 1 8 0v2l3-1 1 2-3 2c0 3 2 4 4 5-2 2-3 0-4 2-2 0-3 2-5 2s-3-2-5-2c-1-2-2 0-4-2 2-1 4-2 4-5l-3-2 1-2Z" fill="white" stroke="#262a2e" stroke-width="1.4"/></svg>',reddit:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 8 2-5 5 1"/><circle cx="20" cy="4" r="2"/><ellipse cx="12" cy="14" rx="9" ry="6"/><circle cx="8" cy="13" r="1" fill="currentColor"/><circle cx="16" cy="13" r="1" fill="currentColor"/><path d="M8 17q4 3 8 0"/></svg>',cloud:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 18h8a4 4 0 1 0-1-8 5 5 0 0 0-7-4v12ZM2 12v4m3-6v8m3-9v9"/></svg>'};
  const symbol=symbols[platform.mark]||`<b>${platform.mark}</b>`;
  return `<span class="platform-mark platform-vector ${extra}" data-platform="${platform.id}" role="img" aria-label="${platform.name}" style="--platform-color:${platform.color}">${symbol}</span>`;
 }

 return `<span class="platform-mark ${extra}" data-platform="${platform.id}" role="img" aria-label="${platform.name}"><img src="assets/furry-platforms.png" alt="" draggable="false" style="left:${-platform.slot*100}%"></span>`;
}
function source(){
 const url=readUrl();const host=url?.hostname.replace(/^www\./,'')||'';const platform=platformFor(host);
 const known=host==='vimeo.com'||host.endsWith('.vimeo.com')?'Vimeo':null;
 $('#site-name').textContent=platform?.name||known||(host?host.slice(0,18):'لینک');
 const sourceIcon=$('#source-icon');sourceIcon.className='source-platform';sourceIcon.innerHTML=platformHTML(host);
 if(platform?.audioOnly&&state.format!=='MP3'){state.format='MP3';renderSelection()}
 $('#valid').textContent=url?'✓':'·';$('#valid').style.opacity=url?'1':'.35';
}
$('#url').addEventListener('input',source);
$('#url').addEventListener('keydown',event=>{if(event.key==='Enter')startOrStop()});
$('#clear').addEventListener('click',()=>{$('#url').value='';source();$('#url').focus()});
$('#paste').addEventListener('click',async()=>{if(nativeApp){window.VidoraNative.paste();return}try{const value=await navigator.clipboard.readText();if(!value.trim()){toast('هیچ لینکێک لە Clipboard ـدا نییە');return}$('#url').value=value.match(/https?:\/\/[^\s<>"']+/i)?.[0]||value;source()}catch{$('#url').focus();toast('لە خانەی لینکەکەدا Paste بکە')}});
function renderSelection(){
 $$('.format').forEach(button=>{const selected=button.dataset.format===state.format;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));skin(button.querySelector('.skin'),selected?'formatOn':'formatOff')});
 const audio=state.format==='MP3';
 $('#quality-label').textContent=audio?'کوالێتی دەنگ':'کوالێتی ڤیدیۆ';$('.hd').textContent=audio?'HQ':'HD';
 const choices=audio?['Best','128k','192k','320k']:['Best','480p','720p','1080p'];
 $$('.quality').forEach((button,index)=>{const value=choices[index];button.dataset.quality=value;button.querySelector('.quality-text').textContent=value;const selected=value===(audio?state.audioQuality:state.videoQuality);button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));skin(button.querySelector('.skin'),index===0?'best':selected?'qualityOn':'qualityOff')});
 const quality=audio?state.audioQuality:state.videoQuality;
 $('#file-details').textContent=`${state.format} · ${quality}`;
 $('#file-title').textContent=window.nativePreview?.title||(audio?'دابەزاندنی دەنگ...':'دابەزاندنی ڤیدیۆ...');
}
$$('.format').forEach(button=>button.addEventListener('click',()=>{state.format=button.dataset.format;renderSelection()}));
$$('.quality').forEach(button=>button.addEventListener('click',()=>{if(state.format==='MP3')state.audioQuality=button.dataset.quality;else state.videoQuality=button.dataset.quality;renderSelection()}));
function percent(value){
 state.percent=Math.max(0,Math.min(100,Math.round(value)));
 const symbol=document.createElement('span');symbol.textContent='%';$('#percentage').replaceChildren(document.createTextNode(String(state.percent)),symbol);
 $('#progress-fill').style.width=state.percent+'%';$('.track').setAttribute('aria-valuenow',String(state.percent));
}
function stop(){clearInterval(state.timer);state.timer=null;state.running=false;$('#download-label').textContent='دابەزاندن'}
function startOrStop(){
 if(!nativeApp){toast('ئەم ڕووکارە لەناو ئەپی ئەندرۆید بکەرەوە');return}
 if(state.running){if(window.nativeSnapshot?.action==='update'){toast('بزوێنەرەکە خەریکی نوێکردنەوەیە');return}window.VidoraNative.cancel();return}
 if(window.vidoraValidateSource&&!window.vidoraValidateSource()){toast('ئەم لینکە بلۆک کراوە و ناتوانرێت دابەزێندرێت');return}
 const url=readUrl();if(!url){toast('تکایە لینکێکی دروست بنووسە');$('#url').focus();return}
 if(platformFor(url.href)?.audioOnly){state.format='MP3';renderSelection()}
 try{const clip=window.vidoraClipPayload?.(url.href);window.VidoraNative.requestDownload(JSON.stringify({url:url.href,format:state.format,quality:state.format==='MP3'?state.audioQuality:state.videoQuality,clip}));}catch(error){toast(error.message)}
}
$('#download').addEventListener('click',startOrStop);

$('#history').addEventListener('click',()=>openScreen('history'));
$('#update').addEventListener('click',()=>openScreen('engine'));
$('#info').addEventListener('click',()=>openScreen('about'));
$('#thumbnail').addEventListener('click',()=>{if(nativeApp){window.vidoraPlayPreview?.();return}openScreen('file',{id:'current'})});
source();renderSelection();percent(0);
window.addEventListener('pagehide',()=>clearInterval(state.timer));

// Full-screen design previews. No native file or engine actions run in the browser.
const paths={home:'<path d="m3 11 9-8 9 8M5 10v11h5v-7h4v7h5V10"/>',folder:'<path d="M3 6a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11H3Z"/>',refresh:'<path d="M20 8A8 8 0 0 0 6 5L3 8m0-5v5h5M4 16a8 8 0 0 0 14 3l3-3m0 5v-5h-5"/>',settings:'<path d="m9 3 1-1h4l1 3 3 1 3 2-1 3v3l1 3-3 2-3 1-1 2h-4l-1-3-3-1-3-2 1-3v-3L3 7l3-2Z"/><circle cx="12" cy="12" r="3"/>',search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',music:'<path d="M10 18V5l10-2v13M10 8l10-2"/><ellipse cx="6.5" cy="18.5" rx="3.5" ry="2.6"/><ellipse cx="16.5" cy="16.5" rx="3.5" ry="2.6"/>',film:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 8h4m-4 8h4M17 8h4m-4 8h4"/>',star:'<path d="m12 2 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z"/>',palette:'<path d="M12 3a9 9 0 1 0 0 18h2a2 2 0 0 0 1-4c-1-1 0-3 2-3h2a2 2 0 0 0 2-2 9 9 0 0 0-9-9Z"/><path d="M7 9h.01M11 6h.01M16 7h.01M5 13h.01"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 1v2m0 18v2M1 12h2m18 0h2M4 4l2 2m12 12 2 2M4 20l2-2M18 6l2-2"/>',moon:'<path d="M21 13A9 9 0 0 1 11 3a9 9 0 1 0 10 10Z"/>',bell:'<path d="M5 9a7 7 0 0 1 14 0v6l2 3H3l2-3ZM9 21h6"/>',wifi:'<path d="M2 8a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0M8 16a6 6 0 0 1 8 0M12 20h.01"/>',check:'<path d="m5 12 4 4L20 5"/>',info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-11v1"/>',trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',edit:'<path d="m14 4 6 6M4 16 16 4a3 3 0 0 1 4 4L8 20H4Z"/>',download:'<path d="M12 3v13m-6-6 6 6 6-6M4 21h16"/>',shield:'<path d="m12 2 9 4v6c0 5-5 8-9 10-4-2-9-5-9-10V6Z"/><path d="m8 12 3 3 5-6"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9 8a3 3 0 0 1 6 0c0 2-3 2-3 5m0 4h.01"/>'};
function icon(name){return `<svg class="ui-symbol" viewBox="0 0 24 24" aria-hidden="true">${paths[name]||paths.info}</svg>`}
function escapeText(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
const demoFiles=[];
let preferences;try{preferences=JSON.parse(saved.get('vidora-ui-prefs','{}'))||{}}catch{preferences={}}
const prefs={format:['MP4','MP3'].includes(preferences.format)?preferences.format:'MP4',videoQuality:['Best','480p','720p','1080p'].includes(preferences.videoQuality)?preferences.videoQuality:'1080p',audioQuality:['Best','128k','192k','320k'].includes(preferences.audioQuality)?preferences.audioQuality:'320k',wifi:preferences.wifi===true,notifications:preferences.notifications!==false,folder:typeof preferences.folder==='string'?preferences.folder.slice(0,100):'Downloads/VideoDownloader'};
const ui={route:'home',stack:[],search:'',filter:'all',favorites:new Set(['demo-2']),deleted:new Set(),names:new Map(),fileId:'current',lastFocus:null,engine:{progress:0,running:false,complete:false,timer:null}};
function savePreferences(){saved.set('vidora-ui-prefs',JSON.stringify(prefs));window.vidoraConfigureNative?.()}
state.format=prefs.format;state.videoQuality=prefs.videoQuality;state.audioQuality=prefs.audioQuality;renderSelection();
$$('[data-nav-icon]').forEach(el=>el.innerHTML=icon(el.dataset.navIcon));
function files(){return state.entries.filter(file=>!ui.deleted.has(file.id)).map(file=>({...file,title:ui.names.get(file.id)||file.title}))}
function currentFile(){if(window.nativeCurrent)return {...window.nativeCurrent,id:'current'};return {id:'current',title:'دۆخی دابەزاندن',host:readUrl()?.hostname||'—',format:state.format,quality:state.format==='MP3'?state.audioQuality:state.videoQuality,size:'—',time:'ئێستا',url:$('#url').value}}
function getFile(id){return id==='current'?currentFile():files().find(file=>file.id===id)}
function setMainInert(value){[...$('#stage').children].forEach(el=>{if(el.id!=='workspace')el.inert=value})}
function openScreen(route,options={}){
 if(route==='home'){closeScreen();return}
 if(!['history','settings','engine','about','file'].includes(route))return;
 if(ui.route==='home')ui.lastFocus=document.activeElement;
 if(options.push&&ui.route!=='home')ui.stack.push(ui.route);else if(!options.keepStack)ui.stack=[];
 ui.route=route;root.dataset.route=route;if(options.id)ui.fileId=options.id;
 $$('dialog').forEach(dialog=>{if(dialog.open)dialog.close()});
 $('#workspace').hidden=false;setMainInert(true);$('#menu').setAttribute('aria-expanded','true');
 const titles={history:'دابەزاندنەکان',settings:'ڕێکخستنەکان',engine:'بزوێنەری دابەزاندن',about:'دەربارەی ڤیدۆرا',file:'وردەکاریی فایل'};
 $('#screen-title').textContent=titles[route];$('#screen-eyebrow').textContent=route==='file'?'دابەزاندنەکان':'ڤیدۆرا';
 $$('.sub-nav [data-route]').forEach(button=>{const active=button.dataset.route===route||(route==='file'&&button.dataset.route==='history')||(route==='about'&&button.dataset.route==='settings');if(active)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current')});
 if(route==='history')renderHistory();if(route==='settings')renderSettings();if(route==='engine')renderEngine();if(route==='about')renderAbout();if(route==='file')renderFile();
 $('#screen-body').scrollTop=0;$('#screen-title').focus();decorateScreen();
}
function closeScreen(){ui.route='home';root.dataset.route='home';ui.stack=[];$('#workspace').hidden=true;setMainInert(false);$('#menu').setAttribute('aria-expanded','false');ui.lastFocus?.focus?.()}
$('#screen-back').addEventListener('click',()=>{if(ui.stack.length){const route=ui.stack.pop();openScreen(route,{keepStack:true})}else closeScreen()});
$$('.sub-nav [data-route]').forEach(button=>button.addEventListener('click',()=>openScreen(button.dataset.route)));
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&ui.route!=='home'&&!$$('dialog').some(dialog=>dialog.open)){event.preventDefault();$('#screen-back').click()}});
function renderHistory(){
 $('#screen-body').innerHTML=`<div class="glass-panel hero-summary"><div class="icon-tile">${icon('folder')}</div><div><h3>فایلەکانی تۆ</h3><p>ڤیدیۆ و دەنگ، لە یەک شوێندا</p></div><span class="summary-mark" id="file-count"></span></div><label class="glass-action search-box">${icon('search')}<input id="history-search" type="search" aria-label="گەڕان لە فایلەکان" placeholder="گەڕان بە ناو یان ماڵپەڕ..."></label><div class="filter-row" role="group" aria-label="پاڵاوتنی فایلەکان">${[['all','هەموو'],['MP4','ڤیدیۆ'],['MP3','دەنگ'],['favorites','دڵخواز']].map(([value,label])=>`<button class="glass-action" data-filter="${value}" aria-pressed="${ui.filter===value}">${label}</button>`).join('')}</div><div class="list-meta"><span id="list-caption"></span><span class="badge sample-badge">تۆمارەکان</span></div><div id="file-list" class="file-list"></div><p class="soft-note">فایلە دابەزێنراوەکانت لێرە دەبینیت. بۆ بینینی هەموو فایلەکان، بوخچەی Downloads بکەرەوە.</p>`;
 $('#history-search').value=ui.search;$('#history-search').addEventListener('input',event=>{ui.search=event.target.value;renderFileList()});
 $$('[data-filter]').forEach(button=>button.addEventListener('click',()=>{ui.filter=button.dataset.filter;$$('[data-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));renderFileList()}));renderFileList();
}
function coverMarkup(file,large=false){
 let url='assets/video-placeholder.svg';
 if(nativeApp&&file.id&&file.id!=='current')url='https://appassets.androidplatform.net/thumbnails/'+encodeURIComponent(file.id)+'.jpg';
 else if(file.id==='current'&&window.nativePreview?.thumbnail)url=window.nativePreview.thumbnail;
 return `<span class="media-preview ${large?'media-preview-large':'file-cover'} is-loading" aria-busy="true"><img data-real-cover loading="lazy" decoding="async" src="${escapeText(url)}" alt="پێشبینینی ${escapeText(file.title)}"><span class="cover-loader" aria-hidden="true"></span>${large?'<span class="preview-play" aria-hidden="true">▶</span>':''}</span>`;
}
function bindCovers(){
 $$('[data-real-cover]').forEach(image=>{const done=()=>{image.closest('.media-preview')?.classList.remove('is-loading');image.closest('.media-preview')?.setAttribute('aria-busy','false')};image.addEventListener('load',done);image.addEventListener('error',()=>{done();if(!image.dataset.fallback){image.dataset.fallback='true';image.src='assets/video-placeholder.svg';image.alt='پێشبینین بەردەست نییە'}});if(image.complete&&image.naturalWidth)done()});
}
function renderFileList(){
 const all=files();const term=ui.search.trim().toLocaleLowerCase();const filtered=all.filter(file=>(ui.filter==='all'||(ui.filter==='MP4'?file.format!=='MP3':file.format===ui.filter)||(ui.filter==='favorites'&&ui.favorites.has(file.id)))&&`${file.title} ${file.host} ${file.format}`.toLocaleLowerCase().includes(term));
 $('#file-count').textContent=String(all.length).padStart(2,'0');$('#list-caption').textContent=`${filtered.length} فایل`;
 $('#file-list').innerHTML=filtered.length?filtered.map(file=>`<article class="glass-panel file-row"><button class="file-open" data-file-id="${escapeText(file.id)}">${file.format==='MP3'?`<span class="file-cover audio-cover">${icon('music')}</span>`:coverMarkup(file)}<span class="file-copy"><strong>${escapeText(file.title)}</strong><small>${escapeText(file.format)} · ${escapeText(file.quality)} · ${escapeText(file.size)}</small><em>${escapeText(file.time)}</em><span class="file-origin">${platformHTML(file.host)}<span>${escapeText(platformFor(file.host)?.name||file.host)}</span></span></span></button><button class="star-button" data-star="${escapeText(file.id)}" aria-label="دڵخواز: ${escapeText(file.title)}" aria-pressed="${ui.favorites.has(file.id)}">${icon('star')}</button>${nativeApp?`<button class="file-delete-shortcut" data-delete-file="${escapeText(file.id)}" aria-label="سڕینەوەی ${escapeText(file.title)}">${icon('trash')}</button>`:''}</article>`).join(''):`<div class="glass-panel empty-state"><div class="icon-tile">${icon(ui.filter==='favorites'?'star':'search')}</div><h3>${term?'هیچ فایلێک نەدۆزرایەوە':ui.filter==='favorites'?'هێشتا دڵخوازێکت نییە':'هیچ فایلێک نییە'}</h3><p>${term?'بە ناوێکی تر بگەڕێ یان پاڵاوتنەکە بگۆڕە.':'لە لیستی فایلەکان ئەستێرەکە دابگرە بۆ هەڵگرتنی دڵخوازەکانت.'}</p></div>`;
 $$('[data-file-id]').forEach(button=>button.addEventListener('click',()=>openScreen('file',{id:button.dataset.fileId,push:true})));
 $$('[data-delete-file]').forEach(button=>button.addEventListener('click',()=>{const file=getFile(button.dataset.deleteFile);if(file)confirmDeleteFile(file)}));
 bindCovers();
 $$('[data-star]').forEach(button=>button.addEventListener('click',()=>{const id=button.dataset.star;if(ui.favorites.has(id))ui.favorites.delete(id);else ui.favorites.add(id);if(nativeApp)window.VidoraNative.favorite(id,ui.favorites.has(id));renderFileList()}));
}
function settingRow(symbol,title,subtitle,control){return `<div class="setting-row">${icon(symbol)}<span class="setting-copy"><b>${title}</b>${subtitle?`<small>${subtitle}</small>`:''}</span>${control}</div>`}
function renderSettings(){
 const mode=root.dataset.mode;const paletteNames={rainbow:'ڕەنگاوڕەنگ',ocean:'شین و سەوز',silver:'زیوی',gold:'زێڕی',amber:'هەنگوینی'};
 $('#screen-body').innerHTML=`<div class="glass-panel settings-brand"><img src="assets/brand.svg" alt=""><div><h3>ڤیدۆرا</h3><p>بە شێوازی خۆت ڕێکی بخە</p></div><span class="badge">Vidora 2.6</span></div><h3 class="section-caption">ڕەنگ و ڕووناکی</h3><div class="glass-panel settings-group"><button class="setting-row setting-link" id="choose-palette">${icon('palette')}<span class="setting-copy"><b>ڕەنگی ڕووکار</b><small id="chosen-palette">${paletteNames[root.dataset.palette]}</small></span><span class="setting-arrow">‹</span></button><div class="setting-row">${icon('sun')}<span class="setting-copy"><b>دۆخی ڕووناکی</b><small>دۆخێک هەڵبژێرە کە پێی ئاسوودەیت</small></span></div><div class="mode-choices">${[['light','ڕووناک','sun'],['dark','تاریک','moon']].map(([value,label,symbol])=>`<button class="glass-action" data-set-mode="${value}" aria-pressed="${mode===value}">${icon(symbol)}${label}</button>`).join('')}</div></div><h3 class="section-caption">دابەزاندن</h3><div class="glass-panel settings-group">${settingRow('film','جۆری بنەڕەتی','بۆ دابەزاندنی داهاتوو','<select id="default-format" aria-label="جۆری بنەڕەتی"><option value="MP4">MP4 — ڤیدیۆ</option><option value="MP3">MP3 — دەنگ</option></select>')}${settingRow('check','کوالێتی بنەڕەتی','','<select id="default-quality" aria-label="کوالێتی بنەڕەتی"></select>')}${settingRow('wifi','تەنها بە Wi-Fi','ڕێکخستنی پەیوەندیی داگرتن',`<label class="switch"><input id="wifi-pref" type="checkbox" aria-label="تەنها بە Wi-Fi" ${prefs.wifi?'checked':''}><span></span></label>`)}${settingRow('bell','ئاگادارکردنەوە','کاتێک دابەزاندن تەواو دەبێت',`<label class="switch"><input id="notify-pref" type="checkbox" aria-label="ئاگادارکردنەوە" ${prefs.notifications?'checked':''}><span></span></label>`)}<button class="setting-row setting-link" id="storage-pref">${icon('folder')}<span class="setting-copy"><b>بوخچەی دابەزاندن</b><small dir="ltr">${escapeText(prefs.folder)}</small></span><span class="setting-arrow">‹</span></button></div><h3 class="section-caption">زیاتر</h3><div class="glass-panel settings-group"><button class="setting-row setting-link" id="settings-engine">${icon('refresh')}<span class="setting-copy"><b>بزوێنەری دابەزاندن</b><small>پشکنین و نوێکردنەوەی yt-dlp</small></span><span class="setting-arrow">‹</span></button><button class="setting-row setting-link" id="settings-about">${icon('info')}<span class="setting-copy"><b>دەربارەی ڤیدۆرا</b><small>ڕێنمایی و زانیاری</small></span><span class="setting-arrow">‹</span></button></div><p class="soft-note">هەڵبژاردنەکانت لە مۆبایلەکەتدا پاشەکەوت دەکرێن.</p>`;
 $('#choose-palette').addEventListener('click',()=>openDialog($('#settings')));
 $$('[data-set-mode]').forEach(button=>button.addEventListener('click',()=>{setMode(button.dataset.setMode);$$('[data-set-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)))}));
 $('#default-format').value=prefs.format;
 function qualityOptions(){const choices=prefs.format==='MP3'?['Best','128k','192k','320k']:['Best','480p','720p','1080p'];$('#default-quality').innerHTML=choices.map(value=>`<option value="${value}">${value==='Best'?'باشترین':value}</option>`).join('');$('#default-quality').value=prefs.format==='MP3'?prefs.audioQuality:prefs.videoQuality}
 qualityOptions();$('#default-format').addEventListener('change',()=>{prefs.format=$('#default-format').value;state.format=prefs.format;qualityOptions();savePreferences();renderSelection()});
 $('#default-quality').addEventListener('change',()=>{const value=$('#default-quality').value;if(prefs.format==='MP3'){prefs.audioQuality=value;state.audioQuality=value}else{prefs.videoQuality=value;state.videoQuality=value}savePreferences();renderSelection()});
 $('#wifi-pref').addEventListener('change',event=>{prefs.wifi=event.target.checked;savePreferences()});$('#notify-pref').addEventListener('change',event=>{prefs.notifications=event.target.checked;savePreferences()});
 $('#storage-pref').addEventListener('click',()=>{details('بوخچەی دابەزاندن','بوخچەی فایلە نوێکان لەناو Downloads هەڵبژێرە؛ فایلە کۆنەکان ناگوازرێنەوە.');const input=document.createElement('input');input.className='folder-input';input.id='folder-name';input.maxLength=100;input.dir='ltr';input.setAttribute('aria-label','ناوی بوخچە');input.value=prefs.folder;const button=document.createElement('button');button.className='glass-action dialog-action';button.textContent='پاشەکەوتکردن';button.addEventListener('click',()=>{if(!input.value.trim())return;prefs.folder=input.value.trim();savePreferences();$('#details').close();renderSettings();toast('ناوی بوخچەکە پاشەکەوت کرا')});$('#dialog-content').append(input,button)});
 $('#settings-engine').addEventListener('click',()=>openScreen('engine',{push:true}));$('#settings-about').addEventListener('click',()=>openScreen('about',{push:true}));
}
$('#settings').addEventListener('close',()=>{if(ui.route==='settings'){const names={rainbow:'ڕەنگاوڕەنگ',ocean:'شین و سەوز',silver:'زیوی',gold:'زێڕی',amber:'هەنگوینی'};const el=$('#chosen-palette');if(el)el.textContent=names[root.dataset.palette]}$('#menu').setAttribute('aria-expanded',String(ui.route!=='home'))});
function renderEngine(){
 $('#screen-body').innerHTML=`<div class="glass-panel engine-hero"><div class="engine-symbol">${icon('refresh')}</div><h3 dir="ltr">yt-dlp</h3><span class="badge">بزوێنەری دابەزاندن</span><p>بزوێنەرەکەت ئامادە بێت بۆ دابەزاندنی ڤیدیۆ و دەنگ.</p><div class="engine-version"><span>وەشانی ئێستا</span><b id="native-engine-version">—</b></div><div class="engine-track" id="engine-track" role="progressbar" aria-label="پێشکەوتنی پشکنین" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="engine-fill" id="engine-fill"></div></div><div class="engine-state"><span id="engine-message">ئامادەی پشکنینە</span><b id="engine-percent">0%</b></div><button id="engine-check" class="primary-action full-width">${icon('refresh')}<span id="engine-button-label">پشکنینی نوێکردنەوە</span></button></div><div class="glass-panel engine-steps">${['پشکنینی پەیوەندی','پشکنینی وەشان','ئامادەکردن','تەواوکردن'].map((text,index)=>`<div class="engine-step" data-engine-step="${index}"><span class="step-dot">${index+1}</span><b>${text}</b></div>`).join('')}</div><h3 class="section-caption">زانیاریی بزوێنەر</h3><div class="glass-panel"><div class="version-row"><span>بزوێنەر</span><strong>yt-dlp</strong></div><div class="version-row"><span>جۆرەکان</span><strong>MP4 / MP3</strong></div><div class="version-row"><span>دۆخ</span><span class="badge sample-badge">ئەندرۆید</span></div></div><p class="soft-note">بۆ نوێکردنەوەی بزوێنەر، ئینتەرنێت پێویستە. کاتێک دابەزاندن بەردەوامە، چاوەڕێی تەواوبوونی بکە.</p>`;
 $('#engine-check').addEventListener('click',()=>window.vidoraEngineAction?.());renderEngineState();
}
function renderEngineState(){window.vidoraRenderEngine?.()}
function renderFile(){
 const file=getFile(ui.fileId);if(!file){openScreen('history');return}
 const current=file.id==='current';
 $('#screen-body').innerHTML=`<div class="glass-panel file-hero"><div class="file-visual">${file.format==='MP3'?icon('music'):coverMarkup(file,true)}</div><div class="file-title-block"><h3>${escapeText(file.title)}</h3><p class="file-detail-origin">${platformHTML(file.host)}<span>${escapeText(file.host)}</span></p><div class="file-badges"><span class="badge">${escapeText(file.format)}</span><span class="badge">${escapeText(file.quality)}</span><span class="badge sample-badge">فایلی دابەزێنراو</span></div></div></div><dl class="glass-panel file-properties">${[['قەبارە',file.size],['کوالێتی',file.quality],['جۆری فایل',file.format],['کات',file.time],['شوێن',prefs.folder],['دۆخ',current?state.running?'دابەزاندن بەردەوامە':`${state.percent}%`:'پاشەکەوت کراوە']].map(([label,value])=>`<div class="file-property"><dt>${label}</dt><dd>${escapeText(value)}</dd></div>`).join('')}</dl><button id="file-reuse" class="primary-action full-width">${icon('download')}بەکارهێنانەوەی لینک</button>${current?'':`<div class="file-actions"><button id="file-rename" class="glass-action">${icon('edit')}گۆڕینی ناو</button><button id="file-favorite" class="glass-action">${icon('star')}${ui.favorites.has(file.id)?'لابردنی دڵخواز':'زیادکردنی دڵخواز'}</button></div><div class="file-actions"><button id="file-delete" class="glass-action danger-action">${icon('trash')}سڕینەوە لە مۆبایل</button></div><button id="file-remove" class="glass-action full-width history-hide">شاردنەوە لە لیست</button>`}<p class="soft-note">«سڕینەوە لە مۆبایل» فایلەکە دەسڕێتەوە؛ «شاردنەوە لە لیست» تەنها تۆمارەکە دەشارێتەوە.</p>`;
 if(nativeApp&&file.id!=='current'){
 const open=document.createElement('button');open.className='primary-action full-width';open.textContent='کردنەوەی فایل';open.addEventListener('click',()=>window.VidoraNative.openFile(file.id));$('#file-reuse').before(open);$('#file-reuse').style.marginTop='15px';
 bindCovers();
 $('.file-visual').setAttribute('role','button');$('.file-visual').tabIndex=0;
 $('.file-visual').addEventListener('click',()=>window.VidoraNative.openFile(file.id));
 $('.file-visual').addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' ')window.VidoraNative.openFile(file.id)});
 const audio=(file.mime||'').startsWith('audio/')||file.format==='MP3';const video=(file.mime||'').startsWith('video/')||['MP4','WEBM','MKV','MOV'].includes(file.format);
 if(audio||video){const convert=document.createElement('button');convert.id='file-convert';convert.className='glass-action full-width';convert.style.marginTop='15px';convert.textContent=audio?'کردن بە ڤیدیۆ — پاشبنەمای ڤیدۆرا':'دەرهێنانی دەنگ — MP3';convert.addEventListener('click',()=>{window.VidoraNative.requestConversion(file.id,audio?'MP4':'MP3');closeScreen()});$('#file-reuse').before(convert)}

 }
 $('#file-reuse').addEventListener('click',()=>{$('#url').value=file.url;source();state.format=file.format==='MP3'?'MP3':'MP4';if(file.format==='MP3')state.audioQuality=['Best','128k','192k','320k'].includes(file.quality)?file.quality:'Best';else state.videoQuality=['Best','480p','720p','1080p'].includes(file.quality)?file.quality:'Best';renderSelection();closeScreen();window.vidoraInspect?.();toast('لینک و هەڵبژاردنەکان گەڕانەوە بۆ پەڕەی سەرەکی')});
 if(current)return;
 $('#file-favorite').addEventListener('click',()=>{if(ui.favorites.has(file.id))ui.favorites.delete(file.id);else ui.favorites.add(file.id);if(nativeApp)window.VidoraNative.favorite(file.id,ui.favorites.has(file.id));renderFile()});
 $('#file-rename').addEventListener('click',()=>{details('گۆڕینی ناوی فایل','ناوێکی نوێ بۆ فایلەکە بنووسە. پاشگرەکەی دەپارێزرێت.');const input=document.createElement('input');input.className='folder-input';input.id='file-name-input';input.maxLength=80;input.dir='auto';input.setAttribute('aria-label','ناوی فایل');input.value=file.title;const button=document.createElement('button');button.className='glass-action dialog-action';button.textContent='پاشەکەوتکردن';button.addEventListener('click',()=>{if(!input.value.trim())return;if(nativeApp){window.VidoraNative.renameFile(file.id,input.value.trim());$('#details').close();return}ui.names.set(file.id,input.value.trim());$('#details').close();renderFile();toast('ناوی نموونەکە گۆڕدرا')});$('#dialog-content').append(input,button)});
 $('#file-delete').addEventListener('click',()=>confirmDeleteFile(file));
 $('#file-remove').addEventListener('click',()=>{ui.deleted.add(file.id);if(nativeApp)window.VidoraNative.removeHistory(file.id,true);openScreen('history');toast('فایلەکە لە مێژوو لابرا');const undo=document.createElement('button');undo.className='undo-button';undo.textContent='گەڕاندنەوە';undo.addEventListener('click',()=>{ui.deleted.delete(file.id);if(nativeApp)window.VidoraNative.removeHistory(file.id,false);$('#toast').classList.remove('visible');if(ui.route==='history')renderFileList()});$('#toast').append(undo)});
}
function confirmDeleteFile(file){
 if(!nativeApp)return toast('سڕینەوە تەنها لە ئەپی ئەندرۆید بەردەستە');
 details('سڕینەوەی فایل','ئەم فایلە لە مۆبایلەکەت دەسڕدرێتەوە و ناگەڕێتەوە.');
 const preview=document.createElement('div');preview.className='delete-file-preview';
 const title=document.createElement('strong');title.textContent=file.title;const info=document.createElement('small');info.textContent=[file.format,file.size].join(' · ');preview.append(title,info);
 const actions=document.createElement('div');actions.className='delete-confirm-actions';
 const cancel=document.createElement('button');cancel.className='glass-action';cancel.textContent='نەخێر، بیهێڵەوە';cancel.addEventListener('click',()=>$('#details').close());
 const confirm=document.createElement('button');confirm.id='delete-file-confirm';confirm.className='glass-action danger-solid';confirm.textContent='بەڵێ، بسڕەوە';
 confirm.addEventListener('click',()=>{confirm.disabled=true;cancel.disabled=true;confirm.textContent='خەریکی سڕینەوەیە...';window.VidoraNative.deleteFile(file.id)});
 actions.append(cancel,confirm);$('#dialog-content').append(preview,actions);
}
window.vidoraFileDeleted=result=>{
 if(result.status==='deleted'){ui.deleted.add(result.id);$('#details').close();if(ui.route==='file')openScreen('history');else if(ui.route==='history')renderFileList();toast(result.message||'فایلەکە سڕایەوە')}
 else if(result.status==='cancelled'){$('#details').close();toast(result.message)}
 else{const button=$('#delete-file-confirm');if(button){button.disabled=false;button.textContent='دووبارە هەوڵ بدە'}$$('.delete-confirm-actions button').forEach(b=>b.disabled=false);toast(result.message||'فایلەکە نەسڕایەوە')}
};
function renderAbout(){
 $('#screen-body').innerHTML=`<div class="glass-panel about-hero"><img src="assets/brand.svg" alt="لۆگۆی ڤیدۆرا"><h3>ڤیدۆرا</h3><p>ڤیدیۆ و دەنگ، بە شێوەیەکی ئاسان و ڕوون.</p><span class="badge">Vidora 2.6</span></div><div class="glass-panel supported-note"><h3>پاراستنی ناوەڕۆک چالاکە</h3><p>ماڵپەڕە سێکسی/18+ و قومارە ناسراوەکان بلۆک کراون؛ ناوەڕۆکی بە نیشانی 18+ ڕەت دەکرێتەوە. لیستەکە ناتوانێت هەموو ناوەڕۆکێکی نەشیاو لە هەموو ماڵپەڕێک بناسێتەوە.</p><p>بۆ پێشبینین، لینک دابنێ و وێنۆچکەکە دابگرە. هەندێک فۆرمات تەنها دوای داگرتن دەکرێت ببینرێت. گۆڕینی دەنگ بۆ ڤیدیۆ، ڤیدیۆیەکی نوێ بە پاشبنەمای ڤیدۆرا دروست دەکات.</p></div><h3 class="section-caption">ئایکۆنی ماڵپەڕەکان</h3><div class="glass-panel platform-gallery">${socialPlatforms.map(platform=>`<button class="platform-example" data-platform-example="${platform.id}">${platformHTML(platform.domains[0])}<span>${platform.name}</span></button>`).join('')}</div><div class="glass-panel supported-note"><h3>ماڵپەڕی زۆر، هەمان شێواز</h3><p>لینکی ڤیدیۆ یان دەنگ لە ماڵپەڕە پشتیوانیکراوەکانی yt-dlp دابنێ؛ ئەپەکە تەنها بە ئەم لیستە سنووردار نییە.</p><p>Pinterest و pin.it، Snapchat Spotlight، Instagram Reels/Posts/Stories گشتی، و ماڵپەڕەکانی تر.</p><p><b>TikTok:</b>فۆرماتی بە نیشانی Watermark ڕەت دەکرێتەوە؛ فۆرماتی بێ نیشان ئەگەر بەردەست بێت هەڵدەبژێردرێت. نیشانی ناو خودی ڤیدیۆ لابراو نییە.</p><p><b>Instagram Stories:</b>هەندێک لینکی گشتیش داوای چوونەژوورەوە دەکات؛ ئەم وەشانە Cookie یان چوونەژوورەوە بەکارناهێنێت.</p></div><h3 class="section-caption">چۆن بەکاری بهێنیت</h3><div class="glass-panel">${[['لینکەکە بلکێنە','لینکی ڤیدیۆکەت لە خانەی سەرەوە دابنێ.'],['جۆر و کوالێتی هەڵبژێرە','MP4 بۆ ڤیدیۆ، MP3 بۆ دەنگ.'],['دابەزاندن دەست پێ بکە','پێشکەوتنی ڕاستەقینەی دابەزاندن دەبینیت.']].map(([title,description],index)=>`<div class="help-step"><span class="step-dot">${index+1}</span><div><strong>${title}</strong><p>${description}</p></div></div>`).join('')}</div><h3 class="section-caption">زانیاری</h3><div class="glass-panel settings-group"><button class="setting-row setting-link" id="copy-diagnostics">${icon('info')}<span class="setting-copy"><b>کۆپیکردنی ڕاپۆرتی هەڵە</b><small>بۆ دۆزینەوەی هۆکاری کێشەی داگرتن</small></span><span class="setting-arrow">‹</span></button><button class="setting-row setting-link" id="privacy-info">${icon('shield')}<span class="setting-copy"><b>زانیاریی پاشەکەوتکردن</b><small>هەڵبژاردنەکان لە مۆبایلەکەت</small></span><span class="setting-arrow">‹</span></button><button class="setting-row setting-link" id="preview-help">${icon('help')}<span class="setting-copy"><b>دەربارەی ئەپەکە</b><small>ڤیدیۆ و دەنگ لە ماڵپەڕە پشتگیریکراوەکان</small></span><span class="setting-arrow">‹</span></button></div><p class="soft-note">فایلەکان لە بوخچەی Downloads پاشەکەوت دەکرێن. تەنها ناوەڕۆکی ڕێگەپێدراو دابەزێنە.</p>`;
 $$('[data-platform-example]').forEach(button=>button.addEventListener('click',()=>{const platform=socialPlatforms.find(p=>p.id===button.dataset.platformExample);if(!platform)return;if(nativeApp){toast('لینکی ڤیدیۆی '+platform.name+' لە پەڕەی سەرەکی دابنێ');return}$('#url').value=platform.example;source();closeScreen();toast('لینکی نموونەی '+platform.name+' دانرا')}));
 $('#copy-diagnostics').addEventListener('click',()=>window.VidoraNative?.copyDiagnostics());
 $('#privacy-info').addEventListener('click',()=>details('زانیاریی پاشەکەوتکردن','هەڵبژاردنەکان و مێژوو لە مۆبایلەکەت پاشەکەوت دەکرێن. فایلەکان لە Downloads ـدان.'));
 $('#preview-help').addEventListener('click',()=>details('دەربارەی ئەپەکە','لینکی ڤیدیۆکە بلکێنە، جۆر و کوالێتی هەڵبژێرە، پاشان دابەزاندن دەست پێ بکە. لە کاتی کارکردندا دەتوانیت هەڵیوەشێنیتەوە.'));
}
window.addEventListener('pagehide',()=>clearInterval(ui.engine.timer));

// Secondary screens reuse the exact image skins used by the home controls.
function decorateScreen(){
 const workspace=$('#workspace');
 const elements=workspace.querySelectorAll('.glass-panel,.glass-action,.primary-action,.icon-tile,.engine-symbol,.sub-nav,.sub-nav button');
 for(const element of elements){
  let name='site';
  if(element.classList.contains('glass-panel'))name='card';
  if(element.classList.contains('sub-back'))name='menu';
  if(element.classList.contains('primary-action'))name='download';
  if(element.classList.contains('icon-tile')||element.classList.contains('engine-symbol'))name='menu';
  if(element.classList.contains('sub-nav'))name='formatBar';
  if(element.getAttribute('aria-current')==='page'||element.getAttribute('aria-pressed')==='true')name='qualityOn';
  if(element.matches('.filter-row button,.mode-choices button,.sub-nav button')&&element.getAttribute('aria-current')!=='page'&&element.getAttribute('aria-pressed')!=='true')name='qualityOff';
  let layer=[...element.children].find(child=>child.classList.contains('shared-home-skin'));
  if(!layer){layer=document.createElement('span');layer.className='skin shared-home-skin';layer.setAttribute('aria-hidden','true');element.prepend(layer)}
  skin(layer,name);
 }
}
if(typeof MutationObserver!=='undefined')new MutationObserver(decorateScreen).observe($('#workspace'),{subtree:true,childList:true,attributes:true,attributeFilter:['aria-pressed','aria-current']});
