Vidora Android UI assets

Loaded offline at https://appassets.androidplatform.net/assets/ui/index.html by MainActivity.
app.js contains the approved visual screens and controls. native.js connects them to the app-owned VidoraNative interface. native.css fits the screen to the Android window.

The native app has no simulated download/engine timers or seeded files. Percentages, history and engine version come from DownloadService and native storage.
Noto Sans Arabic license: assets/fonts/OFL.txt
