'use strict';
if(nativeApp){
 root.classList.add('native-app');let booted=false;let previousStatus='idle';let historyDigest='';window.nativeSnapshot=null;window.nativePreview=null;window.nativeSourceBlocked=false;let blockedReason='';let previewRequest=0;let previewTimer=null;let previewUrl='';
 function nativeFit(){const scale=$('.viewport').clientWidth/720;root.style.setProperty('--native-window-height',window.innerHeight+'px');root.style.setProperty('--native-stage-height',Math.max(1280,window.innerHeight/scale)+'px')}
 window.addEventListener('resize',nativeFit);nativeFit();
 window.vidoraConfigureNative=()=>{if(booted)window.VidoraNative.configure(JSON.stringify({...prefs,mode:root.dataset.mode,palette:root.dataset.palette}))};
 window.vidoraNotice=text=>toast(text);
 window.vidoraSettingsSaved=settings=>{Object.assign(prefs,settings);saved.set('vidora-ui-prefs',JSON.stringify(prefs));const label=$('#storage-pref small');if(label)label.textContent=prefs.folder};
 window.vidoraNewSession=()=>{clearTimeout(toastTimer);$('#toast').classList.remove('visible');$('#url').value='';window.nativeCurrent=null;window.nativePreview=null;source();window.vidoraInspect()};
 window.vidoraSetUrl=value=>{$('#url').value=value;source();closeScreen();$('#url').focus();window.vidoraInspect()};
 function previewLabel(){
  const value=window.nativePreview;if(!value||state.running)return;
  $('#file-title').textContent=value.title;if(value.url!==window.nativeSnapshot?.url)percent(0);
  $('#file-details').textContent=(value.duration>0?Math.floor(value.duration/60)+':'+String(value.duration%60).padStart(2,'0')+' · ':'')+'بۆ بینین وێنەکە دابگرە'+(value.watermark==='original_rendition'?' · سەرچاوەی سەرەکیی Snapchat':value.watermark==='declared_clean'?' · وەشانی بێ‌لۆگۆی سەرچاوە':value.watermark==='marked'?' · لۆگۆ لە خودی سەرچاوەکەدایە':platformFor(value.url)?.id==='snapchat'?' · لۆگۆی ناو خودی فایل دەمێنێتەوە':'');
 }
 window.vidoraValidateSource=()=>{
  const url=readUrl()?.href||'';window.nativeSourceBlocked=false;blockedReason='';
  if(url){try{const result=JSON.parse(window.VidoraNative.validateSource(url));window.nativeSourceBlocked=!result.allowed;blockedReason=result.message||'لینکەکە ڕێگەپێنەدراوە'}catch{window.nativeSourceBlocked=true;blockedReason='پشکنینی پاراستن بەردەست نییە؛ ئەپەکە نوێ بکەرەوە'}}
  $('.site-card').classList.toggle('source-blocked',window.nativeSourceBlocked);
  $('#valid').textContent=window.nativeSourceBlocked?'×':url?'✓':'·';
  $('.site-label').textContent=window.nativeSourceBlocked?'بلۆک کراوە':url?'لینکی ڕێگەپێدراو':'ماڵپەڕی ڤیدیۆ';
  $('#download').disabled=window.nativeSourceBlocked&&!state.running;
  $('#download').setAttribute('aria-disabled',String($('#download').disabled));
  if(window.nativeSourceBlocked&&!state.running){$('#status-text').textContent=blockedReason;$('#file-title').textContent='ناتوانرێت دابەزێندرێت — بلۆک کراوە';percent(0)}
  return !window.nativeSourceBlocked;
 };
 window.vidoraInspect=()=>{
  clearTimeout(previewTimer);const requestId=++previewRequest;const url=readUrl()?.href||'';previewUrl=url;window.nativePreview=null;window.vidoraClipSource?.(null,url);
  const image=$('#thumbnail img');if(image){image.src='assets/thumbnail.svg';image.alt='پێشبینینی ڤیدیۆ'}
  if(!state.running){percent(0);$('#file-title').textContent=url?'چاوەڕێی پێشبینین...':'ئامادەیە بۆ دابەزاندن';$('#file-details').textContent=state.format}
  if(!window.vidoraValidateSource()||!url)return;
  previewTimer=setTimeout(()=>{if(!state.running)$('#status-text').textContent='خەریکی پێشبینینی لینکە...';window.VidoraNative.inspect(JSON.stringify({url,requestId}))},850);
 };
 $('#url').addEventListener('input',window.vidoraInspect);$('#clear').addEventListener('click',window.vidoraInspect);
 window.vidoraPreview=value=>{
  if(value.requestId!==previewRequest||value.url!==previewUrl)return;
  if(value.status==='ready'){
   window.nativePreview=value;window.vidoraClipSource?.(value,value.url);previewLabel();
   const image=$('#thumbnail img');if(image&&value.thumbnail){image.src=value.thumbnail;image.alt=value.title}
   if(!state.running)$('#status-text').textContent=value.playable?'پێشبینین ئامادەیە؛ وێنەکە دابگرە':'سەرەتا دایبەزێنە بۆ بینین';
  }else{window.nativePreview=null;window.vidoraClipSource?.({durationMs:0,clipAllowed:false},value.url);if(!state.running){$('#file-title').textContent=value.blocked?'لینکەکە بلۆک کراوە':'پێشبینین بەردەست نییە';$('#status-text').textContent=value.blocked?value.message:'پێشبینین سەرکەوتوو نەبوو؛ دەتوانیت داگرتن تاقی بکەیتەوە'}if(value.blocked)toast(value.message)}
 };
 window.vidoraPlayPreview=()=>{
  const value=window.nativePreview;
  if(value?.playable){window.VidoraNative.playPreview(value.token);return}
  if(window.nativeCurrent?.id&&window.nativeCurrent.id!=='current'&&window.nativeCurrent.url===(readUrl()?.href||'')){window.VidoraNative.openFile(window.nativeCurrent.id);return}
  toast('لینک دابنێ و چاوەڕێی پێشبینین بکە؛ یان سەرەتا فایلەکە دابەزێنە');
 };
 window.vidoraBack=()=>{const dialog=$$('dialog').find(d=>d.open);if(dialog){dialog.close();return true}if(ui.route!=='home'){$('#screen-back').click();return true}return false};
 window.vidoraEngineAction=()=>{const snapshot=window.nativeSnapshot;if(snapshot?.running){if(snapshot.action==='update')window.VidoraNative.cancel();else toast('سەرەتا دابەزاندنەکە تەواو بکە یان هەڵیوەشێنەوە')}else window.VidoraNative.updateEngine()};
 window.vidoraRenderEngine=()=>{
  const snapshot=window.nativeSnapshot;if(!snapshot||!$('#engine-fill'))return;
  const update=snapshot.action==='update';const busy=update&&snapshot.running;
  const value=update?snapshot.progress:0;
  $('#engine-fill').style.width=value+'%';$('#engine-percent').textContent=value+'%';$('#engine-track').setAttribute('aria-valuenow',String(value));
  $('#engine-message').textContent=update?snapshot.message:'ئامادەی پشکنینە';$('#engine-button-label').textContent=busy?'هەڵوەشاندنەوە':'پشکنینی نوێکردنەوە';
  const version=$('#native-engine-version');if(version)version.textContent=snapshot.engineVersion||'—';
  $$('[data-engine-step]').forEach((row,index)=>{const done=update&&snapshot.status==='success';row.classList.toggle('done',done);row.classList.toggle('current',busy&&index===0);row.querySelector('.step-dot').textContent=done?'✓':String(index+1)});
 };
 function nativeHistoryTools(){
  if(ui.route!=='history'||$('#open-system-downloads'))return;
  const button=document.createElement('button');button.id='open-system-downloads';button.className='glass-action native-downloads-link';button.textContent='کردنەوەی بوخچەی Downloads';button.addEventListener('click',()=>window.VidoraNative.openDownloads());$('#screen-body').append(button);decorateScreen();
 }
 window.vidoraReceive=snapshot=>{
  const firstSnapshot=!booted;window.nativeSnapshot=snapshot;
  if(!booted){Object.assign(prefs,snapshot.settings||{});state.format=prefs.format;state.videoQuality=prefs.videoQuality;state.audioQuality=prefs.audioQuality;setPalette(snapshot.settings?.palette||'rainbow');setMode(snapshot.settings?.mode||'dark');renderSelection();booted=true;window.vidoraConfigureNative()}
  const digest=JSON.stringify(snapshot.history||[]);const historyChanged=digest!==historyDigest;historyDigest=digest;state.entries=Array.isArray(snapshot.history)?snapshot.history:[];ui.favorites=new Set(state.entries.filter(item=>item.favorite).map(item=>item.id));
  state.running=!!snapshot.running;window.vidoraClipBusy?.(state.running);percent(snapshot.progress||0);const preparing=state.running&&(snapshot.progress||0)<=0&&['preparing','connecting'].includes(snapshot.phase||'preparing');$('.progress-card').classList.toggle('is-preparing',preparing);$('.track').setAttribute('aria-busy',String(preparing));if(preparing){$('.track').removeAttribute('aria-valuenow');$('.track').setAttribute('aria-valuetext','ئامادەکردنی داگرتن');$('#percentage').setAttribute('aria-label','ئامادەکردنی داگرتن')}else{$('.track').removeAttribute('aria-valuetext');$('#percentage').removeAttribute('aria-label')};$('#status-text').textContent=snapshot.message||'ئامادەیە بۆ دابەزاندن';
  const current=snapshot.url?state.entries.find(item=>item.url===snapshot.url):null;
  if(current&&snapshot.status==='success'&&!window.nativePreview?.thumbnail){const image=$('#thumbnail img');if(image){const cover='https://appassets.androidplatform.net/thumbnails/'+encodeURIComponent(current.id)+'.jpg';if(image.src!==cover)image.src=cover;image.alt=current.title}}
  window.nativeCurrent=current||{id:'current',title:snapshot.title||'دۆخی دابەزاندن',host:platformFor(snapshot.url)?.name||(readUrl()?.hostname||'—'),format:snapshot.format||state.format,quality:snapshot.quality||'—',size:'—',time:'ئێستا',url:snapshot.url||$('#url').value};
  $('#file-title').textContent=snapshot.action==='update'?'نوێکردنەوەی بزوێنەر':snapshot.title|| (snapshot.running?'دابەزاندن بەردەوامە...':snapshot.status==='success'?'دابەزاندن تەواو بوو':'ئامادەیە بۆ دابەزاندن');
  $('#file-details').textContent=current?[current.format,current.quality,current.size].join(' · '):[snapshot.action==='idle'?state.format:(snapshot.format||state.format),snapshot.action==='idle'?(state.format==='MP3'?state.audioQuality:state.videoQuality):(snapshot.quality||'—')].join(' · ');
  $('#download-label').textContent=snapshot.running&&snapshot.action!=='update'?'هەڵوەشاندنەوە':'دابەزاندن';
  const build=$('#native-build-version');if(build)build.textContent='ڤیدۆرا '+(snapshot.appVersion||'2.6')+' • پاراستن چالاکە';
  const engineVersion=$('.update small');if(engineVersion)engineVersion.textContent='وەشانی ئێستا: '+(snapshot.engineVersion||'—');
  if(snapshot.sharedUrl)window.vidoraSetUrl(snapshot.sharedUrl);
  previewLabel();window.vidoraValidateSource();
  if(ui.route==='history'){const input=$('#history-search');ui.search=input?.value||ui.search;if(historyChanged)renderFileList();nativeHistoryTools()}
  if(ui.route==='file')renderFile();
  if(ui.route==='engine')window.vidoraRenderEngine();
  if(!firstSnapshot&&previousStatus!==snapshot.status&&['error','cancelled','interrupted'].includes(snapshot.status))toast(snapshot.message);
  previousStatus=snapshot.status;
 };
 new MutationObserver(nativeHistoryTools).observe($('#screen-body'),{childList:true});
 window.VidoraNative.ready();
}
