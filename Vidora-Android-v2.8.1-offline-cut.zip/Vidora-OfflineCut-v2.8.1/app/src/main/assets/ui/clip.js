'use strict';
(function(){
 const q=id=>document.getElementById(id),dialog=q('clip-dialog');
 let media=null,source='',selected=null,draft={startMs:0,endMs:0},busy=false,invalid=false;
 const clock=ms=>{const s=Math.floor(ms/1000);return String(Math.floor(s/3600)).padStart(2,'0')+':'+String(Math.floor(s/60)%60).padStart(2,'0')+':'+String(s%60).padStart(2,'0')};
 function parse(text){const digits=String(text).trim().replace(/[٠-٩۰-۹]/g,c=>String(c.charCodeAt(0)-(c>='۰'?1776:1632)));if(!/^\d+(?::\d{1,2}){0,2}$/.test(digits))return null;const a=digits.split(':').map(Number);if(a.length>1&&a.at(-1)>59||a.length===3&&a[1]>59)return null;const seconds=a.reduce((n,v)=>n*60+v,0);return Number.isSafeInteger(seconds)&&seconds>=0?seconds*1000:null;}
 function available(){return !!media&&media.durationMs>=1000&&media.clipAllowed!==false}
 function message(text){q('clip-error').textContent=text;q('clip-error').hidden=!text}
 function mode(){q('clip-all').setAttribute('aria-pressed',String(!selected));q('clip-part').setAttribute('aria-pressed',String(!!selected));q('clip-choice-note').textContent=selected?clock(selected.startMs)+' — '+clock(selected.endMs):'تەواوی ڤیدیۆ یان دەنگەکە';q('clip-all').disabled=busy;q('clip-part').disabled=busy;}
 function render(){
  const ready=available();q('clip-editor').hidden=!ready;q('clip-wait').hidden=ready;q('clip-apply').disabled=!ready||invalid||busy;
  q('clip-wait').textContent=media?'درێژی ئەم سەرچاوەیە بۆ بڕین دیار نییە؛ هەمووی هەڵبژێرە.':source?'چاوەڕێی پێشبینینی لینکە؛ درێژی ڤیدیۆ یان دەنگ دەردەکەوێت.':'سەرەتا لینکی ڤیدیۆ یان دەنگ دابنێ.';
  if(!ready)return;
  for(const id of ['clip-start-range','clip-end-range']){q(id).min=0;q(id).max=media.durationMs;q(id).step=1;}
  q('clip-start-range').value=draft.startMs;q('clip-end-range').value=draft.endMs;
  q('clip-start-range').setAttribute('aria-valuetext',clock(draft.startMs));q('clip-end-range').setAttribute('aria-valuetext',clock(draft.endMs));
  if(!invalid){q('clip-start-time').value=clock(draft.startMs);q('clip-end-time').value=clock(draft.endMs);for(const id of ['clip-start-time','clip-end-time'])q(id).removeAttribute('aria-invalid');}
  q('clip-source-end').textContent=clock(media.durationMs);q('clip-length').textContent=clock(draft.endMs-draft.startMs);
  q('clip-range-fill').style.left=(draft.startMs/media.durationMs*100)+'%';q('clip-range-fill').style.right=(100-draft.endMs/media.durationMs*100)+'%';
 }
 function start(){if(busy)return;invalid=false;message('');draft=selected?{startMs:selected.startMs,endMs:selected.endMs}:{startMs:0,endMs:media?.durationMs||0};render();openDialog(dialog);}
 q('clip-part').addEventListener('click',start);
 q('clip-all').addEventListener('click',()=>{selected=null;mode()});
 for(const which of ['start','end'])q('clip-'+which+'-range').addEventListener('input',()=>{
  if(!available())return;invalid=false;message('');let value=Number(q('clip-'+which+'-range').value);value=value>=media.durationMs-500?media.durationMs:Math.round(value/1000)*1000;
  if(which==='start')draft.startMs=Math.max(0,Math.min(value,draft.endMs-1000));else draft.endMs=Math.min(media.durationMs,Math.max(value,draft.startMs+1000));render();
 });
 for(const which of ['start','end'])q('clip-'+which+'-range').addEventListener('keydown',event=>{
  if(!available())return;const delta={ArrowRight:1000,ArrowUp:1000,ArrowLeft:-1000,ArrowDown:-1000,PageUp:60000,PageDown:-60000}[event.key];
  if(delta===undefined&&!['Home','End'].includes(event.key))return;event.preventDefault();
  const input=q('clip-'+which+'-range');input.value=event.key==='Home'?0:event.key==='End'?media.durationMs:Number(input.value)+delta;input.dispatchEvent(new window.Event('input'));
 });
 function times(){
  const start=parse(q('clip-start-time').value),end=parse(q('clip-end-time').value);
  invalid=start===null||end===null||start<0||end>media.durationMs||end-start<1000;
  // Keep the exact fractional endpoint when its displayed whole-second time was not edited.
  const actualEnd=end===Math.floor(media.durationMs/1000)*1000&&q('clip-end-range').value==media.durationMs?media.durationMs:end;
  if(!invalid){draft={startMs:start,endMs:actualEnd};message('')}else{message('کاتەکان وەک 00:10:00 بنووسە؛ کۆتایی دوای سەرەتا و لە سنووری سەرچاوەکە بێت.');q('clip-start-time').setAttribute('aria-invalid','true');q('clip-end-time').setAttribute('aria-invalid','true');}
  render();
 }
 for(const id of ['clip-start-time','clip-end-time'])q(id).addEventListener('change',()=>{if(available())times()});
 for(const button of dialog.querySelectorAll('[data-clip-preset]'))button.addEventListener('click',()=>{
  if(!available())return;invalid=false;message('');const n=Math.min(600000,media.durationMs),v=button.dataset.clipPreset;
  const start=v==='last'?media.durationMs-n:v==='middle'?Math.floor((media.durationMs-n)/2):0;draft={startMs:start,endMs:start+n};render();
 });
 q('clip-apply').addEventListener('click',()=>{
  if(!available()||invalid||busy)return;
  if(draft.startMs<0||draft.endMs>media.durationMs||draft.endMs-draft.startMs<1000)return;
  selected={token:media.token,startMs:draft.startMs,endMs:draft.endMs};mode();dialog.close();
 });
 window.vidoraClipSource=(value,url='')=>{
  source=url;const previous=media;media=value?{...value,durationMs:Number(value.durationMs??Number(value.duration)*1000)}:null;
  if(!media||!previous||media.token!==previous.token){selected=null;invalid=false;draft={startMs:0,endMs:media?.durationMs||0};message('')}
  mode();render();
 };
 window.vidoraClipBusy=value=>{busy=!!value;mode();render()};
 window.vidoraClipPayload=url=>{if(!selected)return undefined;if(!available()||source!==url||media.token!==selected.token)throw Error('لینکەکە گۆڕاوە؛ پارچەکە دووبارە دیاری بکە');return {...selected}};
 mode();render();
})();
