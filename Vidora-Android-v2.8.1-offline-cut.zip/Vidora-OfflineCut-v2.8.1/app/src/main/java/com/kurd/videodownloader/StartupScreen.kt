package com.kurd.videodownloader

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream

/** Isolated, script-free local loading design. MainActivity owns readiness and failures. */
internal class StartupScreen(context: Context) : FrameLayout(context) {
    private val browser = WebView(context)
    private var active = true
    private var released = false
    init {
        setBackgroundColor(Color.rgb(1, 5, 9))
        isClickable = true
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context)).build()
        browser.setBackgroundColor(Color.rgb(1, 5, 9))
        browser.settings.apply {
            javaScriptEnabled = false; domStorageEnabled = false
            allowFileAccess = false; allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            blockNetworkLoads = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
        }
        browser.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest) = !allowed(request.url)
            @Deprecated("Legacy Android callback")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String) = !allowed(Uri.parse(url))
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse =
                if (allowed(request.url)) loader.shouldInterceptRequest(request.url) ?: blocked() else blocked()
        }
        addView(browser, LayoutParams(-1, -1))
        browser.loadUrl(PAGE)
    }
    private fun allowed(uri: Uri) = uri.scheme == "https" && uri.host == "appassets.androidplatform.net" &&
        uri.port in listOf(-1, 443) && uri.userInfo == null && uri.query == null &&
        uri.path in listOf("/assets/startup/loading.html", "/assets/startup/loading.gif")
    private fun blocked() = WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
    fun running(value: Boolean) {
        if (released || active == value) return
        active = value
        if (value) {
            browser.onResume()
            browser.loadUrl(PAGE)
        } else {
            // onPause alone does not guarantee that GIF/CSS animation stops. Unload the
            // document; never pause global WebView timers needed by the main app.
            browser.stopLoading()
            browser.loadUrl("about:blank")
            browser.onPause()
        }
    }
    fun release() {
        if (released) return
        released = true; active = false
        browser.stopLoading()
        removeView(browser)
        browser.destroy()
    }
    override fun onDetachedFromWindow() { running(false); super.onDetachedFromWindow() }
    fun failed(retry: () -> Unit, close: () -> Unit) {
        release()
        removeAllViews()
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val padding = (24 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding, padding, padding)
        }
        box.addView(TextView(context).apply {
            text = "ڕووکاری ئەپەکە ئامادە نەبوو. دووبارە هەوڵ بدەوە."
            setTextColor(Color.WHITE); textSize = 19f; gravity = Gravity.CENTER
        })
        box.addView(Button(context).apply { text = "دووبارە هەوڵدانەوە"; setOnClickListener { retry() } })
        box.addView(Button(context).apply { text = "داخستن"; setOnClickListener { close() } })
        addView(box, LayoutParams(-1, -1))
    }
    private companion object { const val PAGE = "https://appassets.androidplatform.net/assets/startup/loading.html" }
}
