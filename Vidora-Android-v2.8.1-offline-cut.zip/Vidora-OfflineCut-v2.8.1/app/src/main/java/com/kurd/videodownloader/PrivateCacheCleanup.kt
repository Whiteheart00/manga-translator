package com.kurd.videodownloader

import android.content.Context
import android.os.Environment
import java.io.File

/** One-time process admission: old process tokens/jobs cannot be resumed. Never touches public Downloads. */
internal object PrivateCacheCleanup {
    fun run(c:Context){
        fun remove(file:File){check(!file.exists()||file.deleteRecursively()){"Private temporary cache cleanup failed"}}
        remove(File(c.cacheDir,"previews"))
        remove(File(c.cacheDir,"private-downloads"))
        remove(File(c.cacheDir,"local-cuts"))
        remove(File(c.cacheDir,"yt-dlp-cache"))
        c.cacheDir.listFiles()?.filter{it.name.matches(Regex("snap_probe_[0-9]+|convert_[0-9]+|job_[0-9]+_[0-9]+"))}?.forEach(::remove)
        // v2.3 staged jobs here. These are app-specific external files, not saved media.
        c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.listFiles()?.filter{it.name.matches(Regex("job_[0-9]+_[0-9]+"))}?.forEach(::remove)
    }
}
