package com.kurd.videodownloader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

internal data class StreamSpec(val url:String,val headers:Map<String,String>,val protocol:String)
internal data class PreviewMedia(val token:String,val source:String,val title:String,val duration:Long,val streams:List<StreamSpec>,val thumbnail:File?,val created:Long=System.currentTimeMillis(),val downloadInfo:File?=null,val audioOnly:Boolean=false,val watermark:String="unknown",val durationMs:Long=duration.coerceIn(0,31_536_000)*1000,val clipAllowed:Boolean=durationMs>=1000)
internal object MediaProbe {
    private val previews=linkedMapOf<String,PreviewMedia>()
    @Synchronized fun find(token:String)=previews[token]
    @Synchronized private fun remember(value:PreviewMedia){previews[value.token]=value;while(previews.size>8){val key=previews.keys.first();previews.remove(key)?.let{it.thumbnail?.delete();it.downloadInfo?.delete()}}}
    @Synchronized fun cached(source:String)=previews.values.lastOrNull{it.source==source&&System.currentTimeMillis()-it.created<5*60*1000}
    fun prepare(c:Context,url:String,id:String,cancelled:()->Boolean={false},onConnection:(HttpURLConnection?)->Unit={}):PreviewMedia {
        fun ensureActive(){if(cancelled()||Thread.currentThread().isInterrupted)throw java.io.IOException("هەڵوەشایەوە")}
        ensureActive()
        val resolved=SourceSafety.resolve(c,url,emptyMap(),cancelled,onConnection)
        SnapchatSpotlight.verifyRedirect(url,resolved)
        val existing=File(c.cacheDir,"previews");existing.listFiles()?.filter{System.currentTimeMillis()-it.lastModified()>24*60*60*1000}?.forEach{it.delete()}
        ensureActive()
        YoutubeDL.getInstance().init(c.applicationContext)
        VerifiedEngineUpdater.ensure(c)
        val sourceDirectory=File(c.cacheDir,"snap_probe_${System.nanoTime()}")
        val request=SnapchatSource.request(c,resolved,sourceDirectory,cancelled,onConnection).addOption("--dump-single-json").addOption("--skip-download")
            .addOption("--no-playlist").addOption("--playlist-items","1").addOption("--no-warnings")
            .addOption("--socket-timeout","15").addOption("--extractor-retries","1").addOption("--age-limit","17")
        TransportPolicy.configure(c,request)
        val video=MediaRequestPolicy.videoSelector(resolved,720)
        request.addOption("-f",if(MediaRequestPolicy.identify(resolved)?.audioOnly==true)"bestaudio/best" else video+"/"+MediaRequestPolicy.videoSelector(resolved,0))
        if(MediaRequestPolicy.identify(resolved)?.id=="youtube")request.addOption("--remote-components","ejs:github")
        var value=try{ensureActive();JSONObject(YoutubeDL.getInstance().execute(request,id,null).out.trim())}finally{sourceDirectory.deleteRecursively()}
        ensureActive();SourceSafety.metadata(c,value)
        value.optJSONArray("entries")?.let{entries->if(entries.length()>0)value=entries.optJSONObject(0)?:throw SafetyException("ڤیدیۆ نەدۆزرایەوە")}
        SourceSafety.metadata(c,value)
        fun headers(json:JSONObject?):Map<String,String>{if(json==null)return emptyMap();return json.keys().asSequence().associateWith{json.optString(it)}.filter{!it.key.contains('\n')&&!it.value.contains('\n')&&!it.value.contains('\r')}}
        val common=headers(value.optJSONObject("http_headers"));val streams=mutableListOf<StreamSpec>()
        fun add(item:JSONObject){val link=item.optString("url");if(!link.startsWith("http"))return
            SourceSafety.check(c,link);streams+=StreamSpec(link,common+headers(item.optJSONObject("http_headers")),item.optString("protocol"))}
        val requested=value.optJSONArray("requested_formats")
        if(requested!=null)for(i in 0 until requested.length())requested.optJSONObject(i)?.let(::add) else add(value)
        val token=UUID.randomUUID().toString();var thumbnail:File?=null
        val thumb=value.optString("thumbnail")
        if(thumb.startsWith("http"))try{
            val safe=SourceSafety.resolve(c,thumb,common,cancelled,onConnection);val connection=URL(safe).openConnection() as HttpURLConnection
            connection.connectTimeout=10000;connection.readTimeout=10000;connection.instanceFollowRedirects=false
            common.forEach{(key,v)->connection.setRequestProperty(key,v)}
            onConnection(connection);ensureActive()
            val bytes=try{connection.inputStream.use{it.readNBytesCompat(3*1024*1024)}}finally{connection.disconnect();onConnection(null)}
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(bytes,0,bytes.size,bounds)
            val options=BitmapFactory.Options().apply{inSampleSize=1;while(bounds.outWidth/inSampleSize>720||bounds.outHeight/inSampleSize>720)inSampleSize*=2}
            val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size,options)
            if(bitmap!=null){val folder=File(c.cacheDir,"previews").apply{mkdirs()};thumbnail=File(folder,"$token.jpg");thumbnail!!.outputStream().use{bitmap.compress(Bitmap.CompressFormat.JPEG,85,it)};bitmap.recycle()}
        }catch(_:Exception){/* Metadata/player can still work without cover art. */}
        ensureActive()
        var downloadInfo:File?=null
        try{val folder=File(c.cacheDir,"previews").apply{mkdirs()};val file=File(folder,"$token.info.json");SecretFiles.write(file,PlaybackDownload.capture(c,value,url).toString());downloadInfo=file}catch(_:Exception){/* A player can still open formats that cannot be safely exported. */}
        val result=PreviewMedia(token,url,value.optString("title","ڤیدیۆ"),value.optDouble("duration",0.0).toLong(),streams,thumbnail,downloadInfo=downloadInfo,audioOnly=MediaRequestPolicy.identify(resolved)?.audioOnly==true||(requested!=null&&requested.length()>0&&(0 until requested.length()).all{requested.optJSONObject(it)?.optString("vcodec")=="none"})||(requested==null&&value.optString("vcodec")=="none"))
        val preciseDuration=value.optDouble("duration",0.0).takeIf{it.isFinite()&&it>=0&&it<=31_536_000}?.let{(it*1000).toLong()}?:0L
        val live=value.optBoolean("is_live")||value.optString("live_status") in listOf("is_live","is_upcoming")
        val annotated=result.copy(durationMs=preciseDuration,clipAllowed=preciseDuration>=1000&&!live,watermark=if(value.optBoolean("vidora_original_rendition"))"original_rendition" else value.optString("vidora_watermark_status","unknown"));remember(annotated);return annotated
    }
    private fun java.io.InputStream.readNBytesCompat(limit:Int):ByteArray {val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(16384);var count=0;while(count<limit){val n=read(buffer,0,minOf(buffer.size,limit-count));if(n<0)break;out.write(buffer,0,n);count+=n};return out.toByteArray()}
}
