package com.kurd.videodownloader

import android.Manifest
import android.app.DownloadManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import com.yausername.youtubedl_android.YoutubeDL

/** Offline, app-owned HTML UI. Only the native service performs networking/downloads. */
class MainActivity : AppCompatActivity() {
    internal lateinit var browser:WebView
    private var ready=false
    private var startup:StartupScreen?=null
    private var startupFailed=false
    private val startupTimeout=Runnable{startupError()}
    private var registered=false
    private var sharedUrl:String?=null
    private var pending:Task?=null
    private var deletingId:String?=null
    private var recoveringDelete:String?=null
    private val filesExecutor=java.util.concurrent.ThreadPoolExecutor(0,1,1,java.util.concurrent.TimeUnit.SECONDS,java.util.concurrent.LinkedBlockingQueue<Runnable>())
    private val deletePermission=registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()){result->
        val id=recoveringDelete;recoveringDelete=null
        if(id!=null){if(result.resultCode==RESULT_OK)deletePublishedFile(id)else fileDeleted(id,"cancelled","سڕینەوە هەڵوەشایەوە")}
    }
    private val previewExecutor=java.util.concurrent.ThreadPoolExecutor(0,1,1,java.util.concurrent.TimeUnit.SECONDS,java.util.concurrent.LinkedBlockingQueue<Runnable>())
    private val previewGeneration=AtomicInteger()
    @Volatile private var previewProcess:String?=null
    @Volatile private var previewConnection:java.net.HttpURLConnection?=null
    private data class Task(val update:Boolean,val url:String="",val audio:Boolean=false,val quality:Int=0,val recordId:String="",val target:String="",val clip:ClipSelection?=null)
    private val permissions=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ results ->
        val task=pending;pending=null
        if(task!=null&&Build.VERSION.SDK_INT<=28&&!task.update&&results[Manifest.permission.WRITE_EXTERNAL_STORAGE]==false)
            message("مۆڵەتی پاشەکەوتکردن پێویستە.")
        else if(task!=null)begin(task)
    }
    private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){pushState()}}

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val frame=FrameLayout(this).apply{setBackgroundColor(Color.BLACK)}
        setContentView(frame)
        if(!SecurityGate.admit(this))return
        startup=StartupScreen(this)
        frame.addView(startup,FrameLayout.LayoutParams(-1,-1))
        LauncherIcon.useFixedIcon(this)
        browser=WebView(this)
        browser.importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        frame.addView(browser,0,FrameLayout.LayoutParams(-1,-1))
        WindowCompat.setDecorFitsSystemWindows(window,false)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        ViewCompat.setOnApplyWindowInsetsListener(frame){view,insets->
            val bars=insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime=insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left,bars.top,bars.right,maxOf(bars.bottom,ime.bottom));insets
        }
        ViewCompat.requestApplyInsets(frame)
        if(Build.VERSION.SDK_INT>=29)window.isNavigationBarContrastEnforced=false
        browser.setBackgroundColor(Color.parseColor(AppSettings.background(this)))
        val loader=WebViewAssetLoader.Builder().addPathHandler("/assets/",WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/thumbnails/",WebViewAssetLoader.PathHandler{path->coverResponse(path)})
            .addPathHandler("/preview/",WebViewAssetLoader.PathHandler{path->
                if(!path.matches(Regex("[a-f0-9-]{36}\\.jpg")))blocked() else {
                    val file=File(cacheDir,"previews/$path")
                    if(file.isFile)WebResourceResponse("image/jpeg",null,file.inputStream())else blocked()
                }
            }).build()
        browser.settings.apply {
            javaScriptEnabled=true;domStorageEnabled=true
            allowFileAccess=false;allowContentAccess=false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs=false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs=false
            mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
            blockNetworkLoads=true;setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically=false
            mediaPlaybackRequiresUserGesture=true
        }
        browser.addJavascriptInterface(NativeApi(),"VidoraNative")
        browser.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(view:WebView?,request:WebResourceRequest)=!trusted(request.url)
            @Deprecated("Legacy Android callback")
            override fun shouldOverrideUrlLoading(view:WebView?,url:String)=!trusted(Uri.parse(url))
            override fun shouldInterceptRequest(view:WebView?,request:WebResourceRequest):WebResourceResponse =
                if(trusted(request.url))loader.shouldInterceptRequest(request.url)?:blocked() else blocked()
            override fun onPageFinished(view:WebView?,url:String?) {
                if(!startupFailed&&url=="https://appassets.androidplatform.net/assets/ui/index.html"){ready=true;pushState()}
            }
            override fun onReceivedError(view:WebView?,request:WebResourceRequest?,error:WebResourceError?) {
                if(request?.isForMainFrame==true)startupError()
            }
        }
        browser.webChromeClient=WebChromeClient()
        receiveShare(intent)
        browser.loadUrl("https://appassets.androidplatform.net/assets/ui/index.html")
        onBackPressedDispatcher.addCallback(this,object:OnBackPressedCallback(true){
            override fun handleOnBackPressed(){
                browser.evaluateJavascript("window.vidoraBack ? window.vidoraBack() : false"){ handled->if(handled!="true")finish() }
            }
        })
        applyBars(AppSettings.json(this).optString("mode"))
        frame.setBackgroundColor(Color.BLACK) // Android 15 bars are transparent over these insets.
        window.statusBarColor=Color.BLACK;window.navigationBarColor=Color.BLACK
        WindowCompat.getInsetsController(window,browser).apply{isAppearanceLightStatusBars=false;isAppearanceLightNavigationBars=false}
    }
    private fun startupError(){
        val cover=startup?:return
        if(isDestroyed||isFinishing||startupFailed)return
        startupFailed=true;ready=false
        if(::browser.isInitialized)browser.removeCallbacks(startupTimeout)
        cover.failed({recreate()},{finish()})
    }
    private fun revealStartup(){
        if(startup==null||startupFailed||isDestroyed||isFinishing)return
        // Native settings and the first real snapshot must be painted before uncovering the WebView.
        browser.postVisualStateCallback(1,object:WebView.VisualStateCallback(){override fun onComplete(requestId:Long){
            if(startup==null||startupFailed||isDestroyed||isFinishing)return
            browser.importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_AUTO
            applyBars(AppSettings.json(this@MainActivity).optString("mode"))
            startup?.let{it.release();(it.parent as? FrameLayout)?.removeView(it)}
            startup=null;browser.removeCallbacks(startupTimeout)
        }})
    }
    private fun coverResponse(path:String):WebResourceResponse {
        val file=try{if(path.endsWith(".jpg"))MediaCovers.load(applicationContext,path.removeSuffix(".jpg"))else null}catch(_:Exception){null}
        val stream=try{file?.inputStream()}catch(_:Exception){null}
        return if(stream!=null)WebResourceResponse("image/jpeg",null,200,"OK",mapOf("Cache-Control" to "no-store"),stream)
        else WebResourceResponse("image/svg+xml","UTF-8",200,"OK",mapOf("Cache-Control" to "no-store"),java.io.ByteArrayInputStream("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 180'><rect width='320' height='180' rx='24' fill='#163449'/><path d='M144 64v52l44-26z' fill='#9acbd0'/></svg>".toByteArray()))
    }
    private fun trusted(uri:Uri)=uri.scheme=="https"&&uri.host=="appassets.androidplatform.net"&&uri.port in listOf(-1,443)&&(uri.path.orEmpty().startsWith("/assets/ui/")||uri.path.orEmpty().startsWith("/preview/")||uri.path.orEmpty().startsWith("/thumbnails/"))
    private fun blocked()=WebResourceResponse("text/plain","UTF-8",ByteArrayInputStream(ByteArray(0)))
    override fun onNewIntent(intent:Intent){super.onNewIntent(intent);setIntent(intent);receiveShare(intent);pushState()}
    private fun receiveShare(i:Intent?){if(i?.action==Intent.ACTION_SEND&&i.type=="text/plain")sharedUrl=extractUrl(i.getStringExtra(Intent.EXTRA_TEXT).orEmpty())}
    private fun extractUrl(text:String):String? {
        val value=Regex("https?://[^\\s<>\\\"']+",RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.',',',')','،',']','>')?:return null
        val uri=Uri.parse(value);return if((uri.scheme.equals("https",true)||uri.scheme.equals("http",true))&&!uri.host.isNullOrBlank()&&uri.userInfo==null)value else null
    }
    override fun onStart(){super.onStart();if(!::browser.isInitialized)return;val freshEntry=!AppRuntime.visible();AppRuntime.started(this);val reset=freshEntry&&!DownloadState.running;DownloadSession.enterHome(this);if(reset&&ready)browser.evaluateJavascript("window.vidoraNewSession&&window.vidoraNewSession()",null);ContextCompat.registerReceiver(this,receiver,IntentFilter(DownloadService.ACTION_STATUS),ContextCompat.RECEIVER_NOT_EXPORTED);registered=true;pushState()}
    override fun onResume(){super.onResume();startup?.running(true);if(::browser.isInitialized){browser.removeCallbacks(startupTimeout);if(startup!=null&&!startupFailed)browser.postDelayed(startupTimeout,20_000);browser.onResume();browser.evaluateJavascript("document.documentElement.classList.remove(\"native-paused\")",null)}}
    override fun onPause(){startup?.running(false);if(::browser.isInitialized){browser.removeCallbacks(startupTimeout);browser.evaluateJavascript("document.documentElement.classList.add(\"native-paused\")",null);browser.onPause()};super.onPause()}
    override fun onStop(){cancelPreview();if(registered){unregisterReceiver(receiver);registered=false};super.onStop();AppRuntime.stopped(this)}
    private fun cancelPreview(){
        previewGeneration.incrementAndGet();previewConnection?.disconnect();previewConnection=null
        val id=previewProcess;if(id!=null)Thread{try{YoutubeDL.getInstance().destroyProcessById(id)}catch(_:Exception){}}.start()
    }
    override fun onDestroy(){ready=false;startup?.release();startup=null;filesExecutor.shutdownNow();previewGeneration.incrementAndGet();previewProcess?.let{try{YoutubeDL.getInstance().destroyProcessById(it)}catch(_:Exception){}};previewExecutor.shutdownNow();if(::browser.isInitialized){browser.removeCallbacks(startupTimeout);browser.removeJavascriptInterface("VidoraNative");browser.stopLoading();browser.destroy()};super.onDestroy()}
    private fun applyBars(mode:String){
        val light=mode=="light";val color=Color.parseColor(AppSettings.background(this));browser.setBackgroundColor(color)
        (browser.parent as? View)?.setBackgroundColor(color)
        @Suppress("DEPRECATION")
        window.statusBarColor=color
        @Suppress("DEPRECATION")
        window.navigationBarColor=color
        WindowCompat.getInsetsController(window,browser).apply{isAppearanceLightStatusBars=light;isAppearanceLightNavigationBars=light}
    }
    private fun message(text:String){if(ready)browser.evaluateJavascript("window.vidoraNotice&&window.vidoraNotice(${JSONObject.quote(text)})",null)}
    private fun pushState(){
        if(!ready||isFinishing||isDestroyed)return
        val value=JSONObject().put("appVersion",packageManager.getPackageInfo(packageName,0).versionName).put("safetyRevision","adult-gambling-2026-11-15")
            .put("running",DownloadState.running).put("status",DownloadState.status).put("message",DownloadState.message)
            .put("phase",DownloadState.phase).put("progress",DownloadState.progress).put("action",DownloadState.action).put("url",DownloadState.url)
            .put("format",DownloadState.format).put("quality",DownloadState.quality).put("title",DownloadState.title)
            .put("settings",AppSettings.json(this)).put("history",NativeHistory.list(this))
            .put("engineVersion",securePreferences("engine_updates",MODE_PRIVATE).getString("version","—"))
        sharedUrl?.let{value.put("sharedUrl",it)};sharedUrl=null
        browser.evaluateJavascript("(function(){if(typeof window.vidoraReceive!=='function')return false;window.vidoraReceive(${value.toString().replace("\u2028","\\u2028").replace("\u2029","\\u2029")});return true})()"){applied->if(applied=="true")revealStartup()}
    }
    private fun request(task:Task){
        if(DownloadState.running||pending!=null){message("کردارێکی تر بەردەوامە؛ سەرەتا تەواوی بکە یان هەڵیوەشێنەوە.");return}
        val needed=mutableListOf<String>()
        if(!task.update&&Build.VERSION.SDK_INT<=28&&ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)needed+=Manifest.permission.WRITE_EXTERNAL_STORAGE
        val asked=securePreferences("vidora_permissions",MODE_PRIVATE)
        if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED&&!asked.getBoolean("notificationsAsked",false)){
            needed+=Manifest.permission.POST_NOTIFICATIONS;asked.edit().putBoolean("notificationsAsked",true).apply()
        }
        if(needed.isNotEmpty()){pending=task;permissions.launch(needed.toTypedArray())}else begin(task)
    }
    private fun begin(task:Task){
        if(DownloadState.running)return
        DownloadState.running=true;DownloadState.progress=0;DownloadState.status="running"
        DownloadState.phase="preparing";DownloadState.action=if(task.update)"update" else if(task.recordId.isNotBlank())"convert" else "download";DownloadState.url=task.url
        DownloadState.format=if(task.audio)"MP3" else "MP4"
        DownloadState.quality=if(task.quality==0)"Best" else if(task.audio)"${task.quality}k" else "${task.quality}p"
        DownloadState.title="";DownloadState.message="ئامادەکردنی بزوێنەر...";pushState()
        try{ContextCompat.startForegroundService(this,Intent(this,DownloadService::class.java).apply{
            action=if(task.update)DownloadService.ACTION_UPDATE else if(task.recordId.isNotBlank())DownloadService.ACTION_CONVERT else DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_FILE_ID,task.recordId);putExtra(DownloadService.EXTRA_TARGET,task.target)
            ClipSelection.put(this,task.clip)
            putExtra(DownloadService.EXTRA_URL,task.url);putExtra(DownloadService.EXTRA_AUDIO,task.audio);putExtra(DownloadService.EXTRA_QUALITY,task.quality)
        })}catch(e:Exception){DownloadState.running=false;DownloadState.status="error";DownloadState.message="دەستپێکردن سەرکەوتوو نەبوو: ${e.localizedMessage}";pushState()}
    }
    private fun fileDeleted(id:String,status:String,message:String){
        deletingId=null
        if(status=="deleted")pushState()
        if(ready)browser.evaluateJavascript("window.vidoraFileDeleted&&window.vidoraFileDeleted(${JSONObject().put("id",id).put("status",status).put("message",message)})",null)
    }
    private fun deletePublishedFile(id:String){
        if(isDestroyed||isFinishing)return
        if(deletingId!=null){message("سڕینەوەی فایلێکی تر بەردەوامە");return}
        deletingId=id
        filesExecutor.execute{
            try{NativeFiles.delete(applicationContext,id);runOnUiThread{fileDeleted(id,"deleted","فایلەکە لە مۆبایل سڕایەوە")}}
            catch(error:Exception){runOnUiThread{
                val record=NativeHistory.find(this,id);var sender:android.content.IntentSender?=null
                if(error is SecurityException&&record!=null)try{
                    val uri=Uri.parse(record.getString("uri"))
                    if(Build.VERSION.SDK_INT>=30&&uri.authority=="media")sender=android.provider.MediaStore.createDeleteRequest(contentResolver,listOf(uri)).intentSender
                    else if(Build.VERSION.SDK_INT==29&&error is android.app.RecoverableSecurityException)sender=error.userAction.actionIntent.intentSender
                }catch(_:Exception){}
                if(sender!=null&&!isDestroyed){deletingId=null;recoveringDelete=id;try{deletePermission.launch(androidx.activity.result.IntentSenderRequest.Builder(sender!!).build())}catch(_:Exception){recoveringDelete=null;fileDeleted(id,"error","Android مۆڵەتی سڕینەوەی نەدا")}}
                else fileDeleted(id,"error",error.localizedMessage?:"فایلەکە نەسڕایەوە")
            }}
        }
    }
    inner class NativeApi {
        @JavascriptInterface fun bootstrap()=AppSettings.json(this@MainActivity).toString()
        @JavascriptInterface fun validateSource(url:String):String {
            val response=JSONObject()
            try{SourceSafety.check(this@MainActivity,url);response.put("allowed",true)}
            catch(e:Exception){response.put("allowed",false).put("message",e.localizedMessage?:"لینکەکە ڕێگەپێنەدراوە")}
            return response.toString()
        }
        @JavascriptInterface fun ready(){runOnUiThread{pushState()}}
        @JavascriptInterface fun requestDownload(payload:String){runOnUiThread{
            try{val json=JSONObject(payload);val url=extractUrl(json.optString("url"))?:throw IllegalArgumentException("لینکەکە دروست نییە")
                SourceSafety.check(this@MainActivity,url)
                val audio=json.optString("format")=="MP3"||MediaRequestPolicy.identify(url)?.audioOnly==true;val raw=json.optString("quality").removeSuffix("p").removeSuffix("k").toIntOrNull()?:0
                val quality=if(raw in (if(audio)listOf(128,192,320) else listOf(480,720,1080)))raw else 0
                request(Task(false,url,audio,quality,clip=ClipSelection.fromJson(json,url)))
            }catch(e:Exception){message(e.localizedMessage?:"داواکارییەکە دروست نییە")}
        }}
        @JavascriptInterface fun updateEngine(){runOnUiThread{request(Task(true))}}
        @JavascriptInterface fun cancel(){runOnUiThread{if(DownloadState.running)startService(Intent(this@MainActivity,DownloadService::class.java).apply{action=DownloadService.ACTION_CANCEL})}}
        @JavascriptInterface fun paste(){runOnUiThread{
            val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val text=clipboard.primaryClip?.takeIf{it.itemCount>0}?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString().orEmpty()
            val url=extractUrl(text)
            if(url!=null)browser.evaluateJavascript("window.vidoraSetUrl(${JSONObject.quote(url)})",null)else message("لینکێکی دروست لە Clipboard ـدا نییە")
        }}
        @JavascriptInterface fun configure(payload:String){runOnUiThread{try{
            val value=JSONObject(payload);AppSettings.save(this@MainActivity,value)
            val palettes=listOf("rainbow","silver","amber","gold","ocean")
            val index=palettes.indexOf(value.optString("palette"));if(index>=0)VisualTheme.changePalette(this@MainActivity,index)
            applyBars(AppSettings.json(this@MainActivity).optString("mode"))
            if(ready)browser.evaluateJavascript("window.vidoraSettingsSaved&&window.vidoraSettingsSaved(${AppSettings.json(this@MainActivity)})",null)
        }catch(_:Exception){message("ڕێکخستنەکە پاشەکەوت نەکرا")}}}
        @JavascriptInterface fun copyDiagnostics(){runOnUiThread{
            val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Vidora diagnostics",DownloadDiagnostics.report(this@MainActivity)))
            message("ڕاپۆرتی هەڵە کۆپی کرا")
        }}
        @JavascriptInterface fun openDownloads(){runOnUiThread{try{startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))}catch(_:ActivityNotFoundException){message("فایلەکان لە Downloads ـدان")}}}
        @JavascriptInterface fun inspect(payload:String){
            val generation=previewGeneration.incrementAndGet()
            previewProcess?.let{try{YoutubeDL.getInstance().destroyProcessById(it)}catch(_:Exception){}}
            val json=try{JSONObject(payload)}catch(_:Exception){return}
            val url=extractUrl(json.optString("url")).orEmpty();val requestId=json.optInt("requestId")
            previewExecutor.execute {
                if(generation!=previewGeneration.get())return@execute
                val response=JSONObject().put("url",url).put("requestId",requestId)
                val id="preview_${System.nanoTime()}";previewProcess=id
                try{
                    SourceSafety.check(this@MainActivity,url)
                    val media=MediaProbe.cached(url)?:MediaProbe.prepare(this@MainActivity,url,id,{generation!=previewGeneration.get()},{previewConnection=it})
                    response.put("status","ready").put("token",media.token).put("title",media.title).put("duration",media.duration).put("durationMs",media.durationMs).put("clipAllowed",media.clipAllowed)
                        .put("watermark",media.watermark).put("playable",media.streams.isNotEmpty()).put("thumbnail",if(media.thumbnail!=null)"https://appassets.androidplatform.net/preview/${media.token}.jpg" else "")
                }catch(e:Exception){response.put("status","error").put("blocked",e is SafetyException).put("message",e.localizedMessage?.take(350)?:"پێشبینین بەردەست نییە")}
                catch(e:LinkageError){DownloadDiagnostics.record(this@MainActivity,"preview_native_error",e);response.put("status","error").put("message","بزوێنەر بار نەبوو؛ ڕاپۆرتی هەڵە کۆپی بکە")}
                finally{if(previewProcess==id)previewProcess=null}
                if(generation==previewGeneration.get())runOnUiThread{if(ready&&!isDestroyed)browser.evaluateJavascript("window.vidoraPreview&&window.vidoraPreview(${response.toString().replace("\u2028","\\u2028").replace("\u2029","\\u2029")})",null)}
            }
        }
        @JavascriptInterface fun playPreview(token:String){runOnUiThread{try{
            val media=MediaProbe.find(token)?:throw IllegalArgumentException("دووبارە لینکەکە دابنێ")
            SourceSafety.check(this@MainActivity,media.source)
            startActivity(Intent(this@MainActivity,PlayerActivity::class.java).putExtra("previewToken",token))
        }catch(e:Exception){message(e.localizedMessage?:"پێشبینین بەردەست نییە")}}}
        @JavascriptInterface fun openFile(id:String){runOnUiThread{try{
            val item=NativeHistory.find(this@MainActivity,id)?:throw IllegalArgumentException("فایلەکە نەدۆزرایەوە")
            val url=item.optString("url");if(url.startsWith("http"))SourceSafety.check(this@MainActivity,url)
            startActivity(Intent(this@MainActivity,PlayerActivity::class.java).putExtra("recordId",id))
        }catch(e:Exception){message(e.localizedMessage?:"فایلەکە ناتوانرێت بکرێتەوە")}}}
        @JavascriptInterface fun requestConversion(id:String,target:String){runOnUiThread{try{
            val item=NativeHistory.find(this@MainActivity,id)?:throw IllegalArgumentException("فایلەکە نەدۆزرایەوە")
            val mime=item.optString("mime");require((target=="MP3"&&mime.startsWith("video/"))||(target=="MP4"&&mime.startsWith("audio/"))){"جۆری گۆڕان دروست نییە"}
            val url=item.optString("url");if(url.startsWith("http"))SourceSafety.check(this@MainActivity,url)
            request(Task(false,url,target=="MP3",if(target=="MP3")320 else 720,id,target))
        }catch(e:Exception){message(e.localizedMessage?:"گۆڕان دەست پێ نەکرد")}}}
        @JavascriptInterface fun deleteFile(id:String){runOnUiThread{deletePublishedFile(id)}}
        @JavascriptInterface fun favorite(id:String,value:Boolean){runOnUiThread{NativeHistory.change(this@MainActivity,id){it.put("favorite",value)};pushState()}}
        @JavascriptInterface fun removeHistory(id:String,hidden:Boolean){runOnUiThread{NativeHistory.change(this@MainActivity,id){it.put("hidden",hidden)};pushState()}}
        @JavascriptInterface fun renameFile(id:String,title:String){runOnUiThread{try{check(NativeHistory.rename(this@MainActivity,id,title));message("ناوی فایلەکە گۆڕدرا");pushState()}catch(e:Exception){message(e.localizedMessage?:"ناوەکە نەگۆڕدرا")}}}
    }
}
