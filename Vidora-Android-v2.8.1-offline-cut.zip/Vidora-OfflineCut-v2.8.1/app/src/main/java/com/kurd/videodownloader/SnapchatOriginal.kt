package com.kurd.videodownloader

import org.json.JSONObject
import java.io.IOException
import java.net.URI
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max

/** One known public rendition of the same CDN object; never scan IDs or relax MP4/HTTPS guards. */
internal object SnapchatOriginal {
    const val PROBE_BYTES=128*1024
    data class Movie(val duration:Double,val width:Int,val height:Int,val audio:Boolean)
    private data class Box(val content:Int,val end:Int)
    fun candidate(url:String):String?=try{
        SnapchatSource.requireCdn(url)
        // The first segment is a storage shard (d/z/y/i...), not a rendition type.
        val uri=URI(url);val path=uri.rawPath
        if(!path.matches(Regex("/[a-z]/[A-Za-z0-9_-]+\\.27\\.IRZXSOY")))null
        else "https://${uri.rawAuthority}"+path.removeSuffix(".27.IRZXSOY")+".1034.IRZXSOY"
    }catch(_:Exception){null}
    private fun u32(bytes:ByteArray,at:Int)=ByteBuffer.wrap(bytes,at,4).int.toLong()and 0xffffffffL
    private fun box(bytes:ByteArray,start:Int,end:Int,type:String):Box?{
        var at=start
        while(at+8<=end){
            var size=u32(bytes,at);var header=8
            if(size==1L){if(at+16>end)return null;size=ByteBuffer.wrap(bytes,at+8,8).long;header=16}
            if(size==0L)size=(end-at).toLong()
            if(size<header||size>end-at)return null
            val next=at+size.toInt()
            if(String(bytes,at+4,4,Charsets.US_ASCII)==type)return Box(at+header,next)
            at=next
        };return null
    }
    fun movie(bytes:ByteArray):Movie? {return try{
        SnapchatSource.requireMp4(bytes)
        val moov=box(bytes,0,bytes.size,"moov")?:return null
        val mvhd=box(bytes,moov.content,moov.end,"mvhd")?:return null
        val version=bytes[mvhd.content].toInt()and 255
        if(version !in 0..1)return null
        val scaleAt=mvhd.content+if(version==1)20 else 12
        val timeAt=scaleAt+4;val length=if(version==1)8 else 4
        if(timeAt+length>mvhd.end)return null
        val scale=u32(bytes,scaleAt);if(scale==0L)return null
        val ticks=if(version==1)ByteBuffer.wrap(bytes,timeAt,8).long.toDouble()else u32(bytes,timeAt).toDouble()
        val duration=ticks/scale;if(!duration.isFinite()||duration<=0||duration>86400)return null
        var width=0;var height=0;var audio=false;var at=moov.content
        while(at+8<=moov.end){
            val size=u32(bytes,at);if(size<8||size>moov.end-at)return null
            if(String(bytes,at+4,4,Charsets.US_ASCII)=="trak"){
                val end=at+size.toInt();val mdia=box(bytes,at+8,end,"mdia");val handler=mdia?.let{box(bytes,it.content,it.end,"hdlr")}
                val kind=handler?.takeIf{it.content+12<=it.end}?.let{String(bytes,it.content+8,4,Charsets.US_ASCII)}
                if(kind=="soun")audio=true
                if(kind=="vide"){
                    val tkhd=box(bytes,at+8,end,"tkhd")?:return null
                    if(tkhd.end-tkhd.content<84)return null
                    width=(u32(bytes,tkhd.end-8)ushr 16).toInt();height=(u32(bytes,tkhd.end-4)ushr 16).toInt()
                }
            };at+=size.toInt()
        }
        if(width !in 1..16384||height !in 1..16384)null else Movie(duration,width,height,audio)
    }catch(_:Exception){null}}
    fun prefer(info:JSONObject,sharedHeader:ByteArray,fetch:(String)->ByteArray):JSONObject {
        if(info.optString("extractor_key")!="VidoraSnapchatSpotlight")return info
        val target=candidate(info.optString("url"))?:return info
        val shared=movie(sharedHeader)?:return info
        val original=movie(fetch(target))?:return info
        if(abs(shared.duration-original.duration)>max(.5,shared.duration*.01)||shared.audio&&!original.audio)return info
        if(abs(shared.width.toDouble()/shared.height-original.width.toDouble()/original.height)>.02)return info
        return JSONObject(info.toString()).put("url",target).put("duration",original.duration).put("width",original.width).put("height",original.height)
            .put("vidora_original_rendition",true).put("format_note","Snapchat original rendition")
    }
}
