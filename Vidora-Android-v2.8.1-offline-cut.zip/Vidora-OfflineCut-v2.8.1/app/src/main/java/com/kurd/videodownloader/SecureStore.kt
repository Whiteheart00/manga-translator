package com.kurd.videodownloader

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

internal object PrivateCipher {
    private const val ALIAS="vidora.private-data.v1"
    private var testKey:SecretKey?=null
    internal fun useTestKey(key:SecretKey){check(BuildConfig.DEBUG);testKey=key}
    @Synchronized private fun key():SecretKey {
        if(BuildConfig.DEBUG)testKey?.let{return it}
        val store=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
        (store.getKey(ALIAS,null)as? SecretKey)?.let{return it}
        check(!store.containsAlias(ALIAS)){"Storage key unavailable"}
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply{
            init(KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).setRandomizedEncryptionRequired(true).build())
        }.generateKey()
    }
    fun seal(text:String,aad:String):String {
        val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());cipher.updateAAD(aad.toByteArray(Charsets.UTF_8))
        return "vgcm1:"+Base64.encodeToString(cipher.iv+cipher.doFinal(text.toByteArray(Charsets.UTF_8)),Base64.NO_WRAP)
    }
    fun open(text:String,aad:String):String {
        require(text.startsWith("vgcm1:")){"Encrypted storage version invalid"}
        val data=Base64.decode(text.substringAfter(':'),Base64.NO_WRAP);require(data.size>=28)
        val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,data,0,12));cipher.updateAAD(aad.toByteArray(Charsets.UTF_8))
        return String(cipher.doFinal(data,12,data.size-12),Charsets.UTF_8)
    }
}

internal fun Context.securePreferences(name:String,mode:Int=Context.MODE_PRIVATE):SharedPreferences=SecureStore.open(this,name)

/** Per-value AEAD with AAD binding to both store and key. Original store is cleared only after commit. */
internal object SecureStore {
    private const val MIGRATED="__migration_complete_v1"
    private fun encode(value:Any):String {
        val type=when(value){is String->"s";is Boolean->"b";is Int->"i";is Long->"l";is Float->"f";is Set<*>->"ss";else->error("Unsupported preference type")}
        return JSONObject().put("t",type).put("v",if(value is Set<*>)JSONArray(value.toList())else value).toString()
    }
    private fun decode(text:String):Any {val j=JSONObject(text);return when(j.getString("t")){"s"->j.getString("v");"b"->j.getBoolean("v");"i"->j.getInt("v");"l"->j.getLong("v");"f"->j.getDouble("v").toFloat();"ss"->j.getJSONArray("v").let{a->(0 until a.length()).map{a.getString(it)}.toSet()};else->error("Invalid preference type")}}
    @Synchronized fun open(c:Context,name:String):SharedPreferences {
        val encrypted=c.getSharedPreferences(name+".secure-v1",Context.MODE_PRIVATE)
        val legacy=c.getSharedPreferences(name,Context.MODE_PRIVATE)
        if(!encrypted.contains(MIGRATED)){
            val edit=encrypted.edit()
            for((key,value)in legacy.all)if(value!=null)edit.putString(key,PrivateCipher.seal(encode(value),"$name/$key"))
            edit.putString(MIGRATED,PrivateCipher.seal(encode(true),"$name/$MIGRATED"))
            check(edit.commit()){"Encrypted storage migration failed"}
            // Prove all committed values authenticate before removing the original copy.
            encrypted.all.forEach{(key,value)->decode(PrivateCipher.open(value as String,"$name/$key"))}
        }
        check(decode(PrivateCipher.open(encrypted.getString(MIGRATED,null)?:error("Migration marker missing"),"$name/$MIGRATED"))==true){"Storage marker invalid"}
        // A completed migration never imports newly injected plaintext.
        if(legacy.all.isNotEmpty()){encrypted.all.forEach{(key,value)->decode(PrivateCipher.open(value as String,"$name/$key"))};check(legacy.edit().clear().commit()){"Legacy storage cleanup failed"}}
        return object:SharedPreferences {
            fun value(key:String)=encrypted.getString(key,null)?.let{decode(PrivateCipher.open(it,"$name/$key"))}
            override fun getAll():MutableMap<String,*> = encrypted.all.keys.filter{it!=MIGRATED}.associateWith{value(it)}.toMutableMap()
            override fun contains(key:String)=key!=MIGRATED&&encrypted.contains(key)
            override fun getString(key:String,default:String?)=value(key)as? String?:default
            @Suppress("UNCHECKED_CAST") override fun getStringSet(key:String,default:MutableSet<String>?)=(value(key)as? Set<String>)?.toMutableSet()?:default
            override fun getBoolean(key:String,default:Boolean)=value(key)as? Boolean?:default
            override fun getInt(key:String,default:Int)=value(key)as? Int?:default
            override fun getLong(key:String,default:Long)=value(key)as? Long?:default
            override fun getFloat(key:String,default:Float)=value(key)as? Float?:default
            override fun registerOnSharedPreferenceChangeListener(listener:SharedPreferences.OnSharedPreferenceChangeListener)=encrypted.registerOnSharedPreferenceChangeListener(listener)
            override fun unregisterOnSharedPreferenceChangeListener(listener:SharedPreferences.OnSharedPreferenceChangeListener)=encrypted.unregisterOnSharedPreferenceChangeListener(listener)
            override fun edit():SharedPreferences.Editor {
                val raw=encrypted.edit()
                return object:SharedPreferences.Editor {
                    private fun put(key:String,value:Any?):SharedPreferences.Editor{require(key!=MIGRATED);if(value==null)raw.remove(key)else raw.putString(key,PrivateCipher.seal(encode(value),"$name/$key"));return this}
                    override fun putString(key:String,value:String?)=put(key,value)
                    override fun putStringSet(key:String,value:MutableSet<String>?)=put(key,value?.toSet())
                    override fun putBoolean(key:String,value:Boolean)=put(key,value)
                    override fun putInt(key:String,value:Int)=put(key,value)
                    override fun putLong(key:String,value:Long)=put(key,value)
                    override fun putFloat(key:String,value:Float)=put(key,value)
                    override fun remove(key:String):SharedPreferences.Editor{require(key!=MIGRATED);raw.remove(key);return this}
                    override fun clear():SharedPreferences.Editor{encrypted.all.keys.filter{it!=MIGRATED}.forEach{raw.remove(it)};return this}
                    override fun commit()=raw.commit()
                    override fun apply()=raw.apply()
                }
            }
        }
    }
    fun validate(c:Context){
        for(name in listOf("vidora_file_history","vidora_native_settings","native_runtime","download_state","player_positions","engine_updates","vidora_permissions","vidora_design_v15","player_ui_options"))open(c,name).all
    }
}
internal object SecretFiles {
    fun write(file:java.io.File,text:String){file.writeText(PrivateCipher.seal(text,"snapshot/${file.name}"))}
    fun read(file:java.io.File)=PrivateCipher.open(file.readText(),"snapshot/${file.name}")
}
