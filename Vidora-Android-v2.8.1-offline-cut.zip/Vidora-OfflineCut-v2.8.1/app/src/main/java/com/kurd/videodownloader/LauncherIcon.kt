package com.kurd.videodownloader

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/** One fixed launcher entry. Keep the old aliases only to migrate existing installs. */
object LauncherIcon {
    fun useFixedIcon(context:Context) {
        val pm=context.packageManager
        // Enabling the fixed entry first preserves the existing launcher target on upgrades.
        for(i in 0..7){
            val component=ComponentName(context,"${context.packageName}.LauncherPalette$i")
            val desired=if(i==0)PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            if(pm.getComponentEnabledSetting(component)!=desired)pm.setComponentEnabledSetting(component,desired,PackageManager.DONT_KILL_APP)
        }
    }
}
