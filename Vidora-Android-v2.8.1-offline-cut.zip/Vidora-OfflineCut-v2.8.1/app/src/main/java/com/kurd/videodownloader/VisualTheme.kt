package com.kurd.videodownloader

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Build
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.progressindicator.LinearProgressIndicator

/** Persistent native liquid-glass palettes, independent from the downloader service. */
object VisualTheme {
    private const val PREFS = "vidora_design_v15"
    private const val KEY_PALETTE = "palette"
    private const val KEY_MODE = "mode"
    const val LIGHT = "light"
    const val DARK = "dark"
    const val SYSTEM = "system"

    data class Preset(
        val title: String,
        val first: Int,
        val second: Int,
        val third: Int,
        val darkBase: Int = Color.rgb(8, 13, 29),
        val lightBase: Int = Color.rgb(244, 248, 255)
    )

    private fun hex(s: String): Int = Color.parseColor(s)

    // Rainbow is the FIRST and default choice; monochrome is optional, never forced.
    val presets = listOf(
        Preset("ڕەنگاوڕەنگ", hex("#16DBEB"), hex("#9152FF"), hex("#FF4BB6")),
        Preset("سپی و ڕەش", hex("#ECEFF6"), hex("#A4ADBF"), hex("#F8FAFF"), hex("#0D0F14"), hex("#F4F5F8")),
        Preset("هەنگوینی", hex("#FFB900"), hex("#FF7E36"), hex("#FFE28A"), hex("#261308"), hex("#FFF7E9")),
        Preset("ڕەش و زەرد", hex("#FFDD25"), hex("#FFAB00"), hex("#FFED88"), hex("#0B0B0D"), hex("#FCFAED")),
        Preset("شین و سەوز", hex("#00D5EE"), hex("#00DE91"), hex("#4790FF"), hex("#041E35"), hex("#E8FBFA")),
        Preset("مۆر و پەمەیی", hex("#9F63FF"), hex("#F55ABF"), hex("#67BCFF"), hex("#170B2C"), hex("#FCF2FF")),
        Preset("ئاگرین", hex("#FF704C"), hex("#FFCA4C"), hex("#FF4F96"), hex("#2A1017"), hex("#FFF2E9")),
        Preset("زمردی", hex("#17E0AB"), hex("#50B8FF"), hex("#89E582"), hex("#08221D"), hex("#ECFBF3"))
    )

    data class Scheme(
        val dark: Boolean,
        val main: Int,
        val second: Int,
        val third: Int,
        val background: Int,
        val bottom: Int,
        val text: Int,
        val muted: Int,
        val surface: Int,
        val outline: Int,
        val input: Int,
        val onAccent: Int
    )

    fun currentMode(context: Context): String = context.securePreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_MODE, SYSTEM) ?: SYSTEM
    fun currentPalette(context: Context): Int = context.securePreferences(PREFS, Context.MODE_PRIVATE)
        .getInt(KEY_PALETTE, 0).coerceIn(presets.indices)
    fun changePalette(context: Context, index: Int) {
        context.securePreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_PALETTE, index.coerceIn(presets.indices)).apply()
        // Defer launcher component changes until the Activity is no longer visible.
    }
    fun changeMode(context: Context, mode: String) {
        context.securePreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_MODE, mode).apply()
        AppCompatDelegate.setDefaultNightMode(modeToDelegate(mode))
    }
    fun setAppCompatMode(context: Context) {
        AppCompatDelegate.setDefaultNightMode(modeToDelegate(currentMode(context)))
    }
    private fun modeToDelegate(mode: String) = when (mode) {
        DARK -> AppCompatDelegate.MODE_NIGHT_YES
        LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }
    private fun blend(a: Int, b: Int, weight: Float): Int = ColorUtils.blendARGB(a, b, weight)
    private fun withAlpha(color: Int, alpha: Int): Int = ColorUtils.setAlphaComponent(color, alpha)
    private fun dp(context: Context, v: Float): Int = (v * context.resources.displayMetrics.density + .5f).toInt()

    fun scheme(context: Context): Scheme {
        val preset = presets[currentPalette(context)]
        val dark = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bg = preset.run { if (dark) darkBase else lightBase }
        val text = if (dark) hex("#F9FAFF") else hex("#18253F")
        val muted = if (dark) hex("#B9C5DD") else hex("#596986")
        val surface = if (dark) withAlpha(blend(bg, Color.WHITE, .13f), 236)
            else withAlpha(Color.WHITE, 242)
        val outline = if (dark) withAlpha(blend(preset.first, Color.WHITE, .35f), 95)
            else withAlpha(blend(preset.first, hex("#8C9DB5"), .55f), 110)
        val input = if (dark) blend(bg, Color.WHITE, .11f) else blend(bg, Color.WHITE, .72f)
        val onAccent = if (ColorUtils.calculateLuminance(preset.first) > .44) Color.BLACK else Color.WHITE
        return Scheme(dark, preset.first, preset.second, preset.third,
            bg, blend(bg, if (dark) Color.BLACK else Color.WHITE, if (dark) .15f else .25f),
            text, muted, surface, outline, input, onAccent)
    }

    fun apply(activity: AppCompatActivity) {
        val c = scheme(activity)
        val root = activity.findViewById<ScrollView>(R.id.mainScroll)
        root.background = AmbientDrawable(c)
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        if (root.tag != "insets-ready") {
            val l=root.paddingLeft; val t=root.paddingTop; val r=root.paddingRight; val b=root.paddingBottom
            ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
                val bars=insets.getInsets(WindowInsetsCompat.Type.systemBars())
                view.setPadding(l+bars.left,t+bars.top,r+bars.right,b+bars.bottom)
                insets
            }
            root.tag="insets-ready"
            ViewCompat.requestApplyInsets(root)
        }
        activity.window.statusBarColor=Color.TRANSPARENT
        activity.window.navigationBarColor=Color.TRANSPARENT
        if(Build.VERSION.SDK_INT>=29) activity.window.isNavigationBarContrastEnforced=false
        WindowCompat.getInsetsController(activity.window,root).apply {
            isAppearanceLightStatusBars=!c.dark
            isAppearanceLightNavigationBars=!c.dark
        }
        for(id in intArrayOf(R.id.themeCard,R.id.urlCard,R.id.modeCard,R.id.progressCard,R.id.siteCard,R.id.statusCard)) {
            activity.findViewById<GlassPanel>(id).applyScheme(c,if(id==R.id.urlCard) 28f else 17f)
        }
        applyText(root,c)
        activity.findViewById<TextView>(R.id.tvBrand).apply {
            setTextColor(c.text)
            paint.shader=LinearGradient(0f,0f,paint.measureText(text.toString()).coerceAtLeast(1f),0f,
                intArrayOf(c.main,c.second,c.third),null,Shader.TileMode.CLAMP)
        }
        activity.findViewById<TextView>(R.id.tvPercent).setTextColor(c.main)
        activity.findViewById<TextView>(R.id.statusDot).setTextColor(if(currentPalette(activity)==1)c.main else hex("#36E579"))
        activity.findViewById<EditText>(R.id.etUrl).apply {setTextColor(c.text);setHintTextColor(c.muted)}
        for(id in intArrayOf(R.id.tvSubtitle,R.id.tvDetails)) activity.findViewById<TextView>(id).setTextColor(c.muted)
        for(id in intArrayOf(R.id.btnPalette,R.id.btnAbout,R.id.btnClear,R.id.btnTheme,R.id.btnLight)) {
            activity.findViewById<ImageButton>(id).apply {
                imageTintList=ColorStateList.valueOf(c.text)
                background=if(id==R.id.btnPalette) GlassDrawable(c,false,15f,activity.resources.displayMetrics.density)
                    else android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            }
        }
        val modeButton=activity.findViewById<ImageButton>(if(c.dark)R.id.btnTheme else R.id.btnLight)
        modeButton.background=GlassDrawable(c,true,20f,activity.resources.displayMetrics.density)
        modeButton.imageTintList=ColorStateList.valueOf(if(currentPalette(activity) in listOf(1,3))Color.BLACK else Color.WHITE)
        activity.findViewById<ImageView>(R.id.linkIcon).imageTintList=ColorStateList.valueOf(c.muted)
        activity.findViewById<LiquidWaveView>(R.id.liquidWave).setScheme(c.main,c.second,c.third)
        for(id in intArrayOf(R.id.btnModeVideo,R.id.btnModeAudio,R.id.btnDownload,R.id.btnPaste,R.id.btnCancel,R.id.btnUpdate,R.id.btnOpenDownloads)) {
            activity.findViewById<GlassButton>(id).applyScheme(c,id==R.id.btnDownload||id==R.id.btnPaste)
        }
        for(id in intArrayOf(R.id.qualityBest,R.id.quality480,R.id.quality720,R.id.quality1080))
            activity.findViewById<GlassButton>(id).applyScheme(c)
        activity.findViewById<LinearProgressIndicator>(R.id.progressBar).apply {
            setIndicatorColor(c.main)
            trackColor=withAlpha(c.text,if(c.dark)35 else 45)
        }
        activity.findViewById<GlassProgressIndicator>(R.id.progressBar).applyScheme(c)
        val mono=android.graphics.ColorMatrix().apply {setSaturation(0f)}
        val preset=presets[currentPalette(activity)]
        val tint=android.graphics.ColorMatrix(floatArrayOf(
            .213f*Color.red(preset.first)/255f,.715f*Color.red(preset.first)/255f,.072f*Color.red(preset.first)/255f,0f,0f,
            .213f*Color.green(preset.first)/255f,.715f*Color.green(preset.first)/255f,.072f*Color.green(preset.first)/255f,0f,0f,
            .213f*Color.blue(preset.first)/255f,.715f*Color.blue(preset.first)/255f,.072f*Color.blue(preset.first)/255f,0f,0f,
            0f,0f,0f,1f,0f))
        activity.findViewById<ImageView>(R.id.progressIcon).colorFilter=
            if(currentPalette(activity)==1)android.graphics.ColorMatrixColorFilter(mono) else null
        activity.findViewById<ImageView>(R.id.brandLogo).colorFilter=when(currentPalette(activity)) {
            0,4,5,6,7 -> null
            1 -> android.graphics.ColorMatrixColorFilter(mono)
            else -> android.graphics.ColorMatrixColorFilter(tint)
        }
    }

    private fun applyText(root: ViewGroup,c: Scheme) {
        for(i in 0 until root.childCount) {
            val v=root.getChildAt(i)
            if(v is TextView) {
                val font=if(v.typeface?.isBold==true) R.font.vidora_bold else R.font.vidora_regular
                v.typeface=androidx.core.content.res.ResourcesCompat.getFont(root.context,font)
                if(v !is MaterialButton && v !is Chip) v.setTextColor(c.text)
            }
            if(v is ViewGroup) applyText(v,c)
        }
    }
}
