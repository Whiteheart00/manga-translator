package com.kurd.videodownloader

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import java.io.File
import java.io.IOException

/** Delete only a concrete published record owned by this app. Keep history on every failure. */
internal object NativeFiles {
    fun delete(c:Context,id:String){
        if(DownloadState.running&&DownloadState.action in setOf("convert","cut"))throw IOException("سەرەتا گۆڕین یان بڕینی فایل تەواو بکە یان هەڵیوەشێنەوە")
        val record=NativeHistory.find(c,id)?:throw IOException("فایلەکە لە لیست نییە")
        val uri=Uri.parse(record.getString("uri"))
        if(Build.VERSION.SDK_INT>=29&&uri.scheme=="content"&&uri.authority=="media"){
            require(uri.pathSegments.size>=3&&uri.pathSegments[uri.pathSegments.size-2]=="downloads"&&uri.lastPathSegment?.toLongOrNull()!=null){"ناونیشانی فایلەکە دروست نییە"}
            val count=c.contentResolver.delete(uri,null,null)
            if(count==0){val cursor=c.contentResolver.query(uri,arrayOf("_id"),null,null,null)?:throw IOException("دڵنیابوون لە سڕینەوە سەرکەوتوو نەبوو");val exists=cursor.use{it.moveToFirst()}
                if(exists)throw IOException("فایلەکە نەسڕایەوە؛ تۆمارەکە هەر ماوە")}
        }else{
            require(uri.scheme=="content"&&uri.authority==c.packageName+".files"){"فایلەکە هی ئەم ئەپە نییە"}
            @Suppress("DEPRECATION") val root=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).canonicalFile
            val file=File(record.getString("path")).canonicalFile
            require(file.path.startsWith(root.path+File.separator)&&!file.isDirectory){"تەنها فایلە دابەزێنراوەکانی ئەم ئەپە دەسڕێنەوە"}
            if(file.exists()&&!file.delete())throw IOException("سڕینەوەی فایل سەرکەوتوو نەبوو")
            android.media.MediaScannerConnection.scanFile(c.applicationContext,arrayOf(file.path),null,null)
        }
        NativeHistory.forget(c,id)
        c.securePreferences("player_positions",0).edit().remove("record:$id").apply()
    }
}
