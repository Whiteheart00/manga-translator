package com.kurd.videodownloader

import android.content.Intent
import org.json.JSONObject
import java.io.IOException

/** Times are integer milliseconds, bound to native metadata for this exact source. */
internal data class ClipSelection(val token:String,val startMs:Long,val endMs:Long,val sourceDurationMs:Long) {
    val lengthMs get()=endMs-startMs
    companion object {
        private const val TOKEN="clip_token"
        private const val START="clip_start_ms"
        private const val END="clip_end_ms"
        fun bounds(start:Long,end:Long,duration:Long){
            require(duration in 1000..31_536_000_000L){"درێژی سەرچاوەکە بۆ بڕین دیار نییە"}
            require(start>=0&&start<duration&&end>start&&end<=duration&&end-start>=1000){"سەرەتا و کۆتایی دیاری بکە؛ پارچەکە لانیکەم یەک چرکە بێت"}
        }
        private fun number(json:JSONObject,key:String):Long {
            val value=json.opt(key)
            require(value is Number){"کاتی پارچەکە دروست نییە"}
            val d=value.toDouble()
            require(d.isFinite()&&d>=0&&d<=31_536_000_000L&&d==kotlin.math.floor(d)){"کاتی پارچەکە دروست نییە"}
            return d.toLong()
        }
        fun select(token:String,source:String,start:Long,end:Long):ClipSelection {
            val media=MediaProbe.find(token)?:throw IOException("پێشبینینەکە نوێ بکەرەوە بۆ دیاریکردنی کات")
            require(media.source==source){"پارچەکە بۆ لینکێکی جیاوازە؛ دووبارە دیاری بکە"}
            require(System.currentTimeMillis()-media.created in 0..30*60*1000L){"پێشبینینەکە نوێ بکەرەوە"}
            require(media.clipAllowed){"بۆ لایڤ یان درێژی نادیار، هەمووی هەڵبژێرە"}
            bounds(start,end,media.durationMs)
            return ClipSelection(token,start,end,media.durationMs)
        }
        fun fromJson(json:JSONObject,source:String):ClipSelection? {
            if(!json.has("clip")||json.isNull("clip"))return null
            val clip=json.opt("clip")
            require(clip is JSONObject){"هەڵبژاردنی پارچەکە دروست نییە"}
            val token=clip.opt("token")
            require(token is String&&token.isNotBlank()){"پێشبینینەکە نوێ بکەرەوە"}
            return select(token,source,number(clip,"startMs"),number(clip,"endMs"))
        }
        fun fromIntent(intent:Intent?,source:String):ClipSelection? {
            if(intent==null||!intent.hasExtra(TOKEN)&&!intent.hasExtra(START)&&!intent.hasExtra(END))return null
            return select(intent.getStringExtra(TOKEN).orEmpty(),source,intent.getLongExtra(START,-1),intent.getLongExtra(END,-1))
        }
        fun put(intent:Intent,clip:ClipSelection?){clip?.let{intent.putExtra(TOKEN,it.token).putExtra(START,it.startMs).putExtra(END,it.endMs)}}
    }
}
