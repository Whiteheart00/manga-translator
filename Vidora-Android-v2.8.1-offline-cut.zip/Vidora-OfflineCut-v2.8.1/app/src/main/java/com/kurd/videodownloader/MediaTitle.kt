package com.kurd.videodownloader

/** Android uses ICU regex: inline Java-only (?U) is not supported there. */
internal object MediaTitle {
    private val trailingId=Regex("\\s*\\[[^]]{4,}\\]$")
    private val trailingHashtags=Regex("(?:\\s*[#＃][\\p{L}\\p{N}_]+)+\\s*$")
    private val whitespace=Regex("\\s+")
    fun clean(raw:String):String {
        val file=raw.substringAfterLast('/').substringAfterLast('\\')
        val stem=file.substringBeforeLast('.',file)
        return whitespace.replace(trailingHashtags.replace(trailingId.replace(stem,""),"")," ").trim().take(85)
    }
}

/** yt-dlp invokes its progress callback on a reader thread, outside execute()'s caller. */
internal object ProgressCallback {
    fun safely(report:(Exception)->Unit,work:()->Unit) {
        try{work()}catch(error:Exception){
            try{report(error)}catch(_:Exception){ /* A diagnostic failure must not kill the reader. */ }
        }
    }
}
