package com.kurd.videodownloader

import android.content.Context
import org.json.JSONObject

internal object AppSettings {
    private fun store(c:Context)=c.securePreferences("vidora_native_settings",Context.MODE_PRIVATE)
    fun folder(c:Context)=store(c).getString("folder","VideoDownloader")?:"VideoDownloader"
    fun wifiOnly(c:Context)=store(c).getBoolean("wifi",false)
    fun completionNotifications(c:Context)=store(c).getBoolean("notifications",true)
    fun json(c:Context):JSONObject {
        val p=store(c)
        return JSONObject().put("folder","Downloads/"+folder(c)).put("wifi",wifiOnly(c))
            .put("notifications",completionNotifications(c)).put("format",p.getString("format","MP4"))
            .put("videoQuality",p.getString("videoQuality","1080p"))
            .put("audioQuality",p.getString("audioQuality","320k"))
            .put("mode",p.getString("mode",if(VisualTheme.scheme(c).dark)"dark" else "light"))
            .put("palette",p.getString("palette","rainbow"))
    }
    fun background(c:Context):String{val settings=json(c);return if(settings.optString("mode")=="light")when(settings.optString("palette")){"gold","amber"->"#fffaf0";else->"#eaf1fa"}else when(settings.optString("palette")){"silver"->"#0e1114";"gold"->"#100e06";"amber"->"#2a1309";else->"#061525"}}
    fun save(c:Context,v:JSONObject) {
        val p=store(c).edit()
        if(v.has("wifi"))p.putBoolean("wifi",v.optBoolean("wifi"))
        if(v.has("notifications"))p.putBoolean("notifications",v.optBoolean("notifications",true))
        for((key,allowed) in mapOf("format" to listOf("MP4","MP3"),"videoQuality" to listOf("Best","480p","720p","1080p"),"audioQuality" to listOf("Best","128k","192k","320k"),"mode" to listOf("dark","light"),"palette" to listOf("rainbow","ocean","silver","gold","amber"))) {
            val value=v.optString(key);if(value in allowed)p.putString(key,value)
        }
        if(v.has("folder")) {
            val leaf=v.optString("folder").removePrefix("Downloads/").removePrefix("Download/").trim()
            if(leaf.isNotBlank()&&leaf.length<=60&&leaf!="."&&leaf!=".."&&!leaf.any{it<' '||it in "/\\:*?\"<>|"})p.putString("folder",leaf)
        }
        p.apply()
    }
}
