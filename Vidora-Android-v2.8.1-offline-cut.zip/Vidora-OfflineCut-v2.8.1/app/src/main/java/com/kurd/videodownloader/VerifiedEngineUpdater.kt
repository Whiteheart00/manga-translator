package com.kurd.videodownloader

import android.content.Context
import android.util.AtomicFile
import com.yausername.youtubedl_android.YoutubeDL
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** HTTPS official stable releases + SHA-256, atomic install, encrypted recovery journal. */
internal object VerifiedEngineUpdater {
    private fun binary(c:Context)=File(c.noBackupFilesDir,"${YoutubeDL.baseName}/${YoutubeDL.ytdlpDirName}/${YoutubeDL.ytdlpBin}")
    private fun shaFile(file:File)=file.inputStream().use{stream->val digest=java.security.MessageDigest.getInstance("SHA-256");val buffer=ByteArray(65536);while(true){val n=stream.read(buffer);if(n<0)break;digest.update(buffer,0,n)};digest.digest().joinToString(""){"%02x".format(it.toInt()and 255)}}
    private fun install(target:File,bytes:ByteArray){target.parentFile!!.mkdirs();val atomic=AtomicFile(target);val output=atomic.startWrite();try{output.write(bytes);atomic.finishWrite(output)}catch(error:Exception){atomic.failWrite(output);throw error}}
    @Synchronized fun ensure(c:Context){
        val target=binary(c);val prefs=c.securePreferences("engine_updates")
        if(File(target.path+".bak").isFile)AtomicFile(target).openRead().close()
        val pending=prefs.getString("pending_digest",null)
        val current=if(target.isFile)shaFile(target)else ""
        if(pending!=null&&current==pending){check(prefs.edit().putString("verified_digest",pending).putString("version",prefs.getString("pending_version","verified")).remove("pending_digest").remove("pending_version").commit());return}
        val expected=prefs.getString("verified_digest",null)
        if(expected!=null){check(current==expected){"Engine integrity check failed"};if(pending!=null)prefs.edit().remove("pending_digest").remove("pending_version").commit();return}
        // Existing pre-security cached scripts are not trusted merely because they exist.
        val bundled=c.resources.openRawResource(com.yausername.youtubedl_android.R.raw.ytdlp).use{it.readBytes()}
        val digest=SecurityGate.sha(bundled);if(current!=digest)install(target,bundled)
        // A legacy engine's recent timestamp must not suppress verification of its replacement.
        check(prefs.edit().putString("verified_digest",digest).putString("version","bundled").remove("last_successful_check").remove("pending_digest").remove("pending_version").commit())
    }
    fun checksum(text:String):String=Regex("^([a-fA-F0-9]{64})\\s+\\*?yt-dlp$",RegexOption.MULTILINE).find(text)?.groupValues?.get(1)?.lowercase()?:throw IOException("Official checksum missing")
    fun allowed(url:String):Boolean=try{val uri=java.net.URI(url);val host=uri.host.orEmpty().lowercase();uri.scheme=="https"&&uri.userInfo==null&&host in setOf("api.github.com","github.com","release-assets.githubusercontent.com","objects.githubusercontent.com","github-releases.githubusercontent.com")}catch(_:Exception){false}
    @Synchronized fun update(c:Context,cancelled:()->Boolean,onConnection:(HttpURLConnection?)->Unit):String {
        ensure(c)
        val json=JSONObject(String(fetch("https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest",2*1024*1024,cancelled,onConnection),Charsets.UTF_8))
        val tag=json.getString("tag_name");require(tag.matches(Regex("[0-9A-Za-z._-]{1,64}"))&&!json.optBoolean("draft")&&!json.optBoolean("prerelease"))
        val base="https://github.com/yt-dlp/yt-dlp/releases/download/$tag/"
        val sums=String(fetch(base+"SHA2-256SUMS",1024*1024,cancelled,onConnection),Charsets.UTF_8);val expected=checksum(sums)
        val prefs=c.securePreferences("engine_updates")
        if(prefs.getString("verified_digest",null)!=expected){
            val bytes=fetch(base+"yt-dlp",32*1024*1024,cancelled,onConnection);SecurityGate.requireDigest(bytes,expected)
            if(cancelled())throw IOException("هەڵوەشایەوە")
            check(prefs.edit().putString("pending_digest",expected).putString("pending_version",tag).commit())
            install(binary(c),bytes)
            check(prefs.edit().putString("verified_digest",expected).putString("version",tag).remove("pending_digest").remove("pending_version").commit())
        }
        prefs.edit().putString("version",tag).putLong("last_successful_check",System.currentTimeMillis()).apply()
        return "yt-dlp پشتڕاست کرایەوە: $tag"
    }
    private fun fetch(start:String,limit:Int,cancelled:()->Boolean,onConnection:(HttpURLConnection?)->Unit):ByteArray {
        var url=start
        repeat(8){
            require(allowed(url)){"Untrusted update endpoint"};if(cancelled()||Thread.currentThread().isInterrupted)throw IOException("هەڵوەشایەوە")
            val connection=(URL(url).openConnection()as HttpURLConnection).apply{instanceFollowRedirects=false;connectTimeout=10000;readTimeout=15000;setRequestProperty("User-Agent","Vidora-Updater");setRequestProperty("Accept","application/vnd.github+json")}
            onConnection(connection)
            try{if(cancelled())throw IOException("هەڵوەشایەوە")
                if(connection.responseCode in listOf(301,302,303,307,308)){url=URL(URL(url),connection.getHeaderField("Location")?:throw IOException("Missing redirect")).toString()}
                else{if(connection.responseCode!=200)throw IOException("Official update unavailable")
                    return connection.inputStream.use{stream->val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(65536);var total=0
                        while(true){if(cancelled()||Thread.currentThread().isInterrupted)throw IOException("هەڵوەشایەوە");val n=stream.read(buffer);if(n<0)break;total+=n;if(total>limit)throw IOException("Update exceeds size limit");out.write(buffer,0,n)};out.toByteArray()}
                }
            }finally{connection.disconnect();onConnection(null)}
        }
        throw IOException("Too many update redirects")
    }
}
