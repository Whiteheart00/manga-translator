package com.kurd.videodownloader

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.URI

/** Public Spotlight metadata, bound to the exact URL ID. Never execute page scripts. */
internal object SnapchatSpotlight {
    private val scripts=Regex("<script\\b([^>]*)>(.*?)</script>",setOf(RegexOption.IGNORE_CASE,RegexOption.DOT_MATCHES_ALL))
    private val ldType=Regex("\\btype\\s*=\\s*['\"]application/ld\\+json['\"]",RegexOption.IGNORE_CASE)
    fun id(url:String):String?=try{
        val u=URI(url)
        if(u.scheme!="https"||u.userInfo!=null||u.host.orEmpty().lowercase() !in setOf("snapchat.com","www.snapchat.com")||u.port !in listOf(-1,443))null
        else {val p=u.path.orEmpty().trim('/').split('/');val value=when{
            p.size==2&&p[0]=="spotlight"->p[1]
            p.size==3&&p[0].startsWith("@")&&p[1]=="spotlight"->p[2]
            else->""
        };value.takeIf{it.matches(Regex("[A-Za-z0-9_-]{8,180}"))}}
    }catch(_:Exception){null}
    fun verifyRedirect(original:String,resolved:String){
        val expected=id(original)?:return
        if(id(resolved)!=expected)throw IOException("Spotlight ـی داواکراو گۆڕدراوە؛ ڤیدیۆی جیاواز هەڵنابژێردرێت")
    }
    fun parse(html:String,url:String):JSONObject {
        val target=id(url)?:throw IOException("لینکی خودی Spotlight پێویستە")
        val candidates=mutableListOf<JSONObject>()
        fun collect(value:Any?,depth:Int=0){
            if(depth>8||candidates.size>128)throw IOException("زانیاریی Spotlight زۆر گەورەیە")
            when(value){
                is JSONArray->for(i in 0 until value.length())collect(value.opt(i),depth+1)
                is JSONObject->{
                    val type=value.opt("@type")
                    if(type=="VideoObject"||(type is JSONArray&&(0 until type.length()).any{type.optString(it)=="VideoObject"}))candidates+=value
                    collect(value.opt("@graph"),depth+1);collect(value.opt("video"),depth+1)
                }
            }
        }
        for(script in scripts.findAll(html))if(ldType.containsMatchIn(script.groupValues[1])){
            val value=try{JSONTokener(script.groupValues[2]).nextValue()}catch(_:org.json.JSONException){continue}
            collect(value)
        }
        val exact=candidates.filter{id(it.optString("url"))==target}
        if(exact.isNotEmpty()){
            for(video in exact){
                val entity=video.opt("mainEntityOfPage")
                val entityUrl=when(entity){is JSONObject->entity.optString("@id");is String->entity;else->""}
                if(entityUrl.isNotBlank()&&id(entityUrl)!=target)throw IOException("ناسنامەی Spotlight یەک ناگرێتەوە")
                val embed=video.optString("embedUrl")
                if(embed.isNotBlank()&&id(embed.removeSuffix("/embed"))!=target)throw IOException("ناسنامەی Spotlight یەک ناگرێتەوە")
                guard(video)
            }
            if(exact.map{it.optString("contentUrl")}.distinct().size!=1)throw IOException("سەرچاوەی Spotlight ناڕوونە")
            val video=exact.first()
            val encoding=video.optString("encodingFormat")
            if(encoding.isNotBlank()&&encoding.lowercase() !in listOf("video/mp4","mp4"))throw IOException("ئەم Spotlight ـە ڤیدیۆی MP4 نییە")
            return info(target,url,video.optString("contentUrl"),video.optString("name"),video.opt("thumbnailUrl"),duration(video.optString("duration")),video.optInt("width",0),video.optInt("height",0))
        }
        // Older public Spotlight pages still use Pages Router metadata.
        val data=Regex("<script\\b[^>]*\\bid\\s*=\\s*['\"]__NEXT_DATA__['\"][^>]*>(.*?)</script>",setOf(RegexOption.IGNORE_CASE,RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)
        if(data!=null){
            val root=try{JSONObject(data)}catch(_:org.json.JSONException){throw IOException("زانیاریی Spotlight ناتوانرێت بخوێندرێتەوە")}
            val props=root.optJSONObject("props")?.optJSONObject("pageProps")
            if(props?.optBoolean("showSnapExpiredToast")==true)throw IOException("ئەم Spotlight ـە بەسەرچووە یان چیتر گشتی نییە")
            val stories=props?.optJSONObject("spotlightFeed")?.optJSONArray("spotlightStories")
            if(stories!=null)for(i in 0 until stories.length()){
                val item=stories.optJSONObject(i)?:continue
                if(item.optJSONObject("story")?.optJSONObject("storyId")?.optString("value")!=target)continue
                val meta=item.optJSONObject("metadata")?:continue;val video=meta.optJSONObject("videoMetadata")?:continue
                guard(item);guard(video)
                return info(target,url,video.optString("contentUrl"),video.optString("name"),video.opt("thumbnailUrl"),video.optDouble("durationMs",0.0)/1000,video.optInt("width",0),video.optInt("height",0))
            }
        }
        throw IOException("ڤیدیۆی داواکراوی Spotlight نەدۆزرایەوە؛ ڕەنگە بەسەرچووبێت یان گشتی نەبێت")
    }
    private fun guard(video:JSONObject){
        if(video.optInt("age_limit",0)>=18||video.optInt("minimumAge",0)>=18||!video.optBoolean("isFamilyFriendly",true))throw SafetyException("ناوەڕۆکی 18+ ڕێگەپێنەدراوە")
        val rating=video.optString("contentRating").lowercase()
        if(rating.contains("18")||rating.contains("adult")||rating.contains("restricted"))throw SafetyException("ناوەڕۆکی 18+ ڕێگەپێنەدراوە")
        if(video.optBoolean("requiresSubscription")||!video.optBoolean("isAccessibleForFree",true)||video.has("audienceGateSettings")&&video.opt("audienceGateSettings")!=JSONObject.NULL)throw SafetyException("ئەم Spotlight ـە سنووردارە و ڕێگەپێنەدراوە")
    }
    private fun duration(value:String):Double{
        val m=Regex("PT(?:(\\d+(?:\\.\\d+)?)H)?(?:(\\d+(?:\\.\\d+)?)M)?(?:(\\d+(?:\\.\\d+)?)S)?").matchEntire(value)?:return 0.0
        return ((m.groupValues[1].toDoubleOrNull()?:0.0)*3600+(m.groupValues[2].toDoubleOrNull()?:0.0)*60+(m.groupValues[3].toDoubleOrNull()?:0.0)).coerceIn(0.0,86400.0)
    }
    private fun info(target:String,page:String,media:String,title:String,thumbnail:Any?,duration:Double,width:Int,height:Int):JSONObject{
        SnapchatSource.requireCdn(media)
        val thumb=when(thumbnail){is String->thumbnail;is JSONArray->thumbnail.optString(0);else->""}.takeIf{try{SnapchatSource.requireCdn(it);true}catch(_:Exception){false}}.orEmpty()
        return JSONObject().put("id",target).put("title",title.ifBlank{"Snapchat Spotlight"}).put("url",media).put("ext","mp4").put("protocol","https")
            .put("duration",duration).put("width",width).put("height",height).put("thumbnail",thumb).put("age_limit",0)
            .put("webpage_url",page).put("original_url",page).put("extractor","VidoraSnapchatSpotlight").put("extractor_key","VidoraSnapchatSpotlight")
            .put("http_headers",JSONObject().put("User-Agent","Mozilla/5.0").put("Referer","https://www.snapchat.com/"))
    }
}
