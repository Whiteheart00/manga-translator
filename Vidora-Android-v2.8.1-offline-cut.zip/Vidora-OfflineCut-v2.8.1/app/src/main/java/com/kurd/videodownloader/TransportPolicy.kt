package com.kurd.videodownloader
import android.content.Context
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
internal object TransportPolicy {
    @Synchronized fun configure(c:Context,request:YoutubeDLRequest){
        val root=File(c.noBackupFilesDir,"security-plugins")
        val file=File(root,"vidora/yt_dlp_plugins/postprocessor/vidora_transport.py")
        val bytes=c.assets.open("security/vidora_transport.py").use{it.readBytes()}
        if(!file.isFile||SecurityGate.sha(file.readBytes())!=SecurityGate.sha(bytes)){
            file.parentFile!!.mkdirs();val tmp=File(file.parentFile,"transport.tmp");tmp.writeBytes(bytes);check(tmp.renameTo(file)){"Policy install failed"}
        }
        request.addOption("--ignore-config")
        request.addOption("--no-plugin-dirs")
        request.addOption("--plugin-dirs",root.absolutePath)
        request.addOption("--use-postprocessor","VidoraTransport:when=pre_process")
    }
}
