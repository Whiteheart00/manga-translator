package com.kurd.videodownloader

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

internal object NativeHistory {
    private fun prefs(c:Context)=c.securePreferences("vidora_file_history",Context.MODE_PRIVATE)
    @Synchronized private fun read(c:Context)=try{JSONArray(prefs(c).getString("items","[]"))}catch(_:Exception){JSONArray()}
    @Synchronized fun list(c:Context):JSONArray {
        val out=JSONArray();val records=read(c)
        for(i in 0 until records.length()){val item=records.getJSONObject(i);if(!item.optBoolean("hidden"))out.put(item)}
        return out
    }
    @Synchronized fun find(c:Context,id:String):JSONObject? {
        val records=read(c);for(i in 0 until records.length()){val item=records.getJSONObject(i);if(item.optString("id")==id)return item};return null
    }
    @Synchronized fun add(c:Context,media:PublishedMedia,url:String,quality:String):JSONObject {
        val extension=media.name.substringAfterLast('.',"").lowercase(Locale.ROOT)
        val item=JSONObject().put("id",UUID.randomUUID().toString()).put("title",media.name.substringBeforeLast('.'))
            .put("name",media.name).put("uri",media.uri.toString()).put("path",media.path?:"").put("mime",media.mime)
            .put("bytes",media.bytes).put("size",String.format(Locale.US,"%.2f MB",media.bytes/1048576.0))
            .put("format",extension.uppercase(Locale.ROOT)).put("quality",quality)
            .put("host",Uri.parse(url).host.orEmpty()).put("url",url).put("favorite",false).put("hidden",false)
            .put("time",SimpleDateFormat("yyyy.MM.dd · HH:mm",Locale.US).format(Date()))
        val old=read(c);val all=JSONArray().put(item);for(i in 0 until old.length().coerceAtMost(499))all.put(old.getJSONObject(i))
        prefs(c).edit().putString("items",all.toString()).apply();return item
    }
    @Synchronized fun change(c:Context,id:String,operation:(JSONObject)->Unit):Boolean {
        val all=read(c);for(i in 0 until all.length()){val item=all.getJSONObject(i);if(item.optString("id")==id){operation(item);prefs(c).edit().putString("items",all.toString()).apply();return true}};return false
    }
    @Synchronized fun forget(c:Context,id:String){
        MediaCovers.remove(c,id)
        val old=read(c);val kept=JSONArray();for(i in 0 until old.length()){val item=old.getJSONObject(i);if(item.optString("id")!=id)kept.put(item)}
        prefs(c).edit().putString("items",kept.toString()).apply()
    }
    fun rename(c:Context,id:String,title:String):Boolean {
        val safe=title.trim().take(80)
        require(safe.isNotBlank()&&safe!="."&&safe!=".."&&!safe.any{it<' '||it in "/\\:*?\"<>|"}){"ناوی فایل دروست نییە"}
        return change(c,id){item->
            val oldName=item.getString("name");val ext=oldName.substringAfterLast('.',"")
            val newName=if(ext.isBlank()||safe.endsWith(".$ext",true))safe else "$safe.$ext"
            if(Build.VERSION.SDK_INT>=29) {
                val values=ContentValues().apply{put(MediaStore.MediaColumns.DISPLAY_NAME,newName)}
                check(c.contentResolver.update(Uri.parse(item.getString("uri")),values,null,null)>0){"گۆڕینی ناو سەرکەوتوو نەبوو"}
            }else {
                val source=File(item.getString("path"));val target=File(source.parentFile,newName)
                check(!target.exists()&&source.renameTo(target)){"ناوەکە بەردەست نییە"}
                item.put("path",target.absolutePath).put("uri",FileProvider.getUriForFile(c,c.packageName+".files",target).toString())
            }
            item.put("name",newName).put("title",newName.substringBeforeLast('.'))
        }
    }
}
