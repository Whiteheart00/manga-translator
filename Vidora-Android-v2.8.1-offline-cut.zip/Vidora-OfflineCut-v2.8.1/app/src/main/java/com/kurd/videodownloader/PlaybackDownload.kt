package com.kurd.videodownloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URL

/** Reuse only the rendition actually extracted for playback, never arbitrary JS-supplied URLs. */
internal object PlaybackDownload {
    private val fields=listOf("url","ext","is_watermarked","watermarked","watermark","format_id","format_note","protocol","vcodec","acodec","width","height","fps","tbr","abr","asr","audio_channels","language","filesize","filesize_approx","manifest_url","fragment_base_url")
    private fun headers(value:JSONObject?):JSONObject {val result=JSONObject();value?.keys()?.forEach{key->val text=value.optString(key);if(!key.contains('\r')&&!key.contains('\n')&&!text.contains('\r')&&!text.contains('\n'))result.put(key,text)};return result}
    fun capture(c:Context,value:JSONObject,source:String):JSONObject {
        SourceSafety.check(c,source);SourceSafety.metadata(c,value)
        if(value.optBoolean("has_drm"))throw IOException("ناوەڕۆکی پارێزراو ناتوانرێت دابەزێندرێت")
        val selected=value.optJSONArray("requested_formats")?:JSONArray().put(value)
        val formats=JSONArray()
        for(i in 0 until selected.length()){
            val original=selected.getJSONObject(i);if(original.optBoolean("has_drm"))throw IOException("ناوەڕۆکی پارێزراوە")
            val format=JSONObject();for(key in fields)if(original.has(key)&&!original.isNull(key))format.put(key,original.get(key))
            SourceSafety.check(c,format.getString("url"))
            for(key in listOf("manifest_url","fragment_base_url"))format.optString(key).takeIf{it.isNotBlank()}?.let{SourceSafety.check(c,it)}
            val common=headers(value.optJSONObject("http_headers"));val specific=headers(original.optJSONObject("http_headers"));specific.keys().forEach{key->common.put(key,specific.get(key))};format.put("http_headers",common)
            original.optJSONArray("fragments")?.let{parts->
                require(parts.length()<=20000){"سەرچاوەکە زۆر درێژە؛ داگرتنی ئاسایی تاقی بکەوە"}
                val fragments=JSONArray()
                for(j in 0 until parts.length()){
                    val part=parts.getJSONObject(j);val fragment=JSONObject()
                    for(key in listOf("url","path","duration","range"))if(part.has(key))fragment.put(key,part.get(key))
                    val link=part.optString("url").ifBlank{URL(URL(format.getString("fragment_base_url")),part.getString("path")).toString()}
                    SourceSafety.check(c,link);fragments.put(fragment)
                };format.put("fragments",fragments)
            }
            formats.put(format)
        }
        val id=value.optString("id").takeIf{it.matches(Regex("[A-Za-z0-9_-]{1,200}"))}?:java.util.UUID.randomUUID().toString()
        val info=JSONObject().put("id",id).put("title",value.optString("title","ڤیدیۆ")).put("webpage_url",source).put("original_url",source)
            .put("extractor","VidoraPlayback").put("extractor_key","VidoraPlayback").put("formats",formats)
        for(key in listOf("age_limit","categories","duration"))if(value.has(key))info.put(key,value.get(key))
        return info
    }
    fun media(c:Context,token:String,source:String):PreviewMedia {
        val media=MediaProbe.find(token)?:throw IOException("لینکی پەخش بەسەرچووە؛ دووبارە پێشبینین بکەوە")
        if(media.source!=source)throw IOException("سەرچاوەی پەخش ناگونجێت")
        SourceSafety.check(c,source)
        if(media.downloadInfo?.isFile!=true)throw IOException("زانیاریی داگرتنی ئەم پەخشە بەردەست نییە؛ لینکەکە دووبارە بکەرەوە")
        return media
    }
    fun request(c:Context,media:PreviewMedia,work:File):YoutubeDLRequest {
        val original=media.downloadInfo?:throw IOException("زانیاریی پەخش نەماوە")
        val info=JSONObject(SecretFiles.read(original));SourceSafety.metadata(c,info)
        val formats=info.getJSONArray("formats")
        for(i in 0 until formats.length())SourceSafety.check(c,formats.getJSONObject(i).getString("url"))
        val copy=File(work,"playback-source.info.json");copy.writeText(info.toString())
        return YoutubeDLRequest(emptyList()).addOption("--load-info-json",copy.absolutePath)
    }
}
