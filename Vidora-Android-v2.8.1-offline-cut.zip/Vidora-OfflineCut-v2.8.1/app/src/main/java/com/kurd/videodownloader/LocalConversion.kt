package com.kurd.videodownloader

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import java.io.File
import java.io.IOException

internal object LocalConversion {
    fun arguments(input:String,output:String,poster:String?):List<String> =
        if(poster==null)listOf("-y","-i",input,"-vn","-c:a","libmp3lame","-b:a","320k","-progress","pipe:1","-nostats",output)
        else listOf("-y","-loop","1","-framerate","10","-i",poster,"-i",input,"-c:v","libx264","-preset","ultrafast","-tune","stillimage","-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-shortest","-movflags","+faststart","-progress","pipe:1","-nostats",output)
    fun run(c:Context,id:String,target:String,cancelled:()->Boolean,onProcess:(Process?)->Unit,onProgress:(Int)->Unit):PublishedMedia{
        require(target in listOf("MP3","MP4"))
        val record=NativeHistory.find(c,id)?:throw IOException("فایلەکە نەدۆزرایەوە")
        val original=record.optString("url");if(original.startsWith("http"))SourceSafety.check(c,original)
        val mime=record.optString("mime")
        require(if(target=="MP3")mime.startsWith("video/") else mime.startsWith("audio/")){"ئەم گۆڕانە بۆ جۆری فایلەکە گونجاو نییە"}
        YoutubeDL.getInstance().init(c.applicationContext);FFmpeg.getInstance().init(c.applicationContext)
        val folder=File(c.cacheDir,"convert_${System.nanoTime()}").apply{mkdirs()}
        try{
            val input=File(folder,"input."+record.getString("name").substringAfterLast('.'))
            c.contentResolver.openInputStream(Uri.parse(record.getString("uri")))?.use{source->input.outputStream().use{out->
                val buffer=ByteArray(65536);while(true){if(cancelled())throw IOException("هەڵوەشایەوە");val n=source.read(buffer);if(n<0)break;out.write(buffer,0,n)}
            }}?:throw IOException("خوێندنەوەی فایل سەرکەوتوو نەبوو")
            var duration=0L;val retriever=MediaMetadataRetriever()
            try{retriever.setDataSource(input.absolutePath);duration=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L}catch(_:Exception){}finally{retriever.release()}
            val safeTitle=record.optString("title","Vidora").map{if(it<' '||it in "/\\:*?\"<>|")'_' else it}.joinToString("").take(60).ifBlank{"Vidora"}
            val output=File(folder,safeTitle+(if(target=="MP3")"_audio.mp3" else "_video.mp4"))
            val poster=if(target=="MP4")File(folder,"poster.jpg").also{createPoster(it,record.optString("title"))}else null
            val binary=File(c.applicationInfo.nativeLibraryDir,"libffmpeg.so")
            val builder=ProcessBuilder(listOf(binary.absolutePath)+arguments(input.absolutePath,output.absolutePath,poster?.absolutePath)).redirectErrorStream(true)
            val packages=File(c.noBackupFilesDir,"youtubedl-android/packages")
            builder.environment()["LD_LIBRARY_PATH"]=File(packages,"ffmpeg/usr/lib").absolutePath+":"+File(packages,"python/usr/lib").absolutePath
            builder.environment()["TMPDIR"]=c.cacheDir.absolutePath
            if(cancelled())throw IOException("هەڵوەشایەوە")
            val process=builder.start();onProcess(process);if(cancelled())process.destroy();val tail=StringBuilder()
            try{
                process.inputStream.bufferedReader().useLines{lines->lines.forEach{line->
                    if(cancelled()){process.destroy();throw IOException("هەڵوەشایەوە")}
                    if(line.startsWith("out_time_us=")){val value=line.substringAfter('=').toLongOrNull()?:0L;if(duration>0)onProgress((value/10/duration).toInt().coerceIn(0,99))}
                    if(tail.length>6000)tail.delete(0,3000);tail.append(line).append('\n')
                }}
                if(process.waitFor()!=0||!output.isFile||output.length()==0L)throw IOException("FFmpeg: "+tail.takeLast(1800))
            }finally{onProcess(null);process.destroy()}
            if(cancelled())throw IOException("هەڵوەشایەوە")
            return StoragePublisher.publish(c,output,target=="MP3",cancelled)
        }finally{folder.deleteRecursively()}
    }
    private fun createPoster(file:File,title:String){
        val bitmap=Bitmap.createBitmap(720,1280,Bitmap.Config.ARGB_8888);val canvas=Canvas(bitmap);val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader=LinearGradient(0f,0f,720f,1280f,intArrayOf(Color.rgb(6,21,37),Color.rgb(7,75,98),Color.rgb(61,28,100)),null,Shader.TileMode.CLAMP);canvas.drawRect(0f,0f,720f,1280f,paint)
        paint.shader=null;paint.color=Color.rgb(40,240,218);canvas.drawCircle(360f,450f,130f,paint)
        paint.color=Color.WHITE;val triangle=Path().apply{moveTo(330f,375f);lineTo(330f,525f);lineTo(435f,450f);close()};canvas.drawPath(triangle,paint)
        paint.textAlign=Paint.Align.CENTER;paint.textSize=70f;paint.typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD);canvas.drawText("VIDORA",360f,715f,paint)
        paint.textSize=32f;canvas.drawText(title.take(32),360f,800f,paint)
        file.outputStream().use{bitmap.compress(Bitmap.CompressFormat.JPEG,90,it)};bitmap.recycle()
    }
}
