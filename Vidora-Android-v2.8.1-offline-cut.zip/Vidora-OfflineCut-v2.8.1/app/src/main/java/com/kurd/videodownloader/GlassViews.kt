package com.kurd.videodownloader

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.widget.FrameLayout
import com.google.android.material.button.MaterialButton
import androidx.core.graphics.ColorUtils

/** Static optical layers; the controls remain native Android views with real touch targets. */
class GlassDrawable(private val scheme: VisualTheme.Scheme, private val accent: Boolean = false,
                    private val radiusDp: Float = 18f, private val density: Float = 1f) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var opacity = 255
    override fun draw(canvas: Canvas) {
        val d = density
        val r = RectF(bounds).apply { inset(1.5f*d, 1.5f*d) }
        val radius = radiusDp*d
        val fill = if (accent) intArrayOf(scheme.main, scheme.second, scheme.third)
            else intArrayOf(ColorUtils.setAlphaComponent(scheme.text, if (scheme.dark) 46 else 115),
                ColorUtils.setAlphaComponent(scheme.input, if (scheme.dark) 130 else 155),
                ColorUtils.setAlphaComponent(scheme.main, if (scheme.dark) 27 else 30))
        paint.style = Paint.Style.FILL
        paint.alpha = opacity
        val horizontal=LinearGradient(r.left,r.top,r.right,r.bottom,fill,null,Shader.TileMode.CLAMP)
        paint.shader=if(accent && android.os.Build.VERSION.SDK_INT>=28) ComposeShader(horizontal,
            LinearGradient(0f,r.top,0f,r.bottom,intArrayOf(Color.WHITE,Color.rgb(175,175,175),Color.rgb(248,248,248)),
                floatArrayOf(0f,.53f,1f),Shader.TileMode.CLAMP),PorterDuff.Mode.MULTIPLY) else horizontal
        canvas.drawRoundRect(r,radius,radius,paint)
        val save = canvas.save()
        val clip = Path().apply { addRoundRect(r,radius,radius,Path.Direction.CW) }
        canvas.clipPath(clip)
        paint.shader=RadialGradient(r.left+r.width()*.20f,r.top-r.height()*.5f,r.width()*.65f,
            intArrayOf(ColorUtils.setAlphaComponent(Color.WHITE,if(accent)130 else 50),Color.TRANSPARENT),null,Shader.TileMode.CLAMP)
        canvas.drawRect(r,paint)
        canvas.restoreToCount(save)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.6f*d
        paint.shader = LinearGradient(r.left,r.top,r.right,r.bottom,
            intArrayOf(ColorUtils.setAlphaComponent(Color.WHITE,180),ColorUtils.setAlphaComponent(scheme.main,25),
                ColorUtils.setAlphaComponent(Color.WHITE,95)),null,Shader.TileMode.CLAMP)
        canvas.drawRoundRect(r,radius,radius,paint)
        r.inset(1.2f*d,1.2f*d)
        paint.strokeWidth = .65f*d
        paint.shader = LinearGradient(0f,r.top,0f,r.bottom,
            intArrayOf(ColorUtils.setAlphaComponent(Color.WHITE,225),ColorUtils.setAlphaComponent(Color.WHITE,20),
                ColorUtils.setAlphaComponent(Color.WHITE,155)),floatArrayOf(0f,.48f,1f),Shader.TileMode.CLAMP)
        canvas.drawRoundRect(r,radius,radius,paint)
        paint.shader = null
    }
    override fun setAlpha(alpha: Int) { opacity=alpha;invalidateSelf() }
    override fun setColorFilter(filter: ColorFilter?) { paint.colorFilter=filter;invalidateSelf() }
    @Deprecated("Deprecated in Android") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

class GlassPanel @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : FrameLayout(context,attrs) {
    init { setWillNotDraw(false) }
    fun applyScheme(s: VisualTheme.Scheme, radius: Float=18f) {
        background=GlassDrawable(s,false,radius,resources.displayMetrics.density)
    }
}

class GlassButton @JvmOverloads constructor(context: Context,attrs: AttributeSet?=null) : MaterialButton(context,attrs) {
    private var glass: VisualTheme.Scheme? = null
    var alwaysAccent = false
    fun applyScheme(s: VisualTheme.Scheme, accent: Boolean=false) {
        glass=s;alwaysAccent=accent
        backgroundTintList=ColorStateList.valueOf(Color.TRANSPARENT)
        strokeWidth=0
        val states=arrayOf(intArrayOf(android.R.attr.state_checked),intArrayOf())
        val selectedInk = if (VisualTheme.currentPalette(context) in listOf(1,3)) Color.BLACK else Color.WHITE
        val colors=ColorStateList(states,intArrayOf(selectedInk,if(accent) selectedInk else s.text))
        setTextColor(colors);iconTint=colors
        invalidate()
    }
    override fun onDraw(canvas: Canvas) {
        glass?.let { s -> GlassDrawable(s,alwaysAccent||isChecked,if(height>width) 16f else 24f,resources.displayMetrics.density).apply {
            bounds=Rect(0,0,width,height);alpha=if(isEnabled)255 else 130;draw(canvas)
        } }
        super.onDraw(canvas)
    }
}

/** Soft background ribbons are drawn once per layout, never on a frame timer. */
class AmbientDrawable(private val s: VisualTheme.Scheme) : Drawable() {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(canvas: Canvas) {
        val w=bounds.width().toFloat();val h=bounds.height().toFloat()
        paint.shader=LinearGradient(0f,0f,w,h,intArrayOf(s.background,
            ColorUtils.blendARGB(s.background,s.main,if(s.dark).11f else .05f),s.bottom),null,Shader.TileMode.CLAMP)
        canvas.drawRect(bounds,paint)
        for (bottom in listOf(false,true)) {
            val top=if(bottom) h*.94f else h*.13f
            paint.shader=RadialGradient(if(bottom)w*.9f else w*.1f,top,w*.6f,
                ColorUtils.setAlphaComponent(if(bottom)s.second else s.main,if(s.dark)60 else 30),Color.TRANSPARENT,Shader.TileMode.CLAMP)
            canvas.drawRect(bounds,paint)
            val path=Path().apply {
                moveTo(0f,top)
                cubicTo(w*.22f,top-h*.04f,w*.29f,top+h*.10f,w*.52f,top+h*.06f)
                cubicTo(w*.8f,top-h*.02f,w*.9f,top+h*.07f,w,top-h*.02f)
            }
            paint.style=Paint.Style.STROKE
            for(stroke in listOf(18f,9f,3f,1f)) {
                paint.strokeWidth=stroke
                paint.shader=LinearGradient(0f,top,w,top,
                    intArrayOf(ColorUtils.setAlphaComponent(s.main,if(stroke>3)8 else 65),Color.TRANSPARENT,
                        ColorUtils.setAlphaComponent(s.second,if(stroke>3)8 else 65)),null,Shader.TileMode.CLAMP)
                canvas.drawPath(path,paint)
            }
            paint.style=Paint.Style.FILL
        }
        paint.shader=null
    }
    override fun setAlpha(alpha:Int){}
    override fun setColorFilter(colorFilter:ColorFilter?){}
    @Deprecated("Deprecated in Android") override fun getOpacity()=PixelFormat.OPAQUE
}

/** The existing service percentage drives a multicolor optical progress track. */
class GlassProgressIndicator @JvmOverloads constructor(context:Context,attrs:AttributeSet?=null) :
    com.google.android.material.progressindicator.LinearProgressIndicator(context,attrs) {
    private var glass:VisualTheme.Scheme?=null
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    fun applyScheme(s:VisualTheme.Scheme) {glass=s;invalidate()}
    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas)
        val s=glass ?: return
        if(isIndeterminate||progress<=0||max<=0) return
        val l=paddingLeft.toFloat();val t=paddingTop.toFloat()
        val available=(width-paddingLeft-paddingRight).toFloat()
        val h=(height-paddingTop-paddingBottom).toFloat()
        val r=l+available*progress/max
        paint.shader=LinearGradient(l,0f,l+available,0f,intArrayOf(s.main,s.second,s.third),null,Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(l,t,r,t+h),h/2,h/2,paint)
        paint.shader=LinearGradient(0f,t,0f,t+h,ColorUtils.setAlphaComponent(Color.WHITE,170),Color.TRANSPARENT,Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(l,t,r,t+h*.45f),h/2,h/2,paint)
        paint.shader=null
    }
}
