package com.kurd.videodownloader

import android.content.Context
import org.json.JSONObject
import java.net.IDN
import java.net.URI
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.io.IOException

internal class SafetyException(message:String):IOException(message)
internal object SourceSafety {
    private var adult:LongArray?=null
    private var gambling:LongArray?=null
    @Synchronized private fun ensureLoaded(c:Context){if(adult!=null)return
        fun read(name:String):LongArray {val bytes=c.assets.open("safety/$name.bin").use{it.readBytes()};val b=ByteBuffer.wrap(bytes);return LongArray(bytes.size/8){b.long}}
        adult=read("adult");gambling=read("gambling")
    }
    fun host(url:String):String {
        val uri=try{URI(url)}catch(_:Exception){throw SafetyException("لینکەکە دروست نییە")}
        if(uri.scheme?.lowercase() !in listOf("https")||uri.userInfo!=null)throw SafetyException("تەنها لینکی پارێزراوی HTTPS ڕێگەپێدراوە")
        val name=uri.host?.trimEnd('.')?.lowercase()?:throw SafetyException("ناوی ماڵپەڕ نادیارە")
        if(name.contains(':')||name.matches(Regex("[0-9.]+"))||!name.contains('.'))throw SafetyException("لینکی ژمارەی IP ڕێگەپێنەدراوە")
        return IDN.toASCII(name)
    }
    private fun hash(host:String)=ByteBuffer.wrap(MessageDigest.getInstance("SHA-256").digest(host.toByteArray())).long
    fun check(c:Context,url:String){val host=host(url);ensureLoaded(c)
        var part=host
        while(part.contains('.')){val value=hash(part)
            if(java.util.Arrays.binarySearch(adult!!,value)>=0)throw SafetyException("ئەم ماڵپەڕە بەهۆی ناوەڕۆکی سێکسی/18+ بلۆک کراوە")
            if(java.util.Arrays.binarySearch(gambling!!,value)>=0)throw SafetyException("ئەم ماڵپەڕە بەهۆی قومار بلۆک کراوە")
            part=part.substringAfter('.')
        }
    }
    fun metadata(c:Context,value:JSONObject){
        if(value.optInt("age_limit",0)>=18)throw SafetyException("ناوەڕۆکی 18+ ڕێگەپێنەدراوە")
        for(key in listOf("webpage_url","original_url")){val link=value.optString(key);if(link.startsWith("http"))check(c,link)}
        val categories=value.optJSONArray("categories")
        if(categories!=null)for(i in 0 until categories.length()){
            val text=categories.optString(i).lowercase()
            if(text.contains("porn")||text.contains("gambling")||text.contains("casino")||text=="adult")throw SafetyException("ئەم جۆرە ناوەڕۆکە بلۆک کراوە")
        }
    }
    fun resolve(c:Context,url:String,headers:Map<String,String> = emptyMap(),cancelled:()->Boolean={false},onConnection:(HttpURLConnection?)->Unit={}):String {
        var current=url;val visited=mutableSetOf<String>()
        repeat(8){if(cancelled())throw IOException("هەڵوەشایەوە");check(c,current);if(!visited.add(current))throw SafetyException("لینکەکە گەڕانەوەی دووبارەی هەیە")
            val connection=(URL(current).openConnection() as HttpURLConnection).apply{
                instanceFollowRedirects=false;requestMethod="HEAD";connectTimeout=10000;readTimeout=10000
                setRequestProperty("User-Agent",headers["User-Agent"]?:"Mozilla/5.0")
                for((k,v)in headers)if(!k.contains('\n')&&!v.contains('\n')&&!v.contains('\r'))setRequestProperty(k,v)
            }
            onConnection(connection)
            try{if(cancelled())throw IOException("هەڵوەشایەوە");val status=connection.responseCode
                if(status in listOf(301,302,303,307,308)){val location=connection.getHeaderField("Location")?:return current;current=URL(URL(current),location).toString()}
                else return current
            }finally{connection.disconnect();onConnection(null)}
        }
        throw SafetyException("لینکەکە زۆر گواستنەوەی هەیە")
    }
}
