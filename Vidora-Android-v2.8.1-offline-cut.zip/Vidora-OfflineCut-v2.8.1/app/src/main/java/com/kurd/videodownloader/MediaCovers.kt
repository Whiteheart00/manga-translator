package com.kurd.videodownloader

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Semaphore

/** App-private, regenerable JPEG covers from authoritative local history records. No network. */
internal object MediaCovers {
    private val permit=Semaphore(1)
    private val failures=ConcurrentHashMap<String,Long>()
    private val ids=Regex("[a-f0-9-]{36}")
    private fun file(c:Context,id:String)=File(File(c.cacheDir,"media-covers"),"$id.jpg")
    fun remove(c:Context,id:String){if(ids.matches(id)){file(c,id).delete();failures.remove(id)}}
    fun load(c:Context,id:String):File? {
        if(!ids.matches(id))return null
        val record=NativeHistory.find(c,id)?:return null
        try{
            val source=record.optString("url");if(source.startsWith("http"))SourceSafety.check(c,source)
            val uri=Uri.parse(record.getString("uri"));require(uri.scheme=="content")
            if(uri.authority=="media")require(uri.pathSegments.size>=3&&uri.pathSegments[uri.pathSegments.size-2]=="downloads"&&uri.lastPathSegment?.toLongOrNull()!=null)
            else{
                require(uri.authority==c.packageName+".files")
                @Suppress("DEPRECATION") val root=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).canonicalFile
                require(File(record.getString("path")).canonicalPath.startsWith(root.path+File.separator))
            }
            val target=file(c,id);if(target.isFile&&target.length()>0){target.setLastModified(System.currentTimeMillis());return target}
            if(System.currentTimeMillis()-(failures[id]?:0L)<30000)return null
            permit.acquire()
            try{
                if(target.isFile&&target.length()>0)return target
                val retriever=MediaMetadataRetriever();var bitmap:Bitmap?=null
                try{
                    retriever.setDataSource(c,uri)
                    bitmap=if(record.optString("mime").startsWith("video/")||record.optString("mime").isBlank()&&record.optString("format")in setOf("MP4","MKV","WEBM","MOV","M4V","AVI","FLV")){
                        if(Build.VERSION.SDK_INT>=27)retriever.getScaledFrameAtTime(1_000_000,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,384,384)
                            ?:retriever.getFrameAtTime(1_000_000,MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        else retriever.getFrameAtTime(1_000_000,MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    }else retriever.embeddedPicture?.let{android.graphics.BitmapFactory.decodeByteArray(it,0,it.size)}
                    val frame=bitmap;if(frame==null){failures[id]=System.currentTimeMillis();return null}
                    if(NativeHistory.find(c,id)==null)return null
                    val scale=minOf(1.0,384.0/maxOf(frame.width,frame.height));val small=if(scale<1)Bitmap.createScaledBitmap(frame,(frame.width*scale).toInt().coerceAtLeast(1),(frame.height*scale).toInt().coerceAtLeast(1),true)else frame
                    target.parentFile!!.mkdirs();val temp=File(target.parentFile,"$id.tmp")
                    try{temp.outputStream().use{check(small.compress(Bitmap.CompressFormat.JPEG,82,it))};check(temp.renameTo(target))}finally{temp.delete();if(small!==frame)small.recycle()}
                    var total=target.parentFile!!.listFiles()?.filter{it.extension=="jpg"}?.sumOf{it.length()}?:0
                    target.parentFile!!.listFiles()?.filter{it.extension=="jpg"&&it!=target}?.sortedBy{it.lastModified()}?.forEach{if(total>24*1024*1024){val size=it.length();if(it.delete())total-=size}}
                    return target
                }finally{bitmap?.recycle();retriever.release()}
            }finally{permit.release()}
        }catch(error:Exception){if(error is InterruptedException)Thread.currentThread().interrupt();failures[id]=System.currentTimeMillis();return null}
    }
}
