package com.kurd.videodownloader

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

internal object PlaybackQueue {
    fun records(c:Context,id:String):Pair<List<MediaItem>,Int> {
        val selected=NativeHistory.find(c,id)?:throw IllegalArgumentException("فایلەکە نەدۆزرایەوە")
        val audio=selected.optString("mime").startsWith("audio/")
        val records=NativeHistory.list(c);val items=mutableListOf<MediaItem>()
        for(i in 0 until records.length()){
            val record=records.getJSONObject(i);val mime=record.optString("mime")
            if(if(audio)mime.startsWith("audio/")else mime.startsWith("video/")){
                val source=record.optString("url")
                try{if(source.startsWith("http"))SourceSafety.check(c,source)}catch(_:SafetyException){continue}
                items+=item("record:"+record.getString("id"),record.optString("title"),audio)
            }
        }
        val index=items.indexOfFirst{it.mediaId=="record:$id"}
        require(index>=0){"فایلەکە بلۆک کراوە یان لە لیست نییە"};return items to index
    }
    fun preview(token:String):MediaItem {
        val preview=MediaProbe.find(token)?:throw IllegalArgumentException("دووبارە لینکەکە دابنێ")
        return item("preview:$token",preview.title,preview.audioOnly)
    }
    private fun item(id:String,title:String,audio:Boolean)=MediaItem.Builder().setMediaId(id).setUri(Uri.parse("vidora:///"+id.replace(':','/')))
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist("ڤیدۆرا").setIsPlayable(true).setMediaType(if(audio)MediaMetadata.MEDIA_TYPE_MUSIC else MediaMetadata.MEDIA_TYPE_VIDEO).build()).build()
    fun position(c:Context,id:String)=c.securePreferences("player_positions",0).getLong(id,0).coerceAtLeast(0)
    fun savePosition(c:Context,id:String,position:Long){if(id.startsWith("record:"))c.securePreferences("player_positions",0).edit().putLong(id,position.coerceAtLeast(0)).apply()}
}
