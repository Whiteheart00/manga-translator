package com.kurd.videodownloader

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException

/** Copy via a small buffer into shared Downloads; never request full-storage access. */
internal data class PublishedMedia(val name:String,val uri:android.net.Uri,val mime:String,val bytes:Long,val path:String?=null)

internal object StoragePublisher {
    fun publish(context: Context, source: File, audioOnly: Boolean, cancelled: () -> Boolean): PublishedMedia {
        if (!source.isFile || source.length() <= 0L) {
            throw IOException("فایلی دابەزێنراو بەتاڵە یان نەدۆزرایەوە")
        }
        val mimeType = if (audioOnly) "audio/mpeg" else when (source.extension.lowercase()) {
            "mp4", "m4v" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "avi" -> "video/x-msvideo"
            "flv" -> "video/x-flv"
            else -> "application/octet-stream"
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, source.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/${AppSettings.folder(context)}")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values
            ) ?: throw IOException("MediaStore ناتوانێت فایل دروست بکات")
            try {
                val output = resolver.openOutputStream(uri, "w")
                    ?: throw IOException("فایلی Downloads ناتوانرێت بکرێتەوە")
                output.use { destination ->
                    source.inputStream().use { input -> copyCancellable(input, destination, cancelled) }
                }
                if (cancelled()) throw IOException("پاشەکەوتکردن هەڵوەشایەوە")
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                if (resolver.update(uri, done, null, null) < 1) {
                    throw IOException("تۆمارکردنی تەواوبوونی فایل سەرکەوتوو نەبوو")
                }
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            val actualName=resolver.query(uri,arrayOf(MediaStore.MediaColumns.DISPLAY_NAME),null,null,null)?.use { cursor->
                if(cursor.moveToFirst())cursor.getString(0) else source.name
            }?:source.name
            return PublishedMedia(actualName,uri,mimeType,source.length())
        }

        @Suppress("DEPRECATION")
        val parent = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            AppSettings.folder(context)
        )
        if (!parent.isDirectory && !parent.mkdirs()) {
            throw IOException("دروستکردنی Downloads سەرکەوتوو نەبوو")
        }
        var destination = File(parent, source.name)
        // Atomically claim a new filename; never truncate an existing file, even on collision.
        while(!destination.createNewFile()) {
            destination=File(parent,"${source.nameWithoutExtension}_${java.util.UUID.randomUUID()}.${source.extension}")
        }
        try {
            source.inputStream().use { input ->
                destination.outputStream().use { output -> copyCancellable(input, output, cancelled) }
            }
        } catch (error: Exception) {
            destination.delete()
            throw error
        }
        MediaScannerConnection.scanFile(
            context.applicationContext, arrayOf(destination.absolutePath), arrayOf(mimeType), null
        )
        return PublishedMedia(destination.name,androidx.core.content.FileProvider.getUriForFile(context,context.packageName+".files",destination),mimeType,destination.length(),destination.absolutePath)
    }

    private fun copyCancellable(
        input: java.io.InputStream, output: java.io.OutputStream, cancelled: () -> Boolean
    ) {
        val bytes = ByteArray(64 * 1024)
        while (true) {
            if (cancelled()) throw IOException("پاشەکەوتکردن هەڵوەشایەوە")
            val count = input.read(bytes)
            if (count < 0) break
            output.write(bytes, 0, count)
        }
    }
}
