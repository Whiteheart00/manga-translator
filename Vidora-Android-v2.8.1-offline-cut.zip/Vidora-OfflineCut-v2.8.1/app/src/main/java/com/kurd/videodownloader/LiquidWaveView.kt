package com.kurd.videodownloader

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

/** Transparent optical sculpture behind a real editable link field. No redraw loop. */
class LiquidWaveView @JvmOverloads constructor(context:Context,attrs:AttributeSet?=null):View(context,attrs) {
    private val bitmap=BitmapFactory.decodeResource(resources,R.drawable.liquid_glass,
        BitmapFactory.Options().apply {inSampleSize=2;inScaled=false})
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val target=RectF()
    private var colors=intArrayOf(Color.CYAN,Color.BLUE,Color.GREEN)
    private val tintPaint=Paint(Paint.ANTI_ALIAS_FLAG)
    fun setScheme(first:Int,second:Int,third:Int) {
        colors=intArrayOf(first,third,second)
        val palette=VisualTheme.currentPalette(context)
        paint.colorFilter=when(palette) {
            0,4,5,6,7 -> null
            1 -> ColorMatrixColorFilter(ColorMatrix().apply {setSaturation(0f)})
            else -> {
                val r=Color.red(first)/255f;val g=Color.green(first)/255f;val b=Color.blue(first)/255f
                ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                    .213f*r,.715f*r,.072f*r,0f,0f,
                    .213f*g,.715f*g,.072f*g,0f,0f,
                    .213f*b,.715f*b,.072f*b,0f,0f,
                    0f,0f,0f,1f,0f)))
            }
        }
        paint.alpha=if(VisualTheme.scheme(context).dark)215 else 245
        invalidate()
    }
    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas)
        target.set(0f,0f,width.toFloat(),height.toFloat())
        val layer=canvas.saveLayer(target,null)
        canvas.drawBitmap(bitmap,null,target,paint)
        if(VisualTheme.currentPalette(context)==4) {
            tintPaint.shader=LinearGradient(0f,0f,width.toFloat(),0f,colors,null,Shader.TileMode.CLAMP)
            tintPaint.alpha=105
            tintPaint.xfermode=PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
            canvas.drawRect(target,tintPaint)
            tintPaint.xfermode=null;tintPaint.shader=null
        }
        canvas.restoreToCount(layer)
    }
}
