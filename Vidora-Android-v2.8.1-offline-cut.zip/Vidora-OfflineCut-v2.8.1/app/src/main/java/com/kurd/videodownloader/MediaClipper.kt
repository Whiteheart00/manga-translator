package com.kurd.videodownloader

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import java.io.File
import java.io.IOException
import java.util.Locale

/** Accurate local decode/re-encode, after the existing guarded network download. */
internal object MediaClipper {
    private fun seconds(ms:Long)=String.format(Locale.US,"%.3f",ms/1000.0)
    fun clock(ms:Long):String {val s=ms/1000;return String.format(Locale.US,"%02d-%02d-%02d",s/3600,s/60%60,s%60)}
    fun arguments(input:String,output:String,start:Long,end:Long,audio:Boolean,quality:Int):List<String> {
        require(start>=0&&end>start)
        val args=mutableListOf("-y","-nostdin","-protocol_whitelist","file,pipe","-ss",seconds(start),"-i",input,"-t",seconds(end-start))
        if(audio){args+=listOf("-map","0:a:0","-vn","-c:a","libmp3lame");args+=if(quality in listOf(128,192,320))listOf("-b:a","${quality}k")else listOf("-q:a","2")}
        else args+=listOf("-map","0:v:0","-map","0:a:0?","-vf","pad=ceil(iw/2)*2:ceil(ih/2)*2","-c:v","libx264","-preset","veryfast","-crf","20","-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-movflags","+faststart")
        args+=listOf("-progress","pipe:1","-nostats",output)
        return args
    }
    fun run(c:Context,input:File,clip:ClipSelection,audio:Boolean,quality:Int,cancelled:()->Boolean,onProcess:(Process?)->Unit,onProgress:(Int)->Unit):File {
        ClipSelection.bounds(clip.startMs,clip.endMs,clip.sourceDurationMs)
        require(input.isFile&&input.length()>0){"فایلی سەرچاوە نەدۆزرایەوە"}
        YoutubeDL.getInstance().init(c.applicationContext);FFmpeg.getInstance().init(c.applicationContext)
        val title=input.nameWithoutExtension.take(95)
        val output=File(input.parentFile,title+" — "+clock(clip.startMs)+"–"+clock(clip.endMs)+(if(audio)".mp3" else ".mp4"))
        require(output.canonicalFile!=input.canonicalFile)
        val binary=File(c.applicationInfo.nativeLibraryDir,"libffmpeg.so")
        val builder=ProcessBuilder(listOf(binary.absolutePath)+arguments(input.absolutePath,output.absolutePath,clip.startMs,clip.endMs,audio,quality)).redirectErrorStream(true)
        val packages=File(c.noBackupFilesDir,"youtubedl-android/packages")
        builder.environment()["LD_LIBRARY_PATH"]=File(packages,"ffmpeg/usr/lib").absolutePath+":"+File(packages,"python/usr/lib").absolutePath
        builder.environment()["TMPDIR"]=c.cacheDir.absolutePath
        if(cancelled())throw IOException("هەڵوەشایەوە")
        val process=builder.start();onProcess(process);if(cancelled())process.destroy()
        var success=false
        try{
            process.inputStream.bufferedReader().useLines{lines->lines.forEach{line->
                if(cancelled()){process.destroy();throw IOException("هەڵوەشایەوە")}
                if(line.startsWith("out_time_us=")){val t=line.substringAfter('=').toLongOrNull()?:0;onProgress((t/10/clip.lengthMs).toInt().coerceIn(0,99))}
            }}
            if(process.waitFor()!=0||!output.isFile||output.length()==0L)throw IOException("بڕینی پارچەکە سەرکەوتوو نەبوو؛ هیچ فایلی تەواونەبوو پاشەکەوت نەکرا")
            if(cancelled())throw IOException("هەڵوەشایەوە")
            success=true;return output
        }finally{onProcess(null);process.destroy();if(!success)output.delete()}
    }
}
