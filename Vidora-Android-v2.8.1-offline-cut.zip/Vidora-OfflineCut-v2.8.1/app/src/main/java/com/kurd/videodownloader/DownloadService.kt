package com.kurd.videodownloader

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Uri
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** User-started foreground service: one download at a time, explicit cancellation. */
class DownloadService : Service() {
    companion object {
        @Volatile internal var current:DownloadService?=null
        const val ACTION_CUT="com.kurd.videodownloader.CUT"
        const val EXTRA_CUT_START="local_cut_start_ms"
        const val EXTRA_CUT_END="local_cut_end_ms"
        const val ACTION_CONVERT="com.kurd.videodownloader.CONVERT"
        const val EXTRA_FILE_ID="file_id"
        const val EXTRA_TARGET="target"
        const val ACTION_START = "com.kurd.videodownloader.START"
        const val ACTION_UPDATE = "com.kurd.videodownloader.UPDATE"
        private const val UPDATE_INTERVAL_MS = 3L * 24 * 60 * 60 * 1000
        const val ACTION_CANCEL = "com.kurd.videodownloader.CANCEL"
        const val ACTION_STATUS = "com.kurd.videodownloader.STATUS"
        const val EXTRA_URL = "url"
        const val EXTRA_PREVIEW_TOKEN="preview_token"
        const val EXTRA_AUDIO = "audio"
        const val EXTRA_QUALITY = "quality"
        private const val CHANNEL_ID = "video_downloader_tasks"
        internal const val NOTIFICATION_ID = 1201
    }

    private var trusted=false
    private val executor = Executors.newSingleThreadExecutor()
    private val active = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)
    @Volatile private var taskRemoved=false
    @Volatile private var processId: String? = null
    @Volatile private var conversionProcess:Process?=null
    @Volatile private var nativeConnection:java.net.HttpURLConnection?=null
    private var lastUiUpdateTime = 0L
    @Volatile private var currentMediaTitle: String? = null
    @Volatile private var completedMediaTitle: String? = null
    @Volatile private var downloadSucceeded = false

    private fun cleanMediaTitle(raw:String)=MediaTitle.clean(raw)

    private fun captureDownloadTitle(output: String) {
        // yt-dlp prints the resolved filename after extracting metadata.
        // Never display raw extractor logs or long hashtag strings in notifications.
        val marker = when {
            output.contains("Destination: ") -> "Destination: "
            output.contains("Merging formats into ") -> "Merging formats into "
            output.contains("Extracting audio to ") -> "Extracting audio to "
            else -> return
        }
        val path = output.substringAfter(marker).trim().trim('"', '\'')
        val candidate = cleanMediaTitle(path.substringBeforeLast(".part"))
        if (candidate.isNotBlank()) { currentMediaTitle = candidate; DownloadState.title=candidate }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        trusted=try{SecurityGate.verify(this);true}catch(_:Exception){false}
        if(!trusted){stopSelf();return}
        current=this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if(!trusted){stopSelf();return START_NOT_STICKY}
        if (intent?.action == ACTION_CANCEL) {
            requestCancellation()
            if (!active.get()) stopSelf()
            return START_NOT_STICKY
        }
        val action = intent?.action
        if (action != ACTION_START && action != ACTION_UPDATE && action != ACTION_CONVERT && action != ACTION_CUT) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!active.compareAndSet(false, true)) return START_NOT_STICKY

        val url = intent?.getStringExtra(EXTRA_URL)
        val audio = intent?.getBooleanExtra(EXTRA_AUDIO, false) ?: false
        val quality = intent?.getIntExtra(EXTRA_QUALITY, 0) ?: 0
        val previewToken=intent?.getStringExtra(EXTRA_PREVIEW_TOKEN).orEmpty()
        if (action == ACTION_START && url.isNullOrBlank()) {
            finishWith("لینکی دابەزاندن بەتاڵە.")
            stopSelf()
            return START_NOT_STICKY
        }
        DownloadState.action=if(action==ACTION_UPDATE) "update" else if(action==ACTION_CONVERT)"convert" else if(action==ACTION_CUT)"cut" else "download"
        DownloadState.phase="preparing";DownloadState.status="running"
        DownloadState.url=url.orEmpty();DownloadState.recordId=if(action in listOf(ACTION_CONVERT,ACTION_CUT))intent?.getStringExtra(EXTRA_FILE_ID).orEmpty() else ""
        DownloadState.format=if(audio) "MP3" else "MP4"
        DownloadState.quality=if(audio) {if(quality in listOf(128,192,320)) "${quality}k" else "Best"} else {if(quality in listOf(480,720,1080)) "${quality}p" else "Best"}
        if(previewToken.isNotBlank())DownloadState.quality="پەخش"
        DownloadState.title=""
        cancelled.set(false)
        currentMediaTitle = null
        completedMediaTitle = null
        downloadSucceeded = false
        try {
            val initial = notification("ئامادەکردنی دابەزاندن...", 0, true)
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, initial, if(action in listOf(ACTION_CONVERT,ACTION_CUT)&&Build.VERSION.SDK_INT>=35)ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIFICATION_ID, initial)
            }
            DownloadDiagnostics.record(this,"foreground_started")
            updateState(
                if (action == ACTION_UPDATE) "نوێکردنەوەی yt-dlp..." else "ئامادەکردنی بزوێنەر...",
                0, true
            )
        } catch (e: Exception) {
            DownloadDiagnostics.record(this,"foreground_start_failed",e)
            finishWith("خزمەتگوزاری دابەزاندن دەست پێ نەکرد: ${e.localizedMessage}")
            stopSelf()
            return START_NOT_STICKY
        }
        executor.execute {
            try {
                if (action == ACTION_UPDATE) {
                    YoutubeDL.getInstance().init(application)
                    VerifiedEngineUpdater.ensure(this)
                    val result = updateEngine(force = true)
                    finishWith(result, true)
                } else if(action==ACTION_CUT) {
                    val id=intent?.getStringExtra(EXTRA_FILE_ID).orEmpty()
                    updateState("ئامادەکردنی کۆپیی تایبەت؛ ڕەسەنەکە دەمێنێت...",0,true)
                    val result=LocalCut.run(this,id,intent?.getLongExtra(EXTRA_CUT_START,-1)?:-1,intent?.getLongExtra(EXTRA_CUT_END,-1)?:-1,
                        {cancelled.get()},{conversionProcess=it;if(it!=null)DownloadState.phase="processing"},onProgress={p->
                        val now=System.currentTimeMillis();if(now-lastUiUpdateTime>=500){lastUiUpdateTime=now;updateState("خەریکی بڕینە... $p%",p,true)}
                    })
                    LocalCut.remember(this,id,result)
                    DownloadState.title=result.media.name;DownloadState.format=if(result.media.mime.startsWith("audio/"))"MP3" else "MP4"
                    DownloadState.phase="complete";downloadSucceeded=true
                    finishWith("پارچەی نوێ پاشەکەوت کرا؛ فایلە ڕەسەنەکە ماوە.",true)
                } else if(action==ACTION_CONVERT) {
                    val recordId=intent?.getStringExtra(EXTRA_FILE_ID).orEmpty()
                    val target=intent?.getStringExtra(EXTRA_TARGET).orEmpty()
                    updateState("خەریکی گۆڕینی فایلە...",0,true)
                    val media=LocalConversion.run(this,recordId,target,{cancelled.get()},{conversionProcess=it}){p->updateState("خەریکی گۆڕینی فایلە... $p%",p,true)}
                    val original=NativeHistory.find(this,recordId)?.optString("url").orEmpty()
                    NativeHistory.add(this,media,original,if(target=="MP3")"320k" else "720×1280")
                    DownloadState.title=media.name;DownloadState.format=target
                    downloadSucceeded=true;finishWith("گۆڕینی فایل تەواو بوو: ${media.name}",true)
                } else {
                    doDownload(url!!, audio, quality,previewToken,ClipSelection.fromIntent(intent,url!!))
                }
            } catch (e: Exception) {
                DownloadDiagnostics.record(this,"task_failed",e)
                val message = if (cancelled.get()) "کردارەکە هەڵوەشایەوە."
                else friendlyError(e)
                finishWith(message)
            } catch(e:LinkageError) {
                DownloadDiagnostics.record(this,"native_library_failed",e)
                finishWith("بزوێنەری مۆبایل بار نەبوو؛ ڕاپۆرتی هەڵە لە بەشی دەربارە کۆپی بکە.")
            } finally {
                processId = null
                active.set(false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                showFinishedNotification()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun doDownload(url:String,audioOnly:Boolean,quality:Int)=doDownload(url,audioOnly,quality,"")

    private fun doDownload(url: String, audioOnly: Boolean, quality: Int,previewToken:String,clip:ClipSelection?=null) {
        SourceSafety.check(this,url) // Reject known blocked inputs before any connectivity probe, redirect or engine request.
        val connectivity = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivity.activeNetwork
        val caps = network?.let { connectivity.getNetworkCapabilities(it) }
        if (caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) != true) {
            throw IOException("ئینتەرنێت بەردەست نییە؛ Wi-Fi یان داتای مۆبایل بپشکنە")
        }
        if(AppSettings.wifiOnly(this)&&caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)!=true) {
            throw IOException("دابەزاندن تەنها بە Wi-Fi ڕێگەپێدراوە؛ Wi-Fi پەیوەست بکە یان ڕێکخستنەکە بگۆڕە")
        }
        val playback=if(previewToken.isNotBlank())PlaybackDownload.media(this,previewToken,url)else null
        if(playback?.audioOnly==true&&!audioOnly)throw IOException("ئەم سەرچاوەیە تەنها دەنگە؛ MP3 هەڵبژێرە")
        val approved=if(playback!=null)url else SourceSafety.resolve(this,url,emptyMap(),{cancelled.get()},{nativeConnection=it})
        SnapchatSpotlight.verifyRedirect(url,approved)
        checkCancelled()
        DownloadDiagnostics.record(this,"python_initializing")
        YoutubeDL.getInstance().init(application)
                    VerifiedEngineUpdater.ensure(this)
        DownloadDiagnostics.record(this,"ffmpeg_initializing")
        FFmpeg.getInstance().init(application)
        DownloadDiagnostics.record(this,"engines_initialized")
        checkCancelled()
        // A bundled yt-dlp version can quickly become obsolete when YouTube changes.
        // Only check once every three days; failures must not prevent the offline fallback.
        try {
            if(playback==null)updateEngine(force = false)
        } catch (e: Exception) {
            updateState("نوێکردنەوە سەرکەوتوو نەبوو؛ بە وەشانی ئێستا هەوڵ دەدەین...", 0, true)
        }
        checkCancelled()

        val base = File(cacheDir,"private-downloads").apply{mkdirs()}
        val work = File(base, "job_${System.currentTimeMillis()}_${System.nanoTime()}")
        if (!work.mkdirs()) throw IOException("فۆڵدەری کاتی دروست نەبوو")
        try {
            val guardId="guard_${System.nanoTime()}";processId=guardId
            if(playback==null&&MediaProbe.cached(url)==null)MediaProbe.prepare(this,url,guardId,{cancelled.get()},{nativeConnection=it})
            checkCancelled()
            val request = if(playback!=null)PlaybackDownload.request(this,playback,work)else SnapchatSource.request(this,approved,work,{cancelled.get()},{nativeConnection=it})
            TransportPolicy.configure(this,request)
            request.addOption("--age-limit","17")
            request.addOption("--match-filter","age_limit <=? 17")
            request.addOption("--no-playlist")
            request.addOption("--no-mtime")
            request.addOption("--retries", "3")
            request.addOption("--fragment-retries", "3")
            request.addOption("--extractor-retries", "3")
            request.addOption("--concurrent-fragments", "1")
            request.addOption("--socket-timeout", "30")
            // Keep yt-dlp's small metadata cache across downloads, when supported.
            val engineCache = File(cacheDir, "yt-dlp-cache").apply { mkdirs() }
            request.addOption("--cache-dir", engineCache.absolutePath)
            // youtubedl-android 0.18.1 injects the bundled QuickJS runtime itself.
            // With YouTube, permit yt-dlp's official EJS challenge scripts from GitHub.
            // This requires an Internet connection to GitHub and adds network traffic.
            val host = Uri.parse(url).host.orEmpty().lowercase()
            if (host == "youtu.be" || host == "youtube.com" || host.endsWith(".youtube.com") ||
                host == "youtube-nocookie.com" || host.endsWith(".youtube-nocookie.com")) {
                request.addOption("--remote-components", "ejs:github")
            }
            request.addOption("-o", File(work, "%(title).80B [%(id)s].%(ext)s").absolutePath)
            if (audioOnly) {
                if(playback!=null)request.addOption("-f","bestaudio/best")
                request.addOption("-x")
                request.addOption("--audio-format", "mp3")
                request.addOption("--audio-quality", if(quality in listOf(128,192,320)) "${quality}K" else "0")
            } else {
                request.addOption("-f",MediaRequestPolicy.videoSelector(url,quality))
            }
            val id = "videodl_${System.nanoTime()}"
            processId = id
            DownloadState.phase="connecting";updateState("پەیوەستبوون بە سەرچاوە...", 0, true)
            DownloadDiagnostics.record(this,"download_executing")
            YoutubeDL.getInstance().execute(request, id) { progress, _, output ->
                ProgressCallback.safely({error->DownloadDiagnostics.record(this,"progress_callback_failed",error)}) {
                    captureDownloadTitle(output.orEmpty())
                    if (cancelled.get()) {
                        try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) { }
                    }
                    val now = System.currentTimeMillis()
                    val determinate=progress.isFinite()&&progress>0
                    val firstBytes=determinate&&DownloadState.phase!="downloading"
                    if(firstBytes)DownloadState.phase="downloading"
                    if (firstBytes||now - lastUiUpdateTime >= 1000) {
                        lastUiUpdateTime = now
                        val percent = if(progress.isFinite()&&progress>=0)(progress*(if(clip!=null).9f else 1f)).toInt().coerceIn(0,100)else DownloadState.progress
                        updateState(if(DownloadState.phase=="downloading")"دادەبەزێت: $percent%" else "ئامادەکردنی سەرچاوە...",percent,true)
                    }
                }
            }
            checkCancelled()
            val extensions = if (audioOnly) setOf("mp3")
                else setOf("mp4", "mkv", "webm", "mov", "m4v", "avi", "flv")
            var completed = work.listFiles()?.filter {
                it.isFile && it.length() > 0 && it.extension.lowercase() in extensions
            }?.sortedBy { it.name }.orEmpty()
            if(completed.isEmpty())throw IOException("فایلی ڤیدیۆ یان دەنگ نەدۆزرایەوە؛ لینکەکە پێویستە ناوەڕۆکی میدیایی هەبێت")
            checkCancelled()
            if(clip!=null){
                require(completed.size==1){"بۆ بڕین پێویستە تەنها یەک فایل هەبێت"}
                DownloadState.phase="processing";updateState("خەریکی بڕینی پارچەی هەڵبژێردراو...",90,true)
                val selected=MediaClipper.run(this,completed.single(),clip,audioOnly,quality,{cancelled.get()},{conversionProcess=it}){p->
                    val now=System.currentTimeMillis();if(now-lastUiUpdateTime>=500){lastUiUpdateTime=now;updateState("خەریکی بڕینی پارچەکە... $p%",90+(p*9/100),true)}
                }
                checkCancelled();completed=listOf(selected)
            }
            DownloadState.phase="saving";updateState("پاشەکەوتکردن لە Downloads...",100,true)
            DownloadDiagnostics.record(this,"publishing_media")
            var publishedCount=0
            for(file in completed){
                checkCancelled()
                val media=StoragePublisher.publish(this,file,audioOnly){cancelled.get()}
                val record=NativeHistory.add(this,media,url,DownloadState.quality)
                if(clip!=null)NativeHistory.change(this,record.getString("id")){it.put("clipStartMs",clip.startMs).put("clipEndMs",clip.endMs).put("sourceDurationMs",clip.sourceDurationMs)}
                completedMediaTitle=cleanMediaTitle(media.name).ifBlank{media.name.take(85)}
                DownloadState.title=completedMediaTitle.orEmpty()
                publishedCount++
            }
            downloadSucceeded=true
            val result=if(publishedCount==1)"تەواو! ${completedMediaTitle.orEmpty()} لە Downloads/${AppSettings.folder(this)} پاشەکەوت کرا."
                else "تەواو! $publishedCount فایل لە Downloads/${AppSettings.folder(this)} پاشەکەوت کران."
            finishWith(result,true)
        } finally {
            work.deleteRecursively()
        }
    }

    /** Update the Python yt-dlp script only, via the upstream official GitHub release. */
    private fun updateEngine(force: Boolean): String {
        val prefs = securePreferences("engine_updates", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val lastCheck = prefs.getLong("last_successful_check", 0L)
        if (!force && now - lastCheck in 0 until UPDATE_INTERVAL_MS) {
            return "yt-dlp پێشتر پشکنراوە."
        }
        checkCancelled()
        updateState("پشکنینی نوێترین وەشانی yt-dlp لە GitHub...", 0, true)
        return VerifiedEngineUpdater.update(this,{cancelled.get()},{nativeConnection=it})
    }

    private fun friendlyError(error: Exception): String {
        val raw = error.localizedMessage.orEmpty()
        if(raw.contains("does not contain any stream",true)||raw.contains("matches no streams",true))return "ئەم سەرچاوەیە دەنگی گونجاوی نییە بۆ دەرهێنانی MP3"
        if (raw.contains("HTTP Error 403", ignoreCase = true)) {
            return "ماڵپەڕەکە داواکارییەکەی ڕەتکردەوە (403). بزوێنەری yt-dlp نوێ بکەرەوە؛ " +
                "ڕەنگە ڤیدیۆکە تایبەت، سنووردار یان کاتی بێت."
        }
        if (raw.contains("JavaScript runtime", ignoreCase = true) ||
            raw.contains("challenge", ignoreCase = true) ||
            raw.contains("EJS", ignoreCase = true)) {
            return "کێشەی YouTube JavaScript/EJS: yt-dlp نوێ بکەرەوە و " +
                "دەستڕاگەیشتنی مۆبایل بە GitHub بپشکنە."
        }
        if (raw.contains("Unsupported URL", ignoreCase = true) ||
            raw.contains("No suitable extractor", ignoreCase = true)) {
            return "ئەم لینکە لەلایەن yt-dlp ـەوە پشتگیری ناکرێت. لینکێکی ڤیدیۆی ڕاستەوخۆ تاقی بکە."
        }
        if (raw.contains("Requested format is not available", ignoreCase = true)) {
            if(MediaRequestPolicy.identify(DownloadState.url)?.id=="tiktok")return "فۆرماتێکی TikTok بەبێ Watermark بە کوالێتیی داواکراو نەدۆزرایەوە؛ «باشترین» تاقی بکە یان بزوێنەر نوێ بکەرەوە."
            return "فۆرمات یان کوالیتیی داواکراو بەردەست نییە. هەڵبژاردەی «باشترین» تاقی بکە."
        }
        if (raw.contains("login required", ignoreCase = true) || raw.contains("log in",ignoreCase=true) ||
            raw.contains("private",ignoreCase=true) || raw.contains("cookies",ignoreCase=true) ||
            raw.contains("Sign in", ignoreCase = true) ||
            raw.contains("not available", ignoreCase = true)) {
            return "ئەم ڤیدیۆیە سنوورداری هەیە یان پێویستی بە چوونەژوورەوەیە؛ " +
                "ئەپەکە سنووردارییەکان تێناپەڕێنێت."
        }
        val last = raw.lineSequence().filter { it.isNotBlank() }.lastOrNull()
            ?: error.javaClass.simpleName
        return "هەڵە: ${last.take(400)}"
    }

    private fun checkCancelled() {
        if (cancelled.get()) throw IOException("هەڵوەشایەوە")
    }

    private fun requestCancellation() {
        cancelled.set(true)
        nativeConnection?.disconnect();nativeConnection=null
        conversionProcess?.destroy()
        if(active.get()||DownloadState.running)updateState("خەریکی هەڵوەشاندنەوە...", DownloadState.progress, true)
        processId?.let { id ->
            try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) { }
        }
    }

    private fun finishWith(message: String, success:Boolean=false) {
        DownloadDiagnostics.record(this,if(success)"task_completed" else "task_stopped")
        DownloadState.phase=if(success)"complete" else "stopped"
        DownloadState.status=if(success) "success" else if(cancelled.get()) "cancelled" else "error"
        securePreferences("download_state", MODE_PRIVATE).edit()
            .putString("last_result", message).apply()
        updateState(message, if(success)100 else DownloadState.progress, false)
    }

    private fun updateState(message: String, percent: Int, running: Boolean) {
        DownloadState.running = running
        DownloadState.progress = percent.coerceIn(0, 100)
        DownloadState.message = message
        securePreferences("native_runtime",MODE_PRIVATE).edit().putString("action",DownloadState.action)
            .putString("phase",DownloadState.phase).putString("status",DownloadState.status).putString("message",message).putInt("progress",DownloadState.progress)
            .putString("url",DownloadState.url).putString("format",DownloadState.format).putString("quality",DownloadState.quality)
            .putString("title",DownloadState.title).apply()
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName))
        if (running&&!taskRemoved) {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            if (notificationsAllowed) {
                try{mgr.notify(NOTIFICATION_ID,notification(message,percent,true))}
                catch(e:RuntimeException){DownloadDiagnostics.record(this,"progress_notification_failed",e)}
            }
        }
    }

    private fun showFinishedNotification() {
        if(taskRemoved||AppRuntime.visible())return
        val enabled = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!enabled || !AppSettings.completionNotifications(this)) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try{manager.notify(NOTIFICATION_ID,notification(DownloadState.message,100,false))}
        catch(e:RuntimeException){DownloadDiagnostics.record(this,"completion_notification_failed",e)}
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID, "دابەزاندنەکان", NotificationManager.IMPORTANCE_LOW
                ).apply { description = "پێشکەوتن و هەڵوەشاندنەوەی دابەزاندن" }
            )
        }
    }

    private fun notification(message: String, progress: Int, working: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, DownloadService::class.java).apply { action = ACTION_CANCEL },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val mediaTitle = if (working) currentMediaTitle else completedMediaTitle
        val displayTitle = mediaTitle?.takeIf { it.isNotBlank() } ?: "Vidora • ڤیدۆرا"
        val displayStatus = when {
            !working && downloadSucceeded -> if(DownloadState.action=="cut")"پارچەی نوێ پاشەکەوت کرا • Downloads/${AppSettings.folder(this)}" else "داگرتن تەواو بوو • Downloads/${AppSettings.folder(this)}"
            !working -> message.take(110)
            progress in 1..99 -> if(DownloadState.action=="cut")"دەبڕدرێت • $progress%" else "دادەبەزێت • $progress%"
            progress == 100 -> "پاشەکەوتکردنی فایل..."
            else -> "ئامادەکردنی دابەزاندن..."
        }
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(displayTitle)
            .setContentText(displayStatus)
            .setSubText("Vidora")
            .setContentIntent(open)
            .setOngoing(working)
            .setOnlyAlertOnce(true)
            .setAutoCancel(!working)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (working) {
            builder.setProgress(100, progress.coerceIn(0, 100), progress == 0)
        } else {
            // Android removes the progress bar entirely on completion/failure.
            builder.setProgress(0, 0, false)
        }
        if (working) builder.addAction(
            android.R.drawable.ic_menu_close_clear_cancel, "هەڵوەشاندنەوە", cancel
        )
        return builder.build()
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        requestCancellation()
        finishWith("کاتی ڕێگەپێدراوی دابەزاندنی پاشبنەما تەواو بوو.")
        stopSelf()
    }

    internal fun cancelWhenHidden(){
        if(DownloadState.action=="download")return
        requestCancellation();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()
    }

    override fun onTaskRemoved(rootIntent:Intent?){
        taskRemoved=true;requestCancellation();stopForeground(STOP_FOREGROUND_REMOVE);(getSystemService(Context.NOTIFICATION_SERVICE)as NotificationManager).cancel(NOTIFICATION_ID);stopSelf();super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        if(current===this)current=null
        if (active.get()) {
            cancelled.set(true)
            nativeConnection?.disconnect();nativeConnection=null
        conversionProcess?.destroy()
            processId?.let { id ->
                try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) { }
            }
            if (DownloadState.running) {
                finishWith("دابەزاندن لەلایەن سیستەمەوە وەستێنرا.")
            }
            active.set(false)
        }
        executor.shutdownNow()
        super.onDestroy()
    }
}
