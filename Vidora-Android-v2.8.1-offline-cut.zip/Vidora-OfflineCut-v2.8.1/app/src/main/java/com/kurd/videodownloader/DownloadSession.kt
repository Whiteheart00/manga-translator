package com.kurd.videodownloader

import android.app.NotificationManager
import android.content.Context

/** The Home screen resumes real active work, never an old terminal job or persisted toast. */
internal object DownloadSession {
    fun enterHome(c:Context){
        if(DownloadState.running)return
        DownloadState.phase="idle";DownloadState.progress=0;DownloadState.recordId="";DownloadState.action="idle";DownloadState.status="idle";DownloadState.url="";DownloadState.title=""
        DownloadState.format="MP4";DownloadState.quality="1080p";DownloadState.message="ئامادەیە بۆ دابەزاندن"
        c.securePreferences("native_runtime").edit().clear().apply()
        c.securePreferences("download_state").edit().clear().apply()
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(DownloadService.NOTIFICATION_ID)
    }
}
