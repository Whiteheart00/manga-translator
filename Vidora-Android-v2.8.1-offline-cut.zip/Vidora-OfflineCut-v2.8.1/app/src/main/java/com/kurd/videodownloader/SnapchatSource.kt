package com.kurd.videodownloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.util.UUID

/** Public Story and Spotlight shares, matched to their exact IDs and verified MP4 bytes. */
internal object SnapchatSource {
    private const val AGENT="Mozilla/5.0"
    private val nextScript=Regex("<script\\b[^>]*\\bid\\s*=\\s*['\"]__NEXT_DATA__['\"][^>]*>(.*?)</script>",setOf(RegexOption.IGNORE_CASE,RegexOption.DOT_MATCHES_ALL))
    fun canonical(url:String):String {
        val uri=URI(url);val host=uri.host.orEmpty().lowercase()
        if(host !in listOf("snapchat.com","www.snapchat.com"))return url
        val parts=uri.path.orEmpty().trim('/').split('/')
        return if(parts.size==3&&parts[0].startsWith("@")&&parts[1]=="spotlight"&&parts[2].matches(Regex("[A-Za-z0-9_-]+")))"https://www.snapchat.com/spotlight/${parts[2]}" else url
    }
    fun request(c:Context,url:String,directory:File,cancelled:()->Boolean={false},onConnection:(HttpURLConnection?)->Unit={}):YoutubeDLRequest {
        val target=canonical(url);val host=SourceSafety.host(target)
        if(host !in listOf("snapchat.com","www.snapchat.com","story.snapchat.com"))return YoutubeDLRequest(target)
        val (finalUrl,html)=get(c,target,cancelled,onConnection,3*1024*1024,false)
        var info=parse(html.toString(Charsets.UTF_8),finalUrl)
        SnapchatSpotlight.id(target)?.let{if(info.optString("id")!=it)throw IOException("Spotlight ـی داواکراو گۆڕدراوە؛ ڤیدیۆی جیاواز هەڵنابژێردرێت")}
        SourceSafety.metadata(c,info)
        val probeSize=if(info.optString("extractor_key")=="VidoraSnapchatSpotlight")SnapchatOriginal.PROBE_BYTES else 64
        val (_,header)=get(c,info.getString("url"),cancelled,onConnection,probeSize,true)
        requireMp4(header)
        try{info=SnapchatOriginal.prefer(info,header){candidate->
            get(c,candidate,cancelled,onConnection,SnapchatOriginal.PROBE_BYTES,true).second
        }}catch(error:Exception){
            if(error is SafetyException||cancelled()||Thread.currentThread().isInterrupted)throw error
            // An unavailable original rendition must not break the validated sharing source.
        }
        directory.mkdirs();val file=File(directory,"snapchat_${UUID.randomUUID()}.info.json")
        try{file.writeText(info.toString())}catch(error:Exception){file.delete();throw error}
        return YoutubeDLRequest(emptyList()).addOption("--load-info-json",file.absolutePath)
    }
    fun parse(html:String,finalUrl:String):JSONObject {
        if(SourceSafety.host(finalUrl) !in listOf("snapchat.com","www.snapchat.com","story.snapchat.com"))throw SafetyException("پەڕەی Snapchat پشتڕاست نەکرایەوە")
        if(SnapchatSpotlight.id(finalUrl)!=null)return SnapchatSpotlight.parse(html,finalUrl)
        val text=nextScript.find(html)?.groupValues?.get(1)?:throw IOException("زانیاریی Snapchat بەردەست نییە؛ لینکی گشتیی خودی Snap دابنێ")
        val root=try{JSONObject(text)}catch(_:Exception){throw IOException("زانیاریی Snapchat ناتوانرێت بخوێندرێتەوە")}
        val props=root.optJSONObject("props")?.optJSONObject("pageProps")?:throw IOException("Story نەدۆزرایەوە")
        if(props.optBoolean("showSnapExpiredToast"))throw IOException("ئەم Snap ـە بەسەرچووە یان چیتر گشتی نییە")
        val gate=props.optJSONObject("userProfile")?.optJSONObject("publicProfileInfo")?.opt("audienceGateSettings")
        if(gate!=null&&gate!=JSONObject.NULL)throw SafetyException("ئەم سەرچاوەیە سنوورداریی تەمەن/ناوچەی هەیە و ڕێگەپێنەدراوە")
        val queryId=root.optJSONObject("query")?.optString("snapId").orEmpty()
        val path=URI(finalUrl).path.orEmpty().trim('/').split('/')
        val pathId=when{path.size==2&&path[0].startsWith("@")->path[1];path.size==3&&path[0]=="u"->path[2];else->""}
        val target=pathId.ifBlank{queryId}
        if(!target.matches(Regex("[A-Za-z0-9_-]{8,180}"))||(queryId.isNotBlank()&&target!=queryId))throw IOException("تکایە لینکی خودی Snap دابنێ؛ لینکی پڕۆفایل بەس نییە")
        val snaps=props.optJSONObject("story")?.optJSONArray("snapList")?:throw IOException("ئەم Story ـە گشتی نییە یان بەسەرچووە")
        var selected:JSONObject?=null
        for(i in 0 until snaps.length()){val item=snaps.optJSONObject(i)?:continue;if(item.optJSONObject("snapId")?.optString("value")==target){selected=item;break}}
        val snap=selected?:throw IOException("Snap ـی داواکراو نەدۆزرایەوە؛ پەڕەکە بە ڤیدیۆیەکی پێشنیارکراو ناگۆڕدرێتەوە")
        if(snap.optInt("snapMediaType",-1)!=1)throw IOException("ئەم Snap ـە ڤیدیۆ نییە؛ وێنە بە ڤیدیۆ هەژمار ناکرێت")
        if(snap.optInt("age_limit",0)>=18||!snap.optBoolean("isFamilyFriendly",true))throw SafetyException("ناوەڕۆکی 18+ ڕێگەپێنەدراوە")
        val urls=snap.optJSONObject("snapUrls")?:throw IOException("سەرچاوەی ڤیدیۆ نەدۆزرایەوە")
        val media=urls.optString("mediaUrl");requireCdn(media)
        val title=snap.optJSONObject("snapTitle")?.optString("value").orEmpty().ifBlank{"Snapchat Story"}
        val thumbnail=urls.optJSONObject("mediaPreviewUrl")?.optString("value").orEmpty()
        return JSONObject().put("id",target).put("title",title).put("url",media).put("ext","mp4").put("protocol","https")
            .put("webpage_url",finalUrl).put("original_url",finalUrl).put("extractor","VidoraSnapchatStory").put("extractor_key","VidoraSnapchatStory")
            .put("thumbnail",thumbnail).put("http_headers",JSONObject().put("User-Agent",AGENT).put("Referer","https://www.snapchat.com/"))
    }
    fun requireMp4(bytes:ByteArray){
        val brands=setOf("isom","iso2","mp41","mp42","avc1","dash","MSNV","3gp4","3gp5")
        if(bytes.size<16||String(bytes,4,4,Charsets.US_ASCII)!="ftyp"||String(bytes,8,4,Charsets.US_ASCII) !in brands)throw IOException("سەرچاوەی Snapchat ڤیدیۆی MP4 ـی پشتڕاستکراو نییە")
    }
    fun requireCdn(media:String){
        val uri=try{URI(media)}catch(_:Exception){throw IOException("سەرچاوەی ڤیدیۆ دروست نییە")}
        val host=uri.host.orEmpty().lowercase()
        if(uri.scheme!="https"||uri.userInfo!=null||uri.port !in listOf(-1,443)||(host!="sc-cdn.net"&&!host.endsWith(".sc-cdn.net")))throw SafetyException("سەرچاوەی Snapchat پشتڕاست نەکرایەوە")
    }
    private fun get(c:Context,start:String,cancelled:()->Boolean,onConnection:(HttpURLConnection?)->Unit,limit:Int,range:Boolean):Pair<String,ByteArray>{
        var url=start;val visited=mutableSetOf<String>()
        repeat(8){
            if(cancelled()||Thread.currentThread().isInterrupted)throw IOException("هەڵوەشایەوە")
            SourceSafety.check(c,url)
            if(range)requireCdn(url)else if(SourceSafety.host(url) !in listOf("snapchat.com","www.snapchat.com","story.snapchat.com"))throw SafetyException("پەڕەی Snapchat پشتڕاست نەکرایەوە")
            if(!visited.add(url))throw IOException("لینکەکە گەڕانەوەی دووبارەی هەیە")
            val connection=(URL(url).openConnection()as HttpURLConnection).apply{instanceFollowRedirects=false;connectTimeout=10000;readTimeout=15000;setRequestProperty("User-Agent",AGENT);setRequestProperty("Referer","https://www.snapchat.com/");if(range)setRequestProperty("Range","bytes=0-${limit-1}")}
            onConnection(connection)
            try{
                if(cancelled())throw IOException("هەڵوەشایەوە")
                val status=connection.responseCode
                if(status in listOf(301,302,303,307,308))url=URL(URL(url),connection.getHeaderField("Location")?:throw IOException("لینکەکە بەردەست نییە")).toString()
                else{
                    if(status !in 200..299)throw IOException("Snapchat سەرچاوەکەی نەدا ($status)؛ ڕەنگە بەسەرچووبێت یان تایبەت بێت")
                    val bytes=connection.inputStream.use{stream->val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(8192);var count=0
                        while(count<limit+(if(range)0 else 1)){if(cancelled())throw IOException("هەڵوەشایەوە");val n=stream.read(buffer,0,minOf(buffer.size,limit+(if(range)0 else 1)-count));if(n<0)break;out.write(buffer,0,n);count+=n};if(count>limit)throw IOException("پەڕەی Snapchat زۆر گەورەیە");out.toByteArray()}
                    return url to bytes
                }
            }finally{connection.disconnect();onConnection(null)}
        }
        throw IOException("گواستنەوەی لینکی Snapchat زۆرە")
    }
}
