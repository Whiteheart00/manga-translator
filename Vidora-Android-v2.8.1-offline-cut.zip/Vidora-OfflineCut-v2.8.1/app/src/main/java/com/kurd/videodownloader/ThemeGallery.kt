package com.kurd.videodownloader

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Real palette previews, without references to missing screenshot resources. */
object ThemeGallery {
    private fun dp(a:AppCompatActivity,n:Int)=(n*a.resources.displayMetrics.density).toInt()
    fun show(activity:AppCompatActivity) {
        val scheme=VisualTheme.scheme(activity)
        val content=LinearLayout(activity).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(activity,16),dp(activity,4),dp(activity,16),dp(activity,12))
        }
        val scroll=ScrollView(activity).apply {addView(content)}
        val dialog=AlertDialog.Builder(activity).setTitle("ڕەنگ و ڕووکاری ڤیدۆرا")
            .setView(scroll).setNegativeButton("داخستن",null).create()
        VisualTheme.presets.forEachIndexed { index,p ->
            val row=LinearLayout(activity).apply {
                gravity=Gravity.CENTER_VERTICAL
                minimumHeight=dp(activity,56)
                setPadding(dp(activity,8),dp(activity,7),dp(activity,8),dp(activity,7))
                isClickable=true;isFocusable=true
                contentDescription="ڕووکاری ${p.title}"
            }
            val swatch=TextView(activity).apply {
                text=if(VisualTheme.currentPalette(activity)==index)"✓" else ""
                gravity=Gravity.CENTER;setTextColor(Color.WHITE);textSize=22f
                background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(p.first,p.second,p.third)).apply {
                    cornerRadius=dp(activity,13).toFloat();setStroke(dp(activity,1),Color.LTGRAY)
                }
            }
            row.addView(swatch,LinearLayout.LayoutParams(dp(activity,82),dp(activity,40)))
            row.addView(TextView(activity).apply {
                text=p.title;setTextColor(scheme.text);textSize=15f;gravity=Gravity.END or Gravity.CENTER_VERTICAL
            },LinearLayout.LayoutParams(0,-1,1f))
            row.setOnClickListener {
                VisualTheme.changePalette(activity,index)
                VisualTheme.apply(activity)
                dialog.dismiss()
            }
            content.addView(row)
        }
        dialog.show()
    }
}
