package com.kurd.videodownloader

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

/** Only read the authoritative downloaded record. The original URI is never opened for writing. */
internal object LocalCut {
    data class Source(val record:JSONObject,val uri:Uri,val audio:Boolean)
    data class Result(val media:PublishedMedia,val record:JSONObject,val durationMs:Long,val startMs:Long,val endMs:Long)
    fun source(c:Context,id:String):Source {
        require(id.matches(Regex("[a-f0-9-]{36}"))){"فایلە دابەزێنراوەکە دیار نییە"}
        val record=NativeHistory.find(c,id)?:throw IOException("فایلەکە لە دابەزێنراوەکان نییە")
        record.optString("url").takeIf{it.startsWith("http")}?.let{SourceSafety.check(c,it)}
        val mime=record.optString("mime")
        val format=record.optString("format").uppercase(java.util.Locale.ROOT)
        val audio=mime.startsWith("audio/")||mime.isBlank()&&format in setOf("MP3","M4A","AAC","WAV","OGG","OPUS","FLAC")
        require(audio||mime.startsWith("video/")||mime.isBlank()&&format in setOf("MP4","MKV","WEBM","MOV","M4V","AVI","FLV")){"ئەم فایلە ڤیدیۆ یان دەنگ نییە"}
        val uri=Uri.parse(record.getString("uri"))
        require(uri.scheme=="content"&&uri.userInfo==null&&uri.query==null&&uri.fragment==null){"تەنها فایلە دابەزێنراوە ناوخۆییەکان دەبڕدرێن"}
        if(uri.authority=="media"){
            val parts=uri.pathSegments
            require(parts.size==3&&parts[1]=="downloads"&&parts[2].matches(Regex("[0-9]+"))){"ناونیشانی فایلە دابەزێنراوەکە دروست نییە"}
        }else{
            require(uri.authority==c.packageName+".files"){"فایلەکە هی ئەم ئەپە نییە"}
            @Suppress("DEPRECATION") val root=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).canonicalFile
            val file=File(record.getString("path")).canonicalFile
            require(file.path.startsWith(root.path+File.separator)&&file.isFile){"فایلەکە لە Downloads نییە"}
            require(androidx.core.content.FileProvider.getUriForFile(c,c.packageName+".files",file)==uri){"ناونیشانی فایل و تۆمارەکە ناگونجێن"}
        }
        return Source(JSONObject(record.toString()),uri,audio)
    }
    fun times(start:Double,end:Double,duration:Long):Pair<Long,Long>{
        require(listOf(start,end).all{it.isFinite()&&it>=0&&it<=31_536_000_000L&&it==kotlin.math.floor(it)}){"کاتەکانی بڕین دروست نین"}
        val a=start.toLong();val b=end.toLong();ClipSelection.bounds(a,b,duration);return a to b
    }
    private fun duration(file:File):Long {
        val probe=MediaMetadataRetriever()
        try{probe.setDataSource(file.absolutePath);return probe.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0}
        finally{probe.release()}
    }
    fun remember(c:Context,id:String,result:Result):JSONObject {
        require(result.record.getString("id")==id)
        val row=NativeHistory.add(c,result.media,result.record.optString("url"),result.record.optString("quality","پارچە"))
        NativeHistory.change(c,row.getString("id")){it.put("sourceRecordId",id).put("clipStartMs",result.startMs).put("clipEndMs",result.endMs).put("sourceDurationMs",result.durationMs)}
        return NativeHistory.find(c,row.getString("id"))?:throw IOException("تۆمارکردنی پارچەکە سەرکەوتوو نەبوو")
    }
    fun run(c:Context,id:String,start:Long,end:Long,cancelled:()->Boolean,onProcess:(Process?)->Unit,onProgress:(Int)->Unit,
            durationOf:(File)->Long=::duration,
            render:(File,ClipSelection,Boolean)->File={file,clip,audio->MediaClipper.run(c,file,clip,audio,320,cancelled,onProcess,onProgress)}):Result {
        ClipSelection.bounds(start,end,31_536_000_000L)
        val source=source(c,id)
        val folder=File(c.cacheDir,"local-cuts/${UUID.randomUUID()}").apply{check(mkdirs())}
        try{
            val title=source.record.optString("title","Vidora").map{if(it<' '||it in "/\\:*?\"<>|")'_' else it}.joinToString("").take(45).ifBlank{"Vidora"}
            val ext=source.record.optString("name").substringAfterLast('.').lowercase(java.util.Locale.ROOT).takeIf{it.matches(Regex("[a-z0-9]{1,8}"))}?:if(source.audio)"mp3" else "mp4"
            val input=File(folder,"$title.$ext")
            c.contentResolver.openInputStream(source.uri)?.use{original->input.outputStream().use{copy->
                val buffer=ByteArray(65536)
                while(true){if(cancelled())throw IOException("بڕین هەڵوەشایەوە؛ ڕەسەنەکە ماوە");val n=original.read(buffer);if(n<0)break;copy.write(buffer,0,n)}
            }}?:throw IOException("فایلە ڕەسەنەکە نەخوێندرایەوە")
            if(cancelled())throw IOException("بڕین هەڵوەشایەوە؛ ڕەسەنەکە ماوە")
            val length=durationOf(input)
            // Decoders can round a container endpoint a few milliseconds differently.
            val actualEnd=if(end>length&&end-length<=250)length else end
            val actualStart=if(actualEnd!=end&&actualEnd-start<1000)maxOf(0,actualEnd-1000)else start
            ClipSelection.bounds(actualStart,actualEnd,length)
            val clip=ClipSelection("record:$id",actualStart,actualEnd,length)
            val output=render(input,clip,source.audio)
            require(output.canonicalPath.startsWith(folder.canonicalPath+File.separator)&&output.canonicalFile!=input.canonicalFile){"تەنها پارچەی نوێ پاشەکەوت دەکرێت"}
            if(cancelled())throw IOException("بڕین هەڵوەشایەوە؛ ڕەسەنەکە ماوە")
            // StoragePublisher allocates a new row/file; the original and its bookmark stay intact.
            val media=StoragePublisher.publish(c,output,source.audio,cancelled)
            return Result(media,source.record,length,actualStart,actualEnd)
        }finally{folder.deleteRecursively()}
    }
}
