package com.kurd.videodownloader

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.datasource.*
import androidx.media3.exoplayer.drm.DrmSessionManagerProvider
import androidx.media3.exoplayer.source.*
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import java.io.IOException

/** Resolve only app-owned IDs; keep network headers out of intents and the WebView. */
internal class PlaybackSources(private val context:Context,private val local:Map<String,Uri> = emptyMap()):MediaSource.Factory {
    private val defaults=DefaultMediaSourceFactory(context)
    override fun setDrmSessionManagerProvider(value:DrmSessionManagerProvider):MediaSource.Factory {defaults.setDrmSessionManagerProvider(value);return this}
    override fun setLoadErrorHandlingPolicy(value:LoadErrorHandlingPolicy):MediaSource.Factory {defaults.setLoadErrorHandlingPolicy(value);return this}
    override fun getSupportedTypes()=defaults.supportedTypes
    override fun createMediaSource(item:MediaItem):MediaSource = try {
        val streams=when {
            item.mediaId.startsWith("local:")->listOf(StreamSpec((local[item.mediaId]?:throw SafetyException("فایلەکە ڕێگەپێنەدراوە")).toString(),emptyMap(),""))
            item.mediaId.startsWith("record:")-> {
                val record=NativeHistory.find(context,item.mediaId.removePrefix("record:"))?:throw IOException("فایلەکە نەدۆزرایەوە")
                val original=record.optString("url");if(original.startsWith("http"))SourceSafety.check(context,original)
                listOf(StreamSpec(record.getString("uri"),emptyMap(),""))
            }
            item.mediaId.startsWith("preview:")-> {
                val preview=MediaProbe.find(item.mediaId.removePrefix("preview:"))?:throw IOException("پێشبینینەکە بەسەرچووە؛ دووبارە لینکەکە دابنێ")
                SourceSafety.check(context,preview.source);preview.streams
            }
            else->throw SafetyException("تەنها فایل و پێشبینینی ڤیدۆرا ڕێگەپێدراون")
        }
        require(streams.isNotEmpty()){"سەرەتا فایلەکە دابەزێنە بۆ بینین"}
        val sources=streams.map { spec ->
            val media=MediaItem.Builder().setUri(spec.url).setMediaId(item.mediaId).setMediaMetadata(item.mediaMetadata)
            if(spec.protocol.contains("m3u8"))media.setMimeType(MimeTypes.APPLICATION_M3U8)
            if(spec.protocol=="dash"||Uri.parse(spec.url).path.orEmpty().endsWith(".mpd"))media.setMimeType(MimeTypes.APPLICATION_MPD)
            DefaultMediaSourceFactory(safeFactory(spec.headers)).createMediaSource(media.build())
        }
        if(sources.size==1)sources.first()else MergingMediaSource(*sources.toTypedArray())
    }catch(error:Exception){
        DownloadDiagnostics.record(context,"playback_source_rejected",error)
        // Deliver a normal player error on the playback thread, never an uncaught factory exception.
        ProgressiveMediaSource.Factory(DataSource.Factory {object:DataSource {
            override fun addTransferListener(listener:TransferListener){}
            override fun open(spec:DataSpec):Long=throw IOException(error.localizedMessage,error)
            override fun read(buffer:ByteArray,offset:Int,length:Int):Int=throw IOException(error.localizedMessage,error)
            override fun getUri():Uri?=null
            override fun close(){}
        }}).createMediaSource(MediaItem.Builder().setMediaId(item.mediaId).setUri("file:///vidora/rejected.mp4").build())
    }
    private fun safeFactory(headers:Map<String,String>):DataSource.Factory {
        val http=DefaultHttpDataSource.Factory().setDefaultRequestProperties(headers).setAllowCrossProtocolRedirects(false)
        val factory=DefaultDataSource.Factory(context,http)
        return DataSource.Factory{object:DataSource{
            val delegate=factory.createDataSource()
            override fun addTransferListener(listener:TransferListener)=delegate.addTransferListener(listener)
            override fun open(spec:DataSpec):Long {
                if(spec.uri.scheme in listOf("http","https"))SourceSafety.check(context,spec.uri.toString())
                try{val size=delegate.open(spec);delegate.uri?.let{if(it.scheme in listOf("http","https"))SourceSafety.check(context,it.toString())};return size}
                catch(error:Exception){delegate.close();throw error}
            }
            override fun read(buffer:ByteArray,offset:Int,length:Int)=delegate.read(buffer,offset,length)
            override fun getUri():Uri?=delegate.uri
            override fun getResponseHeaders()=delegate.responseHeaders
            override fun close()=delegate.close()
        }}
    }
}
