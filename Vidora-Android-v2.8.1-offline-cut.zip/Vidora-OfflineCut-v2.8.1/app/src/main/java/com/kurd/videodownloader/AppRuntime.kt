package com.kurd.videodownloader

import android.app.Activity
import java.util.Collections
import java.util.WeakHashMap

/** Called explicitly from both app activities; only downloads may outlive visible UI. */
internal object AppRuntime {
    private val screens=Collections.newSetFromMap(WeakHashMap<Activity,Boolean>())
    @Synchronized fun visible()=screens.isNotEmpty()
    @Synchronized fun started(activity:Activity){screens.add(activity);try{when(activity){is MainActivity->activity.browser.resumeTimers();is PlayerActivity->activity.browser.resumeTimers()}}catch(_:UninitializedPropertyAccessException){}}
    @Synchronized fun stopped(activity:Activity){screens.remove(activity)
        if(screens.isEmpty()&&!activity.isChangingConfigurations){
            try{when(activity){is MainActivity->activity.browser.pauseTimers();is PlayerActivity->activity.browser.pauseTimers()}}catch(_:UninitializedPropertyAccessException){}
            if(DownloadState.running&&DownloadState.action!="download")DownloadService.current?.cancelWhenHidden()
        }
    }
}
