package com.kurd.videodownloader

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import org.json.JSONObject
import java.security.MessageDigest

internal object SecurityGate {
    @Volatile private var verified=false
    fun sha(bytes:ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it.toInt()and 255)}
    fun trustedSigner(signatures:List<ByteArray>,expected:String)=expected.length==64&&signatures.size==1&&sha(signatures[0])==expected
    fun requireDigest(bytes:ByteArray,expected:String){check(expected.length==64&&sha(bytes)==expected){"Integrity check failed"}}
    @Synchronized fun verify(c:Context){
        if(verified)return
        if(!BuildConfig.DEBUG){
            check(BuildConfig.TRUSTED_CERT_SHA256.length==64){"Release certificate pin missing"}
            @Suppress("DEPRECATION") val signatures=if(Build.VERSION.SDK_INT>=28)c.packageManager.getPackageInfo(c.packageName,PackageManager.GET_SIGNING_CERTIFICATES).signingInfo!!.apkContentsSigners
                else c.packageManager.getPackageInfo(c.packageName,PackageManager.GET_SIGNATURES).signatures!!
            check(trustedSigner(signatures.map{it.toByteArray()},BuildConfig.TRUSTED_CERT_SHA256)){"Untrusted signer"}
            val manifest=c.assets.open("security/asset-hashes.json").use{it.readBytes()};requireDigest(manifest,BuildConfig.ASSET_MANIFEST_SHA256)
            val entries=JSONObject(String(manifest,Charsets.UTF_8))
            entries.keys().forEach{name->check(!name.contains("..")&&!name.startsWith('/'));c.assets.open(name).use{requireDigest(it.readBytes(),entries.getString(name))}}
        }
        SecureStore.validate(c)
        PrivateCacheCleanup.run(c)
        verified=true
    }
    fun admit(activity:Activity):Boolean=try{verify(activity);true}catch(_:Exception){
        val box=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(32,64,32,32);setBackgroundColor(0xff061525.toInt())}
        box.addView(TextView(activity).apply{text="وەشانی ئەپ یان پاراستنی داتا پشتڕاست نەکرایەوە. فایلەکانت نەسڕاونەتەوە. وەشانی ڕەسەن بە هەمان واژۆ دامەزرێنە؛ ئەگەر هەر ماوە، پەیوەندی بە خاوەنی ئەپ بکە.";textSize=19f;setTextColor(-1)})
        box.addView(Button(activity).apply{text="داخستن";setOnClickListener{activity.finish()}});activity.setContentView(box);false
    }
}
