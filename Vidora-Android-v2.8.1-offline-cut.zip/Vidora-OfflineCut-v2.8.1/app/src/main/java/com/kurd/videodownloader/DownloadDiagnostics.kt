package com.kurd.videodownloader

import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local, encrypted, bounded structural events only. Exception messages never enter storage. */
internal object DownloadDiagnostics {
    private const val LOG="download-diagnostics.txt"
    private fun read(c:Context):String=try{val file=File(c.filesDir,LOG);if(file.isFile&&file.readText().startsWith("vgcm1:"))SecretFiles.read(file)else ""}catch(_:Exception){""}
    @Synchronized fun record(context:Context,stage:String,error:Throwable?=null){try{
        val safeStage=stage.takeIf{it.matches(Regex("[A-Za-z0-9_-]{1,80}"))}?:"event"
        val stamp=SimpleDateFormat("HH:mm:ss",Locale.US).format(Date())
        val type=error?.javaClass?.simpleName.orEmpty()
        val frames=error?.stackTrace?.filter{it.className.startsWith("com.kurd.videodownloader.")}?.take(10)?.joinToString("\n"){"${it.className}.${it.methodName}:${it.lineNumber}"}.orEmpty()
        val text=(read(context)+"$stamp [$safeStage] $type\n$frames\n").takeLast(32000)
        SecretFiles.write(File(context.filesDir,LOG),text)
    }catch(_:Exception){}}
    fun report(context:Context):String {
        val version=try{context.packageManager.getPackageInfo(context.packageName,0).versionName}catch(_:Exception){"unknown"}
        return "Vidora $version\nAndroid API ${Build.VERSION.SDK_INT}\nLocal structural diagnostics\n\n"+read(context)
    }
    fun install(context:Context){
        // Legacy logs can contain identifiers; do not import their free-form content.
        try{val file=File(context.filesDir,LOG);if(file.isFile&&!file.readText().startsWith("vgcm1:"))file.delete()}catch(_:Exception){}
        val previous=Thread.getDefaultUncaughtExceptionHandler()?:return
        if(previous !is Reporter)Thread.setDefaultUncaughtExceptionHandler(Reporter(context.applicationContext,previous))
    }
    private class Reporter(val context:Context,val next:Thread.UncaughtExceptionHandler):Thread.UncaughtExceptionHandler{
        override fun uncaughtException(thread:Thread,error:Throwable){record(context,"uncaught",error);val redacted=RuntimeException("Vidora stopped: ${error.javaClass.simpleName}").apply{stackTrace=error.stackTrace.filter{it.className.startsWith("com.kurd.videodownloader.")}.toTypedArray()};next.uncaughtException(thread,redacted)}
    }
}
class VidoraApplication:Application(){override fun onCreate(){super.onCreate();DownloadDiagnostics.install(this)}}
