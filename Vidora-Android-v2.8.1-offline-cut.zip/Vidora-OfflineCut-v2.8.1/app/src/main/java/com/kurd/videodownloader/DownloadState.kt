package com.kurd.videodownloader

object DownloadState {
    @Volatile var phase="idle"
    @Volatile var running=false
    @Volatile var progress=0
    @Volatile var message="ئامادەیە بۆ دابەزاندن"
    @Volatile var action="idle"
    @Volatile var status="idle"
    @Volatile var url=""
    @Volatile var format="MP4"
    @Volatile var quality="1080p"
    @Volatile var title=""
    @Volatile var recordId=""
}
