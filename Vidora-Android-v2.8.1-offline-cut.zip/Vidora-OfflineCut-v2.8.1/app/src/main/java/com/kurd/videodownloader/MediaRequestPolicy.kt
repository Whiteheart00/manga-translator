package com.kurd.videodownloader

import java.net.URI
import java.util.Locale

/** Recognition improves UI/format choices; it never acts as a downloader domain allowlist. */
internal object MediaRequestPolicy {
    data class Site(val id:String,val title:String,val domains:List<String>,val audioOnly:Boolean=false)
    val sites=listOf(
        Site("youtube","YouTube",listOf("youtube.com","youtu.be","youtube-nocookie.com")),
        Site("pinterest","Pinterest",listOf("pinterest.com","pinterest.co.uk","pinterest.fr","pinterest.de","pinterest.ca","pinterest.com.au","pin.it")),
        Site("tiktok","TikTok",listOf("tiktok.com","tiktokv.com")),
        Site("instagram","Instagram",listOf("instagram.com")),
        Site("facebook","Facebook",listOf("facebook.com","fb.watch","fb.com")),
        Site("x","X",listOf("x.com","twitter.com","t.co")),
        Site("snapchat","Snapchat",listOf("snapchat.com")),
        Site("reddit","Reddit",listOf("reddit.com","redd.it","v.redd.it")),
        Site("vimeo","Vimeo",listOf("vimeo.com")),
        Site("dailymotion","Dailymotion",listOf("dailymotion.com","dai.ly")),
        Site("soundcloud","SoundCloud",listOf("soundcloud.com","snd.sc"),true)
    )
    fun identify(url:String):Site? {
        val host=try{URI(url).host?.lowercase(Locale.ROOT)?.removeSuffix(".")?:return null}catch(_:Exception){return null}
        return sites.firstOrNull{site->site.domains.any{host==it||host.endsWith(".$it")}}
    }
    fun videoSelector(url:String,quality:Int):String {
        // Unknown height is common for direct media and some social-site extractors.
        val height=if(quality in listOf(480,720,1080))"[height<=?$quality]" else ""
        // Reject only explicit watermark/unplayable metadata; never fall back to a known watermarked stream.
        val clean=if(identify(url)?.id=="tiktok")"[format_note!*=?watermarked][format_note!*=?UNPLAYABLE]" else ""
        val filter=height+clean
        // The final video-only branch preserves silent Pinterest/GIF-style clips.
        return "bv*$filter[ext=mp4]+ba[ext=m4a]/b$filter[ext=mp4]/bv*$filter+ba/b$filter/bv*$filter"
    }
}
