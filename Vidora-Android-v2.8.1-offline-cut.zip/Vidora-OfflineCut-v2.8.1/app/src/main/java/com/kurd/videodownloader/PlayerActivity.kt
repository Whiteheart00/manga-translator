package com.kurd.videodownloader

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.ContentValues
import android.content.pm.ActivityInfo
import android.graphics.*
import android.net.Uri
import android.os.*
import android.media.AudioManager
import androidx.media3.exoplayer.DefaultRenderersFactory
import android.provider.MediaStore
import android.view.*
import android.webkit.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.*
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.*
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors

/** User-supplied HTML controls over a native decoder. No playback survives leaving this screen. */
class PlayerActivity:AppCompatActivity(){
    internal lateinit var browser:WebView
    private lateinit var surface:PlayerView
    private lateinit var frame:FrameLayout
    private var player:ExoPlayer?=null
    private var ready=false
    private var visible=false
    private var full=false
    private var normalOrientation=ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var normalWasPortrait=true
    private var desiredVolume=.85f
    private var captionsEnabled=false
    private var audioOnly=false
    private var renderedFirstFrame=false
    private data class CutTask(val id:String,val start:Long,val end:Long,val duration:Long)
    private var pendingCut:CutTask?=null
    private val cutPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){granted->
        val job=pendingCut;pendingCut=null
        if(job!=null){if(granted)beginCut(job)else{notice("مۆڵەتی پاشەکەوتکردن پێویستە");snapshot()}}
    }
    private var pendingDownload:Pair<String,Boolean>?=null
    private val downloadPermissions=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){result->
        val job=pendingDownload;pendingDownload=null
        if(job!=null){if(Build.VERSION.SDK_INT<=28&&result[Manifest.permission.WRITE_EXTERNAL_STORAGE]==false)notice("مۆڵەتی پاشەکەوتکردن پێویستە")else beginDownload(job.first,job.second)}
    }
    private var current=""
    private var position=0L
    private var bounds=doubleArrayOf(0.0,0.0,1.0,1.0)
    private var aspectMode="fit"
    private val handler=Handler(Looper.getMainLooper())
    private var io=Executors.newSingleThreadExecutor()
    private val items=linkedMapOf<String,MediaItem>()
    private val local=linkedMapOf<String,Uri>()
    private val queue=JSONArray()
    private val ticker=object:Runnable{override fun run(){if(!visible)return;snapshot();handler.postDelayed(this,400)}}
    private val picker=registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->uris.forEach{uri->
        try{val mime=contentResolver.getType(uri).orEmpty();require(mime.startsWith("audio/")||mime.startsWith("video/"))
            val title=contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())it.getString(0)else "ڤیدۆرا"}?:"ڤیدۆرا"
            val id="local:"+UUID.randomUUID();local[id]=uri;items[id]=MediaItem.Builder().setMediaId(id).setUri(uri).build()
            js("window.loadMedia(${JSONObject.quote(id)},${JSONObject.quote(title)},'',${mime.startsWith("audio/")},'')")
        }catch(_:Exception){notice("ئەم فایلە ناتوانرێت بکرێتەوە")}
    }}
    private val subtitle=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)io.execute{try{
        val text=contentResolver.openInputStream(uri)?.use{source->val bytes=ByteArray(1024*1024+1);var count=0;while(count<bytes.size){val n=source.read(bytes,count,bytes.size-count);if(n<0)break;count+=n};require(count<=1024*1024);String(bytes,0,count,Charsets.UTF_8)}?:error("empty")
        runOnUiThread{js("window.loadSubtitleText(${JSONObject.quote(text)})")}
    }catch(_:Exception){runOnUiThread{notice("ژێرنووس نەخوێندرایەوە")}}}}
    private val imagePermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){granted->if(granted)capture()}
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState);if(!SecurityGate.admit(this))return;position=savedInstanceState?.getLong("position")?:0L;current=savedInstanceState?.getString("current").orEmpty()
        volumeControlStream=AudioManager.STREAM_MUSIC
        val settings=try{JSONObject(securePreferences("player_ui_options").getString("options","{}")?:"{}")}catch(_:Exception){JSONObject()}
        desiredVolume=(settings.optDouble("volume",85.0).takeIf{it.isFinite()&&it>0}?:85.0).coerceIn(1.0,100.0).toFloat()/100f
        WindowCompat.setDecorFitsSystemWindows(window,false)
        frame=FrameLayout(this).apply{setBackgroundColor(Color.rgb(7,9,14))};surface=layoutInflater.inflate(R.layout.player_surface,frame,false)as PlayerView;surface.subtitleView?.visibility=View.GONE;frame.addView(surface)
        browser=WebView(this).apply{setBackgroundColor(Color.TRANSPARENT)};frame.addView(browser,FrameLayout.LayoutParams(-1,-1));setContentView(frame)
        ViewCompat.setOnApplyWindowInsetsListener(frame){v,insets->val b=insets.getInsets(WindowInsetsCompat.Type.systemBars());v.setPadding(b.left,b.top,b.right,b.bottom);insets};ViewCompat.requestApplyInsets(frame)
        val loader=WebViewAssetLoader.Builder().addPathHandler("/assets/",WebViewAssetLoader.AssetsPathHandler(this)).build()
        browser.settings.apply{javaScriptEnabled=true;domStorageEnabled=true;allowFileAccess=false;allowContentAccess=false;blockNetworkLoads=true;mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;mediaPlaybackRequiresUserGesture=true}
        browser.addJavascriptInterface(Controls(),"VidoraPlayerNative")
        browser.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(v:WebView?,r:WebResourceRequest)=true
            override fun shouldInterceptRequest(v:WebView?,r:WebResourceRequest):WebResourceResponse{
                val u=r.url;return if(u.scheme=="https"&&u.host=="appassets.androidplatform.net"&&u.path.orEmpty().startsWith("/assets/"))loader.shouldInterceptRequest(u)?:blocked()else blocked()
            }
        }
        try{val record=intent.getStringExtra("recordId");val preview=intent.getStringExtra("previewToken")
            val list=if(record!=null)PlaybackQueue.records(this,record).first else if(preview!=null)listOf(PlaybackQueue.preview(preview))else emptyList()
            for(item in list){items[item.mediaId]=item;val audio=item.mediaMetadata.mediaType==MediaMetadata.MEDIA_TYPE_MUSIC
                queue.put(JSONObject().put("id",item.mediaId).put("title",item.mediaMetadata.title).put("isAudio",audio))}
            if(current.isBlank())current=if(record!=null)"record:$record" else list.firstOrNull()?.mediaId.orEmpty()
        }catch(error:Exception){notice(error.localizedMessage?:"فایلەکە نەدۆزرایەوە")}
        browser.loadUrl("https://appassets.androidplatform.net/assets/player/index.html")
        onBackPressedDispatcher.addCallback(this,object:OnBackPressedCallback(true){override fun handleOnBackPressed(){browser.evaluateJavascript("window.nativeBack?window.nativeBack():false"){handled->if(handled!="true"){if(full)fullscreen()else finish()}}}})
    }
    private fun blocked()=WebResourceResponse("text/plain","UTF-8",ByteArrayInputStream(ByteArray(0)))
    private fun createPlayer(){if(player!=null)return
        player=ExoPlayer.Builder(this,DefaultRenderersFactory(this).setEnableDecoderFallback(true)).build().also{p->
            surface.player=p
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),true)
            p.setHandleAudioBecomingNoisy(true);p.volume=desiredVolume
            p.trackSelectionParameters=p.trackSelectionParameters.buildUpon().setPreferredTextLanguages("ku","en")
                .setSelectUndeterminedTextLanguage(true).setTrackTypeDisabled(C.TRACK_TYPE_AUDIO,false)
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT,!captionsEnabled).setTrackTypeDisabled(C.TRACK_TYPE_VIDEO,audioOnly).build()
            p.addListener(object:Player.Listener{override fun onRenderedFirstFrame(){renderedFirstFrame=true;snapshot()}
                override fun onPlaybackStateChanged(state:Int){snapshot()}
                override fun onIsLoadingChanged(loading:Boolean){snapshot()}
                override fun onPlayerError(error:PlaybackException){DownloadDiagnostics.record(this@PlayerActivity,"player_error",error);snapshot(JSONObject().put("code",3))}})
        }
    }
    private fun open(id:String){if(!visible)return;val item=items[id]?:return
        try{savePosition();renderedFirstFrame=false;current=id;position=PlaybackQueue.position(this,id);createPlayer();player!!.volume=desiredVolume;player!!.setMediaSource(PlaybackSources(applicationContext,local).createMediaSource(item));player!!.seekTo(position);player!!.prepare();snapshot()}
        catch(error:Exception){notice(error.localizedMessage?:"پەخش نەکرا")}
    }
    private fun snapshot(error:JSONObject?=null){val p=player?:return
        val cues=p.currentCues.cues.mapNotNull{it.text?.toString()}.joinToString("\n")
        val waitingFrame=p.playbackState==Player.STATE_READY&&!audioOnly&&p.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)&&!renderedFirstFrame
        val loading=error==null&&p.playerError==null&&(p.playbackState==Player.STATE_BUFFERING||p.playbackState==Player.STATE_IDLE&&current.isNotBlank()||waitingFrame)
        val data=JSONObject().put("fullscreen",full).put("loading",loading).put("id",current).put("duration",if(p.duration>0)p.duration/1000.0 else 0).put("currentTime",p.currentPosition.coerceAtLeast(0)/1000.0)
            .put("paused",!p.playWhenReady).put("ended",p.playbackState==Player.STATE_ENDED).put("seeking",false).put("buffer",p.bufferedPosition.coerceAtLeast(0)/1000.0)
            .put("videoWidth",p.videoSize.width).put("videoHeight",p.videoSize.height).put("readyState",if(p.playbackState==Player.STATE_READY)4 else 1).put("embedded",cues).put("error",error?:JSONObject.NULL)
            .put("canDownload",current.startsWith("preview:")&&MediaProbe.find(current.removePrefix("preview:"))?.downloadInfo?.isFile==true)
            .put("downloadCurrent",current.startsWith("preview:")&&MediaProbe.find(current.removePrefix("preview:"))?.source==DownloadState.url&&DownloadState.action=="download")
            .put("audioOnly",current.startsWith("preview:")&&MediaProbe.find(current.removePrefix("preview:"))?.audioOnly==true)
            .put("canCut",current.startsWith("record:")&&p.duration in 1000..31_536_000_000L)
            .put("cutDurationMs",p.duration.coerceAtLeast(0)).put("cutPending",pendingCut!=null)
            .put("taskAction",DownloadState.action).put("taskRecordId",DownloadState.recordId)
            .put("saved",current.startsWith("record:")).put("downloadPhase",DownloadState.phase).put("downloadRunning",DownloadState.running).put("downloadProgress",DownloadState.progress)
            .put("downloadMessage",DownloadState.message).put("downloadStatus",DownloadState.status).put("downloadSource",DownloadState.url)
        js("window.nativePlayerSnapshot&&window.nativePlayerSnapshot($data)")
    }
    private fun js(code:String){if(ready&&!isDestroyed)browser.evaluateJavascript(code.replace("\u2028","\\u2028").replace("\u2029","\\u2029"),null)}
    private fun savePosition(){player?.let{p->position=p.currentPosition.coerceAtLeast(0);PlaybackQueue.savePosition(this,current,if(p.playbackState==Player.STATE_ENDED)0 else position)}}
    internal fun releasePlayback(){handler.removeCallbacks(ticker);savePosition();player?.let{it.pause();surface.player=null;it.release()};player=null}
    override fun onStart(){if(io.isShutdown)io=Executors.newSingleThreadExecutor();super.onStart();if(!::browser.isInitialized)return;AppRuntime.started(this);visible=true;browser.onResume();browser.resumeTimers();createPlayer();if(ready&&current.isNotBlank()){open(current);snapshot();js("window.nativeResume&&window.nativeResume()") };handler.post(ticker)}
    override fun onPause(){player?.pause();snapshot();js("window.nativeSuspend&&window.nativeSuspend()");super.onPause()}
    override fun onStop(){visible=false;releasePlayback();io.shutdownNow();if(::browser.isInitialized)browser.onPause();super.onStop();AppRuntime.stopped(this)}
    override fun onSaveInstanceState(outState:Bundle){savePosition();outState.putString("current",current);outState.putLong("position",position);super.onSaveInstanceState(outState)}
    override fun onDestroy(){ready=false;releasePlayback();io.shutdownNow();if(::browser.isInitialized){browser.removeJavascriptInterface("VidoraPlayerNative");browser.stopLoading();browser.destroy()};super.onDestroy()}
    private fun fullscreen(){
        if(!full){normalOrientation=requestedOrientation;normalWasPortrait=resources.configuration.orientation!=android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        full=!full
        requestedOrientation=if(full)ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else if(normalWasPortrait)ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else normalOrientation
        WindowCompat.getInsetsController(window,browser).apply{systemBarsBehavior=WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE;if(full)hide(WindowInsetsCompat.Type.systemBars())else show(WindowInsetsCompat.Type.systemBars())}
        js("window.nativeFullscreenState&&window.nativeFullscreenState($full)")
        snapshot()
    }
    private fun applyBounds(){
        val d=resources.displayMetrics.density;var x=bounds[0];var y=bounds[1];var w=bounds[2];var h=bounds[3]
        val ratio=when(aspectMode){"ratio169"->16.0/9;"ratio43"->4.0/3;else->0.0}
        if(ratio>0){val width=minOf(w,h*ratio);val height=width/ratio;x+=(w-width)/2;y+=(h-height)/2;w=width;h=height}
        surface.layoutParams=FrameLayout.LayoutParams((w*d).toInt(),(h*d).toInt()).apply{leftMargin=(x*d).toInt();topMargin=(y*d).toInt()}
        surface.resizeMode=when(aspectMode){"fill","ratio169","ratio43"->AspectRatioFrameLayout.RESIZE_MODE_FILL;"zoom"->AspectRatioFrameLayout.RESIZE_MODE_ZOOM;else->AspectRatioFrameLayout.RESIZE_MODE_FIT}
    }
    private fun notice(text:String)=Toast.makeText(this,text,Toast.LENGTH_SHORT).show()
    private fun requestDownload(id:String,audio:Boolean){
        if(id!=current||!id.startsWith("preview:")){notice("ئەم فایلە ناوخۆییە یان پێشتر پاشەکەوت کراوە");return}
        if(DownloadState.running||pendingDownload!=null){notice("کردارێکی تر بەردەوامە؛ چاوەڕێ بکە یان هەڵیوەشێنەوە");return}
        val media=MediaProbe.find(id.removePrefix("preview:"))?:return notice("دووبارە لینکەکە بکەرەوە")
        if(media.audioOnly&&!audio){notice("ئەم سەرچاوەیە تەنها دەنگە؛ MP3 هەڵبژێرە");return}
        try{PlaybackDownload.media(this,media.token,media.source)}catch(error:Exception){notice(error.localizedMessage?:"لینکی پەخش بەسەرچووە");return}
        val needed=mutableListOf<String>()
        if(Build.VERSION.SDK_INT<=28&&ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)needed+=Manifest.permission.WRITE_EXTERNAL_STORAGE
        val prefs=securePreferences("vidora_permissions",0)
        if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED&&!prefs.getBoolean("notificationsAsked",false)){needed+=Manifest.permission.POST_NOTIFICATIONS;prefs.edit().putBoolean("notificationsAsked",true).apply()}
        if(needed.isEmpty())beginDownload(media.token,audio)else{pendingDownload=media.token to audio;downloadPermissions.launch(needed.toTypedArray())}
    }
    private fun beginDownload(token:String,audio:Boolean){
        if(DownloadState.running)return
        try{val media=MediaProbe.find(token)?:throw java.io.IOException("دووبارە پێشبینین بکەوە");PlaybackDownload.media(this,token,media.source)
            DownloadState.phase="preparing";DownloadState.running=true;DownloadState.action="download";DownloadState.status="running";DownloadState.progress=0;DownloadState.url=media.source
            DownloadState.format=if(audio)"MP3" else "MP4";DownloadState.quality="پەخش";DownloadState.title=media.title;DownloadState.message="داگرتن لە سەرچاوەی پەخش دەست پێ دەکات..."
            ContextCompat.startForegroundService(this,Intent(this,DownloadService::class.java).setAction(DownloadService.ACTION_START)
                .putExtra(DownloadService.EXTRA_URL,media.source).putExtra(DownloadService.EXTRA_PREVIEW_TOKEN,token).putExtra(DownloadService.EXTRA_AUDIO,audio).putExtra(DownloadService.EXTRA_QUALITY,0))
            snapshot();notice("داگرتن دەستی پێکرد؛ دەتوانیت چاوەڕێ بکەیت یان بگەڕێیتەوە")
        }catch(error:Exception){DownloadState.running=false;DownloadState.status="error";DownloadState.message=error.localizedMessage?:"داگرتن دەستی پێ نەکرد";notice(DownloadState.message);snapshot()}
    }
    private fun requestCut(id:String,start:Double,end:Double){
        try{
            require(visible&&id==current&&id.startsWith("record:")){"Cut تەنها بۆ فایلە دابەزێنراوەی ئێستا ڕێگەپێدراوە"}
            require(!DownloadState.running&&pendingDownload==null&&pendingCut==null){"کردارێکی تر بەردەوامە"}
            LocalCut.source(this,id.removePrefix("record:"))
            val duration=player?.duration?:0
            val times=LocalCut.times(start,end,duration);val job=CutTask(id,times.first,times.second,duration)
            player?.pause()
            if(Build.VERSION.SDK_INT<=28&&ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){pendingCut=job;cutPermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);snapshot()}
            else beginCut(job)
        }catch(error:Exception){notice(error.localizedMessage?:"بڕین دەست پێ نەکرد");snapshot()}
    }
    private fun beginCut(job:CutTask){
        if(!visible||job.id!=current||DownloadState.running){notice("فایلەکە گۆڕاوە یان کردارێکی تر بەردەوامە");snapshot();return}
        try{
            val source=LocalCut.source(this,job.id.removePrefix("record:"));ClipSelection.bounds(job.start,job.end,job.duration)
            DownloadState.action="cut";DownloadState.recordId=job.id.removePrefix("record:");DownloadState.url=source.record.optString("url")
            DownloadState.running=true;DownloadState.status="running";DownloadState.phase="preparing";DownloadState.progress=0
            DownloadState.title=source.record.optString("title");DownloadState.format=if(source.audio)"MP3" else "MP4";DownloadState.quality=source.record.optString("quality")
            DownloadState.message="ئامادەکردنی پارچەی نوێ؛ ڕەسەنەکە دەمێنێت..."
            ContextCompat.startForegroundService(this,Intent(this,DownloadService::class.java).setAction(DownloadService.ACTION_CUT)
                .putExtra(DownloadService.EXTRA_FILE_ID,DownloadState.recordId).putExtra(DownloadService.EXTRA_URL,DownloadState.url)
                .putExtra(DownloadService.EXTRA_AUDIO,source.audio).putExtra(DownloadService.EXTRA_CUT_START,job.start).putExtra(DownloadService.EXTRA_CUT_END,job.end))
        }catch(error:Exception){DownloadState.running=false;DownloadState.status="error";DownloadState.message=error.localizedMessage?:"بڕین دەست پێ نەکرد";notice(DownloadState.message)}
        snapshot()
    }
    private fun capture(){
        if(Build.VERSION.SDK_INT<=28&&ContextCompat.checkSelfPermission(this,android.Manifest.permission.WRITE_EXTERNAL_STORAGE)!=android.content.pm.PackageManager.PERMISSION_GRANTED){imagePermission.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);return}
        val bitmap=(surface.videoSurfaceView as? TextureView)?.bitmap?:return notice("ڤیدیۆ هێشتا ئامادە نییە")
        io.execute{try{val name="Vidora_${System.currentTimeMillis()}.png"
            if(Build.VERSION.SDK_INT>=29){val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,"image/png");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Vidora");put(MediaStore.Images.Media.IS_PENDING,1)}
                val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)?:error("insert")
                try{contentResolver.openOutputStream(uri)?.use{check(bitmap.compress(Bitmap.CompressFormat.PNG,100,it))}?:error("write");contentResolver.update(uri,ContentValues().apply{put(MediaStore.Images.Media.IS_PENDING,0)},null,null)}catch(e:Exception){contentResolver.delete(uri,null,null);throw e}
            }else{@Suppress("DEPRECATION") val folder=File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"Vidora").apply{mkdirs()};File(folder,name).outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}}
            runOnUiThread{notice("وێنەکە لە Pictures/Vidora پاشەکەوت کرا")}
        }catch(_:Exception){runOnUiThread{notice("وێنەکە پاشەکەوت نەکرا")}}finally{bitmap.recycle()}}
    }
    inner class Controls {
        @JavascriptInterface fun settings()=securePreferences("player_ui_options").getString("options","{}")?:"{}"
        @JavascriptInterface fun saveSettings(value:String){if(value.length<=8192)try{val json=JSONObject(value);securePreferences("player_ui_options").edit().putString("options",json.toString()).apply()}catch(_:Exception){}}

        @JavascriptInterface fun ready(){runOnUiThread{ready=true;val index=(0 until queue.length()).firstOrNull{queue.getJSONObject(it).optString("id")==current}?:0;js("window.nativePlaylist($queue,$index)");js("window.nativeFullscreenState&&window.nativeFullscreenState($full)")}}
        @JavascriptInterface fun open(id:String){runOnUiThread{this@PlayerActivity.open(id)}}
        @JavascriptInterface fun play(){runOnUiThread{if(visible){createPlayer();player?.play()}}}
        @JavascriptInterface fun pause(){runOnUiThread{player?.pause();snapshot()}}
        @JavascriptInterface fun seek(seconds:Double){runOnUiThread{if(seconds.isFinite())player?.seekTo((seconds.coerceAtLeast(0.0)*1000).toLong())}}
        @JavascriptInterface fun speed(value:Double){runOnUiThread{if(value.isFinite())player?.setPlaybackSpeed(value.toFloat().coerceIn(.25f,3f))}}
        @JavascriptInterface fun volume(value:Double){runOnUiThread{if(value.isFinite()){desiredVolume=value.toFloat().coerceIn(0f,1f);player?.volume=desiredVolume}}}
        @JavascriptInterface fun audioMode(audio:Boolean){runOnUiThread{
            if(audioOnly&&!audio)renderedFirstFrame=false;audioOnly=audio;surface.visibility=if(audio)View.INVISIBLE else View.VISIBLE
            player?.let{p->p.trackSelectionParameters=p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO,false).setTrackTypeDisabled(C.TRACK_TYPE_VIDEO,audio).build();p.volume=desiredVolume}
        }}
        @JavascriptInterface fun captions(enabled:Boolean){runOnUiThread{captionsEnabled=enabled;player?.let{p->p.trackSelectionParameters=p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT,!enabled).build()}}}
        @JavascriptInterface fun layout(x:Double,y:Double,w:Double,h:Double){runOnUiThread{if(listOf(x,y,w,h).all{it.isFinite()}&&w>0&&h>0){bounds=doubleArrayOf(x,y,w,h);applyBounds()}}}
        @JavascriptInterface fun aspect(mode:String){runOnUiThread{aspectMode=mode;applyBounds()}}
        @JavascriptInterface fun filters(contrast:Double,saturation:Double,warmth:Double){runOnUiThread{if(listOf(contrast,saturation,warmth).all{it.isFinite()}){val a=(contrast/100).toFloat().coerceIn(.5f,1.7f);val t=128*(1-a);val warm=(warmth/100).toFloat().coerceIn(0f,1f);val matrix=ColorMatrix().apply{setSaturation((saturation/100).toFloat().coerceIn(0f,2f));postConcat(ColorMatrix(floatArrayOf(a,0f,0f,0f,t,0f,a,0f,0f,t,0f,0f,a,0f,t,0f,0f,0f,1f,0f)));postConcat(ColorMatrix(floatArrayOf(1+.15f*warm,0f,0f,0f,0f,0f,1f,0f,0f,0f,0f,0f,1-.25f*warm,0f,0f,0f,0f,0f,1f,0f)))};surface.videoSurfaceView?.setLayerType(View.LAYER_TYPE_HARDWARE,Paint().apply{colorFilter=ColorMatrixColorFilter(matrix)})}}}
        @JavascriptInterface fun fullscreen(){runOnUiThread{this@PlayerActivity.fullscreen()}}
        @JavascriptInterface fun back(){runOnUiThread{if(full)fullscreen()else finish()}}
        @JavascriptInterface fun pickMedia(){runOnUiThread{picker.launch(arrayOf("video/*","audio/*"))}}
        @JavascriptInterface fun pickSubtitle(){runOnUiThread{subtitle.launch(arrayOf("text/*","application/octet-stream","application/x-subrip"))}}
        @JavascriptInterface fun download(id:String,format:String){runOnUiThread{if(format in listOf("MP4","MP3"))requestDownload(id,format=="MP3")}}
        @JavascriptInterface fun cancelDownload(){runOnUiThread{if(DownloadState.running&&DownloadState.action=="download"&&current.startsWith("preview:")&&MediaProbe.find(current.removePrefix("preview:"))?.source==DownloadState.url)DownloadService.current?.let{startService(Intent(this@PlayerActivity,DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))}}}
        @JavascriptInterface fun cut(id:String,startMs:Double,endMs:Double){runOnUiThread{requestCut(id,startMs,endMs)}}
        @JavascriptInterface fun cancelCut(id:String){runOnUiThread{
            if(DownloadState.running&&DownloadState.action=="cut"&&DownloadState.recordId==id.removePrefix("record:"))DownloadService.current?.let{startService(Intent(this@PlayerActivity,DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))}
        }}
        @JavascriptInterface fun capture(){runOnUiThread{this@PlayerActivity.capture()}}
    }
}
