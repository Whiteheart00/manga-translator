# JavaScript calls are discovered by annotation, not Kotlin call sites.
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-keepattributes Signature,*Annotation*,InnerClasses,EnclosingMethod
# yt-dlp metadata uses Jackson field/property reflection.
-keep class com.yausername.youtubedl_android.mapper.** { *; }
-keep class com.fasterxml.jackson.** { *; }
-dontwarn java.beans.**
# Jackson's optional desktop DOM serializer is unused by yt-dlp JSON metadata.
-dontwarn org.w3c.dom.bootstrap.DOMImplementationRegistry
